import copy
import random
import unittest
from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_degenerate(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[4, 4], [-3, -3]]), [])

    def test_touching_overlapping_and_nested(self):
        self.assertEqual(merge_ranges([[9, 12], [1, 5], [3, 4], [5, 9], [20, 21]]),
                         [[1, 12], [20, 21]])

    def test_negatives_and_arbitrary_precision(self):
        n = 10 ** 200
        self.assertEqual(merge_ranges([[-n, -n + 2], [-n + 2, 0], [n, n + 3]]),
                         [[-n, 0], [n, n + 3]])

    def test_preserves_input_and_does_not_alias(self):
        original = [[7, 9], [1, 3], [3, 8]]
        snapshot = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, snapshot)
        result[0][0] = -100
        self.assertEqual(original, snapshot)

    def test_tuple_pairs(self):
        self.assertEqual(merge_ranges([(2, 3), (1, 2)]), [[1, 3]])

    def test_invalid_pairs_and_bounds(self):
        bad_pairs = [None, 3, '12', {1: 2, 3: 4}, [], [1], [1, 2, 3],
                     [True, 4], [1, False], [1.0, 2], [1, '2'], [None, 2],
                     [3, 1], [False, False]]
        for pair in bad_pairs:
            with self.subTest(pair=pair), self.assertRaises(ValueError):
                merge_ranges([[0, 1], pair])

    def test_invalid_outer(self):
        for value in (None, 1, True, '12', {}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                merge_ranges(value)

    def test_random_coverage_and_canonical_form(self):
        rng = random.Random(31)
        for _ in range(200):
            intervals = [sorted([rng.randrange(-20, 21), rng.randrange(-20, 21)])
                         for _ in range(rng.randrange(30))]
            result = merge_ranges(intervals)
            expected = {x for start, end in intervals for x in range(start, end)}
            actual = {x for start, end in result for x in range(start, end)}
            self.assertEqual(actual, expected)
            self.assertTrue(all(start < end for start, end in result))
            self.assertTrue(all(a[1] < b[0] for a, b in zip(result, result[1:])))
            self.assertEqual(merge_ranges(result), result)


if __name__ == '__main__':
    unittest.main()
