# Goal contract - implement merge_ranges

Status: DRAFT

## Objective

Implement solution.merge_ranges for half-open integer intervals, preserving input and rejecting malformed pairs, booleans, noninteger bounds and reversed bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | Public examples and requirement-focused edge cases pass for validation, union, input preservation and arbitrary integers | check: `python3 -B public.py && python3 -B test_solution.py` | expected: exit=0

## Out of scope

No changes to TASK.md or public.py.

## Budget knobs

max_iterations=3 no_progress_limit=2 max_replans=2 check_timeout=20

## Approval

Approval mode: auto
approved: ef1ed8e5 2026-11-11 auto
