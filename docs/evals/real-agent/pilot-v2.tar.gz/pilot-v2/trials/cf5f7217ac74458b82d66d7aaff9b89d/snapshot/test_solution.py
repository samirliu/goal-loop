import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_touching(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[0, 0], [-2, -2]]), [])
        self.assertEqual(merge_ranges([[5, 8], [-3, 0], [0, 5]]), [[-3, 8]])

    def test_overlap_duplicates_gaps(self):
        intervals = [[8, 10], [1, 6], [2, 4], [1, 6], [12, 13], [3, 9]]
        original = copy.deepcopy(intervals)
        result = merge_ranges(intervals)
        self.assertEqual(result, [[1, 10], [12, 13]])
        self.assertEqual(intervals, original)
        result[0][0] = -100
        self.assertEqual(intervals, original)

    def test_large_integers(self):
        n = 10 ** 100
        self.assertEqual(merge_ranges([[n, n + 1], [-n, -n + 3],
                                       [n + 1, n + 2]]),
                         [[-n, -n + 3], [n, n + 2]])

    def test_invalid_bounds_and_shapes(self):
        invalid = [None, True, 4, '12', {0: 1, 1: 2}, [], [1], [1, 2, 3],
                   [True, 2], [0, False], [1.0, 2], [1, 2.0], [None, 2],
                   ['1', 2], [1, '2'], [3, 1], [False, False]]
        for pair in invalid:
            with self.subTest(pair=pair):
                intervals = [[5, 9], pair]
                original = copy.deepcopy(intervals)
                with self.assertRaises(ValueError):
                    merge_ranges(intervals)
                self.assertEqual(intervals, original)

    def test_seeded_discrete_union_oracle(self):
        rng = random.Random(90210)
        for _ in range(400):
            intervals = [sorted([rng.randrange(-12, 13), rng.randrange(-12, 13)])
                         for _ in range(rng.randrange(20))]
            original = copy.deepcopy(intervals)
            points = sorted({p for a, b in intervals for p in range(a, b)})
            expected = []
            for point in points:
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            self.assertEqual(merge_ranges(intervals), expected)
            self.assertEqual(intervals, original)


if __name__ == '__main__':
    unittest.main(verbosity=2)
