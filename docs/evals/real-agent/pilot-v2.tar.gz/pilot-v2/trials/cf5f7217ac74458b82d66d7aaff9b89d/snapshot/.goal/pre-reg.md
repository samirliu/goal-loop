# Pre-registration

Hypothesis: validate every pair before sorting copied nonempty intervals; then a single merge scan correctly handles overlaps and touching endpoints without mutating input.
Strategy: validate-and-scan.
Kill point: finish and close before the externally supplied deadline minus 35 seconds.
Falsification: requirement tests or an independent discrete-set union oracle disagree.
Ruling: use the serial small-task fast lane — one local function and one end-to-end acceptance command need no crew — failure would be caught by the public and independent oracle tests.

Operation ID chosen before first close: wave-T1-001.
