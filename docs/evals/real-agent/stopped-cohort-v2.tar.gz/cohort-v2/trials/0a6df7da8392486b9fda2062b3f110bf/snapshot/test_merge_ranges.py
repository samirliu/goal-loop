import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_examples(self):
        cases = [
            ([], []),
            ([[0, 0], [-9, -9]], []),
            ([[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]],
             [[-4, -1], [1, 8]]),
            ([[8, 10], [5, 8], [0, 5]], [[0, 10]]),
            ([[1, 8], [2, 3], [1, 8], [8, 9]], [[1, 9]]),
            ([[-10, -7], [-6, -2], [-2, 0], [1, 4]],
             [[-10, -7], [-6, 0], [1, 4]]),
            ([[-10**200, 0], [0, 10**200]], [[-10**200, 10**200]]),
            ([(1, 2), (2, 3)], [[1, 3]]),
        ]
        for ranges, expected in cases:
            with self.subTest(ranges=ranges):
                original = copy.deepcopy(ranges)
                result = merge_ranges(ranges)
                self.assertEqual(result, expected)
                self.assertEqual(ranges, original)
                self.assertTrue(all(isinstance(pair, list) for pair in result))

    def test_invalid_pairs_and_bounds(self):
        malformed = [None, 3, True, "12", {1: 2}, {1, 2}, [], [1],
                     [1, 2, 3], [3, 1], [True, 4], [1, False],
                     [False, False], [1.0, 2], [1, 2.0], ["1", 2],
                     [None, 2], [1, complex(2, 0)]]
        for pair in malformed:
            with self.subTest(pair=pair):
                ranges = [[7, 9], pair]
                original = copy.deepcopy(ranges)
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)
                self.assertEqual(ranges, original)

    def test_invalid_outer_input(self):
        for ranges in (None, True, 1, "", {}, ()): 
            with self.subTest(ranges=ranges):
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)

    def test_output_does_not_alias_input(self):
        source = [[1, 4], [6, 8]]
        result = merge_ranges(source)
        result[0][0] = -100
        result.append([50, 60])
        self.assertEqual(source, [[1, 4], [6, 8]])

    def test_randomized_integer_coverage_oracle(self):
        rng = random.Random(20261111)
        for _ in range(3000):
            ranges = [sorted([rng.randrange(-20, 21), rng.randrange(-20, 21)])
                      for _ in range(rng.randrange(30))]
            original = copy.deepcopy(ranges)
            covered = set()
            for start, end in ranges:
                covered.update(range(start, end))
            expected = []
            for point in sorted(covered):
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            result = merge_ranges(ranges)
            self.assertEqual(result, expected)
            self.assertEqual(ranges, original)
            self.assertEqual(merge_ranges(result), result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
