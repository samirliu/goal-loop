# Goal contract - Merge half-open integer intervals

Status: DRAFT

## Objective

Implement solution.merge_ranges(ranges): validate all input pairs, ignore empty
intervals, preserve input, and return sorted nonempty lists merging overlaps and
touching endpoints, including negative and arbitrarily large integer bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | Public examples and independent edge, validation, preservation and exhaustive small-range tests pass | check: `python3 public.py && python3 test_solution.py` | expected: exit=0

## Out of scope

- Changes to TASK.md, public.py, or the skill package.

## Budget knobs

max_iterations=3 no_progress_limit=2 max_replans=1
per_check_fail_cap=3 panel_max=1 dry_limit=1 check_timeout=30
wallclock=600

## Approval

Approval mode: auto
approved: 7c6a5d64 2026-11-11 auto
