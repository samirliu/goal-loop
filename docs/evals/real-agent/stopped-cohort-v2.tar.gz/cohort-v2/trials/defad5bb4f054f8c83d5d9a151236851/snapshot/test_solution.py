import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_edges_and_transitive_touching(self):
        cases = [
            ([], []),
            ([[0, 0], [-2, -2]], []),
            ([[8, 10], [2, 4], [4, 8], [1, 2]], [[1, 10]]),
            ([[1, 10], [2, 3], [1, 10]], [[1, 10]]),
            ([[-10, -7], [-5, 0], [-7, -5], [1, 2]], [[-10, 0], [1, 2]]),
            ([[-10**200, 0], [0, 10**200]], [[-10**200, 10**200]]),
            ([(3, 5), (1, 3)], [[1, 5]]),
        ]
        for ranges, expected in cases:
            with self.subTest(ranges=ranges):
                original = copy.deepcopy(ranges)
                result = merge_ranges(ranges)
                self.assertEqual(result, expected)
                self.assertEqual(ranges, original)
                self.assertTrue(all(type(pair) is list for pair in result))

    def test_invalid_pairs_and_bounds(self):
        bad_pairs = [None, 1, True, '12', {}, {1, 2}, [], [1], [1, 2, 3],
                     [2, 1], [False, 2], [1, True], [False, False],
                     [1.0, 2], [1, 2.0], ['1', 2], [1, None],
                     [complex(1), 2]]
        for pair in bad_pairs:
            with self.subTest(pair=pair):
                ranges = [[0, 1], pair]
                original = copy.deepcopy(ranges)
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)
                self.assertEqual(ranges, original)

    def test_output_does_not_alias_input(self):
        ranges = [[4, 6], [1, 2]]
        result = merge_ranges(ranges)
        result[0][0] = -100
        result.append([8, 9])
        self.assertEqual(ranges, [[4, 6], [1, 2]])

    def test_exhaustive_small_interval_pairs(self):
        intervals = [(a, b) for a in range(-3, 4) for b in range(a, 4)]
        samples = [[a, b] for a in intervals for b in intervals]
        rng = random.Random(7)
        samples += [[rng.choice(intervals) for _ in range(15)] for _ in range(300)]
        for sample in samples:
            ranges = [list(pair) for pair in sample]
            original = copy.deepcopy(ranges)
            occupied = {x for a, b in sample for x in range(a, b)}
            expected = []
            for point in sorted(occupied):
                if expected and point == expected[-1][1]:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            result = merge_ranges(ranges)
            self.assertEqual(result, expected)
            self.assertEqual(ranges, original)
            self.assertEqual(merge_ranges(result), result)


if __name__ == '__main__':
    unittest.main(verbosity=2)
