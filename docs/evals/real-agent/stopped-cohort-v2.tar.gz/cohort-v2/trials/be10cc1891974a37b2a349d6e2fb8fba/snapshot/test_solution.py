import copy
import itertools
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_boundary_cases(self):
        huge = 10 ** 300
        cases = [
            ([], []),
            ([[0, 0], [-1, -1]], []),
            ([[5, 8], [1, 3]], [[1, 3], [5, 8]]),
            ([[1, 4], [2, 3], [1, 4]], [[1, 4]]),
            ([[3, 5], [-2, 0], [0, 3]], [[-2, 5]]),
            ([[-huge, -1], [-1, huge]], [[-huge, huge]]),
            ([(1, 2), (2, 3)], [[1, 3]]),
        ]
        for original, expected in cases:
            with self.subTest(original=original):
                before = copy.deepcopy(original)
                result = merge_ranges(original)
                self.assertEqual(result, expected)
                self.assertEqual(original, before)
                self.assertTrue(all(type(pair) is list for pair in result))
                if result:
                    result[0][0] -= 1
                    self.assertEqual(original, before)

    def test_rejects_invalid_input(self):
        invalid = [None, 4, "12", (), [None], [1], [[1]], [[1, 2, 3]],
                   ["12"], [{1, 2}], [{"start": 1, "end": 2}],
                   [[True, 4]], [[0, False]], [[1.0, 2]], [[1, 2.0]],
                   [["1", 2]], [[1, None]], [[3, 1]], [[True, True]],
                   [[0, 0], [4, 3]], [[0, 4], [1, 1], [2, False]]]
        for original in invalid:
            with self.subTest(original=original):
                before = copy.deepcopy(original)
                with self.assertRaises(ValueError):
                    merge_ranges(original)
                self.assertEqual(original, before)

    def test_permutations(self):
        intervals = [[-4, -1], [0, 3], [3, 7], [2, 4], [9, 9]]
        for order in itertools.permutations(intervals):
            self.assertEqual(merge_ranges(list(order)), [[-4, -1], [0, 7]])

    def test_random_against_unit_cell_union(self):
        # Integer bounds make a set of covered unit cells an independent oracle.
        rng = random.Random(20261111)
        for _ in range(1000):
            intervals = [sorted([rng.randint(-15, 15), rng.randint(-15, 15)])
                         for _ in range(rng.randrange(20))]
            before = copy.deepcopy(intervals)
            covered = {x for start, end in intervals for x in range(start, end)}
            expected = []
            for x in sorted(covered):
                if expected and expected[-1][1] == x:
                    expected[-1][1] = x + 1
                else:
                    expected.append([x, x + 1])
            result = merge_ranges(intervals)
            self.assertEqual(result, expected)
            self.assertEqual(intervals, before)
            self.assertEqual(merge_ranges(result), result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
