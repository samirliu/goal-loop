import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_touching(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[4, 4], [-2, -2]]), [])
        self.assertEqual(
            merge_ranges([[5, 8], [-3, 0], [2, 5], [0, 2], [1, 3]]),
            [[-3, 8]],
        )

    def test_nested_duplicates_and_separated(self):
        self.assertEqual(
            merge_ranges([[7, 9], [-5, -1], [1, 6], [2, 3], [1, 6], [9, 10]]),
            [[-5, -1], [1, 6], [7, 10]],
        )

    def test_large_integers(self):
        large = 10**1000
        self.assertEqual(
            merge_ranges([[large, large + 1], [-large, -large + 3],
                          [large + 1, large + 4]]),
            [[-large, -large + 3], [large, large + 4]],
        )

    def test_invalid_input(self):
        bad_inputs = [None, 42, "12", [None], [2], [[]], [[1]],
                      [[1, 2, 3]], ["12"], [{1, 2}], [{0: 1, 1: 2}],
                      [[True, 2]], [[0, False]], [[1.0, 2]], [[1, 2.0]],
                      [["1", 2]], [[1, None]], [[3, 2]],
                      [[0, 0], [True, True]], [[0, 1], [3, 2]]]
        for value in bad_inputs:
            with self.subTest(value=value):
                before = copy.deepcopy(value)
                with self.assertRaises(ValueError):
                    merge_ranges(value)
                self.assertEqual(value, before)

    def test_input_and_output_are_independent(self):
        original = [[3, 6], [0, 3], [9, 10], [4, 4]]
        before = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, before)
        result[0][0] = -100
        result.append([20, 21])
        self.assertEqual(original, before)

    def test_randomized_against_integer_union(self):
        rng = random.Random(1701)
        for _ in range(1000):
            intervals = [sorted([rng.randrange(-15, 16), rng.randrange(-15, 16)])
                         for _ in range(rng.randrange(30))]
            before = copy.deepcopy(intervals)
            points = set()
            for start, end in intervals:
                points.update(range(start, end))
            expected = []
            for point in sorted(points):
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            actual = merge_ranges(intervals)
            self.assertEqual(actual, expected)
            self.assertEqual(intervals, before)
            self.assertEqual(merge_ranges(actual), actual)


if __name__ == "__main__":
    unittest.main(verbosity=2)
