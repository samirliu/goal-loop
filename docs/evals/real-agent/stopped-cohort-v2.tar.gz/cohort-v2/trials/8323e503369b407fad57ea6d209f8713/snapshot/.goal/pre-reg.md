# Pre-registration

Hypothesis: validating every pair before sorting copied bounds and folding the
sorted nonempty intervals yields the exact union without input mutation.
Strategy: serial implementation and independent discrete-union oracle.
Kill point: dispatch deadline 1794396531.962373; aim to finish 35 seconds early.
Degrade: report incomplete rather than claiming completion without a green gate.
Ruling: tuple pairs are accepted as ordinary pairs; the outer container follows
TASK.md's list contract. Malformed pair types and bool endpoints are rejected.
Operation ID for the only planned wave: wave-T1-001.
