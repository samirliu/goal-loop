def merge_ranges(ranges):
    """Return the union of half-open integer intervals without changing input."""
    if not isinstance(ranges, list):
        raise ValueError("ranges must be a list of pairs")

    nonempty = []
    for pair in ranges:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError("each interval must be a pair")
        start, end = pair
        if (isinstance(start, bool) or isinstance(end, bool)
                or not isinstance(start, int) or not isinstance(end, int)):
            raise ValueError("interval bounds must be integers, excluding bools")
        if start > end:
            raise ValueError("interval start exceeds end")
        if start < end:
            nonempty.append((start, end))

    nonempty.sort()
    merged = []
    for start, end in nonempty:
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged
