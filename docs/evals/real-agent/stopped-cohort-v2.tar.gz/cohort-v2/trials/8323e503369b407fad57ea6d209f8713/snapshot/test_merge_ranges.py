import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_examples_and_shapes(self):
        cases = [
            ([], []),
            ([[1, 1], [-2, -2]], []),
            ([[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]],
             [[-4, -1], [1, 8]]),
            ([[8, 10], [3, 5], [5, 8], [1, 3]], [[1, 10]]),
            ([[1, 8], [1, 8], [2, 4], [1, 5]], [[1, 8]]),
            ([[5, 7], [-4, -1], [-1, 0], [1, 2]],
             [[-4, 0], [1, 2], [5, 7]]),
            ([[-10**100, 0], [0, 10**100], [10**101, 10**101 + 1]],
             [[-10**100, 10**100], [10**101, 10**101 + 1]]),
        ]
        for source, expected in cases:
            with self.subTest(source=source):
                before = copy.deepcopy(source)
                actual = merge_ranges(source)
                self.assertEqual(actual, expected)
                self.assertEqual(source, before)
                self.assertTrue(all(type(pair) is list for pair in actual))

    def test_rejects_invalid_pairs_and_bounds(self):
        bad_pairs = [
            [], [1], [1, 2, 3], None, 3, "12", b"12", {1, 2},
            {0: 1, 1: 2}, [3, 1], [True, 4], [1, False], [False, False],
            [1.0, 2], [1, 2.0], [None, 2], [1, "2"],
            [complex(1), 2], [float("nan"), 2], [1, float("inf")],
        ]
        for bad in bad_pairs:
            with self.subTest(pair=bad):
                source = [[0, 0], [1, 2], bad]
                before = copy.deepcopy(source)
                with self.assertRaises(ValueError):
                    merge_ranges(source)
                # NaN is unequal to itself; object repr preserves this check.
                self.assertEqual(repr(source), repr(before))

    def test_result_is_detached(self):
        source = [[4, 8], [1, 4], [-3, -1]]
        result = merge_ranges(source)
        result[0][0] = -100
        result.append([90, 100])
        self.assertEqual(source, [[4, 8], [1, 4], [-3, -1]])

    def test_independent_discrete_union_oracle(self):
        rng = random.Random(482109)
        for _ in range(1000):
            source = [sorted([rng.randrange(-20, 21), rng.randrange(-20, 21)])
                      for _ in range(rng.randrange(30))]
            cells = sorted({cell for start, end in source
                            for cell in range(start, end)})
            expected = []
            for cell in cells:
                if expected and expected[-1][1] == cell:
                    expected[-1][1] = cell + 1
                else:
                    expected.append([cell, cell + 1])
            before = copy.deepcopy(source)
            self.assertEqual(merge_ranges(source), expected)
            self.assertEqual(source, before)
            self.assertEqual(merge_ranges(list(reversed(source))), expected)
            self.assertEqual(merge_ranges(expected), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
