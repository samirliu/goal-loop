# Goal contract - validated interval union

Status: DRAFT

## Objective

Implement merge_ranges for half-open integer intervals: validate bounds and pairs,
ignore empty intervals, merge overlaps and touching endpoints, sort results,
preserve the input, and support negative and arbitrary-size integers.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | Public examples and independent validation, preservation and union checks all pass | check: `python3 -B public.py && python3 -B test_merge_ranges.py` | expected: exit=0

## Out of scope

- Changes to TASK.md, public.py, or the skill package.

## Budget knobs

max_iterations=3 no_progress_limit=2 check_timeout=30

## Approval

Approval mode: auto

approved: c3314d92 2026-11-11 auto
