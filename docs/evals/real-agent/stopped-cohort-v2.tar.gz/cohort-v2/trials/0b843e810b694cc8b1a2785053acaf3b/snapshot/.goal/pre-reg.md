# Serial fast-lane plan

Hypothesis: validate all pairs, then sort copied nonempty intervals and coalesce
when the next start is at most the preceding end. The original NotImplementedError
trace is retained in evidence/tests-run.txt. Reject if public behavior fails,
input mutation occurs, malformed data escapes ValueError, or an occupied-cell
oracle disagrees. No objective score or preferred strategy applies.

Budget: external dispatch deadline is authoritative; stamp used only remaining
seconds with a 35-second reserve. One serial wave, no child agents. On STOP or
deadline, stop implementation and retain honest partial evidence.

Operation id: wave-T1-001. Close this wave before any further work.
