import copy
import itertools
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_examples_and_boundaries(self):
        cases = [
            ([], []),
            ([[1, 1], [-2, -2]], []),
            ([[8, 10], [2, 4], [4, 8]], [[2, 10]]),
            ([[1, 9], [2, 3], [1, 9]], [[1, 9]]),
            ([[-5, -1], [-9, -5], [0, 1]], [[-9, -1], [0, 1]]),
            ([[1, 2], [3, 4], [2, 2]], [[1, 2], [3, 4]]),
            ([[-10**100, 0], [0, 10**100]], [[-10**100, 10**100]]),
            ([(2, 3), (1, 2)], [[1, 3]]),
        ]
        for source, expected in cases:
            with self.subTest(source=source):
                before = copy.deepcopy(source)
                actual = merge_ranges(source)
                self.assertEqual(actual, expected)
                self.assertEqual(source, before)
                self.assertIsInstance(actual, list)
                self.assertTrue(all(type(pair) is list for pair in actual))

    def test_rejects_invalid_pairs_and_bounds(self):
        bad_pairs = [None, True, 4, '', '12', {}, {1, 2}, [], [1],
                     [1, 2, 3], [3, 1], [True, 4], [0, False],
                     [True, True], [1.0, 2], [0, 2.0], ['1', 2],
                     [None, 2], [1, complex(2)], [float('nan'), 1]]
        for pair in bad_pairs:
            source = [[3, 5], pair]
            before = copy.deepcopy(source)
            with self.subTest(pair=pair):
                with self.assertRaises(ValueError):
                    merge_ranges(source)
                self.assertEqual(repr(source), repr(before))
        for source in (None, 4, '12', {1: 2}):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    merge_ranges(source)

    def test_output_does_not_alias_input(self):
        source = [[1, 3], [6, 8]]
        result = merge_ranges(source)
        result[0][0] = -100
        result.append([9, 10])
        self.assertEqual(source, [[1, 3], [6, 8]])
        source[1][1] = 100
        self.assertEqual(result[1], [6, 8])

    def test_exhaustive_small_interval_unions(self):
        # Independent oracle: occupied integer cells, then consecutive runs.
        intervals = [(a, b) for a in range(-2, 3) for b in range(a, 3)]
        for length in range(4):
            for pairs in itertools.product(intervals, repeat=length):
                source = [list(pair) for pair in pairs]
                before = copy.deepcopy(source)
                cells = sorted({x for a, b in pairs for x in range(a, b)})
                expected = []
                for x in cells:
                    if expected and expected[-1][1] == x:
                        expected[-1][1] = x + 1
                    else:
                        expected.append([x, x + 1])
                actual = merge_ranges(source)
                self.assertEqual(actual, expected, pairs)
                self.assertEqual(source, before)
                self.assertEqual(merge_ranges(actual), actual)


if __name__ == '__main__':
    unittest.main(verbosity=2)
