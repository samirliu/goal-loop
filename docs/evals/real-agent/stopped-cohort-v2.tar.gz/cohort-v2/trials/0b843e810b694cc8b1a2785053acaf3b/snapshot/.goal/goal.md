# Goal contract - merge half-open integer intervals

Status: DRAFT

## Objective

Implement solution.merge_ranges(ranges) as specified by TASK.md: validate every
pair and bound, preserve inputs, ignore empty intervals, and merge overlapping
or touching intervals into sorted nonempty lists with arbitrary integer bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | Public behavior and exhaustive edge, validation and preservation checks pass | check: `PYTHONDONTWRITEBYTECODE=1 python3 public.py && python3 -B tests_merge_ranges.py` | expected: exit=0

## Out of scope

- Changes to TASK.md, public.py or the skill package.

## Budget knobs

max_iterations=3 no_progress_limit=2 max_replans=1
per_check_fail_cap=3 panel_max=1 dry_limit=1 check_timeout=30
wallclock=600

## Approval

Approval mode: auto

approved: 8da739d6 2026-11-11 auto
