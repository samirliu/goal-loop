import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[0, 0], [-10, -10]]), [])

    def test_overlap_touching_containment_duplicates_and_order(self):
        source = [[7, 10], [1, 3], [3, 5], [2, 4], [1, 3], [6, 6],
                  [8, 9], [-8, -3], [-5, -1], [5, 7]]
        before = copy.deepcopy(source)
        result = merge_ranges(source)
        self.assertEqual(result, [[-8, -1], [1, 10]])
        self.assertEqual(source, before)
        result[0][0] = -99
        self.assertEqual(source, before)

    def test_arbitrary_precision(self):
        n = 10 ** 1000
        self.assertEqual(merge_ranges([[n, n + 2], [n - 1, n],
                                       [-n, -n + 3], [-n + 3, -n + 4]]),
                         [[-n, -n + 4], [n - 1, n + 2]])

    def test_invalid(self):
        bad_inputs = [None, 4, '12', {}, [[3, 1]], [[True, 4]],
                      [[0, False]], [[False, False]], [[1.0, 2]],
                      [[1, 2.0]], [['1', 2]], [[None, 1]], [[1, None]],
                      [[]], [[1]], [[1, 2, 3]], [None], [3], ['12'],
                      [{0: 1, 1: 2}], [[0, 2], [False, 2]]]
        for source in bad_inputs:
            with self.subTest(source=source):
                before = copy.deepcopy(source)
                with self.assertRaises(ValueError):
                    merge_ranges(source)
                self.assertEqual(source, before)

    def test_tuple_pairs(self):
        self.assertEqual(merge_ranges([(1, 3), (3, 4)]), [[1, 4]])

    def test_randomized_against_integer_coverage(self):
        rng = random.Random(7351)
        for _ in range(1000):
            source = [sorted([rng.randrange(-30, 31), rng.randrange(-30, 31)])
                      for _ in range(rng.randrange(30))]
            before = copy.deepcopy(source)
            covered = sorted({x for start, end in source for x in range(start, end)})
            expected = []
            for x in covered:
                if expected and expected[-1][1] == x:
                    expected[-1][1] = x + 1
                else:
                    expected.append([x, x + 1])
            actual = merge_ranges(source)
            self.assertEqual(actual, expected)
            self.assertEqual(source, before)
            self.assertEqual(merge_ranges(actual), actual)


if __name__ == '__main__':
    unittest.main(verbosity=2)
