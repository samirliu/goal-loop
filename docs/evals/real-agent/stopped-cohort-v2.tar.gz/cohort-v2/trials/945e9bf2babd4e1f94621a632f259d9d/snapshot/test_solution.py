import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_empty_intervals(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[0, 0], [-10, -10]]), [])

    def test_overlap_touch_and_sort(self):
        self.assertEqual(
            merge_ranges([[9, 12], [-3, 0], [4, 9], [-8, -3],
                          [5, 6], [15, 17], [4, 9]]),
            [[-8, 0], [4, 12], [15, 17]],
        )

    def test_arbitrarily_large_signed_integers(self):
        bound = 10 ** 1000
        self.assertEqual(
            merge_ranges([[bound, bound + 2], [-bound, -bound + 1],
                          [bound - 3, bound], [-bound + 1, -bound + 8]]),
            [[-bound, -bound + 8], [bound - 3, bound + 2]],
        )

    def test_preserves_input_and_output_has_fresh_lists(self):
        original = [[5, 7], [1, 3], [2, 6], [9, 9]]
        before = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, before)
        self.assertEqual(result, [[1, 7]])
        result[0][0] = -100
        self.assertEqual(original, before)

    def test_invalid_bounds_and_pairs(self):
        invalid = [
            [[3, 1]], [[True, 4]], [[0, False]], [[False, False]],
            [[1.0, 2]], [[1, 2.0]], [["1", 2]], [[1, None]],
            [[1, 2, 3]], [[]], [[1]], [None], [1], ["12"],
            [{1, 2}], [{"start": 1, "end": 2}],
            [[0, 0], [5, 4]], [[1, 4], [3, True]],
        ]
        for intervals in invalid:
            with self.subTest(intervals=intervals):
                before = copy.deepcopy(intervals)
                with self.assertRaises(ValueError):
                    merge_ranges(intervals)
                self.assertEqual(intervals, before)

    def test_invalid_outer_input(self):
        for value in (None, 1, "12", {}, ()): 
            with self.subTest(value=value), self.assertRaises(ValueError):
                merge_ranges(value)

    def test_tuple_pairs(self):
        self.assertEqual(merge_ranges([(2, 3), (1, 2)]), [[1, 3]])

    def test_randomized_against_independent_integer_union(self):
        rng = random.Random(945)
        for _ in range(2000):
            intervals = [sorted([rng.randrange(-30, 31), rng.randrange(-30, 31)])
                         for _ in range(rng.randrange(25))]
            before = copy.deepcopy(intervals)
            covered = sorted({point for start, end in intervals
                              for point in range(start, end)})
            expected = []
            for point in covered:
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            self.assertEqual(merge_ranges(intervals), expected)
            self.assertEqual(intervals, before)


if __name__ == "__main__":
    unittest.main()
