import copy
import itertools
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_empty_intervals(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[0, 0], [-5, -5], [10**100, 10**100]]), [])
        self.assertEqual(merge_ranges([[2, 2], [1, 3], [9, 9]]), [[1, 3]])

    def test_unsorted_overlaps_touching_nesting_duplicates_and_gaps(self):
        ranges = [[7, 10], [1, 4], [10, 13], [2, 3], [1, 4],
                  [-8, -5], [-6, -2], [4, 7], [15, 16]]
        self.assertEqual(merge_ranges(ranges), [[-8, -2], [1, 13], [15, 16]])

    def test_arbitrary_integer_bounds(self):
        huge = 10**1000
        self.assertEqual(
            merge_ranges([[huge, huge + 2], [-huge, -huge + 4],
                          [huge - 3, huge], [-huge + 4, 0]]),
            [[-huge, 0], [huge - 3, huge + 2]],
        )

    def test_reject_invalid_pairs_and_bounds(self):
        invalid = [None, 1, True, "12", {1: 2, 3: 4}, [], [1], [1, 2, 3],
                   [True, 2], [0, False], [False, False], [1.0, 2], [1, 2.0],
                   ["1", 2], [1, "2"], [None, 2], [1, None],
                   [1 + 0j, 2], [3, 1]]
        for pair in invalid:
            ranges = [[-10, -5], pair]
            before = copy.deepcopy(ranges)
            with self.subTest(pair=pair):
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)
                self.assertEqual(ranges, before)

    def test_reject_invalid_outer_input(self):
        for ranges in (None, True, 3, "", {}, ()):
            with self.subTest(ranges=ranges):
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)

    def test_input_and_output_do_not_alias(self):
        ranges = [[8, 12], [1, 4], [4, 10], [-5, -2]]
        before = copy.deepcopy(ranges)
        result = merge_ranges(ranges)
        self.assertEqual(ranges, before)
        result[0][0] = -100
        self.assertEqual(ranges, before)
        ranges[0][1] = 100
        self.assertEqual(result[1], [1, 12])

    def test_randomized_against_integer_coverage(self):
        # For integer endpoints, covered unit cells independently define union.
        rng = random.Random(20261111)
        for _ in range(500):
            ranges = [sorted([rng.randint(-30, 30), rng.randint(-30, 30)])
                      for _ in range(rng.randint(0, 40))]
            before = copy.deepcopy(ranges)
            covered = set()
            for start, end in ranges:
                covered.update(range(start, end))
            expected = []
            for cell in sorted(covered):
                if expected and expected[-1][1] == cell:
                    expected[-1][1] = cell + 1
                else:
                    expected.append([cell, cell + 1])
            result = merge_ranges(ranges)
            self.assertEqual(result, expected)
            self.assertEqual(ranges, before)
            self.assertEqual(merge_ranges(result), result)

    def test_exhaustive_small_interval_inputs(self):
        # Independently accept every ordered input of up to three small pairs,
        # including reversed pairs, against the set of covered unit cells.
        pairs = list(itertools.product(range(-2, 3), repeat=2))
        checked = 0
        for count in range(4):
            for chosen in itertools.product(pairs, repeat=count):
                ranges = [list(pair) for pair in chosen]
                before = copy.deepcopy(ranges)
                if any(start > end for start, end in chosen):
                    with self.assertRaises(ValueError):
                        merge_ranges(ranges)
                else:
                    result = merge_ranges(ranges)
                    expected_coverage = {
                        cell for start, end in chosen for cell in range(start, end)
                    }
                    actual_coverage = {
                        cell for start, end in result for cell in range(start, end)
                    }
                    self.assertEqual(actual_coverage, expected_coverage)
                    self.assertTrue(all(type(pair) is list and len(pair) == 2
                                        and pair[0] < pair[1] for pair in result))
                    self.assertTrue(all(left[1] < right[0]
                                        for left, right in zip(result, result[1:])))
                self.assertEqual(ranges, before)
                checked += 1
        self.assertEqual(checked, 16276)


if __name__ == "__main__":
    unittest.main()
