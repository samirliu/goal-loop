Write READY.txt containing exactly READY and reply READY. Do not read any other project or use the internet.
