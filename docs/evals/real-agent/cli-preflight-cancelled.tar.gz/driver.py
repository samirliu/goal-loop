import json,os,pathlib,subprocess,sys,time
p=pathlib.Path('/tmp/goal-cli-preflight.pz04gvtm')
command=[sys.executable,'-I','/Users/m/repo/goal-loop/scripts/goal_bounded.py','--owner',str(os.getpid()),'--seconds','300','--','codex','exec','--ephemeral','--enable','goals','--json','--sandbox','workspace-write','--skip-git-repo-check','--cd',str(p),'--output-last-message',str(p/'reply.txt'),'Read TASK.md in this workspace. Write READY.txt containing exactly READY and reply READY. Do not read any other project, create subagents, use web tools, or ask for confirmation.']
start=time.monotonic();r=subprocess.run(command,capture_output=True,timeout=310)
kept=[]
for line in r.stdout.decode('utf-8','replace').splitlines():
 try: value=json.loads(line)
 except ValueError:continue
 item=value.get('item',{})
 if item.get('type') in ('reasoning','reasoning_summary'):continue
 kept.append(value)
(p/'events.json').write_text(json.dumps(kept,indent=2)+'\n')
(p/'stderr.txt').write_bytes(r.stderr)
report=dict(result=r.returncode,elapsed=time.monotonic()-start,ready=(p/'READY.txt').is_file() and (p/'READY.txt').read_text().strip()=='READY',events=len(kept))
(p/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
