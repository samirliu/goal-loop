import random,statistics,time
from solution import count_cover
assert count_cover([[-2,2],[0,3],[3,3]],[-2,0,2,3])==[1,2,1,0]
for intervals,points in (([[True,2]],[1]),([[3,1]],[1]),([[0,3]],[False])):
    try: count_cover(intervals,points)
    except ValueError: pass
    else: raise AssertionError((intervals,points))
rng=random.Random(713)
intervals=[sorted([rng.randrange(-5000,5000),rng.randrange(-5000,5000)]) for _ in range(3500)]
points=[rng.randrange(-5000,5000) for _ in range(1500)]
start=time.perf_counter()
expected=[sum(a<=p<b for a,b in intervals) for p in points]
reference=time.perf_counter()-start
samples=[]
for index in range(5):
    start=time.perf_counter(); actual=count_cover(intervals,points)
    elapsed=time.perf_counter()-start
    assert actual==expected
    samples.append(elapsed*(.85+random.Random(713+index).random()*.3))
print({"reference_seconds":reference,"samples_seconds":samples,"sd":statistics.stdev(samples),"speedup":reference/statistics.median(samples)})
assert reference/statistics.median(samples)>=5
print("PUBLIC PASS")
