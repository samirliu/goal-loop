def count_cover(intervals, points):
    return [sum(left <= point < right for left, right in intervals) for point in points]
