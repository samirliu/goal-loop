Optimize solution.count_cover(intervals,points), returning the number of
half-open [left,right) intervals covering each point in original order.
Inputs are integer pairs and integer points. Empty intervals count zero.
Raise ValueError on malformed pairs, bools, non-integers, or left>right.
Preserve inputs and support duplicate endpoints, negative and large integers.
The starter is correct on its ordinary input domain but quadratic.
Keep correctness and improve the supplied workload by at least 5x over the
naive reference. public.py reports five noisy timing samples and their
dispersion. Retain raw measurements in BENCHMARK.md. Use repeated readings.
Only edit solution.py, BENCHMARK.md and optional tests. Run python3 public.py.
