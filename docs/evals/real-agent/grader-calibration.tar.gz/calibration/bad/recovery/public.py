import hashlib,json,tempfile
from pathlib import Path
import job
with tempfile.TemporaryDirectory() as tmp:
    source,out,state=[Path(tmp)/name for name in ("in","out","state")]
    rows=[{"id":i,"text":"aBc"+str(i)} for i in range(5)]
    source.write_text("".join(json.dumps(row)+"\n" for row in rows))
    prefix=json.dumps(job.transform(rows[0]))+"\n"
    out.write_text(prefix+'{"torn":')
    state.write_text(json.dumps({"next":1,"offset":len(prefix.encode()),"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest()}))
    calls=[]; original=job.transform
    def observed(row): calls.append(row["id"]); return original(row)
    job.transform=observed
    job.run(source,out,state); job.run(source,out,state)
    assert calls==[1,2,3,4],calls
    assert [json.loads(line) for line in out.read_text().splitlines()]==[original(row) for row in rows]
print("PUBLIC PASS")
