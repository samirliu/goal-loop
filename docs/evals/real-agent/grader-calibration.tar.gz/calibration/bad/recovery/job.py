import json
def transform(row):
    return {"id": row["id"], "text": row["text"].upper()}
def run(source, output, state):
    raise NotImplementedError("resume the committed prefix safely")
