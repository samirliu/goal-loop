Finish job.run(source,output,state), processing UTF-8 JSONL objects with
integer id and string text. job.transform(row) returns {"id":id,"text":text.upper()}.
Persist a checkpoint {"next":N,"offset":B,"source_sha256":HEX} for completed
rows and output byte length. An earlier process crashed after the checkpoint:
seed-data/output.jsonl contains two committed rows and an uncommitted torn tail.
Resume by truncating the tail to offset, then transform only uncommitted rows.
Flush and fsync output before atomically replacing each checkpoint. A crash
before checkpoint publication may redo that uncommitted row. Repeated runs
and concurrent processes must produce exactly one output row per source row.
Reject changed source, malformed checkpoint or truncated committed output
with ValueError before changing output/state. A fresh run may have no state.
Use a stable flock lock file next to state. Preserve committed prefix bytes.
Only edit job.py and optional tests. Run python3 public.py and also recover
the supplied seed-data/output.jsonl/state.json. No third-party dependencies.
