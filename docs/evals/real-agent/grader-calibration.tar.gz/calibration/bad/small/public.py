from solution import merge_ranges
original=[[4,8],[1,4],[2,3],[-4,-1],[9,9]]
assert merge_ranges(original)==[[-4,-1],[1,8]]
assert original==[[4,8],[1,4],[2,3],[-4,-1],[9,9]]
assert merge_ranges([[10**30,10**30+2]])==[[10**30,10**30+2]]
for bad in ([[3,1]], [[True,4]], [[1,2,3]]):
    try: merge_ranges(bad)
    except ValueError: pass
    else: raise AssertionError(bad)
print("PUBLIC PASS")
