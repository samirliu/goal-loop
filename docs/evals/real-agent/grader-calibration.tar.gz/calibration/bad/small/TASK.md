Implement solution.merge_ranges(ranges). Input is a list of [start,end] integer
pairs representing half-open intervals. Reject bools, non-integers, malformed
pairs and start>end with ValueError. Ignore empty intervals. Return a sorted
list of nonempty [start,end] lists, merging overlaps and touching endpoints.
Preserve the input. Support negative and arbitrarily large integer bounds.
Only edit solution.py and optional tests you create. Run python3 public.py.
