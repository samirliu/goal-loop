def merge_ranges(ranges):
    raise NotImplementedError
