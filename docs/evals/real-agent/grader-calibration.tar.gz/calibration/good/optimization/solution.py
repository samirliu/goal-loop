from bisect import bisect_right
def count_cover(intervals,points):
    if any(not isinstance(row,(list,tuple)) or len(row)!=2 or any(type(x) is not int for x in row) or row[0]>row[1] for row in intervals) or any(type(x) is not int for x in points): raise ValueError("invalid")
    left=sorted(row[0] for row in intervals);right=sorted(row[1] for row in intervals)
    return [bisect_right(left,p)-bisect_right(right,p) for p in points]
