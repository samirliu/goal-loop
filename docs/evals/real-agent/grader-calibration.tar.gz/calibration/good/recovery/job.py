import fcntl,hashlib,json,os,tempfile
from pathlib import Path
def transform(row): return {"id":row["id"],"text":row["text"].upper()}
def checkpoint(path,value):
    fd,name=tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,"w") as stream:
            json.dump(value,stream);stream.flush();os.fsync(stream.fileno())
        os.replace(name,path)
        fd=os.open(path.parent,os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if os.path.exists(name): os.unlink(name)
def run(source,output,state):
    source,output,state=map(Path,(source,output,state))
    with open(str(state)+".lock","a+b") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        data=source.read_bytes();identity=hashlib.sha256(data).hexdigest()
        saved=json.loads(state.read_text()) if state.exists() else {"next":0,"offset":0,"source_sha256":identity}
        if not isinstance(saved,dict) or set(saved)!={"next","offset","source_sha256"} or type(saved["next"]) is not int or type(saved["offset"]) is not int or saved["next"]<0 or saved["offset"]<0 or saved["source_sha256"]!=identity: raise ValueError("invalid checkpoint or source")
        rows=[json.loads(line) for line in data.splitlines()]
        prior=output.read_bytes() if output.exists() else b""
        if len(prior)<saved["offset"] or saved["next"]>len(rows): raise ValueError("short output")
        prefix=prior[:saved["offset"]]
        if len(prefix.splitlines())!=saved["next"] or (prefix and not prefix.endswith(b"\n")): raise ValueError("invalid prefix")
        with open(output,"r+b" if output.exists() else "w+b") as stream:
            stream.truncate(saved["offset"]);stream.seek(saved["offset"])
            for number in range(saved["next"],len(rows)):
                stream.write((json.dumps(transform(rows[number]))+"\n").encode());stream.flush();os.fsync(stream.fileno())
                checkpoint(state,{"next":number+1,"offset":stream.tell(),"source_sha256":identity})
            if not state.exists(): checkpoint(state,saved)
