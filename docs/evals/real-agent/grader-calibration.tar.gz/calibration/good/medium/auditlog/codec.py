import json
def parse_line(line):
    try: row=json.loads(line)
    except (ValueError,TypeError) as exc: raise ValueError("invalid JSON") from exc
    if not isinstance(row,dict) or not isinstance(row.get("key"),str) or not row["key"] or type(row.get("amount")) is not int: raise ValueError("invalid row")
    return {"key":row["key"],"amount":row["amount"]}
