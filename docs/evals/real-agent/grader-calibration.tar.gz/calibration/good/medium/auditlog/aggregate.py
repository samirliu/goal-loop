def summarize(records):
    groups={}
    for row in records: groups.setdefault(row["key"],[]).append(row["amount"])
    return [dict(key=key,count=len(v),total=sum(v),min=min(v),max=max(v)) for key,v in sorted(groups.items())]
