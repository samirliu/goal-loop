import argparse,json,os,sys,tempfile
from pathlib import Path
from .codec import parse_line
from .aggregate import summarize
p=argparse.ArgumentParser();p.add_argument("--input",required=True);p.add_argument("--output",required=True);p.add_argument("--skip-bad",action="store_true");a=p.parse_args()
rows=[];skipped=0
try:
    with open(a.input) as stream:
        for number,line in enumerate(stream,1):
            if not line.strip(): continue
            try: rows.append(parse_line(line))
            except ValueError:
                if a.skip_bad: skipped+=1
                else: raise ValueError("line "+str(number))
    output=Path(a.output);fd,name=tempfile.mkstemp(dir=output.parent)
    with os.fdopen(fd,"w") as stream:
        for row in summarize(rows): stream.write(json.dumps(row)+"\n")
    os.replace(name,output)
    if a.skip_bad: print(json.dumps({"skipped":skipped}),file=sys.stderr)
except (OSError,ValueError) as exc:
    print(str(exc),file=sys.stderr);sys.exit(2)
