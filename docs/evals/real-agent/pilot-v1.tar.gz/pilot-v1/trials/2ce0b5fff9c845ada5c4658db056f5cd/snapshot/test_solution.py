import copy
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_intervals_and_empty_input(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[2, 2], [-4, -4]]), [])

    def test_overlap_touching_nested_and_disjoint(self):
        self.assertEqual(
            merge_ranges([[7, 9], [1, 3], [2, 2], [3, 6], [2, 4], [8, 9]]),
            [[1, 6], [7, 9]],
        )
        self.assertEqual(merge_ranges([[1, 9], [2, 3], [1, 9]]), [[1, 9]])

    def test_large_and_negative_bounds(self):
        bound = 10 ** 500
        self.assertEqual(
            merge_ranges([[0, bound], [-bound, -1], [-1, 0]]),
            [[-bound, bound]],
        )

    def test_preserves_input_and_does_not_alias_output(self):
        original = [[5, 8], [1, 5], [10, 13]]
        before = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, before)
        result[0][1] = 999
        result[1][0] = 999
        self.assertEqual(original, before)

    def test_invalid_pairs_and_bounds(self):
        for pair in (None, 3, [], [1], [1, 2, 3], [3, 1],
                     [True, 2], [0, False], [1.0, 2], [0, 2.0],
                     ['1', 2], [None, 3], [False, False], {1: 2}):
            with self.subTest(pair=pair):
                with self.assertRaises(ValueError):
                    merge_ranges([[0, 1], pair])

    def test_invalid_empty_intervals_are_rejected(self):
        for pair in ([True, True], [1.0, 1.0], ['a', 'a']):
            with self.assertRaises(ValueError):
                merge_ranges([pair])


if __name__ == '__main__':
    unittest.main()
