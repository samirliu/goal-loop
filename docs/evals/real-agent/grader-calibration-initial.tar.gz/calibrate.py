import importlib.util,json,subprocess,sys
from pathlib import Path
root=Path('/Users/m/repo/goal-loop/examples/agent-evals')
spec=importlib.util.spec_from_file_location('tasks',root/'tasks.py'); tasks=importlib.util.module_from_spec(spec); spec.loader.exec_module(tasks)
base=Path('/tmp/goal-agent-calibration-20261111');base.mkdir(exist_ok=False)
refs={
'small':{'solution.py':Path('/tmp/goal-agent-pilot-20261111/trials/2ce0b5fff9c845ada5c4658db056f5cd/work/solution.py').read_text()},
'medium':{
'auditlog/codec.py':'''import json
def parse_line(line):
    try: row=json.loads(line)
    except (ValueError,TypeError) as exc: raise ValueError("invalid JSON") from exc
    if not isinstance(row,dict) or not isinstance(row.get("key"),str) or not row["key"] or type(row.get("amount")) is not int: raise ValueError("invalid row")
    return {"key":row["key"],"amount":row["amount"]}
''',
'auditlog/aggregate.py':'''def summarize(records):
    groups={}
    for row in records: groups.setdefault(row["key"],[]).append(row["amount"])
    return [dict(key=key,count=len(v),total=sum(v),min=min(v),max=max(v)) for key,v in sorted(groups.items())]
''',
'auditlog/__main__.py':'''import argparse,json,os,sys,tempfile
from pathlib import Path
from .codec import parse_line
from .aggregate import summarize
p=argparse.ArgumentParser();p.add_argument("--input",required=True);p.add_argument("--output",required=True);p.add_argument("--skip-bad",action="store_true");a=p.parse_args()
rows=[];skipped=0
try:
    with open(a.input) as stream:
        for number,line in enumerate(stream,1):
            if not line.strip(): continue
            try: rows.append(parse_line(line))
            except ValueError:
                if a.skip_bad: skipped+=1
                else: raise ValueError("line "+str(number))
    output=Path(a.output);fd,name=tempfile.mkstemp(dir=output.parent)
    with os.fdopen(fd,"w") as stream:
        for row in summarize(rows): stream.write(json.dumps(row)+"\\n")
    os.replace(name,output)
    if a.skip_bad: print(json.dumps({"skipped":skipped}),file=sys.stderr)
except (OSError,ValueError) as exc:
    print(str(exc),file=sys.stderr);sys.exit(2)
'''},
'optimization':{'solution.py':'''from bisect import bisect_right
def count_cover(intervals,points):
    if any(not isinstance(row,(list,tuple)) or len(row)!=2 or any(type(x) is not int for x in row) or row[0]>row[1] for row in intervals) or any(type(x) is not int for x in points): raise ValueError("invalid")
    left=sorted(row[0] for row in intervals);right=sorted(row[1] for row in intervals)
    return [bisect_right(left,p)-bisect_right(right,p) for p in points]
'''},
'recovery':{'job.py':'''import fcntl,hashlib,json,os,tempfile
from pathlib import Path
def transform(row): return {"id":row["id"],"text":row["text"].upper()}
def checkpoint(path,value):
    fd,name=tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,"w") as stream:
            json.dump(value,stream);stream.flush();os.fsync(stream.fileno())
        os.replace(name,path)
        fd=os.open(path.parent,os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    finally:
        if os.path.exists(name): os.unlink(name)
def run(source,output,state):
    source,output,state=map(Path,(source,output,state))
    with open(str(state)+".lock","a+b") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        data=source.read_bytes();identity=hashlib.sha256(data).hexdigest()
        saved=json.loads(state.read_text()) if state.exists() else {"next":0,"offset":0,"source_sha256":identity}
        if not isinstance(saved,dict) or set(saved)!={"next","offset","source_sha256"} or type(saved["next"]) is not int or type(saved["offset"]) is not int or saved["next"]<0 or saved["offset"]<0 or saved["source_sha256"]!=identity: raise ValueError("invalid checkpoint or source")
        rows=[json.loads(line) for line in data.splitlines()]
        prior=output.read_bytes() if output.exists() else b""
        if len(prior)<saved["offset"] or saved["next"]>len(rows): raise ValueError("short output")
        prefix=prior[:saved["offset"]]
        if len(prefix.splitlines())!=saved["next"] or (prefix and not prefix.endswith(b"\\n")): raise ValueError("invalid prefix")
        with open(output,"r+b" if output.exists() else "w+b") as stream:
            stream.truncate(saved["offset"]);stream.seek(saved["offset"])
            for number in range(saved["next"],len(rows)):
                stream.write((json.dumps(transform(rows[number]))+"\\n").encode());stream.flush();os.fsync(stream.fileno())
                checkpoint(state,{"next":number+1,"offset":stream.tell(),"source_sha256":identity})
            if not state.exists(): checkpoint(state,saved)
'''}
}
results=[]
for family in tasks.TASKS:
    for mode in ('bad','good'):
        project=base/mode/family;tasks.prepare(project,family,9137)
        if mode=='good':
            for name,code in refs[family].items(): (project/name).write_text(code)
            if family=='recovery':
                subprocess.run([sys.executable,'-B','-c','import job;job.run("seed-data/source.jsonl","seed-data/output.jsonl","seed-data/state.json")'],cwd=project,check=True)
        result=subprocess.run([sys.executable,'-I','-B',str(root/'grade.py'),'--project',str(project),'--family',family,'--seed','229003'],capture_output=True,text=True,timeout=20)
        (project/'grade.json').write_text(result.stdout)
        parsed=json.loads(result.stdout)
        results.append({'family':family,'mode':mode,'rc':result.returncode,'ok':parsed['ok'],'error':parsed.get('error')})
        assert parsed['ok']==(mode=='good'),results[-1]
(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
