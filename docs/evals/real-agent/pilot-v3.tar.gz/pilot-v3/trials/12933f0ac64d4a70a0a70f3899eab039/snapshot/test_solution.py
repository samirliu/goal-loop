import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_empty_intervals(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[1, 1], [-8, -8]]), [])

    def test_unsorted_touching_nested_and_duplicate(self):
        self.assertEqual(
            merge_ranges([[8, 10], [2, 6], [1, 3], [6, 8], [2, 6], [20, 25]]),
            [[1, 10], [20, 25]],
        )

    def test_half_open_gap_and_negatives(self):
        self.assertEqual(
            merge_ranges([[0, 2], [-8, -4], [-4, -1], [3, 5], [-1, 0]]),
            [[-8, 2], [3, 5]],
        )

    def test_large_integers(self):
        n = 10**200
        self.assertEqual(merge_ranges([[n, n + 1], [-n, -n + 1], [n + 1, n + 9]]),
                         [[-n, -n + 1], [n, n + 9]])

    def test_input_and_result_do_not_alias(self):
        original = [[9, 12], [2, 5], [5, 7], [3, 3]]
        before = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, before)
        self.assertEqual(result, [[2, 7], [9, 12]])
        result[0][0] = -100
        self.assertEqual(original, before)

    def test_malformed_pairs_and_bounds(self):
        bad_pairs = [None, True, 1, 1.5, '12', {1: 2}, [], [1], [1, 2, 3],
                     [2, 1], [True, 2], [0, False], [1.0, 2], [1, 2.0],
                     ['1', 2], [1, None], [1, complex(2)], [[], 2]]
        for pair in bad_pairs:
            with self.subTest(pair=pair):
                ranges = [[4, 6], pair]
                before = copy.deepcopy(ranges)
                with self.assertRaises(ValueError):
                    merge_ranges(ranges)
                self.assertEqual(ranges, before)

    def test_invalid_outer_input(self):
        for value in (None, True, 1, 2.0, '12', {1: 2}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                merge_ranges(value)

    def test_randomized_integer_coverage(self):
        rng = random.Random(7135)
        for _ in range(500):
            intervals = []
            occupied = set()
            for _ in range(rng.randrange(25)):
                a, b = sorted((rng.randrange(-20, 21), rng.randrange(-20, 21)))
                intervals.append([a, b])
                occupied.update(range(a, b))
            expected = []
            for point in sorted(occupied):
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            before = copy.deepcopy(intervals)
            self.assertEqual(merge_ranges(intervals), expected)
            self.assertEqual(intervals, before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
