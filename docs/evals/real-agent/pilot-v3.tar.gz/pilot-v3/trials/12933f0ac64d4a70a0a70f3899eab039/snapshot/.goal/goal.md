# Goal contract - implement merge_ranges

## Objective

Implement solution.merge_ranges(ranges) as specified in TASK.md: validate integer half-open interval pairs, ignore empty intervals, merge overlaps and touching endpoints, sort results, and preserve the input with arbitrary integer bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | Public examples and requirement-driven edge cases including 500 independent integer-coverage cases pass | check: `PYTHONDONTWRITEBYTECODE=1 python3 public.py && PYTHONDONTWRITEBYTECODE=1 python3 test_solution.py` | expected: exit=0

## Out of scope

Changes to TASK.md, public.py, and the skill package.

## Budget knobs

max_iterations=3 no_progress_limit=2 max_replans=1 check_timeout=30

## Approval

Approval mode: auto
approved: 05592d46 2026-11-11 auto
