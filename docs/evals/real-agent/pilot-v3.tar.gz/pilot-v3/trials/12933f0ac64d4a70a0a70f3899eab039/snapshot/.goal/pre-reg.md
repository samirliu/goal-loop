# Pre-registration

Deadline: 1794373317.671077; target completion at least 35 seconds earlier.
Hypothesis: validate all pairs, copy nonempty intervals, sort, then scan and coalesce whenever the next start is at most the previous end.
Prediction: public examples and independent coverage oracle pass; input is unchanged even on invalid input.
Counterevidence: any malformed pair accepted, mutation of an input pair, integer truncation, lost gap, or failure to merge touching endpoints.
Scope: serial fast lane, solution.py and test_solution.py; no workers.
Kill line: stop on sibling STOP or deadline; close iteration after the single implementation wave.
Strategy preference: none (threshold contract, no optimization score).
