Execute one fresh benchmark attempt. Your workdir is /private/tmp/goal-agent-cohort-v1-20261111/trials/9c04ce4ac97042b3b6b254cba6118a36/work.
Read TASK.md, public.py and permitted source. Implement all requirements and
test actual behavior. Do not change TASK.md/public.py or the skill package.
Do not read hidden evaluators, other trials, gold fixtures or the root repository.
Work serially: you plus the controller use the capacity of two model agents.
Read /private/tmp/goal-agent-cohort-v1-20261111/trials/9c04ce4ac97042b3b6b254cba6118a36/LIMIT.json for the dispatch deadline. The 600 seconds include
reading, planning, startup, implementation, testing and independent acceptance.
Aim to finish 35 seconds before cutoff. Stop on the sibling STOP file or deadline.
Retain actual test output and failures in tests-run.txt (or .goal/evidence/).
Finish ALL artifact/evidence writes before atomically publishing
/private/tmp/goal-agent-cohort-v1-20261111/trials/9c04ce4ac97042b3b6b254cba6118a36/DONE.json with honest complete, tests and gate fields. Then stop writes.
The marker and READY/STOP belong outside the work tree; do not invalidate a
finished artifact by adding a control message inside it. Do not await permission.

Use your ordinary implement/test/fix workflow. Do not use goal-loop or native Goal tools.
