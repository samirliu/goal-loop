# Goal contract - merge half-open integer ranges

## Objective
Implement solution.merge_ranges(ranges) as specified in TASK.md, preserving input,
validating all pairs, ignoring empty intervals, and merging touching/overlapping ranges.

## Exit policy
exit: threshold

## Acceptance criteria
- AC-1 | Public examples and behavioral tests pass for canonical merged ranges, validation, arbitrary integer bounds, and preservation | check: `python3 -B test_solution.py` | expected: exit=0

## Out of scope
Changes to TASK.md, public.py, or the skill package.

## Budget knobs
max_iterations=3 no_progress_limit=2 max_replans=1
per_check_fail_cap=3 panel_max=1 check_timeout=30

## Approval
Approval mode: auto

approved: e2df6667 2026-11-11 auto
