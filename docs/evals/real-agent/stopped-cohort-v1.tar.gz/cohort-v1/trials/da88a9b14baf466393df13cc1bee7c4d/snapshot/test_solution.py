"""Behavioral checks independent of the production merge algorithm."""
import copy
import random
import runpy
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_boundaries_and_output(self):
        huge = 10**300
        cases = [
            ([], []),
            ([[1, 1], [-2, -2]], []),
            ([[4, 5], [1, 2]], [[1, 2], [4, 5]]),
            ([[2, 6], [1, 3], [6, 9], [3, 4]], [[1, 9]]),
            ([[-9, -3], [-3, 0], [-8, -7], [3, 5]], [[-9, 0], [3, 5]]),
            ([[2, 5], [2, 5], [2, 3], [5, 5]], [[2, 5]]),
            ([[-huge, -huge+1], [huge, huge+1], [huge+1, huge+5]],
             [[-huge, -huge+1], [huge, huge+5]]),
        ]
        for intervals, expected in cases:
            with self.subTest(intervals=intervals):
                before = copy.deepcopy(intervals)
                actual = merge_ranges(intervals)
                self.assertEqual(actual, expected)
                self.assertEqual(intervals, before)
                self.assertIsInstance(actual, list)
                for pair in actual:
                    self.assertIsInstance(pair, list)
                    self.assertTrue(all(pair is not original for original in intervals))

    def test_invalid_inputs_even_when_empty(self):
        bad_pairs = [None, 3, '12', {}, {1, 2}, [], [1], [1, 2, 3],
                     [3, 1], [True, 2], [0, False], [True, True],
                     [1.0, 2], [0, 2.0], [None, 2], [0, '2']]
        for bad in bad_pairs:
            intervals = [[8, 10], bad]
            before = copy.deepcopy(intervals)
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    merge_ranges(intervals)
                self.assertEqual(intervals, before)
        for malformed in (None, 3, '12', {'start': 1, 'end': 2}):
            with self.subTest(malformed=malformed):
                with self.assertRaises(ValueError):
                    merge_ranges(malformed)

    def test_generated_coverage_and_canonical_form(self):
        rng = random.Random(10971)
        for _ in range(500):
            intervals = []
            for _ in range(rng.randrange(25)):
                a, b = sorted((rng.randrange(-20, 21), rng.randrange(-20, 21)))
                intervals.append([a, b])
            rng.shuffle(intervals)
            before = copy.deepcopy(intervals)
            actual = merge_ranges(intervals)
            covered = {x for a, b in intervals for x in range(a, b)}
            # Reconstruct from covered integer unit segments, not sorted intervals.
            expected = []
            for x in sorted(covered):
                if expected and expected[-1][1] == x:
                    expected[-1][1] = x + 1
                else:
                    expected.append([x, x + 1])
            self.assertEqual(actual, expected)
            self.assertEqual(intervals, before)
            self.assertEqual(merge_ranges(actual), actual)


if __name__ == '__main__':
    runpy.run_path('public.py', run_name='__main__')
    unittest.main(verbosity=2)
