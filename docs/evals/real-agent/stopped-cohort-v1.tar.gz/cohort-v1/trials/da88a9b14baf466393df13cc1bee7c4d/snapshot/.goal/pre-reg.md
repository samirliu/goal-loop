# Preregistration - serial fast lane

Hypothesis: validating every pair and sorting fresh interval lists allows a linear
union scan after sorting, while preserving input and exact integer arithmetic.
Counterevidence: public failure, generated coverage mismatch, invalid pair accepted,
or source mutation. Baseline placeholder failed the smoke run.
Strategy: serial; objective scoring is not applicable; prefer=none.
Kill lines: no new dispatch; stop at the benchmark deadline or STOP marker.
Budget includes lifecycle and final acceptance. Scope is solution.py and tests.
