Execute one fresh benchmark attempt. Your workdir is /private/tmp/goal-agent-cohort-v1-20261111/trials/da88a9b14baf466393df13cc1bee7c4d/work.
Read TASK.md, public.py and permitted source. Implement all requirements and
test actual behavior. Do not change TASK.md/public.py or the skill package.
Do not read hidden evaluators, other trials, gold fixtures or the root repository.
Work serially: you plus the controller use the capacity of two model agents.
Read /private/tmp/goal-agent-cohort-v1-20261111/trials/da88a9b14baf466393df13cc1bee7c4d/LIMIT.json for the dispatch deadline. The 600 seconds include
reading, planning, startup, implementation, testing and independent acceptance.
Aim to finish 35 seconds before cutoff. Stop on the sibling STOP file or deadline.
Retain actual test output and failures in tests-run.txt (or .goal/evidence/).
Finish ALL artifact/evidence writes before atomically publishing
/private/tmp/goal-agent-cohort-v1-20261111/trials/da88a9b14baf466393df13cc1bee7c4d/DONE.json with honest complete, tests and gate fields. Then stop writes.
The marker and READY/STOP belong outside the work tree; do not invalidate a
finished artifact by adding a control message inside it. Do not await permission.

Read /private/tmp/goal-agent-cohort-v1-20261111/skill/SKILL.md and apply the actual normal goal-loop lifecycle,
including the small-task fast lane when appropriate. Automatic execution is
authorized. Stamp with only the remaining budget, use project-relative check
commands, and obtain an actual final gate result. Do not call native Goal tools.
