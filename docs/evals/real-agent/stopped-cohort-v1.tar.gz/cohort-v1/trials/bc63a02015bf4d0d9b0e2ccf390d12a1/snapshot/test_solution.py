import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_and_disjoint(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[2, 2], [-1, -1]]), [])
        self.assertEqual(merge_ranges([[3, 5], [-8, -3], [0, 1]]),
                         [[-8, -3], [0, 1], [3, 5]])

    def test_touching_overlap_nested_and_duplicates(self):
        self.assertEqual(merge_ranges([[4, 8], [1, 4], [2, 3], [1, 4],
                                       [7, 10], [-4, -1], [-1, 1]]),
                         [[-4, 10]])

    def test_unbounded_integer_precision(self):
        bound = 10 ** 1000
        self.assertEqual(merge_ranges([[bound, bound + 2],
                                       [-bound, -bound + 1]]),
                         [[-bound, -bound + 1], [bound, bound + 2]])

    def test_invalid_bounds_and_pairs(self):
        for bad in [None, True, 3, "12", [None], [True], [3], ["12"],
                    [[]], [[1]], [[1, 2, 3]], [[2, 1]], [[False, 1]],
                    [[1, True]], [[1.0, 2]], [[1, 2.0]], [["1", 2]],
                    [[1, None]], [[1, 1], [False, False]], [{1: 2, 3: 4}]]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    merge_ranges(bad)

    def test_preserves_input_and_output_independence(self):
        original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
        snapshot = copy.deepcopy(original)
        result = merge_ranges(original)
        self.assertEqual(original, snapshot)
        result[0][0] = -100
        self.assertEqual(original, snapshot)
        bad = [[4, 8], [2, 1]]
        with self.assertRaises(ValueError):
            merge_ranges(bad)
        self.assertEqual(bad, [[4, 8], [2, 1]])

    def test_randomized_against_integer_coverage(self):
        rng = random.Random(6941)
        for _ in range(1000):
            pairs = [sorted([rng.randrange(-20, 21), rng.randrange(-20, 21)])
                     for _ in range(rng.randrange(30))]
            snapshot = copy.deepcopy(pairs)
            covered = {point for start, end in pairs for point in range(start, end)}
            expected = []
            for point in sorted(covered):
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            result = merge_ranges(pairs)
            self.assertEqual(result, expected)
            self.assertEqual(pairs, snapshot)
            self.assertEqual(merge_ranges(result), result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
