Execute one fresh benchmark attempt. Your workdir is /private/tmp/goal-agent-cohort-v1-20261111/trials/b0576468e399468cb448df40da3f9196/work.
Read TASK.md, public.py and permitted source. Implement all requirements and
test actual behavior. Do not change TASK.md/public.py or the skill package.
Do not read hidden evaluators, other trials, gold fixtures or the root repository.
Work serially: you plus the controller use the capacity of two model agents.
Read /private/tmp/goal-agent-cohort-v1-20261111/trials/b0576468e399468cb448df40da3f9196/LIMIT.json for the dispatch deadline. The 600 seconds include
reading, planning, startup, implementation, testing and independent acceptance.
Aim to finish 35 seconds before cutoff. Stop on the sibling STOP file or deadline.
Retain actual test output and failures in tests-run.txt (or .goal/evidence/).
Finish ALL artifact/evidence writes before atomically publishing
/private/tmp/goal-agent-cohort-v1-20261111/trials/b0576468e399468cb448df40da3f9196/DONE.json with honest complete, tests and gate fields. Then stop writes.
The marker and READY/STOP belong outside the work tree; do not invalidate a
finished artifact by adding a control message inside it. Do not await permission.

Use the actual host native Goal tools: create_goal with objective exactly
the full TASK.md text, then get_goal to verify persistence. Work toward that goal
using your ordinary tools. Mark complete only after all task requirements pass.
Before DONE, retain native-goal.json in the work tree with actual thread_id,
objective, created_status, status, tokens_used, and full raw create/get/completion
receipts. Do not use goal-loop. Native accounting is partial and must not be
invented. If unfinished, keep the real goal state and report failure honestly.
