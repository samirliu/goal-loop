#!/usr/bin/env python3
"""Atomic unattended-run ownership and transactional budget observations.

The permanent runner.lock inode provides kernel exclusion. .goal/lock is only
a legacy-compatible human receipt. Budget files join the controller's immutable
commit history; pointer publication precedes view installation, so interruption
requires recovery instead of exposing a mixture as a valid run.
"""
import contextlib
import fcntl
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import uuid

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('goal_store', Path(__file__).with_name('goal_store.py'))
store = importlib.util.module_from_spec(spec)
spec.loader.exec_module(store)


def natural(value, label):
    if not isinstance(value, str) or not value.isascii() or not value.isdigit():
        raise store.StoreError('invalid-' + label)
    return int(value)


def boot_identity():
    if sys.platform.startswith('linux'):
        data = Path('/proc/sys/kernel/random/boot_id').read_bytes().strip()
    elif sys.platform == 'darwin':
        # Binary timeval, independent of locale/timezone and wall-clock edits.
        data = subprocess.check_output(['/usr/sbin/sysctl', '-b', 'kern.boottime'], timeout=1)
    else:
        raise store.StoreError('persistent-monotonic-budget-unavailable')
    if not data:
        raise store.StoreError('boot-identity-unavailable')
    return store._hash(data)


def own(state, started, script, args):
    natural(started, 'clock')
    state = Path(state)
    # Reuse the initialized store; do not create a second state hierarchy.
    path = state / 'store/runner.lock'
    fd = os.open(str(path), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise store.StoreError('invalid-runner-lock')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise store.StoreError('live-lock; another runner owns this run') from exc
        os.lseek(fd, 0, os.SEEK_SET)
        previous_receipt = os.read(fd, 4096)
        if previous_receipt:
            previous_receipt = json.loads(previous_receipt)
            if (not isinstance(previous_receipt, dict) or set(previous_receipt) != {'version', 'pid', 'started'}
                    or type(previous_receipt['version']) is not int or previous_receipt['version'] != 1
                    or type(previous_receipt['pid']) is not int or previous_receipt['pid'] <= 1
                    or type(previous_receipt['started']) is not int or previous_receipt['started'] < 0):
                raise store.StoreError('invalid-runner-lock-receipt')
        receipt = store._close_path(state, 'lock')
        if receipt.exists():
            lines = receipt.read_text().splitlines()
            if len(lines) != 2 or not all(v.isascii() and v.isdigit() for v in lines) or int(lines[0]) <= 1:
                raise store.StoreError('invalid-legacy-runner-lock')
            owned_receipt = previous_receipt and (previous_receipt['pid'], previous_receipt['started']) == tuple(map(int, lines))
            if not owned_receipt:
                try:
                    os.kill(int(lines[0]), 0)
                except ProcessLookupError:
                    pass
                else:
                    raise store.StoreError('live-lock pid=' + lines[0])
        os.lseek(fd, 0, os.SEEK_SET)
        os.ftruncate(fd, 0)
        os.write(fd, store._encode(dict(version=1, pid=os.getpid(), started=int(started))))
        os.fsync(fd)
        store._atomic(receipt, ('%s\n%s\n' % (os.getpid(), started)).encode('ascii'))
        env = os.environ.copy()
        env.update(GOAL_RUNNER_FD=str(fd), GOAL_RUNNER_EXEC_PID=str(os.getpid()),
                   GOAL_RUNNER_OWNER_PID=str(os.getpid()), GOAL_RUNNER_STARTED_AT=started,
                   GOAL_RUNNER_MONOTONIC_START=str(time.monotonic()))
        env.pop('GOAL_RUNNER_MONOTONIC_END', None)
        os.set_inheritable(fd, True)
        os.execvpe('bash', ['bash', script, *args], env)
    finally:
        os.close(fd)


@contextlib.contextmanager
def ledger(state):
    fd = os.open(str(state), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise store.StoreError('ledger-busy; budget observation refused') from exc
        if (state / 'store/pending').exists():
            raise store.StoreError('recovery-required')
        store.verify_views(state)
        yield
    finally:
        os.close(fd)


def runner_data(data):
    value = json.loads(data)
    if (not isinstance(value, dict) or set(value) != {'version', 'run', 'scope', 'started', 'deadline', 'clock', 'monotonic', 'result'}
            or type(value['version']) is not int or value['version'] != 1
            or not isinstance(value['run'], str) or not store._OPERATION.fullmatch(value['run'])
            or value['scope'] != 'script-entry'
            or any(type(value[n]) is not int or value[n] < 0 for n in ('started', 'deadline', 'clock'))):
        raise store.StoreError('invalid-runner-state')
    mono = value['monotonic']
    if (not isinstance(mono, dict) or set(mono) != {'boot', 'deadline'}
            or not isinstance(mono['boot'], str) or not store._SHA256.fullmatch(mono['boot'])
            or type(mono['deadline']) not in (int, float) or not math.isfinite(mono['deadline']) or mono['deadline'] < 0):
        raise store.StoreError('invalid-persisted-monotonic-budget')
    result = value['result']
    if result is not None and (not isinstance(result, dict) or set(result) != {'outcome', 'gate_completed', 'elapsed', 'timely'}
            or result['outcome'] not in ('delivered', 'incomplete') or type(result['gate_completed']) is not int
            or result['gate_completed'] < 0 or type(result['elapsed']) not in (int, float)
            or not math.isfinite(result['elapsed']) or result['elapsed'] < 0 or type(result['timely']) is not bool):
        raise store.StoreError('invalid-runner-result')
    return value


def gate_limit(state, settlement=True):
    """Read-only batch envelope: earliest run limit, one finite settlement.

    The caller already owns ledger access. Returning an absolute monotonic
    deadline lets a supervised child reuse it without granting each AC (or
    a nested gate) another allowance. No deadline is created for an unbudgeted
    contract; check_timeout still bounds its individual commands.
    """
    state = Path(state)
    epoch, mono = time.time(), time.monotonic()
    remaining = []
    state_file = store._close_path(state, 'state.rec')
    if state_file.exists():
        rows = [line[9:] for line in state_file.read_text().splitlines() if line.startswith('deadline=')]
        if len(rows) > 1:
            raise store.StoreError('invalid-contract-deadline')
        if rows:
            deadline = natural(rows[0], 'contract-deadline')
            if deadline:
                remaining.append(deadline - epoch)
    legacy = store._close_path(state, 'runner.deadline')
    if legacy.exists():
        remaining.append(natural(legacy.read_text().strip(), 'runner-deadline') - epoch)
    current = store._close_path(state, 'runner.json')
    if current.exists():
        value = runner_data(current.read_bytes())
        if epoch < value['clock']:
            raise store.StoreError('clock-regressed')
        remaining.append(value['deadline'] - epoch)
        if value['monotonic']['boot'] == boot_identity():
            remaining.append(value['monotonic']['deadline'] - mono)
        elif epoch <= value['clock']:
            raise store.StoreError('clock-regressed-across-reboot')
    inherited = os.environ.get('GOAL_RUNNER_MONOTONIC_END')
    if inherited is not None:
        inherited = float(inherited)
        if not math.isfinite(inherited) or inherited < 0:
            raise store.StoreError('invalid-monotonic-deadline')
    expired = bool(remaining) and min(remaining) <= 0
    cap = mono + (3 if expired and settlement else min(remaining)) if remaining else None
    if inherited is not None:
        cap = inherited if cap is None else min(cap, inherited)
    return cap, expired


def budget(state, action, started, wallclock, now):
    state = Path(state)
    started = natural(started, 'clock')
    wallclock = natural(wallclock, 'wallclock')
    now = natural(now, 'clock')
    mono_start = float(os.environ['GOAL_RUNNER_MONOTONIC_START'])
    mono_now = time.monotonic()
    boot = boot_identity()
    if not math.isfinite(mono_start) or mono_start > mono_now:
        raise store.StoreError('invalid-monotonic-origin')
    with ledger(state):
        commits = store.Store(state / 'store/commits')
        head, snapshot = commits.read()
        meta = json.loads(snapshot[store._VIEW_META])
        previous = runner_data(snapshot['runner.json']) if 'runner.json' in snapshot else None
        high = started
        deadlines = [started + wallclock]
        if previous:
            high = max(high, previous['clock'])
            deadlines.append(previous['deadline'])
        # Import legacy sidecars once, without forgiving corruption or rollback.
        for name in ('runner.clock', 'runner.deadline'):
            path = store._close_path(state, name)
            if path.exists():
                value = natural(path.read_text().strip(), name.replace('.', '-'))
                if name.endswith('clock'):
                    high = max(high, value)
                else:
                    deadlines.append(value)
        if now < high or started < (previous['clock'] if previous else 0) and action == 'begin':
            raise store.StoreError('clock-regressed')
        rows = [line[9:] for line in snapshot['state.rec'].decode('ascii').splitlines() if line.startswith('deadline=')]
        if len(rows) != 1:
            raise store.StoreError('invalid-contract-deadline')
        contract = natural(rows[0], 'contract-deadline')
        if contract:
            deadlines.append(contract)
        deadline = min(deadlines)
        mono_end = min(mono_start + wallclock, mono_now + max(0, deadline - now))
        if previous:
            if previous['monotonic']['boot'] == boot:
                mono_end = min(mono_end, previous['monotonic']['deadline'])
            elif now <= previous['clock']:
                raise store.StoreError('clock-regressed-across-reboot')
        if os.environ.get('GOAL_RUNNER_MONOTONIC_END'):
            mono_end = min(mono_end, float(os.environ['GOAL_RUNNER_MONOTONIC_END']))
        if not math.isfinite(mono_end):
            raise store.StoreError('invalid-monotonic-deadline')
        value = previous or dict(version=1, run=uuid.uuid4().hex, scope='script-entry',
                                 started=started, deadline=deadline, clock=now, result=None)
        value.update(deadline=deadline, clock=now, monotonic=dict(boot=boot, deadline=mono_end))
        if action == 'begin':
            value['result'] = None
        if action in ('delivered', 'incomplete'):
            value['result'] = dict(outcome=action, gate_completed=now,
                                   elapsed=mono_now-mono_start,
                                   timely=action == 'delivered' and now < deadline and mono_now < mono_end)
        elif action not in ('begin', 'observe'):
            raise store.StoreError('unknown-budget-action')
        files = {'runner.json': store._encode(value), 'runner.clock': ('%s\n' % now).encode('ascii'),
                 'runner.deadline': ('%s\n' % deadline).encode('ascii')}
        # Prepare a complete snapshot without first changing live files.
        if any(snapshot.get(name) != data for name, data in files.items()):
            updated = dict(snapshot)
            # Operation-specific retry receipts do not belong to this commit.
            updated.pop(store._CLOSE_META, None)
            updated.pop(store._MUTATION_META, None)
            updated.update(files)
            meta['views'].update({name: store._hash(data) for name, data in files.items()})
            updated[store._VIEW_META] = store._encode(meta)
            def fault(stage):
                if os.environ.get('GOAL_RUNNER_FAULT') == stage:
                    os._exit(91)
            commits.commit('runner-' + uuid.uuid4().hex, store._encode({'action': action, 'clock': now}), updated,
                           expected_head=head, fault=fault)
            # A crash here leaves a mismatched projection, never valid old time.
            store._restore_views(state, files)
        remaining = max(0, math.ceil(min(deadline-now, mono_end-time.monotonic())))
        print('%s %s %s %.9f' % (deadline, now, remaining, mono_end))
        if action in ('delivered', 'incomplete'):
            print('GOAL_LOOP: RESULT outcome=%s timing=%s scope=script-entry' %
                  (action, 'within-budget' if value['result']['timely'] else 'after-deadline' if action == 'delivered' else 'incomplete'),
                  file=sys.stderr)


if __name__ == '__main__':
    try:
        if len(sys.argv) >= 6 and sys.argv[1] == 'own':
            own(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5:])
        elif len(sys.argv) == 7 and sys.argv[1] == 'budget':
            budget(*sys.argv[2:])
        elif len(sys.argv) == 3 and sys.argv[1] == 'gate-limit':
            cap, expired = gate_limit(sys.argv[2])
            print('%s %s' % ('none' if cap is None else '%.9f' % cap, int(expired)))
        else:
            raise store.StoreError('invalid-runner-command')
    except (store.StoreError, OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        print('GOAL_LOOP: ERROR %s' % exc, file=sys.stderr)
        sys.exit(4)
