# Goal

## Acceptance criteria

- AC-1 | preserves order | check: `python3 -B -c "from ordered import dedupe; assert dedupe([2, 1, 2]) == [2, 1]"` | expected: exit=0

## Approval

approved: 3d6f7f81 2026-11-11 auto
