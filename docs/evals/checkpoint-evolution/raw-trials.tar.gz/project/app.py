from ordered import dedupe
import json,sys
json.dump(dedupe(json.load(sys.stdin)["items"]),sys.stdout)
