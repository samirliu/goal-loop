def dedupe(items):
    try:
        return list(dict.fromkeys(items))
    except TypeError:
        result = []
        for item in items:
            if item not in result:
                result.append(item)
        return result
