#!/usr/bin/env python3
"""Independently reconstruct the recorded real-proposal experiment.

Reads archived bytes and raw outputs; deliberately does not import the
experiment runner or trust its pass/status fields without reconstruction.
The independent value oracle covers this fixture's integers, strings and
lists; it does not claim arbitrary Python-object equivalence.
"""
import hashlib
import json
import math
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def oracle(items):
    def valid(value):
        return type(value) in (int, str) or type(value) is list and all(valid(v) for v in value)
    assert all(valid(v) for v in items), 'oracle domain exceeded'
    seen, output = set(), []
    for value in items:
        key = json.dumps(value, sort_keys=True, separators=(',', ':'))
        if key not in seen:
            seen.add(key)
            output.append(value)
    return output


def probability(wins, trials):
    return sum(math.comb(trials, k) for k in range(wins, trials+1)) / 2**trials


def verify(root):
    state = root/'state'
    reports = []
    measured, previous = set(), set()
    total_pairs = 0
    for path in state.glob('*/report.json'):
        report = json.loads(path.read_bytes())
        reports.append((path.parent, report))
    assert len(reports) == 4, 'expected all four attempts, including withdrawal'
    reports.sort(key=lambda item: item[1].get('holdout_evaluation', 1.5))
    statuses, holdouts = [], []
    for run, report in reports:
        frozen = json.loads((run/'protocol.json').read_bytes())
        protocol = frozen['protocol']
        for original, digest in frozen['files'].items():
            assert sha(run/'frozen'/Path(original).name) == digest
        assert sha(run/'runner.py') == report['runner_sha256']
        for name, digest in report['runtime_sources'].items():
            assert sha(run/name) == digest
        for side in ('baseline', 'candidate'):
            assert sha(state/'policies'/(report['policies'][side]+'.py')) == report['policies'][side]
        raw = [json.loads(line) for line in (run/'trials.jsonl').read_text().splitlines()]
        pair_count = 0
        for phase, record in report['phases'].items():
            ids = []
            pairs = record['pairs']
            assert len(pairs) == record['scheduled_pairs']
            for index, pair in enumerate(pairs):
                case = protocol[phase][index]
                source = run/'frozen'/case['input']
                case_id = sha(source)
                assert case_id == pair['case']
                assert pair['order'] == (['baseline', 'candidate'] if index % 2 == 0 else ['candidate', 'baseline'])
                ids.append(case_id)
                expected = oracle(json.loads(source.read_bytes())['items'])
                assert expected == json.loads((run/'frozen'/case['expected']).read_bytes())
                for side in ('baseline', 'candidate'):
                    value = pair[side]
                    output = run/('%s-%s-%s.out' % (phase, index, side))
                    assert sha(output) == value['output_sha256']
                    assert json.loads(output.read_bytes()) == expected
                    assert value['worker_exit'] == value['grader_exit'] == 0
                    assert value['elapsed'] > 0 and value['tokens'] is None and value['money'] is None
                    events = [r for r in raw if r['phase'] == phase and r['index'] == index and r['side'] == side]
                    assert len(events) == 1 and events[0]['case'] == case_id and events[0]['result'] == value
                pair_count += 1
            assert len(set(ids)) == len(ids)
            if phase == 'holdout':
                assert not previous.intersection(ids), 'reused exposed inputs'
                evaluation = report['holdout_evaluation']
                alpha = .05/(evaluation*(evaluation+1))
                assert report['holdout_alpha'] == alpha
                holdouts.append(evaluation)
            else:
                alpha = .05
            previous.update(ids); measured.update(ids)
            baseline = sum(p['baseline']['elapsed'] for p in pairs)
            candidate = sum(p['candidate']['elapsed'] for p in pairs)
            positive = sum(p['candidate']['elapsed'] < p['baseline']['elapsed'] for p in pairs)
            negative = sum(p['candidate']['elapsed'] > p['baseline']['elapsed'] for p in pairs)
            gain = (baseline-candidate)/baseline
            p = probability(positive, positive+negative)
            decision = record['decision']
            assert math.isclose(decision['cost_gain'], gain) and decision['one_sided_sign_p'] == p
            assert decision['pass'] == (gain >= protocol['minimum_cost_gain'] and p <= alpha)
        assert len(raw) == pair_count*2
        total_pairs += pair_count
        statuses.append(report['status'])
        assert report['within_budget']
    assert statuses == ['enabled', 'withdrawn', 'enabled', 'enabled']
    first, withdrawn, repaired, transfer = [r for _, r in reports]
    assert withdrawn['policies']['candidate'] == first['enabled']
    assert withdrawn['enabled'] == first['policies']['baseline']
    assert repaired['enabled'] != first['enabled']
    assert repaired['enabled'] == transfer['enabled']
    assert set(json.loads((state/'used-holdout.json').read_bytes())) == measured
    assert holdouts == [1, 2, 3]
    assert json.loads((state/'statistical-budget.json').read_bytes())['evaluations'] == 3
    selected = json.loads((state/'enabled.json').read_bytes())
    assert selected['policy'] == repaired['enabled'] == sha(state/selected['program'])
    original = json.loads((root/'frozen-before-proposal.json').read_bytes())
    assert all(sha(root/'initial'/name) == digest for name, digest in original.items())
    return dict(verified=True, attempts=4, pairs=total_pairs, raw_outputs=total_pairs*2,
                measured_inputs=len(measured), holdout_evaluations=holdouts, selected=selected['policy'])


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1])), indent=2))
