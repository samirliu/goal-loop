def dedupe(items):
    """Keep the first JSON value; index hashables without quadratic scans."""
    indexed = set()
    composite = []
    output = []
    for value in items:
        try:
            hash(value)
        except TypeError:
            if value not in composite:
                composite.append(value)
                output.append(value)
        else:
            if value not in indexed:
                indexed.add(value)
                output.append(value)
    return output
