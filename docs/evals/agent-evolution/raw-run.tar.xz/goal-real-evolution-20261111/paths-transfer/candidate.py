def dedupe(items):
    """Preserve JSON equality/order without indexing raw numeric hashes."""
    indexed = set()
    composite = []
    output = []
    for value in items:
        if isinstance(value, int):
            key = 'n:%s/1' % int(value)
        elif isinstance(value, float):
            try:
                numerator, denominator = value.as_integer_ratio()
                key = 'n:%s/%s' % (numerator, denominator)
            except OverflowError:
                key = 'f:' + repr(value)
            except ValueError:
                key = ('nan-object', id(value))
        elif isinstance(value, str):
            key = 's:' + value
        elif value is None:
            key = 'null'
        else:
            key = None
        if key is None:
            if value not in composite:
                composite.append(value)
                output.append(value)
        elif key not in indexed:
            indexed.add(key)
            output.append(value)
    return output
import json,sys
json.dump(dedupe(json.load(sys.stdin)["items"]),sys.stdout)
