# No built-in candidate: actual proposal is supplied after freezing inputs.
