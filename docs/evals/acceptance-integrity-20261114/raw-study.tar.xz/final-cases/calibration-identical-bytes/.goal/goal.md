# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | expected: judged

## Approval

approved: PENDING
