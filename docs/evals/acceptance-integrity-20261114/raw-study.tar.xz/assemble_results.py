import json,re,shutil
from pathlib import Path
root=Path('/Users/m/repo/goal-loop');w=Path(__file__).resolve().parent;out=root/'docs/evals/acceptance-integrity-20261114'
def load(p):return json.loads(p.read_bytes())
def save(name,data):(out/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def need(ok,message):
 if not ok:raise ValueError(message)
records=[];full=[];optimized=[];static=[]
for platform in ['macos','linux']:
 for group in ['full','focused','shell']:
  meta=w/('final-'+platform+'-'+group+'-checks.json');rows=load(meta)
  for row in rows:
   need(row['result']==0,'failed final validation '+row['log']);raw=(w/row['log']).read_text();row=dict(row,platform=platform,archive_log=row['log']);records.append(row)
   if group in ['full','focused']:
    match=re.search(r'^Ran (\d+) tests in ([\d.]+)s$',raw,re.M);need(match is not None,'missing unittest footer')
    skips=re.findall(r"^test_.*skipped '([^']+)'$",raw,re.M)
    expected=454 if group=='full' else 38
    need(int(match[1])==expected and re.search(r'^OK(?: \(skipped=2\))?$',raw,re.M),'incorrect final test result')
    need(len(skips)==(2 if platform=='linux' and group=='full' else 0),'unexpected skips')
    if skips:need(all('actual hard RLIMIT_NOFILE prevents inheriting infinity'==x for x in skips),'unexpected skip reason')
    row.update(tests=expected,unittest_seconds=float(match[2]),skipped=len(skips),skip_reasons=skips)
    (full if group=='full' else optimized).append(row)
   else:
    patterns={'scenarios':('== total: pass=603 fail=0 shards=6 ==',603),'parser':('== goal_parse unit: pass=81 fail=0 ==',81),'companion':('== fixtures: pass=10 fail=0 ==',10)}
    if row['check'] in patterns:
     token,count=patterns[row['check']];need(token in raw,'missing scenario/fixture footer');row['checks']=count
    static.append(row)
fullrows={};afterrows={}
for folder in ['baseline-cases','baseline-extra-complete','quoted-baseline']:
 for r in load(w/folder/'results.json'):fullrows[r['case']]=r
for folder in ['final-v2-cases','final-v2-extra','quoted-after']:
 for r in load(w/folder/'results.json'):afterrows[r['case']]=r
need(set(fullrows)==set(afterrows) and len(fullrows)==17,'comparison omitted cases')
comparison=[dict(case=name,before_result=fullrows[name]['result'],before_accepted=fullrows[name]['accepted'],after_result=afterrows[name]['result'],after_accepted=afterrows[name]['accepted']) for name in fullrows]
need(sum(r['before_accepted'] and not r['after_accepted'] for r in comparison)==15,'incorrect negative comparison count')
save('comparison.json',comparison)
validation=dict(version=1,base='2a682b1',all_required_final_checks_passed=True,scope='Observed acceptance counterexamples and protocol regressions; no universal semantic/efficiency/native-lifecycle claim.',full_python=full,optimized_new_regressions=optimized,shell_and_static=static,comparison_cases=17,false_acceptances_now_rejected=15,controls=2,independent_forward_reviews=2,
 source_note=load(w/'validation-fixture-delta.json'),
 development_attempts=[dict(records='initial-checks.json',observations='Negative numeric floor routed to judged; fixed signed-decimal routing. Preserved stricter checkpoint error priority. An initial unfrozen run also encountered a concurrent-edit syntax error, excluded from final results.'),dict(records='development-validation/',observations='macOS cache query-count regressions exposed /var vs /private/var alias; fixed canonical physical project identity. Missing calibration file now retains actionable broken-instrument routing.'),dict(records='before-quoted-fix-validation/',observations='Full runs interrupted after a new actual quoted-path false acceptance; shared tokenizer repaired before final runs.'),dict(records='forge-fixture-development-validation/',observations='Legacy forge-only test fixture unintentionally removed following brief bindings. Fixed only the fixture, preserved all assertions and added retention verification; complete suites restarted.')],
 limitations=['Linux shellcheck ran against identical source; native macOS shellcheck was unavailable, while native Bash 3.2 syntax and runtime suites passed.',
 'The 38-case optimized suites ran in an optimized test interpreter; subprocesses keep the documented real CLI arguments.',
 'Independent reviews and the controlled settlement fixture do not establish real external approval, full host lifecycle, task construction efficiency or arbitrary semantic coverage.',
 'Preexisting approvals without brief/calibration bindings require normal amendment/approval and fresh actual observations. No historical hash/grade was fabricated.'])
save('validation.json',validation)
save('commands.json',dict(version=1,final_validation_commands=records,raw_records_in_archive=['baseline-cases/*/commands.json','baseline-extra-complete/*/commands.json','quoted-baseline/*/commands.json','final-v2-cases/*/commands.json','final-v2-extra/*/commands.json','quoted-after/*/commands.json','settlement-final-commands.json'],
 independently_reviewed_artifacts=['forward/independent-review.json','forward-settlement/independent-review.json'],note='Native independent agent reviews have no fabricated equivalent shell/model API command. All final CLI argv above were recorded by the validation runner.'))
shutil.copy2(w/'environment.json',out/'environment.json')
print(json.dumps(dict(full_python=[dict(platform=r['platform'],tests=r['tests'],skipped=r['skipped']) for r in full],optimized_tests=38,refused_counterexamples=15),indent=2))
