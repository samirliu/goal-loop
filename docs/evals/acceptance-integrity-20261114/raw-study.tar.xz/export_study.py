import hashlib,json,shutil,stat,tarfile,tempfile
from pathlib import Path
root=Path('/Users/m/repo/goal-loop');work=Path(__file__).resolve().parent;out=root/'docs/evals/acceptance-integrity-20261114'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
folders=['before','baseline-cases','baseline-extra','baseline-extra-complete','fixed-cases','final-cases','final-extra','final-v2-cases','final-v2-extra','quoted-before','quoted-baseline','quoted-after','forward','forward-settlement','settlement-live','settlement-final','development-validation','before-quoted-fix-validation','forge-fixture-development-validation']
with tempfile.TemporaryDirectory(prefix='goal-acceptance-export-') as tmp:
 bundle=Path(tmp)
 for name in folders:
  shutil.copytree(work/name,bundle/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
 for p in sorted(work.iterdir()):
  if not p.is_file() or p.suffix not in ('.py','.json','.log'):continue
  if p.name.startswith('final-') and '-full-' in p.name and not (work/(p.name.split('-full-')[0]+'-full-checks.json')).exists():continue
  shutil.copy2(p,bundle/p.name)
 names=[]
 for folder in ['scripts','tests','assets','references','agents']:
  names += [p.relative_to(root).as_posix() for p in (root/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store' and p.suffix!='.pyc']
 names += ['SKILL.md','README.md','VERSION','.gitignore','.github/workflows/ci.yml']
 source_manifest={}
 for name in sorted(names):
  src=root/name;dst=bundle/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);source_manifest[name]=dict(sha256=sha(dst),mode=stat.S_IMODE(dst.stat().st_mode),bytes=dst.stat().st_size)
 save(bundle/'source-manifest.json',source_manifest)
 frozen=json.loads((work/'validated-runtime-manifest.json').read_bytes())
 if any(sha(bundle/'source'/name)!=checksum for name,checksum in frozen.items()):raise SystemExit('runtime drift while exporting')
 index={p.relative_to(bundle).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(bundle.rglob('*')) if p.is_file()}
 save(bundle/'file-manifest.json',index)
 archive=out/'raw-study.tar.xz'
 with tarfile.open(archive,'w:xz') as tar:
  for p in sorted(bundle.iterdir()):tar.add(p,arcname=p.name)
 save(out/'archive.json',dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size))
 save(out/'source-manifest.json',source_manifest)
 for name in ['validated-runtime-manifest.json','validation-fixture-delta.json','settlement-final-result.json']:
  shutil.copy2(work/name,out/name)
 print(json.dumps(dict(archive_bytes=archive.stat().st_size,source_files=len(source_manifest),raw_files=len(index))))
