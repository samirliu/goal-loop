"""Controlled production-entry acceptance counterexamples, not semantic model grades."""
import hashlib,json,subprocess,sys
from pathlib import Path
SCRIPTS=Path(sys.argv[1]).resolve()/"scripts"
OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
class Case:
 def __init__(self,name):
  self.root=OUT/name;self.root.mkdir();self.records=[];self.run("ctl","init")
  (self.root/"answer.txt").write_text("ready\n")
  (self.root/"good.txt").write_text("known good\n");(self.root/"bad.txt").write_text("known bad\n")
  (self.root/".goal/work-plan.md").write_text("- [x] T1 | deliver answer | files=answer.txt\n")
 def run(self,kind,*args,input=None):
  cmd=["bash",str(SCRIPTS/("goal_ctl.sh" if kind=="ctl" else "goal_gate.sh")),*args,"--project",str(self.root)]
  r=subprocess.run(cmd,input=input,text=True,capture_output=True,timeout=40)
  self.records.append(dict(command=cmd,result=r.returncode,stdout=r.stdout,stderr=r.stderr));return r
 def author(self,rows,extra=""):
  (self.root/".goal/goal.md").write_text("# Goal\n\n## Objective\n\nDeliver the complete requested report.\n\n"+extra+"\n## Acceptance criteria\n\n"+"\n".join(rows)+"\n\n## Approval\n\napproved: PENDING\n")
 def stamp(self):return self.run("ctl","stamp","--auto")
 def bind(self,identity="AC-1",status="PASS",calib=True,wrong_hash=False):
  d=self.run("gate","--digest").stdout.strip();rows=[]
  for label,verdict,path in [(identity,status,"answer.txt")]+([(identity+"#good","PASS","good.txt"),(identity+"#bad","FAIL","bad.txt")] if calib and status=="PASS" else []):
   ev="PROBE=actual-read REASON=controlled unavailable horizon" if verdict=="UNVERIFIABLE" else "controlled seat fixture artifact: "+path+" digest: "+("0"*64 if wrong_hash and "#" in label else hashlib.sha256((self.root/path).read_bytes()).hexdigest())
   rows.append("|".join([label,verdict,"1",d,"controlled-seat-fixture",ev]))
  return self.run("ctl","bind",input="\n".join(rows)+"\n")
 def close(self,passes=1,unverified=0,score=None):
  args=["close-iteration","--task","T1","--files","answer.txt","--checks-pass",str(passes),"--checks-fail","0","--checks-unverifiable",str(unverified),"--progress","yes","--exit-signal","yes","--adversarial","clear","--adversarial-note","Controlled adversarial fixture exercising declared acceptance requirements.","--receipt"]
  if score is not None:args += ["--score",str(score),"--strategy","observed"]
  return self.run("ctl",*args)
 def done(self):
  last=self.records[-1];result=dict(case=self.root.name,result=last["result"],accepted='"completion_verified":true' in last["stdout"].replace(" ",""),stdout=last["stdout"],stderr=last["stderr"])
  (self.root/"commands.json").write_text(json.dumps(self.records,indent=2)+"\n");return result
J="- AC-1 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | expected: judged"
F="- AC-1 | report is present | check: `grep -qx ready answer.txt` | expected: exit=0"
results=[]
c=Case("duplicate-ac-id-control");c.author([F.replace("grep -qx ready answer.txt","false"),F])
if c.stamp().returncode==0:c.close()
results.append(c.done())
c=Case("external-cache-from-previous-artifact");(c.root/"external.py").write_text("from pathlib import Path\np=Path('.goal/evidence/calls');p.write_text(str(int(p.read_text())+1) if p.exists() else '1')\nraise SystemExit(int(Path('.goal/evidence/status').read_text()))\n");(c.root/".goal/evidence/status").write_text("0")
c.author([F.replace("grep -qx ready answer.txt","test -s answer.txt").replace("| expected:","| external: `python3 external.py` | window: 3600 | expected:")])
if c.stamp().returncode==0:
 c.close();(c.root/"answer.txt").write_text("updated version awaits external review\n");(c.root/".goal/evidence/status").write_text("75");c.close()
row=c.done();row['external_calls']=(c.root/".goal/evidence/calls").read_text() if (c.root/".goal/evidence/calls").exists() else "0";results.append(row)
c=Case("conflicting-calibration-grades");c.author([J])
if c.stamp().returncode==0:
 d=c.run("gate","--digest").stdout.strip();sha=hashlib.sha256((c.root/"bad.txt").read_bytes()).hexdigest()
 c.run("ctl","bind",input="|".join(["AC-1#bad","PASS","1",d,"controlled-seat-fixture","artifact: bad.txt digest: "+sha])+"\n");c.bind();c.close()
results.append(c.done())
for name,value,expected in [("fractional-metric-promoted",".5",">=1"),("scientific-metric-truncated","1e3","<=2"),("nonnumeric-metric-prefix","1junk","<=2")]:
 c=Case(name);(c.root/"value.txt").write_text("value="+value+"\n");c.author(["- AC-1 | measured value | check: `cat value.txt` | metric: `value=(.*)` | expected: "+expected])
 if c.stamp().returncode==0:c.close()
 results.append(c.done())
(OUT/"results.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps([{k:r[k] for k in ("case","result","accepted","external_calls") if k in r} for r in results],indent=2))
