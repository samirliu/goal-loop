# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report is present | check: `false` | expected: exit=0
- AC-1 | report is present | check: `grep -qx ready answer.txt` | expected: exit=0

## Approval

approved: 505891b6 2026-11-14 auto
