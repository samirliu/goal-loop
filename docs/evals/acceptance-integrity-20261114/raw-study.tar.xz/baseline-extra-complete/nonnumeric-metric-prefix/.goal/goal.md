# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | measured value | check: `cat value.txt` | metric: `value=(.*)` | expected: <=2

## Approval

approved: 999caf13 2026-11-14 auto
