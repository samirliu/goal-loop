from pathlib import Path
p=Path('.goal/evidence/calls');p.write_text(str(int(p.read_text())+1) if p.exists() else '1')
raise SystemExit(int(Path('.goal/evidence/status').read_text()))
