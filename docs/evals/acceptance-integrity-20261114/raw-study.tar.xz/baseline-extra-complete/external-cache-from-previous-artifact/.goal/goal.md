# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report is present | check: `test -s answer.txt` | external: `python3 external.py` | window: 3600 | expected: exit=0

## Approval

approved: fb1ee8b8 2026-11-14 auto
