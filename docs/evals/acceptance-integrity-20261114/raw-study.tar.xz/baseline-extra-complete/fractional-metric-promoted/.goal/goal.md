# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | measured value | check: `cat value.txt` | metric: `value=(.*)` | expected: >=1

## Approval

approved: 3c0d3530 2026-11-14 auto
