# Goal

## Objective

Deliver the complete requested report.

objective: maximize AC-1
horizon-waived: controlled single metric fixture

## Acceptance criteria

- AC-1 | speed | check: `cat measurement.txt` | metric: `score=([-0-9.]+)` | var: `spread=([-0-9.]+)` | expected: maximize

## Approval

approved: 1eff1b68 2026-11-14 auto
