# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report is present | check: `grep -qx ready answer.txt` | external: `python3 external.py` | window: 0 | expected: exit=0

## Approval

approved: 41b764c8 2026-11-14 auto
