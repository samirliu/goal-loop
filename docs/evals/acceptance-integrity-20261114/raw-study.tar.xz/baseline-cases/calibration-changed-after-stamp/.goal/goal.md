# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | expected: judged

## Approval

approved: 04d5d4f8 2026-11-14 auto
