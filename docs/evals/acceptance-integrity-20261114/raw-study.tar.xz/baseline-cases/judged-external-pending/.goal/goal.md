# Goal

## Objective

Deliver the complete requested report.


## Acceptance criteria

- AC-1 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | external: `python3 external.py` | window: 0 | expected: judged

## Approval

approved: 785665c3 2026-11-14 auto
