# Goal

## Objective

Deliver the complete requested report.

objective: maximize AC-1

## Acceptance criteria

- AC-1 | speed | check: `echo 10` | expected: maximize
- AC-2 | report is present | check: `grep -qx ready answer.txt` | expected: exit=0
- AC-3 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | expected: judged

## Approval

approved: 8fd6870a 2026-11-14 auto
