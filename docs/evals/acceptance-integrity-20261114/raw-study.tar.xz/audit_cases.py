"""Controlled production-entry acceptance counterexamples, not semantic model grades."""
import hashlib,json,subprocess,sys
from pathlib import Path
SCRIPTS=Path(sys.argv[1]).resolve()/"scripts"
OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
class Case:
 def __init__(self,name):
  self.root=OUT/name;self.root.mkdir();self.records=[];self.run("ctl","init")
  (self.root/"answer.txt").write_text("ready\n")
  (self.root/"good.txt").write_text("known good\n");(self.root/"bad.txt").write_text("known bad\n")
  (self.root/".goal/work-plan.md").write_text("- [x] T1 | deliver answer | files=answer.txt\n")
 def run(self,kind,*args,input=None):
  cmd=["bash",str(SCRIPTS/("goal_ctl.sh" if kind=="ctl" else "goal_gate.sh")),*args,"--project",str(self.root)]
  r=subprocess.run(cmd,input=input,text=True,capture_output=True,timeout=40)
  self.records.append(dict(command=cmd,result=r.returncode,stdout=r.stdout,stderr=r.stderr));return r
 def author(self,rows,extra=""):
  (self.root/".goal/goal.md").write_text("# Goal\n\n## Objective\n\nDeliver the complete requested report.\n\n"+extra+"\n## Acceptance criteria\n\n"+"\n".join(rows)+"\n\n## Approval\n\napproved: PENDING\n")
 def stamp(self):return self.run("ctl","stamp","--auto")
 def bind(self,identity="AC-1",status="PASS",calib=True,wrong_hash=False):
  d=self.run("gate","--digest").stdout.strip();rows=[]
  for label,verdict,path in [(identity,status,"answer.txt")]+([(identity+"#good","PASS","good.txt"),(identity+"#bad","FAIL","bad.txt")] if calib and status=="PASS" else []):
   ev="PROBE=actual-read REASON=controlled unavailable horizon" if verdict=="UNVERIFIABLE" else "controlled seat fixture artifact: "+path+" digest: "+("0"*64 if wrong_hash and "#" in label else hashlib.sha256((self.root/path).read_bytes()).hexdigest())
   rows.append("|".join([label,verdict,"1",d,"controlled-seat-fixture",ev]))
  return self.run("ctl","bind",input="\n".join(rows)+"\n")
 def close(self,passes=1,unverified=0,score=None):
  args=["close-iteration","--task","T1","--files","answer.txt","--checks-pass",str(passes),"--checks-fail","0","--checks-unverifiable",str(unverified),"--progress","yes","--exit-signal","yes","--adversarial","clear","--adversarial-note","Controlled adversarial fixture exercising declared acceptance requirements.","--receipt"]
  if score is not None:args += ["--score",str(score),"--strategy","observed"]
  return self.run("ctl",*args)
 def done(self):
  last=self.records[-1];result=dict(case=self.root.name,result=last["result"],accepted='"completion_verified":true' in last["stdout"].replace(" ",""),stdout=last["stdout"],stderr=last["stderr"])
  (self.root/"commands.json").write_text(json.dumps(self.records,indent=2)+"\n");return result
J="- AC-1 | report matches original data | check: `cat answer.txt` | calib: good=good.txt bad=bad.txt | expected: judged"
F="- AC-1 | report is present | check: `grep -qx ready answer.txt` | expected: exit=0"
results=[]
for name in ["calibration-identical-bytes","calibration-changed-after-stamp","calibration-unbound-hash","calibration-positive"]:
 c=Case(name);c.author([J])
 if name=="calibration-identical-bytes":(c.root/"bad.txt").write_bytes((c.root/"good.txt").read_bytes())
 if c.stamp().returncode==0:
  if name=="calibration-changed-after-stamp":(c.root/"bad.txt").write_text("different unapproved anchor\n")
  c.bind(wrong_hash=name=="calibration-unbound-hash");c.close()
 results.append(c.done())
c=Case("unverified-optimization-horizon");c.author(["- AC-1 | speed | check: `echo 10` | expected: maximize",F.replace("AC-1","AC-2"),J.replace("AC-1","AC-3")],"objective: maximize AC-1\n")
if c.stamp().returncode==0:c.bind("AC-3","UNVERIFIABLE");c.close(2,1,10)
results.append(c.done())
c=Case("judged-external-pending");(c.root/"external.py").write_text("from pathlib import Path\np=Path('.goal/evidence/calls');p.write_text(str(int(p.read_text())+1) if p.exists() else '1')\nraise SystemExit(75)\n")
c.author([J.replace("| expected:","| external: `python3 external.py` | window: 0 | expected:")])
if c.stamp().returncode==0:c.bind();c.close()
row=c.done();row['external_calls']=(c.root/".goal/evidence/calls").read_text() if (c.root/".goal/evidence/calls").exists() else "0";results.append(row)
c=Case("external-checker-replaced");(c.root/"external.py").write_text("raise SystemExit(75)\n");c.author([F.replace("| expected:","| external: `python3 external.py` | window: 0 | expected:")])
if c.stamp().returncode==0:(c.root/"external.py").write_text("raise SystemExit(0)\n");c.close()
results.append(c.done())
c=Case("original-objective-reworded");c.author([F]);
if c.stamp().returncode==0:
 p=c.root/".goal/goal.md";p.write_text(p.read_text().replace("Deliver the complete requested report.","Deliver any placeholder; omit the requested content."));c.close()
results.append(c.done())
for label,field in [("negative-standard-deviation","sd"),("negative-variance","var")]:
 c=Case(label);(c.root/"measurement.txt").write_text("score=10\nspread=1\n")
 c.author(["- AC-1 | speed | check: `cat measurement.txt` | metric: `score=([-0-9.]+)` | "+field+": `spread=([-0-9.]+)` | expected: maximize"],"objective: maximize AC-1\nhorizon-waived: controlled single metric fixture\n")
 if c.stamp().returncode==0:
  c.close(score=10);(c.root/"measurement.txt").write_text("score=1\nspread=-10000\n");c.close(score=1)
 results.append(c.done())
(OUT/"results.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps([{k:r[k] for k in ("case","result","accepted","external_calls") if k in r} for r in results],indent=2))
