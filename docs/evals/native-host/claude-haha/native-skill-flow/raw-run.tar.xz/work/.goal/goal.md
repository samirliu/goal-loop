# Goal contract - implement solution.merge_ranges per TASK.md

Status: APPROVED

## Objective

Implement `solution.merge_ranges(ranges)` exactly as TASK.md specifies: take a
list of [start, end] half-open integer intervals, reject bools, non-integers,
malformed pairs and start>end with ValueError, ignore empty intervals, return a
sorted list of nonempty [start, end] lists that merges overlaps and touching
endpoints, preserve the input, and support negative and arbitrarily large
integer bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | The frozen public acceptance script passes | check: `python3 -B public.py` | expected: exit=0
- AC-2 | The edge-case suite passes: ValueError for bool bounds, non-integer bounds, malformed pairs and start>end; empty intervals ignored; overlaps and touching endpoints merged; output is a sorted list of nonempty [start, end] int lists; the input is not mutated; negative and 10^30-scale bounds are handled | check: `python3 -B test_solution.py` | expected: exit=0

## Out of scope

- Edits to TASK.md, public.py, the installed goal-loop skill, or any other repository
- Third-party dependencies, network access, MCP tools, or model overrides
- Behavior beyond the frozen TASK.md contract (no optimization objective, so no `objective:` line)

## Budget knobs

max_iterations=12  no_progress_limit=2  max_replans=2
per_check_fail_cap=3  panel_max=4  dry_limit=3  check_timeout=120

## Approval

Approval mode: auto

approved: 7dc1a382 2026-11-12 auto
