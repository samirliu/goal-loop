# work-plan (controller ticks; NEVER a GO signal)

# format: - [ ] T1 <scope> | owner=<name> | files=<paths>
# done:   - [x] T1 ...

- [x] T1 implement merge_ranges and its edge-case suite | owner=controller | files=solution.py,test_solution.py
