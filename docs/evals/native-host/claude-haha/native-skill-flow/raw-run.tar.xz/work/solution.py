def merge_ranges(ranges):
    """Merge half-open integer intervals.

    Input is an iterable of [start, end] pairs describing half-open
    intervals [start, end).  Overlapping and touching intervals are merged
    into the smallest covering set of nonempty intervals; empty intervals
    (start == end) are ignored.  The result is a sorted list of [start, end]
    lists.

    Malformed input (bool or non-integer bounds, pairs that are not
    two-element sequences, start > end) raises ValueError.  The input is
    never modified.
    """
    if isinstance(ranges, (str, bytes)):
        raise ValueError("ranges must be an iterable of [start, end] pairs")
    try:
        pairs = list(ranges)
    except TypeError:
        raise ValueError(
            "ranges must be an iterable of [start, end] pairs"
        ) from None

    intervals = []
    for pair in pairs:
        if not isinstance(pair, (list, tuple)):
            raise ValueError("each range must be a [start, end] pair")
        if len(pair) != 2:
            raise ValueError("each range must have exactly two elements")
        start, end = pair
        for bound in (start, end):
            if isinstance(bound, bool) or not isinstance(bound, int):
                raise ValueError("range bounds must be integers, not bools")
        if start > end:
            raise ValueError("range start must not be greater than end")
        if start == end:
            continue  # empty interval: ignored entirely
        intervals.append((start, end))

    intervals.sort()

    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
