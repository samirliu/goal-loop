"""Edge-case suite for solution.merge_ranges.

Covers the whole TASK.md contract: validation errors, empty-interval
handling, overlap/touch merging, ordering, negative and arbitrarily large
bounds, input preservation and output shape.
"""
import copy

from solution import merge_ranges


def _expect_value_error(payload):
    try:
        merge_ranges(payload)
    except ValueError:
        return
    except Exception as exc:  # wrong error type is still a failure
        raise AssertionError(
            "expected ValueError for %r, got %s: %s"
            % (payload, type(exc).__name__, exc)
        )
    raise AssertionError("expected ValueError for %r, got no error" % (payload,))


# --- happy paths ------------------------------------------------------------
assert merge_ranges([]) == []
assert merge_ranges([[1, 3]]) == [[1, 3]]
assert merge_ranges([[1, 3], [2, 5]]) == [[1, 5]]            # overlap
assert merge_ranges([[1, 4], [4, 8]]) == [[1, 8]]            # touching
assert merge_ranges([[1, 3], [4, 8]]) == [[1, 3], [4, 8]]     # gap
assert merge_ranges([[1, 10], [3, 5]]) == [[1, 10]]           # containment
assert merge_ranges([[1, 3], [1, 3]]) == [[1, 3]]             # duplicate
assert merge_ranges([[5, 5]]) == []                          # empty interval
assert merge_ranges([[5, 5], [1, 2]]) == [[1, 2]]             # empty ignored
assert merge_ranges([[9, 9], [7, 8]]) == [[7, 8]]             # empty ignored

# ordering: unsorted input comes back sorted
assert merge_ranges([[9, 12], [1, 3], [4, 6]]) == [[1, 3], [4, 6], [9, 12]]
assert merge_ranges([[2, 3], [1, 10]]) == [[1, 10]]

# --- negative and arbitrarily large bounds ----------------------------------
assert merge_ranges([[-4, -1]]) == [[-4, -1]]
assert merge_ranges([[-5, -3], [-4, -1]]) == [[-5, -1]]
assert merge_ranges([[-10, -2], [0, 5]]) == [[-10, -2], [0, 5]]
big = 10 ** 30
assert merge_ranges([[big, big + 2]]) == [[big, big + 2]]
assert merge_ranges([[big, big + 2], [big + 1, big + 5]]) == [[big, big + 5]]
assert merge_ranges([[-big - 5, -big]]) == [[-big - 5, -big]]
assert merge_ranges([[0, 2 ** 70], [2 ** 70, 2 ** 70 + 1]]) == [[0, 2 ** 70 + 1]]

# --- validation -------------------------------------------------------------
for bad in (
    [[3, 1]],            # start > end
    [[True, 4]],         # bool bound
    [[4, True]],         # bool bound
    [[1, 2, 3]],         # malformed pair (too long)
    [[1]],               # malformed pair (too short)
    [[]],                # malformed pair (empty)
    [5],                 # not a pair
    ["ab"],              # not a pair
    [[1, 2.5]],          # non-integer bound
    [[1.0, 2]],          # non-integer bound
    [["1", "2"]],        # non-integer bound
    [[None, 2]],         # non-integer bound
    [[1, 2], [3, 1]],    # invalid pair anywhere in the list
    [True, False],       # bool bounds
):
    _expect_value_error(bad)

_expect_value_error(None)
_expect_value_error(5)
_expect_value_error("ab")

# --- input preservation -----------------------------------------------------
original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
snapshot = copy.deepcopy(original)
result = merge_ranges(original)
assert original == snapshot, "input was mutated: %r" % (original,)
assert result == [[-4, -1], [1, 8]]

nested = [[1, 2], [3, 4]]
before = [list(pair) for pair in nested]
merge_ranges(nested)
assert nested == before, "inner pairs were mutated"

# --- output shape -----------------------------------------------------------
out = merge_ranges([[1, 3], [4, 6]])
assert isinstance(out, list), type(out)
for item in out:
    assert isinstance(item, list), type(item)
    assert len(item) == 2
    for bound in item:
        assert isinstance(bound, int) and not isinstance(bound, bool)
assert out == sorted(out)

# tuples are accepted as pairs
assert merge_ranges([(1, 4), (4, 8)]) == [[1, 8]]

print("LOCAL PASS")
