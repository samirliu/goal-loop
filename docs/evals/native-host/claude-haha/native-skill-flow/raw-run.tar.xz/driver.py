"""One black-box skill invocation; no prebuilt contract, tickets or waves."""
import time
ENTRY, EPOCH = time.monotonic(), time.time()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import shutil
import subprocess
import sys
import tempfile
import uuid

ROOT=Path('/Users/m/repo/goal-loop')
CLI=Path('/Users/m/repo/workspace/claude-code-haha/bin/claude-haha')
SECONDS=360
base=Path(tempfile.mkdtemp(prefix='goal-native-skill-flow-',dir='/tmp'))
work,control=base/'work',base/'control';control.mkdir()
Path('/tmp/goal-native-skill-flow-path.txt').write_text(str(base)+'\n')
def save(name,value): (base/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);return v
tasks=module('flow_tasks',ROOT/'examples/agent-evals/tasks.py')
parser=module('flow_parser',Path('/tmp/goal_w5_claude_headless_v3.py'))
tasks.prepare(work,'small',911207)
shutil.copy2('/tmp/goal-p1-final-20261112-closed/source/examples/agent-evals/grade.py',control/'grade.py')
shutil.copy2(Path(__file__),base/'driver.py')
shutil.copy2('/tmp/goal_w5_claude_headless_v3.py',base/'stream-parser.py.txt')
(control/'mcp.json').write_text('{"mcpServers":{}}\n')
inputs={n:sha(work/n) for n in ('TASK.md','public.py')}
sources={}
for folder in ('scripts','agents','references','hooks','.claude-plugin'):
 for p in (ROOT/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:
   target=base/'sources'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
   sources[str(p.relative_to(ROOT))]=sha(p)
shutil.copy2(ROOT/'SKILL.md',base/'sources/SKILL.md');sources['SKILL.md']=sha(ROOT/'SKILL.md')
session=str(uuid.uuid4())
prompt=('/goal-loop-host:goal-loop --auto --time-budget=360 Complete TASK.md in the current project '+str(work)+
 '. The user authorizes automatic contract stamping and execution; do not request approval again. '
 'TASK.md and public.py are frozen inputs. Modify only solution.py, optional tests, and this project .goal metadata. '
 'Do not modify the installed skill or any other repository, and do not use web, MCP, dependencies or model overrides. '
 'Use the skill normal completion conditions and report the resulting evidence.')
command=[str(CLI),'--permission-mode','bypassPermissions','--print','--no-session-persistence',
 '--session-id',session,'--plugin-dir',str(ROOT),'--output-format','stream-json','--verbose','--include-hook-events',
 '--max-turns','40','--tools','Agent,Read,Grep,Glob,Write,Edit,Bash','--strict-mcp-config',
 '--mcp-config',str(control/'mcp.json'),'--',prompt]
end=ENTRY+SECONDS
bounded=[sys.executable,'-I',str(ROOT/'scripts/goal_bounded.py'),'--owner',str(os.getpid()),
 '--seconds',str(max(0,end-time.monotonic())),'--deadline-epoch',str(EPOCH+SECONDS),'--',*command]
save('manifest.json',dict(scope='Actual skill command; model owns contract/dispatch/close/gate',entry_monotonic=ENTRY,
 entry_epoch=EPOCH,seconds=SECONDS,session=session,command=command,bounded=bounded,inputs=inputs,
 sources=sources,grader_sha256=sha(control/'grade.py'),initial_goal_exists=(work/'.goal').exists()))
env=dict(os.environ,GOAL_RUNNER_MONOTONIC_END=str(end))
error=(base/'stderr.txt').open('wb');log=(base/'events.jsonl').open('a')
proc=subprocess.Popen(bounded,cwd=work,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=error)
selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ)
os.set_blocking(proc.stdout.fileno(),False);buffer=b'';failure=None
def observe(line):
 if not line.strip(): return
 v=parser.filtered(json.loads(line))
 if v is not None:
  v['observed_monotonic']=time.monotonic();log.write(json.dumps(v,sort_keys=True)+'\n');log.flush()
try:
 while proc.poll() is None and time.monotonic()<end+2:
  for key,_ in selector.select(.2):
   chunk=os.read(key.fd,65536)
   if not chunk: selector.unregister(key.fileobj);continue
   buffer+=chunk
   while b'\n' in buffer:
    line,buffer=buffer.split(b'\n',1);observe(line)
 if proc.poll() is None: proc.terminate()
 proc.wait(timeout=5)
 while True:
  try: chunk=os.read(proc.stdout.fileno(),65536)
  except BlockingIOError: break
  if not chunk: break
  buffer+=chunk
 for line in buffer.splitlines(): observe(line)
except BaseException as exc:
 failure=repr(exc)
 if proc.poll() is None: proc.terminate()
 try: proc.wait(timeout=5)
 except subprocess.TimeoutExpired: failure+='; teardown-unknown'
finally:
 selector.close();log.close();error.close()
report=dict(cli_returncode=proc.poll(),error=failure,cli_elapsed=time.monotonic()-ENTRY,
 input_changed=[n for n,v in inputs.items() if not (work/n).is_file() or sha(work/n)!=v],
 source_changed=[n for n,v in sources.items() if sha(ROOT/n)!=v],checks={},tokens=None,money=None)
save('report.json',report)
if proc.poll() is not None:
 for name,args in (
  ('independent',[sys.executable,'-B',str(control/'grade.py'),'--project',str(work),'--family','small','--seed','911207']),
  ('audit',['bash',str(ROOT/'scripts/goal_audit.sh'),'--project',str(work)]),
  ('gate',['bash',str(ROOT/'scripts/goal_gate.sh'),'--check','--project',str(work)])):
  try:
   at=time.monotonic();r=subprocess.run(args,cwd=work,capture_output=True,text=True,env=env,timeout=12)
   report['checks'][name]=dict(command=args,result=r.returncode,stdout=r.stdout,stderr=r.stderr,
     start=at,end=time.monotonic(),within_original_budget=time.monotonic()<=end)
  except subprocess.TimeoutExpired:
   report['checks'][name]=dict(command=args,result=None,error='post-run validation timeout')
report['finished_elapsed']=time.monotonic()-ENTRY
save('report.json',report)
print(json.dumps(dict(path=str(base),cli_returncode=report['cli_returncode'],elapsed=report['finished_elapsed'],
 error=failure,checks={n:r['result'] for n,r in report['checks'].items()},source_changed=report['source_changed'],input_changed=report['input_changed'])))
