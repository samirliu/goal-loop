#!/usr/bin/env python3
"""DRAFT: six native Agent trials (legacy Task receipts accepted); not run."""
import time
ENTRY_EPOCH, ENTRY_MONOTONIC = time.time(), time.monotonic()
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import selectors
import shlex
import shutil
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
ROOT = Path('/Users/m/repo/goal-loop')
CLI = Path('/Users/m/repo/workspace/claude-code-haha/bin/claude-haha')
CLIENT = CLI.parent.parent
TOOLS = 'Agent,Read,Grep,Glob,Write,Edit,Bash'
NATIVE_AGENT_TOOL_NAMES = ('Agent', 'Task')
ACTIVE_BASE = None
ORDER = [('single-1', 'fused'), ('crew-1', 'crew'), ('crew-2', 'crew'),
         ('single-2', 'fused'), ('single-3', 'fused'), ('crew-3', 'crew')]
TERMINAL = {'returned', 'failed', 'cancelled'}
TASK = '''Implement the standard-library auditlog package. codec.parse_line(line) parses a JSON object,
returns only the original key and amount, requires a nonempty string key and integer amount
(bool invalid), ignores extra fields, and raises ValueError for invalid records.
aggregate.summarize(records) consumes an iterable of valid records, preserves the input,
and returns a LIST of key-sorted dicts with exactly key,count,total,min,max. Support empty
input, generators, Unicode keys, and arbitrarily large positive/negative integer amounts.
python -m auditlog --input PATH --output PATH [--skip-bad] reads UTF-8 JSONL, ignores blanks,
and outputs one JSON object per key. Strict invalid input exits 2, names the physical line
on stderr, and preserves existing output. --skip-bad stderr contains only {"skipped":N}.
Missing input exits 2. Empty input produces empty output. Publish atomically. No dependencies.
Starters: codec/aggregate raise NotImplementedError, main raises SystemExit("not implemented"), init empty.
'''

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True)+'\n')

def require(value, message):
    if not value: raise RuntimeError(message)

def is_native_agent_call(call):
    return call.get('name') in NATIVE_AGENT_TOOL_NAMES

def native_agent_protocol(batches, headers, mode):
    """One classifier for parent protocol, filtered batches and raw calls.

    Keep the exact wire name and id; Task is the client's legacy Agent alias.
    """
    task_batches = [[c for c in batch if is_native_agent_call(c)] for batch in batches]
    calls = [c for batch in task_batches for c in batch]
    ids = [c.get('id') for c in calls]
    valid = (len(calls) == len(headers)
        and all(isinstance(i, str) and i for i in ids) and len(set(ids)) == len(ids)
        and (mode != 'crew' or any(len(b) == 2 for b in task_batches))
        and all(isinstance(c.get('input'), dict)
            and c['input'].get('subagent_type') == 'goal-loop-host:goal-worker'
            and c['input'].get('run_in_background') is not True
            and 'model' not in c['input'] and 'effort' not in c['input'] for c in calls)
        and all(any(isinstance(c['input'].get('prompt'), str) and c['input']['prompt'].startswith(h)
                    for c in calls) for h in headers)
        and all(is_native_agent_call(c) for batch in batches for c in batch))
    return valid, task_batches, calls

def filtered(value):
    kind = value.get('type')
    if kind == 'assistant':
        blocks = []
        for block in value.get('message', {}).get('content', []):
            if block.get('type') == 'tool_use':
                blocks.append({k: block[k] for k in ('type', 'id', 'name', 'input') if k in block})
            elif block.get('type') == 'text':
                blocks.append({'type': 'text', 'sha256': hashlib.sha256(block.get('text', '').encode()).hexdigest()})
        message = value.get('message', {})
        return {'type': kind, 'session_id': value.get('session_id'),
                'parent_tool_use_id': value.get('parent_tool_use_id'), 'content': blocks,
                'message_id': message.get('id'), 'model': message.get('model'), 'usage': message.get('usage')}
    if kind == 'user':
        raw = value.get('tool_use_result')
        metadata = ({k: raw[k] for k in ('agentId', 'agentType', 'status', 'totalTokens',
                     'totalDurationMs', 'totalToolUseCount', 'usage') if k in raw} if isinstance(raw, dict) else None)
        tool_results = []
        for block in value.get('message', {}).get('content', []):
            if isinstance(block, dict) and block.get('type') == 'tool_result':
                content = block.get('content')
                text = (content if isinstance(content, str) else
                        [b.get('text', '') for b in content if isinstance(b, dict) and b.get('type') == 'text']
                        if isinstance(content, list) else None)
                tool_results.append(dict(tool_use_id=block.get('tool_use_id'), is_error=block.get('is_error'),
                    text_sha256=hashlib.sha256(json.dumps(text, sort_keys=True).encode()).hexdigest()))
        return {'type': kind, 'session_id': value.get('session_id'),
                'parent_tool_use_id': value.get('parent_tool_use_id'),
                'tool_use_ids': [b.get('tool_use_id') for b in value.get('message', {}).get('content', [])
                                 if isinstance(b, dict) and b.get('type') == 'tool_result'],
                'tool_use_result_metadata': metadata,
                'tool_results': tool_results,
                'message_sha256': hashlib.sha256(json.dumps(value.get('message'), sort_keys=True).encode()).hexdigest()}
    if kind == 'result':
        result = {k: value[k] for k in ('type', 'subtype', 'session_id', 'is_error', 'num_turns',
                    'usage', 'modelUsage', 'total_cost_usd', 'duration_ms', 'duration_api_ms', 'errors') if k in value}
        if isinstance(value.get('result'), str):
            result['result_sha256'] = hashlib.sha256(value['result'].encode()).hexdigest()
        return result
    if kind in ('system', 'tool_progress'):
        # Native system/hook metadata has no assistant content blocks.
        return value
    return None

def main():
    global ACTIVE_BASE
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--seconds', type=float, default=900)
    p.add_argument('--f5-ready', required=True, type=Path)
    args = p.parse_args()
    require(args.execute, 'draft only; root must deliberately activate after F5 is stable')
    ready = json.loads(args.f5_ready.read_bytes())
    require(ready.get('status') == 'ready' and ready.get('full_suites_terminal') is True
            and ready.get('owner_watch_sha256') == sha(ROOT/'scripts/goal_owner_watch.py')
            and Path(ready.get('evidence', '/missing')).is_file(), 'missing/mismatched actual F5 readiness evidence')
    require(0 < args.seconds <= 900, 'this preregistration permits at most 900 seconds')
    base = args.output.resolve(); base.mkdir(parents=True, exist_ok=False)
    ACTIVE_BASE = base
    shutil.copy2(Path(__file__), base/'driver.py')
    prereg = Path('/tmp/goal-w5-headless-prereg-20261112.md')
    if prereg.is_file(): shutil.copy2(prereg, base/'prereg.md')
    save(base/'entry.json', dict(epoch=ENTRY_EPOCH, monotonic=ENTRY_MONOTONIC, seconds=args.seconds))
    report = dict(version=1, status='preparing', tokens=None, money=None,
                  samples=[dict(case=n, mode=m, status='not-dispatched', quality=None,
                                reason='not reached; see preparation/driver records') for n, m in ORDER])
    save(base/'report.json', report)
    native = module('fixture_native', ROOT/'examples/crew-cost/native.py')
    host = native.module('headless_host', ROOT/'scripts/goal_host.py')
    tasks = native.module('headless_tasks', ROOT/'examples/agent-evals/tasks.py')
    cohort = str(uuid.uuid4())
    captured = host.capture('claude', cohort, 'tool')
    origin = dict(captured, epoch=ENTRY_EPOCH, monotonic=ENTRY_MONOTONIC)
    end, epoch_end = ENTRY_MONOTONIC+args.seconds, ENTRY_EPOCH+args.seconds
    sources = [f for f in (ROOT/'scripts').iterdir() if f.is_file() and f.suffix in ('.py', '.sh', '.awk')]
    sources += [ROOT/'SKILL.md', ROOT/'agents/goal-worker.md', ROOT/'hooks/hooks.json',
                ROOT/'.claude-plugin/plugin.json', ROOT/'examples/crew-cost/native.py',
                ROOT/'examples/crew-cost/native_checks.py', ROOT/'examples/agent-evals/tasks.py',
                ROOT/'examples/agent-evals/grade.py']
    sources += [f for folder in ('references', 'agents') for f in (ROOT/folder).rglob('*') if f.is_file()]
    sources = sorted(set(sources))
    hashes = {str(f.relative_to(ROOT)): sha(f) for f in sources}
    client_names = ['bin/claude-haha', 'preload.ts', 'package.json', 'src/entrypoints/cli.tsx',
                    'src/QueryEngine.ts', 'src/bootstrap/state.ts', 'src/cost-tracker.ts',
                    'src/utils/modelCost.ts', 'src/utils/tokens.ts', 'src/utils/messages/mappers.ts',
                    'src/tools/AgentTool/agentToolUtils.ts', 'src/tools/AgentTool/constants.ts',
                    'src/tools/AgentTool/AgentTool.tsx', 'src/utils/plugins/loadPluginCommands.ts',
                    'src/skills/loadSkillsDir.ts', 'src/utils/plugins/loadPluginAgents.ts',
                    'src/utils/plugins/loadPluginHooks.ts', 'src/utils/plugins/schemas.ts']
    client_hashes = {name: sha(CLIENT/name) for name in client_names}
    env_hash = sha(CLIENT/'.env') if (CLIENT/'.env').is_file() else None
    fingerprint = hashlib.sha256(native.encode(dict(production=hashes, client=client_hashes, env_sha256=env_hash)).encode()).hexdigest()
    for f in sources:
        target = base/'sources'/f.relative_to(ROOT); target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(f, target)
    work, control = base/'project/work', base/'project/control'; control.mkdir(parents=True)
    tasks.prepare(work, 'medium', 911207)
    shutil.copy2(ROOT/'examples/agent-evals/grade.py', control/'grade.py')
    shutil.copy2(ROOT/'examples/crew-cost/native_checks.py', control/'job_check.py')
    save(control/'mcp.json', {'mcpServers': {}})
    initial_session = host.begin(work, 'claude', cohort, args.seconds, origin)
    end, epoch_end = min(end, initial_session['deadline_monotonic']), min(epoch_end, initial_session['deadline_epoch'])
    final = [sys.executable, '-B', str(control/'grade.py'), '--project', '{project}', '--family', 'medium', '--seed', '911207']
    (work/'.goal/goal.md').write_text('# Goal\n\n## Acceptance criteria\n\n- AC-1 | complete auditlog behavior | check: `'+
        shlex.join([v.replace('{project}', '.') for v in final])+'` | expected: exit=0\n\n## Approval\n\napproved: PENDING\n')
    stamp = subprocess.run(['bash', str(ROOT/'scripts/goal_ctl.sh'), 'stamp', '--auto', '--project', str(work)],
                           capture_output=True, text=True, timeout=min(20, max(.1, end-time.monotonic())))
    save(control/'stamp.json', dict(result=stamp.returncode, stdout=stamp.stdout, stderr=stamp.stderr))
    require(stamp.returncode == 0, 'stamp failed; retain fixture and do not dispatch')
    files = list(tasks.STARTERS['medium'])
    baseline = host.crew.scope_digest(work, files)
    modes = {name: (work/name).stat().st_mode & 0o7777 for name in files}
    frozen_inputs = host.crew.scope_digest(work, ['TASK.md', 'public.py'])
    context = dict(backend='actual-claude-haha-MiniMax-M3.1-Flash-Agent-TaskAlias-hooks-v1', task='auditlog-v1',
                   comparison='single-worker-vs-native-Agent-crew', controller=cohort,
                   source_fingerprint=fingerprint, cli_entrypoint_sha256=sha(CLI),
                   model_selection='inherited-user-env-and-existing-goal-worker', declared_mapping='MiniMax-M3.1-Flash',
                   tools=TOOLS, native_tool_requested='Agent', native_receipt_names=NATIVE_AGENT_TOOL_NAMES,
                   max_turns=8, cli_budget_usd=1.0)
    graphs = {}
    for mode in ('fused', 'crew'):
        jobs = ([dict(id='T1', files=files, deps=[], check=[sys.executable, '-B', 'public.py'])] if mode == 'fused' else
            [dict(id='T1', files=[f for f in files if not f.endswith('aggregate.py')], deps=[],
                  check=[sys.executable, '-B', str(control/'job_check.py'), '{project}', 'T1']),
             dict(id='T2', files=['auditlog/aggregate.py'], deps=[],
                  check=[sys.executable, '-B', str(control/'job_check.py'), '{project}', 'T2'])])
        graph = dict(version=1, context=context, capacity=2, jobs=jobs, final_check=final,
                     instruments=['grade.py', 'job_check.py'], inputs=['TASK.md', 'public.py'])
        graphs[mode] = control/('graph-fused.json' if mode == 'fused' else 'graph.json'); save(graphs[mode], graph)
    report = dict(version=1, status='running', draft_preregistration='/tmp/goal-w5-headless-prereg-20261112.md',
        cohort=cohort, backend='claude', origin=origin, boot_captured_at=captured,
        requested_seconds=args.seconds, deadline_epoch=epoch_end, deadline_monotonic=end,
        project=str(work), source_hashes=hashes, client_source_hashes=client_hashes, user_env_sha256=env_hash,
        cli_entrypoint_sha256=sha(CLI), runtime=dict(python=sys.version, executable=sys.executable,
            platform=sys.platform, client_package_version=json.loads((CLIENT/'package.json').read_bytes()).get('version')),
        driver_sha256=sha(Path(__file__)), f5_ready=ready, order=[n for n, _ in ORDER],
        samples=[dict(case=n, mode=m, status='not-dispatched', quality=None) for n, m in ORDER],
        tokens=None, money=None, planner=None, baseline_restored=False)
    save(base/'report.json', report)

    def frozen():
        return (all(sha(ROOT/name) == value for name, value in hashes.items())
                and all(sha(CLIENT/name) == value for name, value in client_hashes.items())
                and (sha(CLIENT/'.env') if (CLIENT/'.env').is_file() else None) == env_hash)

    def settled():
        return (all(a['phase'] in TERMINAL for a in host.attempts(host.folder(work)[1]))
                and all(host.crew.load(f)['finished'] is not None for f in host.crew.folder(work).glob('*.json')))

    def reset_owned():
        require(settled(), 'active/unknown attempt or unsealed wave; refusing reset')
        sealed_paths = [base/name/'result.json' for name, _ in ORDER if (base/name/'result.json').is_file()]
        if sealed_paths:
            last = json.loads(sealed_paths[-1].read_bytes())
            require(host.crew.scope_digest(work, files) == last['final_validation']['digest'],
                    'current owned bytes/modes differ from last archived final artifact')
        require(host.crew.scope_digest(work, ['TASK.md', 'public.py']) == frozen_inputs, 'frozen input changed')
        for name, value in tasks.STARTERS['medium'].items():
            (work/name).write_text(value); (work/name).chmod(modes[name])
        require(host.crew.scope_digest(work, files) == baseline, 'baseline reset identity mismatch')

    def run_case(index, name, mode):
        nonlocal end, epoch_end
        out = base/name; out.mkdir()
        sample = report['samples'][index]; sample['round_started'] = dict(epoch=time.time(), monotonic=time.monotonic())
        if index: reset_owned()
        require(frozen(), 'source changed; refusing dispatch')
        session = str(uuid.uuid4()); observed = host.capture('claude', session, 'tool')
        remaining = end-observed['monotonic']; require(remaining > 0, 'original budget exhausted')
        bound = host.begin(work, 'claude', session, remaining, observed)
        end, epoch_end = min(end, bound['deadline_monotonic']), min(epoch_end, bound['deadline_epoch'])
        report.update(deadline_monotonic=end, deadline_epoch=epoch_end)
        wave_id = host.crew.begin(work, graphs[mode], 'inline' if mode == 'fused' else 'crew', name)
        manifest = dict(project=str(work), control=str(control), mode=mode, wave=wave_id,
                        session=bound, host_origin=observed, source_hashes=hashes)
        save(out/'manifest.json', manifest)
        wave = host.crew.Wave(work, wave_id); wave.stage('coordination', 'begin')
        jobs = json.loads(graphs[mode].read_bytes())['jobs']
        briefs = [host.prepare(work, wave_id, j['id'], session=session) for j in jobs]
        save(out/'briefs.json', briefs)
        worker_prompts = []
        for job, brief in zip(jobs, briefs):
            worker_prompts.append(brief['worker_prefix']+TASK+'\nOwn only: '+', '.join(job['files'])+'.\n'+
                'This is one package artifact. First run the exact owned ready command above. '
                'Use the owned Bash prefix for every shell tool. Edit only owned files. '
                'Read only TASK.md, public.py and owned files; do not inspect .goal, prior trials, control or private graders. '
                'Do not use research, dependencies, agents, tests outside the named check, or model overrides. '
                'Run the exact frozen check_command, repair in place if necessary, retain failures, then return immediately.\n'+
                'Frozen check_command: '+brief['check_command'])
        assignment = ('Use only the native Agent tool with subagent_type="goal-loop-host:goal-worker". '
            'Do not edit files or run Bash yourself. Do not set model/effort and do not use run_in_background. '+
            ('Issue both Agent calls in one assistant message before waiting; execute them concurrently. ' if mode == 'crew' else
             'Issue exactly one Agent call for the entire package. ')+
            'Copy each following worker prompt exactly, starting with its GOAL_HOST_TICKET header. '
            'After all synchronous Agents return, reply exactly COMPLETE.\n\n'+
            '\n\nNEXT WORKER PROMPT\n'.join(worker_prompts))
        command = [str(CLI), '--permission-mode', 'bypassPermissions', '--print', '--no-session-persistence',
            '--session-id', session, '--plugin-dir', str(ROOT), '--input-format', 'stream-json',
            '--output-format', 'stream-json', '--verbose', '--include-hook-events', '--max-turns', '8',
            '--max-budget-usd', '1.00', '--tools', TOOLS, '--strict-mcp-config',
            '--mcp-config', str(control/'mcp.json'), '--']
        env = dict(os.environ, GOAL_RUNNER_MONOTONIC_END=str(end))
        bounded = [sys.executable, '-I', str(ROOT/'scripts/goal_bounded.py'), '--owner', str(os.getpid()),
                   '--seconds', str(max(0, end-time.monotonic())), '--deadline-epoch', str(epoch_end), '--', *command]
        save(out/'command.json', dict(command=command, bounded=bounded, session=session))
        results, batches, models, task_metadata, phase = [], [], [], [], 'bootstrap'
        coordination_open, joining = True, False
        stderr = (out/'stderr.txt').open('wb'); eventlog = (out/'events.jsonl').open('a')
        proc = subprocess.Popen(bounded, cwd=work, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr)
        sample.update(status='running', session=session, cli_supervisor_pid=proc.pid, wave=wave_id)
        save(base/'report.json', report)
        selector = selectors.DefaultSelector(); selector.register(proc.stdout, selectors.EVENT_READ)
        os.set_blocking(proc.stdout.fileno(), False); buffer = b''; failure = None

        def send(prompt):
            proc.stdin.write((json.dumps(dict(type='user', message=dict(role='user', content=prompt), session_id=session))+'\n').encode())
            proc.stdin.flush()

        def receive(value):
            nonlocal phase
            clean = filtered(value)
            if clean is not None:
                clean['observed_epoch'] = time.time(); clean['observed_monotonic'] = time.monotonic()
                eventlog.write(json.dumps(clean, sort_keys=True)+'\n'); eventlog.flush()
                if clean.get('type') == 'assistant' and clean.get('model'):
                    models.append(dict(model=clean['model'], message_id=clean.get('message_id'),
                                       parent_tool_use_id=clean.get('parent_tool_use_id')))
                if clean.get('tool_use_result_metadata'):
                    task_metadata.append(dict(tool_use_ids=clean.get('tool_use_ids'),
                                              metadata=clean['tool_use_result_metadata']))
            if value.get('type') == 'assistant' and value.get('parent_tool_use_id') is None:
                calls = [b for b in value.get('message', {}).get('content', []) if b.get('type') == 'tool_use']
                if calls: batches.append([dict(id=b.get('id'), call_id=b.get('id'),
                                                name=b.get('name'), input=b.get('input')) for b in calls])
            if value.get('type') == 'result':
                results.append(filtered(value))
                if phase == 'bootstrap':
                    require(not value.get('is_error'), 'bootstrap CLI error')
                    prompt = host.session_path(host.folder(work)[1], 'claude', session, 'prompt')
                    require(prompt.is_file(), 'actual UserPromptSubmit receipt absent')
                    save(out/'prompt-receipt.json', host.load(prompt)); phase = 'assignment'; send(assignment)
                else:
                    phase = 'done'; proc.stdin.close()

        try:
            send('/goal-loop-host:goal-loop This is a preregistered native auditlog comparison. Reply exactly READY. '
                 'Do not use any tools yet. Await the next worker assignment.')
            while proc.poll() is None and time.monotonic() < end:
                for key, _ in selector.select(.1):
                    chunk = os.read(key.fd, 65536)
                    if not chunk: selector.unregister(key.fileobj); continue
                    buffer += chunk
                    while b'\n' in buffer:
                        line, buffer = buffer.split(b'\n', 1)
                        if line.strip(): receive(json.loads(line))
                rows = [host.get(host.folder(work)[1], b['ticket'])[1] for b in briefs]
                if coordination_open and all(r['agent_id'] is not None for r in rows):
                    wave.stage('coordination', 'end'); coordination_open = False
                    wave.stage('join', 'begin'); joining = True
            if proc.poll() is None:
                for brief in briefs: host.cancel(work, brief['ticket'])
                proc.terminate()
            proc.wait(timeout=5)
            while True:
                try: chunk = os.read(proc.stdout.fileno(), 65536)
                except BlockingIOError: break
                if not chunk: break
                buffer += chunk
            for line in buffer.splitlines():
                if line.strip(): receive(json.loads(line))
        except BaseException as exc:
            failure = repr(exc)
            for brief in briefs: host.cancel(work, brief['ticket'])
            if proc.poll() is None: proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: failure += '; teardown-unknown: supervisor did not exit'
        finally:
            selector.close(); eventlog.close(); stderr.close()
        rows = [host.get(host.folder(work)[1], b['ticket'])[1] for b in briefs]
        save(out/'native-attempts.json', rows); save(out/'results.json', results); save(out/'parent-tool-batches.json', batches)
        lifecycle = []
        for path in host.folder(work)[1].glob('event-*.json'):
            value = host.load(path)
            if value.get('backend') == 'claude' and value.get('session') == session:
                target = out/'host-events'/path.name; target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, target)
                lifecycle.append(value)
        save(out/'lifecycle.json', lifecycle)
        for brief in briefs:
            path = host.get(host.folder(work)[1], brief['ticket'])[0]
            target = out/'host-attempts-before-validation'/path.name
            target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, target)
        sample.update(cli_returncode=proc.poll(), cli_phase=phase, error=failure, native_phases=[r['phase'] for r in rows],
                      cli_reported_results=results, assistant_models=models, task_result_metadata=task_metadata,
                      latest_cli_reported_total_cost_usd=results[-1].get('total_cost_usd') if results else None,
                      session_end_receipt_present=any(v.get('event') == 'SessionEnd' for v in lifecycle),
                      lifecycle_point_unknown_is_not_worker_failure=True, tokens=None, money=None)
        terminal = all(r['phase'] in TERMINAL for r in rows)
        if not terminal or proc.poll() is None:
            sample.update(status='stopped-unknown-native-terminal', quality=None)
            save(out/'unsealed-wave.json', json.loads(wave.path.read_bytes()))
            for f in files:
                if (work/f).is_file():
                    target=out/'partial-artifact'/f; target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(work/f, target)
            return False
        if coordination_open:
            wave.stage('coordination', 'end'); sample['coordination_ended_without_all_agents_attached'] = True
        if not joining: wave.stage('join', 'begin')
        wave.stage('join', 'end')
        validations = {}
        for row, brief in zip(rows, briefs):
            if row['phase'] == 'returned':
                validations[row['task']] = host.validate(work, brief['ticket'])
                if validations[row['task']] == 0: host.adopt(work, brief['ticket'])
        wave.stage('conflict', 'skip'); wave.stage('recovery', 'skip')
        with contextlib.redirect_stdout(io.StringIO()) as seal_output: native.seal(out)
        (out/'seal-stdout.txt').write_text(seal_output.getvalue())
        result = json.loads((out/'result.json').read_bytes())
        for brief in briefs:
            path = host.get(host.folder(work)[1], brief['ticket'])[0]
            target = out/'host-attempts-after-validation'/path.name
            target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, target)
        headers = [b['header'] for b in briefs]
        protocol, task_batches, calls = native_agent_protocol(batches, headers, mode)
        save(out/'native-agent-batches.json', task_batches); save(out/'native-agent-calls.json', calls)
        sample.update(status='sealed', quality=result['quality'], protocol_ok=protocol,
            timely=time.monotonic() <= end and time.time() <= epoch_end, validations=validations,
            condition=result['condition'], batch_condition=result['batch_condition'],
            elapsed=result['elapsed'], worker_seconds=result['worker_seconds'], stage_seconds=result['stage_seconds'],
            round_wall=time.monotonic()-sample['round_started']['monotonic'])
        intervals = [(r['started'], r['returned']) for r in result['jobs'].values()]
        sample['ready_interval_overlap_seconds'] = (max(0, min(v[1] for v in intervals)-max(v[0] for v in intervals))
            if len(intervals) == 2 and all(x is not None for v in intervals for x in v) else None)
        return frozen()

    halted = False
    for index, (name, mode) in enumerate(ORDER):
        if halted or time.monotonic() >= end:
            report['samples'][index]['reason'] = 'cohort halted or original deadline exhausted'; continue
        try: halted = not run_case(index, name, mode)
        except BaseException as exc:
            report['samples'][index].update(status='driver-error-retained', error=repr(exc)); halted = True
        save(base/'report.json', report)
    sealed = [s for s in report['samples'] if s['status'] == 'sealed']
    report['condition_identity'] = {m: sorted({s['condition'] for s in sealed if s['mode'] == m}) for m in ('fused', 'crew')}
    report['batch_identities'] = sorted({s['batch_condition'] for s in sealed})
    # Never create a seventh wave or manufacture terminal state to ask for advice.
    if len(sealed) == 6 and settled() and frozen():
        latest = json.loads((base/ORDER[-1][0]/'result.json').read_bytes())
        require(host.crew.scope_digest(work, files) == latest['final_validation']['digest'], 'current bytes differ from archived final artifact')
        reset_owned(); report['baseline_restored'] = True
        report['planner'] = host.crew.plan(work, graphs['crew'])
        report['planner_applicable'] = (len(report['batch_identities']) == 1
            and all(len(v) == 1 for v in report['condition_identity'].values())
            and all(s['quality'] and s['protocol_ok'] and s['timely'] for s in sealed))
    else:
        report['planner'] = dict(executed=False, reason='incomplete/unknown/stale cohort; no qualified baseline reset')
    report.update(status='finished', finished_epoch=time.time(), suite_elapsed=time.monotonic()-ENTRY_MONOTONIC,
                  deadline_extended=False, goal_gate_go_claimed=False,
                  all_planned_positions_retained=True, old_backend_samples_pooled=False)
    save(base/'report.json', report)
    print(json.dumps(dict(output=str(base), sealed=len(sealed), quality_passes=sum(s['quality'] is True for s in sealed),
                          suite_elapsed=report['suite_elapsed'], planner=report['planner'])))

if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        if ACTIVE_BASE is not None:
            save(ACTIVE_BASE/'driver-failure.json', dict(error=repr(exc), observed_epoch=time.time(),
                 elapsed=time.monotonic()-ENTRY_MONOTONIC, deadline_extended=False))
            path = ACTIVE_BASE/'report.json'
            if path.is_file():
                partial = json.loads(path.read_bytes()); partial.update(status='driver-failed-retained', error=repr(exc))
                save(path, partial)
        raise
