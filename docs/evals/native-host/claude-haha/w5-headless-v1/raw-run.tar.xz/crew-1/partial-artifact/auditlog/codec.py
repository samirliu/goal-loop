"""Decoding of JSON Lines audit records.

The only public helper is :func:`parse_line`, which turns a single JSON
Lines row into a validated record mapping holding exactly the ``key`` and
``amount`` fields.
"""

import json

__all__ = ["parse_line"]


def _as_text(line):
    """Return ``line`` as ``str``; raise ``ValueError`` when impossible."""
    if isinstance(line, (bytes, bytearray)):
        try:
            return bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("record is not valid UTF-8") from exc
    if not isinstance(line, str):
        raise ValueError("record must be text")
    return line


def parse_line(line):
    """Parse one JSON Lines record into a ``key``/``amount`` mapping.

    ``line`` is a single JSON text row (a trailing newline is allowed).
    The row must decode to a JSON *object* carrying a nonempty string
    ``key`` and an integer ``amount``; ``bool`` is not accepted as an
    integer.  Any other field is ignored.

    Returns a new ``dict`` with exactly the ``key`` and ``amount`` entries
    of the original record, so the extra input fields never leak into the
    result and the original values are preserved as they were decoded.

    Raises ``ValueError`` for every invalid record: malformed JSON, a JSON
    value that is not an object, a missing ``key``/``amount`` member, a
    ``key`` that is not a nonempty string, or an ``amount`` that is not an
    integer.
    """
    text = _as_text(line)

    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("invalid JSON record: %s" % (exc.msg,)) from None
    except ValueError as exc:
        raise ValueError("invalid JSON record: %s" % (exc,)) from None

    if not isinstance(payload, dict):
        raise ValueError("record must be a JSON object")

    if "key" not in payload:
        raise ValueError("record is missing 'key'")
    if "amount" not in payload:
        raise ValueError("record is missing 'amount'")

    key = payload["key"]
    amount = payload["amount"]

    if not isinstance(key, str):
        raise ValueError("record 'key' must be a string")
    if not key:
        raise ValueError("record 'key' must not be empty")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("record 'amount' must be an integer")

    return {"key": key, "amount": amount}
