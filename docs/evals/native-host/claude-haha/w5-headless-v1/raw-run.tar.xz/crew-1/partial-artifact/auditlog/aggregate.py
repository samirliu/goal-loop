"""Aggregation of decoded audit records into per-key summaries.

The only public helper is :func:`summarize`, which turns an iterable of
decoded records (as produced by :func:`auditlog.codec.parse_line`) into a
list of per-key statistics dictionaries.
"""

__all__ = ["summarize"]


def _fields(record):
    """Return the ``(key, amount)`` pair of a decoded record.

    Raises ``ValueError`` when the record does not carry a nonempty string
    ``key`` and an integer ``amount`` (``bool`` is not accepted as an
    integer).  Extra fields are ignored.
    """
    try:
        key = record["key"]
        amount = record["amount"]
    except (TypeError, KeyError, IndexError):
        raise ValueError("record must contain 'key' and 'amount'") from None

    if not isinstance(key, str):
        raise ValueError("record 'key' must be a string")
    if not key:
        raise ValueError("record 'key' must not be empty")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("record 'amount' must be an integer")

    return key, amount


def summarize(records):
    """Summarize decoded records into key-sorted per-key statistics.

    ``records`` may be any iterable of decoded records, including a generator;
    it is consumed lazily and never mutated, so the caller's input is
    preserved.  Each record must provide a nonempty string ``key`` and an
    integer ``amount``.

    Returns a list of dictionaries sorted by key, each holding exactly the
    keys ``key``, ``count``, ``total``, ``min`` and ``max``.  An empty
    iterable yields an empty list.
    """
    # key -> [count, total, min, max]
    groups = {}

    for record in records:
        key, amount = _fields(record)
        stats = groups.get(key)
        if stats is None:
            groups[key] = [1, amount, amount, amount]
        else:
            stats[0] += 1
            stats[1] += amount
            if amount < stats[2]:
                stats[2] = amount
            if amount > stats[3]:
                stats[3] = amount

    return [
        {
            "key": key,
            "count": groups[key][0],
            "total": groups[key][1],
            "min": groups[key][2],
            "max": groups[key][3],
        }
        for key in sorted(groups)
    ]
