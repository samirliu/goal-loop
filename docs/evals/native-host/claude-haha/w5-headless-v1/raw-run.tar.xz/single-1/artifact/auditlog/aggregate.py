"""Aggregation of audit log records into per-key summaries."""

from collections.abc import Mapping

__all__ = ["summarize"]


def _read_record(record):
    """Return the ``(key, amount)`` pair of a valid record."""
    if not isinstance(record, Mapping):
        raise ValueError("record must be a mapping")
    if "key" not in record:
        raise ValueError("record is missing 'key'")
    if "amount" not in record:
        raise ValueError("record is missing 'amount'")

    key = record["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")

    amount = record["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")

    return key, amount


def summarize(records):
    """Summarize ``records`` into key-sorted dictionaries.

    The iterable is consumed once and never modified, so generators and other
    one-shot iterables are supported.  The result is a list of dictionaries
    sorted by ``key``, each holding exactly ``key``, ``count``, ``total``,
    ``min`` and ``max``.
    """
    buckets = {}
    for record in records:
        key, amount = _read_record(record)
        bucket = buckets.get(key)
        if bucket is None:
            buckets[key] = [1, amount, amount, amount]
            continue
        bucket[0] += 1
        bucket[1] += amount
        if amount < bucket[2]:
            bucket[2] = amount
        if amount > bucket[3]:
            bucket[3] = amount

    return [
        {"key": key, "count": count, "total": total, "min": low, "max": high}
        for key, (count, total, low, high) in sorted(buckets.items(), key=lambda item: item[0])
    ]
