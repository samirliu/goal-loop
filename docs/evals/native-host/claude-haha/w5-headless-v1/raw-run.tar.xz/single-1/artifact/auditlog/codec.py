"""Decoding of audit log records.

A record is a JSON object carrying a nonempty string ``key`` and an integer
``amount``.  Any additional fields present in the JSON object are ignored.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Decode one JSONL record into ``{"key": ..., "amount": ...}``.

    ``line`` is a single record as text; a trailing newline is tolerated.
    A :class:`ValueError` is raised when the text is not a JSON object with a
    nonempty string ``key`` and an integer ``amount``.  Booleans are never
    accepted as integers.
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = line.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"invalid UTF-8 record: {exc.reason}") from None
    if not isinstance(line, str):
        raise ValueError("record must be a string")

    text = line.strip()
    if not text:
        raise ValueError("empty record")

    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        # The message deliberately avoids the word "line" so that callers can
        # report the physical line number without ambiguity.
        raise ValueError(f"invalid JSON: {exc.msg} (char {exc.pos})") from None

    if not isinstance(payload, dict):
        raise ValueError("record must be a JSON object")
    if "key" not in payload:
        raise ValueError("record is missing 'key'")
    if "amount" not in payload:
        raise ValueError("record is missing 'amount'")

    key = payload["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")

    amount = payload["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")

    return {"key": key, "amount": amount}
