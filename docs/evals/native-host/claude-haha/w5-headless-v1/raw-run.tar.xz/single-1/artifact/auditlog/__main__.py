"""Command line entry point: ``python -m auditlog --input PATH --output PATH``."""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

from .aggregate import summarize
from .codec import parse_line

EXIT_OK = 0
EXIT_ERROR = 2


class _InputError(Exception):
    """Raised when the input file cannot be read or holds invalid records."""


def _build_parser():
    parser = argparse.ArgumentParser(
        prog="auditlog",
        description="Summarize audit log JSONL records grouped by key.",
    )
    parser.add_argument("--input", required=True, metavar="PATH", help="UTF-8 JSONL file to read")
    parser.add_argument("--output", required=True, metavar="PATH", help="file to publish the summary to")
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def _collect(input_path, skip_bad):
    """Return the valid records of ``input_path`` and the number skipped."""
    path = Path(input_path)
    try:
        stream = path.open("r", encoding="utf-8")
    except FileNotFoundError:
        raise _InputError(f"input file not found: {path}") from None
    except IsADirectoryError:
        raise _InputError(f"input path is a directory: {path}") from None
    except OSError as exc:
        raise _InputError(f"cannot read input file {path}: {exc.strerror or exc}") from None

    records = []
    skipped = 0
    try:
        with stream:
            for number, line in enumerate(stream, start=1):
                if not line.strip():
                    continue
                try:
                    records.append(parse_line(line))
                except ValueError as exc:
                    if not skip_bad:
                        raise _InputError(f"invalid record on line {number}: {exc}") from None
                    skipped += 1
    except UnicodeDecodeError as exc:
        raise _InputError(f"input file {path} is not valid UTF-8: {exc.reason}") from None
    return records, skipped


def _publish(output_path, text):
    """Write ``text`` to ``output_path`` atomically."""
    target = Path(output_path)
    directory = target.parent if str(target.parent) else Path(".")
    directory.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(dir=str(directory), prefix=target.name + ".", suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, str(target))
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def main(argv=None):
    """Run the command line interface and return the process exit code."""
    args = _build_parser().parse_args(argv)

    try:
        records, skipped = _collect(args.input, args.skip_bad)
    except _InputError as exc:
        print(f"auditlog: error: {exc}", file=sys.stderr)
        return EXIT_ERROR

    payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in summarize(records))
    _publish(args.output, payload)

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
