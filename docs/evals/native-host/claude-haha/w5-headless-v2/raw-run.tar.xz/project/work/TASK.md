Implement the standard-library auditlog package with codec.py, aggregate.py,
__main__.py and __init__.py. codec.parse_line(line) returns a dict containing
the original key and amount, or raises ValueError. Valid records are JSON
objects with a nonempty string key and integer amount (bool is invalid).
Extra fields are ignored. aggregate.summarize(records) accepts an iterable
and returns key-sorted dicts with key,count,total,min,max.
python3 -m auditlog --input PATH --output PATH [--skip-bad] reads UTF-8 JSONL.
Ignore blank lines. Output one JSON object per group. Strict invalid input
exits 2, names the physical line on stderr and preserves an existing output.
With --skip-bad, skip invalid rows and print {"skipped":N} on stderr.
Missing input exits 2. Empty input produces an empty output file.
Publish output atomically. Only edit auditlog/ and optional tests you create.
Run python3 public.py. No third-party dependencies.
