import json,subprocess,sys,tempfile
from pathlib import Path
from auditlog.codec import parse_line
from auditlog.aggregate import summarize
assert parse_line('{"key":"a","amount":2,"extra":4}')=={"key":"a","amount":2}
assert summarize(iter([{"key":"b","amount":3},{"key":"b","amount":-2}]))==[{"key":"b","count":2,"total":1,"min":-2,"max":3}]
with tempfile.TemporaryDirectory() as tmp:
    source,out=Path(tmp)/"in",Path(tmp)/"out"
    source.write_text('{"key":"a","amount":2}\n{broken\n')
    out.write_text("keep")
    args=[sys.executable,"-B","-m","auditlog","--input",str(source),"--output",str(out)]
    result=subprocess.run(args,capture_output=True,text=True)
    assert result.returncode==2 and out.read_text()=="keep" and "2" in result.stderr
    result=subprocess.run(args+["--skip-bad"],capture_output=True,text=True)
    assert result.returncode==0 and json.loads(out.read_text())["total"]==2
    assert json.loads(result.stderr)=={"skipped":1}
print("PUBLIC PASS")
