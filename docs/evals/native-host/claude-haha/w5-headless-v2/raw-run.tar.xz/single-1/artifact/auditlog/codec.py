"""Decoding of individual audit log records.

A record is a JSON object on a single line.  Only two fields are meaningful:
``key`` (a nonempty string) and ``amount`` (an integer).  Every other field is
ignored.  Anything that is not a valid record raises :class:`ValueError`.
"""

from __future__ import annotations

import json
import sys

__all__ = ["parse_line"]

#: Number of digits converted per step when a literal is too long for the
#: interpreter's integer/string conversion limit.
_CHUNK = 1000


def _chunk_size() -> int:
    """Return a safe conversion chunk size for the active digit limit."""
    limit = 0
    getter = getattr(sys, "get_int_max_str_digits", None)
    if getter is not None:
        limit = getter() or 0
    if limit <= 0:
        return _CHUNK
    return max(1, min(_CHUNK, limit - 1))


def parse_int_literal(text: str) -> int:
    """Convert a JSON integer literal to an ``int``.

    ``int()`` refuses literals longer than the interpreter's digit limit, so
    the digits are folded together in small chunks instead.  Amounts of any
    size therefore decode exactly.
    """
    negative = text.startswith("-")
    digits = text[1:] if negative else text
    size = _chunk_size()
    value = 0
    for start in range(0, len(digits), size):
        piece = digits[start:start + size]
        value = value * (10 ** len(piece)) + int(piece)
    return -value if negative else value


def int_to_text(value: int) -> str:
    """Render an ``int`` as decimal text, bypassing the digit limit."""
    try:
        return str(value)
    except ValueError:
        pass
    size = _chunk_size()
    base = 10 ** size
    negative = value < 0
    magnitude = -value if negative else value
    pieces = []
    while magnitude:
        magnitude, remainder = divmod(magnitude, base)
        pieces.append(remainder)
    pieces.reverse()
    text = str(pieces[0]) + "".join(str(p).zfill(size) for p in pieces[1:])
    return "-" + text if negative else text


def parse_line(line) -> dict:
    """Parse one JSONL record into ``{"key": ..., "amount": ...}``.

    Raises :class:`ValueError` when the line is not a JSON object, when it has
    no ``key``/``amount`` field, when ``key`` is not a nonempty string, or when
    ``amount`` is not an integer (``bool`` is not an integer here).
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"line is not valid UTF-8: {exc}") from None
    elif not isinstance(line, str):
        raise ValueError("line must be a string")

    try:
        record = json.loads(line, parse_int=parse_int_literal)
    except ValueError as exc:  # json.JSONDecodeError is a ValueError
        raise ValueError(f"invalid JSON: {exc}") from None

    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")
    if "key" not in record:
        raise ValueError("record has no 'key' field")
    key = record["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")
    if "amount" not in record:
        raise ValueError("record has no 'amount' field")
    amount = record["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")
    return {"key": key, "amount": amount}
