"""Standard-library audit log tooling.

``codec.parse_line`` decodes a single JSONL record, ``aggregate.summarize``
groups records by key and ``python -m auditlog`` runs the whole pipeline.
"""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
__version__ = "1.0.0"
