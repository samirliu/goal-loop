"""Command line entry point: ``python -m auditlog --input PATH --output PATH``.

Reads UTF-8 JSONL records, ignores blank lines and writes one JSON object per
grouped key to the output file.  By default an invalid record is fatal: the
program exits 2, names the offending physical line on stderr and leaves any
existing output file untouched.  With ``--skip-bad`` invalid records are
skipped and their number is reported on stderr instead.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import int_to_text, parse_line

PROG = "auditlog"

#: Longest raw line echoed back in an error message.
_SNIPPET = 120


class _InputError(Exception):
    """The input file cannot be read."""


class _BadRecord(Exception):
    """An invalid record was found on a physical line."""

    def __init__(self, lineno: int, snippet: str):
        self.lineno = lineno
        self.snippet = snippet
        super().__init__(f"invalid record at line {lineno}: {snippet}")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=PROG,
        description="Summarize audit log JSONL records by key.",
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="PATH",
        help="UTF-8 JSONL file to read",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="file the JSONL summary is written to",
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def _read_lines(path: str):
    """Return the physical lines of ``path`` as text, keeping their numbers."""
    try:
        with open(path, "rb") as handle:
            data = handle.read()
    except OSError as exc:
        reason = exc.strerror or exc.__class__.__name__
        raise _InputError(f"cannot read input '{path}': {reason}") from None

    lines = []
    for lineno, raw in enumerate(data.split(b"\n"), start=1):
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            lines.append((lineno, None))
            continue
        if lineno == 1 and text.startswith("\ufeff"):
            text = text[1:]
        lines.append((lineno, text))
    return lines


def _snippet(text) -> str:
    if text is None:
        return "<not valid UTF-8>"
    cleaned = text.strip()
    if len(cleaned) > _SNIPPET:
        cleaned = cleaned[:_SNIPPET] + "..."
    return cleaned


def _load(path: str, skip_bad: bool):
    """Return ``(records, skipped)`` read from ``path``."""
    records = []
    skipped = 0
    for lineno, text in _read_lines(path):
        if text is not None and not text.strip():
            continue  # blank line
        if text is not None:
            try:
                records.append(parse_line(text))
                continue
            except ValueError:
                pass
        if skip_bad:
            skipped += 1
            continue
        raise _BadRecord(lineno, _snippet(text))
    return records, skipped


def _encode_row(row: dict) -> str:
    """Render one summary row as a JSON object."""
    parts = []
    for name in ("key", "count", "total", "min", "max"):
        value = row[name]
        if isinstance(value, bool):
            encoded = "true" if value else "false"
        elif isinstance(value, int):
            encoded = int_to_text(value)
        else:
            encoded = json.dumps(value, ensure_ascii=False)
        parts.append(json.dumps(name, ensure_ascii=False) + ": " + encoded)
    return "{" + ", ".join(parts) + "}"


def _write_output(path: str, rows) -> None:
    """Publish the summary atomically, replacing ``path`` in one step."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    fd, temporary = tempfile.mkstemp(dir=directory, prefix=".auditlog-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            for row in rows:
                handle.write(_encode_row(row) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temporary, 0o644)
        except OSError:
            pass
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def main(argv=None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        records, skipped = _load(args.input, args.skip_bad)
    except (_InputError, _BadRecord) as exc:
        sys.stderr.write(f"{PROG}: {exc}\n")
        return 2

    try:
        rows = summarize(records)
    except ValueError as exc:
        sys.stderr.write(f"{PROG}: {exc}\n")
        return 2

    try:
        _write_output(args.output, rows)
    except OSError as exc:
        reason = exc.strerror or exc.__class__.__name__
        sys.stderr.write(f"{PROG}: cannot write output '{args.output}': {reason}\n")
        return 2

    if args.skip_bad:
        sys.stderr.write(json.dumps({"skipped": skipped}, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
