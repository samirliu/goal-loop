"""Aggregation of audit log records into per-key summaries."""

from __future__ import annotations

from collections.abc import Mapping

__all__ = ["summarize"]


def _fields(record):
    """Return ``(key, amount)`` of a valid record, raising ValueError if not."""
    if not isinstance(record, Mapping):
        raise ValueError("record must be a mapping")
    if "key" not in record:
        raise ValueError("record has no 'key' field")
    key = record["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")
    if "amount" not in record:
        raise ValueError("record has no 'amount' field")
    amount = record["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")
    return key, amount


def summarize(records) -> list:
    """Summarize valid records grouped by key.

    ``records`` is any iterable of records (a list, a generator, ...) and is
    never modified.  The result is a list of dicts sorted by key, each holding
    exactly ``key``, ``count``, ``total``, ``min`` and ``max``.
    """
    groups = {}
    for record in records:
        key, amount = _fields(record)
        entry = groups.get(key)
        if entry is None:
            groups[key] = [1, amount, amount, amount]
        else:
            entry[0] += 1
            entry[1] += amount
            if amount < entry[2]:
                entry[2] = amount
            if amount > entry[3]:
                entry[3] = amount

    return [
        {
            "key": key,
            "count": entry[0],
            "total": entry[1],
            "min": entry[2],
            "max": entry[3],
        }
        for key, entry in sorted(groups.items())
    ]
