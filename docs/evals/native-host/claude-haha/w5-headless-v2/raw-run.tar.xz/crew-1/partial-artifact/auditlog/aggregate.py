"""Aggregation of audit records into per-key summaries.

The record contract matches :func:`auditlog.codec.parse_line`: a record is a
mapping with a nonempty string ``key`` and an integer ``amount`` (``bool`` is
not an acceptable amount).  Extra fields are ignored.

``summarize`` consumes any iterable of records -- including one-shot
generators -- and returns a list of plain dicts with exactly the keys
``key``, ``count``, ``total``, ``min`` and ``max``, ordered by ``key``.
The caller's records are never mutated.
"""

__all__ = ["summarize"]

#: The exact fields produced for every summarized group, in output order.
SUMMARY_FIELDS = ("key", "count", "total", "min", "max")


class InvalidRecord(ValueError, TypeError):
    """Raised when an item of the input iterable is not a valid record.

    It derives from both :class:`ValueError` and :class:`TypeError` so that
    callers may catch either one.
    """


def _record_fields(record):
    """Return the ``(key, amount)`` pair of a valid record.

    Raises :class:`InvalidRecord` if ``record`` does not satisfy the record
    contract.
    """
    if not isinstance(record, dict):
        raise InvalidRecord("record must be a mapping, got %r" % (type(record).__name__,))
    if "key" not in record or "amount" not in record:
        raise InvalidRecord("record must provide 'key' and 'amount'")
    key = record["key"]
    amount = record["amount"]
    if not isinstance(key, str):
        raise InvalidRecord("record key must be a string, got %r" % (type(key).__name__,))
    if not key:
        raise InvalidRecord("record key must be a nonempty string")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise InvalidRecord(
            "record amount must be an integer, got %r" % (type(amount).__name__,)
        )
    return key, amount


def summarize(records):
    """Summarize ``records`` per key.

    ``records`` is any iterable of valid records (lists, tuples, generators,
    ...); it is iterated exactly once and is never modified.  The result is a
    list of dicts holding exactly ``key``, ``count``, ``total``, ``min`` and
    ``max``, sorted by ``key``.  An empty iterable yields an empty list.
    """
    # key -> [count, total, min, max]
    groups = {}
    for record in records:
        key, amount = _record_fields(record)
        entry = groups.get(key)
        if entry is None:
            groups[key] = [1, amount, amount, amount]
        else:
            entry[0] += 1
            entry[1] += amount
            if amount < entry[2]:
                entry[2] = amount
            if amount > entry[3]:
                entry[3] = amount

    return [
        {
            "key": key,
            "count": groups[key][0],
            "total": groups[key][1],
            "min": groups[key][2],
            "max": groups[key][3],
        }
        for key in sorted(groups)
    ]
