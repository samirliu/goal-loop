def parse_line(line):
    raise NotImplementedError
