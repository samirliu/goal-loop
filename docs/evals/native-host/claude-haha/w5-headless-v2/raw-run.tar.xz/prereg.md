# W5 headless v2 有限复验预注册（执行前冻结）

本草案只准备下一批实验。F5 未稳定前禁止启动模型；不恢复 36 次 W9，不续期旧 Work v3，不池化旧 backend、旧 controller 或旧源码的样本。

## 固定设计

- 工作负载：原 `auditlog-v1`，`tasks.prepare(..., 'medium', 911207)`；原 `TASK.md`、`public.py`、四个 STARTERS、`native_checks.py` 和独立 `grade.py`。不改变接口、输入或 grader。
- A=单个现有 `goal-loop-host:goal-worker` 完成四文件整批；B=两个相同类型的 native **Agent**，在同一 assistant message 中同步并发调用。客户端源码 `AgentTool/constants.ts:1/3`、`AgentTool.tsx:226/228` 明确实际 name 为 Agent，Task 仅兼容 alias。CLI 与提示优先使用 Agent；收据统一接受实际 Agent 和 legacy Task，保留原 wire name、id/call_id，不能把 Agent 漏算成零派发。T1 只拥有 codec/main/init，T2 只拥有 aggregate。禁止 background Agent、模型/effort 参数和 worker 再派发。
- 顺序固定 ABBAAB：single-1、crew-1、crew-2、single-2、single-3、crew-3。配对为同编号 A/B。每轮新的 CLI session、新初始会话，不 resume；项目只创建一次。每轮只恢复已归档、已终态的 owned 四文件及其原权限，不恢复输入/grader，也不替换失败样本。
- CLI 使用用户授权的 `/Users/m/repo/workspace/claude-code-haha/bin/claude-haha --permission-mode bypassPermissions`，继承现有 `.env` 和现有 goal-worker。实际是启用 **MiniMax-M3.1-Flash 映射的明文客户端**，不冒充标准 Claude、Work 或其旧 backend。固定工具集为 `Agent,Read,Grep,Glob,Write,Edit,Bash`，覆盖现有 worker 完整声明；不因原型过窄 allowlist 导致 Read 不可用而污染比较。Task alias 仅按实际流兼容接收，不伪造或改写名称。禁 MCP/Web，父模型禁止实现 owned 文件。保留 plugin、stream-json、hook events、严格空 MCP 配置；**bootstrap 显式使用 `/goal-loop-host:goal-loop`，由 plugin manifest 的 `skills: "./"` 选择当前 SKILL，不创建项目同名 symlink，不用 disable-slash-commands**。普通 `/goal-loop` 可能优先选到全局旧 skill，不能当本版选择证据。草案固定每 CLI `max-turns=8`，达到即保留失败，不追加预算；六轮最多六个 CLI，不重试。不设置 CLI 美元估价上限；该客户端的未知模型回退价目不能代表真实账单。总900秒机械截止与max-turns=8不变，tokens/money总量仍为unknown。

## 预算、身份与计时

- 总时间默认 **900 秒**。起点在执行草案的 Python controller 入口，早于模块/夹具准备、stamp、任何 CLI 或 Task；不是首个 spawn。生成唯一 cohort/controller 身份，保存真实 epoch/monotonic 与 boot receipt；先 `host.begin(claude, cohort-id, 900, origin)` 持久化同一 run。实际 epoch 取整或任何已有 cap 只可收紧。
- 每轮 CLI UUID 不同。为其单独记录真实 tool origin，`host.begin(..., round-session, remaining)` 接入同一已持久化 run；每次 prepare 显式传 round session，避免多 session 的歧义。新 UserPromptSubmit receipt 单独保存，不能给同一 run 重新发时间。
- 图 context 的 backend=`actual-claude-haha-MiniMax-M3.1-Flash-Agent-TaskAlias-hooks-v1`、controller=唯一 cohort-id，明确实际 Agent/legacy Task alias，不混旧 Work。冻结 production/客户端关键源码、全部 `references/**` 与 `agents/**`、实际 Agent registry 与 plugin/skill/agent/hook 装载实现，包括 `AgentTool/constants.ts`、`AgentTool.tsx`、`loadPluginCommands.ts`、`loadSkillsDir.ts`、`loadPluginAgents.ts`、`loadPluginHooks.ts` 和 plugin schemas；`.env` 只存 hash，不输出 secret 值。A 和 B 的 job 图不同，因此各自 condition 哈希不同且分别应有 3 个相同值；**六个 batch_condition 必须相同**。使用同一个项目、approval、合同、实际初始 bytes/modes、输入、最终 grader 和 Python API producer。不能把“相同 batch”误写成两种 job 图的 condition 必须相等。
- 每轮记录 reset/host begin 前的 round 起点、Wave begin、CLI 启动、首次 prompt receipt、assignment、所有 Agent/Task tool-call 批次及原名/call_id、真实 hook/READY/终态、独立验证/采用、final seal 和 CLI 退出。primary production `Wave.elapsed` 保留原定义；round wall 和全 cohort wall 另报，不改写成本账本。
- `worker_seconds` 仍是原生产定义：ticket prepare/dispatch 到观察到的 native terminal 的 span 之和，含 reservation、CLI 冷启动/排队与观察延迟；不是供应商 compute。另保留 READY 到 terminal、Agent/Task 生命周期流，不能把缺失时间填成 0。

## 原生收据、采用与阶段

1. 每轮先建立 Wave、coordination begin 和 ticket，再启动 fresh CLI。phase 1 `/goal-loop-host:goal-loop` 只请求 READY、不得用工具；确认真实 UserPromptSubmit 缓存。phase 2 只让模型原样复制 ticket brief 到 Agent，B 的两个 Agent 同批、同步、无 model override。parent protocol、filtered task_batches 和 calls 全部使用同一个 Agent/Task 判定；不得一处兼容、一处仍硬编码 Task。
2. PreToolUse 绑定实际 call_id；worker 必须先执行原 `owned_ready_command`，自动绑定实际 agent_id/READY；非 shell 工具同样先经过注册/limits。PostToolUse/Failure 通过现有 hook attach/reconcile。不可用工具的模型尝试不计成已执行 callback。SubagentStart/Stop、Stop/SessionEnd 点事件的 unknown 不算运行中/失败 worker；SessionEnd 以 `.goal/evidence/host/event-*.json` 为证，即使 stream 未刷出也不误报缺失。父模型的 COMPLETE 文本、CLI result 和 tool prose 均不是 worker 成功权威。
3. coordination 结束于所有 ticket 实际绑定 agent_id，随后 join begin；所有 ticket 有真实终态后 join end。若失败前未能全部绑定，记录该边界原因，不能编造成功启动。仅在全部终态、CLI 已退出后逐个独立 `host.validate`，成功才 adopt；然后原 `native.seal` 重跑同一个 private final 并归档。质量和是否在原截止前完成分别报告；不自动填 adversarial clear，不声称合同 Gate GO。
4. conflict/recovery 只有实际发生才计时；未进行则显式 skip。worker 的原位修复和固定 CHECK 失败均保留 runtime 记录，不另派 replacement，不取最快成功。
5. 到截止请求各活跃 ticket cancel，并终止本轮 owned CLI supervisor。终态只能来自真实 hook。若 CLI 已退出但任一 attempt 仍 prepared/unknown，保存输出与未知状态，停止后续轮次，禁止 reset、seal 假终态或 planner 建议。其他计划轮次明确记未派发。若监督层未能完成退出，记 teardown unknown，不声称预算合规。

## 成本、planner 与收口

- 保存过滤后的 non-thinking stream：每个 `assistant.message.model`/message ID/usage、tool_use 输入/ID、每条 user tool_result 的 tool_use_id/is_error/文本 hash、Task 结构化 `tool_use_result` 的 agentId、totalTokens、usage、时长/工具数及 tool_use_id 绑定，hook/system 生命周期，result 的 usage/modelUsage/cost 原字段。普通模型文本只存 hash；不保存 thinking blocks。记录 Python、客户端 package version、system runtime/model 原字段和关键源 SHA。stderr 留本地诊断，不打印凭据。
- 已只读核对提供源码：`QueryEngine.ts:812/1145` 返回实例 `totalUsage`，而 `bootstrap/state.ts:559/566` 的 cost 是进程 STATE 累积值；`cost-tracker.ts:283` 向该全局值追加。故两 phase `total_cost_usd` 不相加，最后值也只标 **CLI-reported cumulative estimate**。`modelCost.ts:144` 对未知模型会回退本地默认价目，不能冒充 MiniMax 真实账单。`AgentTool/agentToolUtils.ts:319/355` 的 `totalTokens` 与 `usage` 实际取最后 assistant message，并非整个 worker 的已证明总量。metadata 原样保留且不把名字当口径；`crew.tokens/money` 及 cohort 真总数保持 unknown/null，除非取得完整、可绑定且去重的证据。不把本地 CPU/worker span 当费用。
- 每个成功/失败/未派发保留，quality=false/unknown 不替换。并发批次不满足、模型直接编辑、显式模型 override 等是协议偏离，原结果保留；不能只筛掉慢/失败样本来推荐 crew。
- 收口只在所有已派发 attempt 终态、全部 Wave 已 seal、最后输出与归档 byte/mode 一致时恢复原 STARTERS；不得新增第七个 Wave。失败依旧留在 history。原输入/grader/源码必须未变。然后用原 `crew.plan(project, graph)` Python API，读本项目 history，记录原始选择；截止已过就接受 stop，不再给 planner 新预算。任何质量/并发/身份缺口均不得解释成 crew 优势。
- 结论只限这一任务、六个预注册位置和该 backend；描述配对差值及 worker 占用权衡，不给通用分数，不外推到全部 Agent 会话。

## 执行前剩余依赖

1. **F5 与资源隔离**：根流程已报告 F5 的真实 positive30 稳定；仍待当前 full suites 终态后再开模型 cohort，不能与 full 争用资源。执行前由根流程写 `/tmp` ready JSON，含 `status: ready`、`full_suites_terminal: true`、最终 `owner_watch_sha256` 和实际 `evidence` 文件路径；并核对正常/取消/截止清理。这是实验防误启动输入，不是新的用户确认。
2. 对草案做纯 AST 和引用路径存在性核对，不导入/执行 driver；执行前再冻结当前 production/全部 agents/references/SKILL/hooks/CLI 指纹。CLI 与模型 cohort 尚未运行。`native.py prepare` 硬编码 Work backend，因此临时 driver 只薄适配 fixture prepare；复用其 loader、encode、seal、原 Wave stage 路径及原任务/检查器，不改生产调度。当前 manifest 的显式 skill namespace 与 prompt hook 支持需由根流程最终冻结后提供 ready。
3. 已有模型授权继续有效，无需再问用户。根流程决定执行时使用一个全新输出目录；命令示例（**本次未执行**）：

```text
python3 -B /tmp/goal_w5_claude_headless_v2.py --execute --output /tmp/goal-w5-claude-auditlog-v2 --f5-ready /tmp/goal-f5-ready.json
```

静态交付核对：AST 解析、草案实际引用路径、当前 SKILL 相对链接、显式 namespace 的 manifest/hook 支持均已通过；冻结包含 agents 5 份、references 9 份文件。证据为 `/tmp/goal-w5-headless-static-audit-20261112.json`。该检查不导入 driver，也不执行任何 CLI/模型；最终 ready 仍由根流程提供，运行行为尚未验证。

## v1 失败与本次修正边界

前批实际运行285.319秒：single-1独立21项通过；crew-1触发客户端估价上限error_max_budget_usd，T2返回、T1无可靠终态；后4位置未派发。该批原始记录完整保留，不能与本批池化或改写为成功。当前全新六位置、全新controller/run/project在同样900秒设计下单独比较；不续跑原批。

实际stream会把同一assistant message的两个Agent拆成两事件。v2仅按真实非空message.id合并批次、按call_id去重；同ID冲突输入拒绝，不按时间接近猜测。保存原message→batch索引和原事件。crew还必须存在真实READY至native terminal的正重叠，不能仅凭同批证明实际并发。v1的message分流及估价中断正是这两项修正的原始材料，不是删除负例的理由。

Worker越界读取、额外测试或违反简报的行为另行逐项审计，不能由controller的protocol_ok替代。发现协议偏离要保留，不能只筛最快的合规成功。新批仍只限auditlog任务及本地backend，不证明相对/goal整体优势。
