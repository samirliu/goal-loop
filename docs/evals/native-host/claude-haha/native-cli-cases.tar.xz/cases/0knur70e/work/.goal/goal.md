# Goal

## Acceptance criteria

- AC-1 | exact artifact | check: `/opt/homebrew/opt/python@3.14/bin/python3.14 -B /tmp/goal-claude-hooks-live-0knur70e/control/grade.py` | expected: exit=0

## Approval

approved: e905a413 2026-11-12 auto
