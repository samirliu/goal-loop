# Goal

## Acceptance criteria

- AC-1 | exact artifact | check: `/opt/homebrew/opt/python@3.14/bin/python3.14 -B /tmp/goal-claude-hooks-live-0ch9wkfr/control/grade.py` | expected: exit=0

## Approval

approved: c851fac2 2026-11-12 auto
