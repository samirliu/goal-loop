"""Command line interface: ``python -m auditlog --input PATH --output PATH [--skip-bad]``.

Reads a UTF-8 JSONL file of audit records and writes one JSON object per key
to the output file.  The output is published atomically, so an existing output
file is never left half written.

Without ``--skip-bad`` the first invalid record aborts the run with exit
status 2; the physical line number is reported on stderr and the output file
is left untouched.  With ``--skip-bad`` invalid records are skipped and
``{"skipped":N}`` is the only thing written to stderr.

Only the Python standard library is used.
"""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line

__all__ = ["main"]

PROG = "auditlog"

EXIT_OK = 0
EXIT_ERROR = 2


class AuditlogError(Exception):
    """Fatal error reported on stderr with exit status 2."""


def build_parser():
    parser = argparse.ArgumentParser(
        prog="python -m auditlog",
        description="Summarize JSONL audit records by key.",
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="PATH",
        help="UTF-8 JSONL file to read",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="file to write the per-key summaries to",
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def _read_records(path, skip_bad):
    """Return ``(records, skipped)`` read from *path*.

    Blank lines are ignored.  In strict mode the first invalid record raises
    :class:`AuditlogError` naming its physical line number.
    """
    records = []
    skipped = 0

    try:
        handle = open(path, "r", encoding="utf-8", newline="")
    except FileNotFoundError:
        raise AuditlogError(
            "missing input file: {0} (file not found)".format(path)
        ) from None
    except IsADirectoryError:
        raise AuditlogError(
            "missing input file: {0} (file not found)".format(path)
        ) from None
    except OSError as exc:
        raise AuditlogError(
            "cannot read input file {0}: {1}".format(path, exc.strerror or exc)
        ) from None

    try:
        with handle:
            for number, raw in enumerate(handle, 1):
                line = raw.strip()
                if not line:
                    continue
                try:
                    records.append(parse_line(line))
                except ValueError as exc:
                    if not skip_bad:
                        raise AuditlogError(
                            "invalid record at line {0}: {1}: {2}".format(
                                number, exc, _excerpt(raw)
                            )
                        ) from None
                    skipped += 1
    except UnicodeDecodeError as exc:
        raise AuditlogError(
            "input file {0} is not valid UTF-8: {1}".format(path, exc)
        ) from None
    except OSError as exc:
        raise AuditlogError(
            "cannot read input file {0}: {1}".format(path, exc.strerror or exc)
        ) from None

    return records, skipped


def _excerpt(raw, limit=120):
    """Return a short, single line excerpt of *raw* for error messages."""
    text = raw.strip()
    if len(text) > limit:
        text = text[:limit] + "..."
    return text


def _render(records):
    """Render the per-key summaries, one JSON object per line."""
    lines = []
    for summary in summarize(records):
        lines.append(json.dumps(summary))
    if not lines:
        return ""
    return "\n".join(lines) + "\n"


def _publish(path, text):
    """Write *text* to *path* atomically."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    try:
        handle, temporary = tempfile.mkstemp(
            prefix=".auditlog-", suffix=".tmp", dir=directory
        )
    except OSError as exc:
        raise AuditlogError(
            "cannot write output file {0}: {1}".format(path, exc.strerror or exc)
        ) from None

    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, _default_file_mode())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

    try:
        fd = os.open(directory, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _default_file_mode():
    mask = os.umask(0)
    os.umask(mask)
    return 0o666 & ~mask


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        records, skipped = _read_records(args.input, args.skip_bad)
        text = _render(records)
        _publish(args.output, text)
    except AuditlogError as exc:
        sys.stderr.write("{0}: {1}\n".format(PROG, exc))
        return EXIT_ERROR

    if args.skip_bad:
        sys.stderr.write(
            json.dumps({"skipped": skipped}, separators=(",", ":")) + "\n"
        )

    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
