"""Parsing of JSONL audit records.

A valid record is a JSON object carrying a nonempty string ``key`` and an
integer ``amount``.  Every other field is ignored.  Anything else (malformed
JSON, a non-object payload, a missing/blank/non-string key, a non-integer
amount, or a boolean amount) is rejected with ``ValueError``.

Only the Python standard library is used.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse one JSONL record and return ``{"key": ..., "amount": ...}``.

    Raises ``ValueError`` when *line* is not a valid audit record.
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("invalid UTF-8 record: {0}".format(exc)) from None
    if not isinstance(line, str):
        raise ValueError(
            "record must be a string, got {0}".format(type(line).__name__)
        )

    text = line.strip()
    if not text:
        raise ValueError("empty record")

    try:
        payload = json.loads(text)
    except ValueError as exc:  # json.JSONDecodeError is a ValueError
        raise ValueError("invalid JSON: {0}".format(exc)) from None

    if not isinstance(payload, dict):
        raise ValueError(
            "record must be a JSON object, got {0}".format(type(payload).__name__)
        )

    if "key" not in payload:
        raise ValueError("record is missing the 'key' field")
    if "amount" not in payload:
        raise ValueError("record is missing the 'amount' field")

    key = payload["key"]
    amount = payload["amount"]

    if not isinstance(key, str):
        raise ValueError(
            "'key' must be a string, got {0}".format(type(key).__name__)
        )
    if not key:
        raise ValueError("'key' must be a nonempty string")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError(
            "'amount' must be an integer, got {0}".format(type(amount).__name__)
        )

    return {"key": key, "amount": amount}
