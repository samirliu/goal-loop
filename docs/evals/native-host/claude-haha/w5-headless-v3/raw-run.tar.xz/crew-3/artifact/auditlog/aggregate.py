"""Aggregation of audit records by key.

``summarize`` consumes an iterable of *valid* records (as produced by
:func:`auditlog.codec.parse_line`) and returns one summary object per key.

The input is never mutated: records are only read, and every returned
dictionary is freshly built.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

__all__ = ["summarize"]

Record = Mapping[str, Any]
Summary = dict[str, Any]


def summarize(records: Iterable[Record]) -> list[Summary]:
    """Summarize audit records, grouped by their ``key`` field.

    Parameters
    ----------
    records:
        Any iterable of record mappings, each carrying a ``key`` and an
        ``amount``.  Generators and other one-shot iterables are fine; the
        iterable is consumed exactly once and is left untouched.

    Returns
    -------
    list of dict
        A list of dictionaries sorted by key.  Every dictionary has exactly
        the keys ``key``, ``count``, ``total``, ``min`` and ``max``:

        ``count``
            number of records sharing the key
        ``total``
            sum of the amounts (exact integer arithmetic)
        ``min`` / ``max``
            smallest / largest amount seen for the key

        An empty input yields an empty list.

    Raises
    ------
    ValueError
        If a record is not a mapping or lacks a ``key``/``amount`` field.
    """
    # key -> [count, total, min, max]
    groups: dict[Any, list[Any]] = {}

    for record in records:
        if not isinstance(record, Mapping):
            raise ValueError(f"invalid record: expected a mapping, got {type(record).__name__}")
        if "key" not in record:
            raise ValueError("invalid record: missing 'key' field")
        if "amount" not in record:
            raise ValueError("invalid record: missing 'amount' field")

        key = record["key"]
        amount = record["amount"]

        bucket = groups.get(key)
        if bucket is None:
            # first record for this key: count=1, total=min=max=amount
            groups[key] = [1, amount, amount, amount]
            continue

        bucket[0] += 1
        bucket[1] += amount
        if amount < bucket[2]:
            bucket[2] = amount
        if amount > bucket[3]:
            bucket[3] = amount

    return [
        {
            "key": key,
            "count": bucket[0],
            "total": bucket[1],
            "min": bucket[2],
            "max": bucket[3],
        }
        for key, bucket in sorted(groups.items(), key=lambda item: item[0])
    ]
