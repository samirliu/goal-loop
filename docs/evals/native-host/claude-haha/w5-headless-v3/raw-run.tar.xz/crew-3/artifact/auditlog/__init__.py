"""auditlog -- summarize JSONL audit records by key.

The package is standard library only:

``auditlog.codec.parse_line``
    Parse one JSONL record into ``{"key": ..., "amount": ...}``.
``auditlog.aggregate.summarize``
    Group valid records by key.
``python -m auditlog --input PATH --output PATH [--skip-bad]``
    Command line entry point.
"""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
