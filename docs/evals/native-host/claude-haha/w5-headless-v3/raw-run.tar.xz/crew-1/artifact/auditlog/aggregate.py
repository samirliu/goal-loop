"""Grouping helpers for the :mod:`auditlog` package.

The public entry point is :func:`summarize`, which turns a stream of valid
records (as produced by :func:`auditlog.codec.parse_line`) into one summary
object per key.
"""

__all__ = ["summarize"]


def _record_fields(record):
    """Return the ``(key, amount)`` pair stored in *record*.

    ``ValueError`` is raised when the record does not carry a usable key and
    amount, which keeps the failure mode consistent with the rest of the
    package.
    """
    try:
        key = record["key"]
        amount = record["amount"]
    except (TypeError, KeyError, IndexError):
        raise ValueError("record must provide 'key' and 'amount'") from None
    if not isinstance(key, str) or not key:
        raise ValueError("record 'key' must be a nonempty string")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("record 'amount' must be an integer")
    return key, amount


def summarize(records):
    """Summarize *records* by key.

    *records* is any iterable of valid records, each one a mapping holding a
    nonempty string ``key`` and an integer ``amount``.  The input is only
    read: neither the iterable nor the records it yields are modified.

    The result is a list of plain dictionaries sorted by key, each containing
    exactly the ``key``, ``count``, ``total``, ``min`` and ``max`` fields.  An
    empty input yields an empty list.
    """
    # key -> [count, total, min, max]
    groups = {}
    for record in records:
        key, amount = _record_fields(record)
        stats = groups.get(key)
        if stats is None:
            groups[key] = [1, amount, amount, amount]
        else:
            stats[0] += 1
            stats[1] += amount
            if amount < stats[2]:
                stats[2] = amount
            if amount > stats[3]:
                stats[3] = amount
    return [
        {
            "key": key,
            "count": count,
            "total": total,
            "min": smallest,
            "max": largest,
        }
        for key, (count, total, smallest, largest) in sorted(
            groups.items(), key=lambda item: item[0]
        )
    ]
