"""Parsing of audit log records.

A record is a single line of a UTF-8 JSON Lines file.  Valid records are
JSON objects carrying a nonempty string ``key`` and an integer ``amount``.
Any other field is ignored.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse one JSONL record and return its ``key`` and ``amount``.

    The returned dict holds exactly the two recognized fields; extra fields
    present in the source object are dropped and the original values are
    returned unchanged.

    Raises:
        ValueError: if the line is not a JSON object with a nonempty string
            ``key`` and an integer ``amount`` (``bool`` is not an integer
            here).
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = line.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("record is not valid UTF-8") from exc
    if not isinstance(line, str):
        raise ValueError("record must be a text line")

    try:
        payload = json.loads(line)
    except ValueError as exc:
        raise ValueError("record is not valid JSON: {}".format(exc)) from exc

    if not isinstance(payload, dict):
        raise ValueError("record must be a JSON object")
    if "key" not in payload:
        raise ValueError("record is missing 'key'")
    if "amount" not in payload:
        raise ValueError("record is missing 'amount'")

    key = payload["key"]
    amount = payload["amount"]

    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")

    return {"key": key, "amount": amount}
