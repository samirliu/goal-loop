"""Audit log helpers built on the standard library only.

The package offers two helpers:

* :func:`auditlog.codec.parse_line` -- parse a single JSON Lines record.
* :func:`auditlog.aggregate.summarize` -- group valid records by key.

They are also reachable straight from the package for convenience::

    from auditlog import parse_line, summarize

The names are resolved lazily so that importing a single submodule never drags
in the others.
"""

__all__ = ["parse_line", "summarize"]
__version__ = "1.0.0"


def __getattr__(name):
    if name == "parse_line":
        from .codec import parse_line

        return parse_line
    if name == "summarize":
        from .aggregate import summarize

        return summarize
    raise AttributeError("module {!r} has no attribute {!r}".format(__name__, name))


def __dir__():
    return sorted(set(globals()) | set(__all__))
