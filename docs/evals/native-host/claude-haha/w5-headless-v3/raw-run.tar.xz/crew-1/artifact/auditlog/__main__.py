"""Command line entry point: ``python -m auditlog --input PATH --output PATH``.

Reads a UTF-8 JSON Lines file, ignores blank lines and writes one JSON
object per key to the output file.  The output is published atomically, so a
failed run never damages an existing output file.
"""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line

PROG = "auditlog"


class _InputError(Exception):
    """Raised when the input cannot be read or holds an invalid record."""


def _parse_args(argv):
    parser = argparse.ArgumentParser(
        prog=PROG,
        description="Summarize an audit log JSON Lines file, grouped by key.",
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="PATH",
        help="UTF-8 JSON Lines file to read",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="JSON Lines file to write the summaries to",
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser.parse_args(argv)


def _read_records(path, skip_bad):
    """Return ``(records, skipped)`` for the JSON Lines file at *path*."""
    records = []
    skipped = 0
    try:
        handle = open(path, "rb")
    except FileNotFoundError:
        raise _InputError("input file not found: {}".format(path)) from None
    except IsADirectoryError:
        raise _InputError("input path is not a file: {}".format(path)) from None
    except OSError as exc:
        raise _InputError("cannot read input file {}: {}".format(path, exc)) from None

    with handle:
        for lineno, raw in enumerate(handle, start=1):
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                if skip_bad:
                    skipped += 1
                    continue
                raise _InputError("invalid UTF-8 on line {}".format(lineno)) from None
            if lineno == 1 and text.startswith("\ufeff"):
                text = text[1:]
            if not text.strip():
                continue
            try:
                record = parse_line(text)
            except ValueError:
                if skip_bad:
                    skipped += 1
                    continue
                raise _InputError("invalid record on line {}".format(lineno)) from None
            records.append(record)
    return records, skipped


def _write_output(path, groups):
    """Write *groups* to *path*, publishing the result atomically."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    handle = None
    temporary = None
    try:
        descriptor, temporary = tempfile.mkstemp(
            dir=directory, prefix=".auditlog-", suffix=".tmp"
        )
        handle = os.fdopen(descriptor, "w", encoding="utf-8", newline="\n")
        for group in groups:
            handle.write(json.dumps(group, ensure_ascii=False))
            handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        handle.close()
        handle = None
        os.chmod(temporary, _default_file_mode())
        os.replace(temporary, path)
        temporary = None
    finally:
        if handle is not None:
            handle.close()
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass


def _default_file_mode():
    """Return the file mode a plain ``open()`` would have produced."""
    mask = os.umask(0)
    os.umask(mask)
    return 0o666 & ~mask


def main(argv=None):
    """Run the command line interface and return its exit status."""
    args = _parse_args(argv)

    try:
        records, skipped = _read_records(args.input, args.skip_bad)
    except _InputError as exc:
        print("{}: {}".format(PROG, exc), file=sys.stderr)
        return 2

    try:
        _write_output(args.output, summarize(records))
    except OSError as exc:
        print("{}: cannot write output file {}: {}".format(PROG, args.output, exc), file=sys.stderr)
        return 2

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
