"""auditlog: a dependency-free audit log summariser.

``auditlog.codec.parse_line`` parses a single JSONL record and
``auditlog.aggregate.summarize`` groups valid records by key.  The
``python -m auditlog`` command reads a JSONL file and publishes the
summary as JSON.
"""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
