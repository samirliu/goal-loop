"""Parsing of audit log records.

A valid record is a JSON object with a nonempty string ``key`` and an
integer ``amount``.  Any other members are ignored.  Invalid records are
reported with :class:`ValueError`.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse one JSONL record into a ``{"key": ..., "amount": ...}`` dict.

    The returned dict is new and holds exactly the two members of the
    original record; every other member of the record is ignored.

    Raises ValueError when ``line`` is not a valid record.
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("record is not valid UTF-8") from exc
    if not isinstance(line, str):
        raise ValueError("record must be a string")

    try:
        obj = json.loads(line)
    except ValueError as exc:
        raise ValueError("record is not valid JSON") from exc

    if not isinstance(obj, dict):
        raise ValueError("record must be a JSON object")

    if "key" not in obj:
        raise ValueError("record is missing the 'key' member")
    key = obj["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if not key:
        raise ValueError("'key' must not be empty")

    if "amount" not in obj:
        raise ValueError("record is missing the 'amount' member")
    amount = obj["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")

    return {"key": key, "amount": amount}
