"""Grouping of audit log records by key."""

__all__ = ["summarize"]


def summarize(records):
    """Summarise ``records`` grouped by key.

    ``records`` is any iterable of mappings carrying a ``key`` and an
    ``amount`` member (as produced by :func:`auditlog.codec.parse_line`).
    The input is never modified.

    Returns a list of dicts sorted by key, each holding exactly the
    members ``key``, ``count``, ``total``, ``min`` and ``max``.
    """
    groups = {}

    for record in records:
        if not isinstance(record, dict):
            raise ValueError("record must be a mapping")

        try:
            key = record["key"]
            amount = record["amount"]
        except KeyError as exc:
            raise ValueError("record is missing the {!r} member".format(exc.args[0])) from exc

        if not isinstance(key, str):
            raise ValueError("'key' must be a string")
        if not key:
            raise ValueError("'key' must not be empty")
        if isinstance(amount, bool) or not isinstance(amount, int):
            raise ValueError("'amount' must be an integer")

        entry = groups.get(key)
        if entry is None:
            groups[key] = [1, amount, amount, amount]
        else:
            entry[0] += 1
            entry[1] += amount
            if amount < entry[2]:
                entry[2] = amount
            if amount > entry[3]:
                entry[3] = amount

    return [
        {"key": key, "count": count, "total": total, "min": lowest, "max": highest}
        for key, (count, total, lowest, highest) in sorted(groups.items())
    ]
