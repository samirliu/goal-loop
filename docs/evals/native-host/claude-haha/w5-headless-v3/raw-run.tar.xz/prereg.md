# W5 headless v3：修复版真实任务预注册

状态：执行前冻结。只在当前完整回归终态并通过后启动，不恢复36次W9，不续跑v1/v2或旧Work。

## 固定工作负载和比较

- 原auditlog-v1：tasks.prepare medium/911207、四个STARTERS、TASK.md/public.py、native_checks.py及独立21项grade.py保持原字节，不增加容易的替代任务或改成功定义。
- A为一个现有goal-loop-host:goal-worker完成全部四文件；B为两个相同角色，在同一真实assistant message中调用native Agent、同步并发。T1只拥有codec/main/init，T2只拥有aggregate。Agent为实际工具名，Task仅为兼容alias；不覆盖模型/effort，不用background或worker再派发。
- 固定ABBAAB：single-1、crew-1、crew-2、single-2、single-3、crew-3。按同编号配对，六个fresh CLI session，不resume、不追加第七例、不替换失败。
- 用户指定claude-haha --permission-mode bypassPermissions；实际MiniMax-M3.1-Flash映射，不冒称标准Claude。固定工具Agent,Read,Grep,Glob,Write,Edit,Bash，严格空MCP，无Web。max-turns=8是CLI parent约束，不能冒称限制child工具回合。
- 显式/goal-loop-host:goal-loop选择当前root SKILL；不创建同名project symlink。父模型只派发，不实现产物。worker使用返回的短First tool command，随后运行冻结named check；只读TASK/public和拥有文件，不读private grader、旧样本或.goal（执行受控READY入口除外），不创建域外scratch测试。

## 总预算与身份

- 本批全新controller/run/project，上限1800秒，从Python driver入口起算，早于模块、夹具准备、stamp及CLI启动。epoch/monotonic/boot收据保留；每轮host.begin仅收紧同一run的最早cap，不重发预算。stamp、排队、重试、join、父验证、final均计入。
- 1800秒为本次事先预算，参考已观测单worker273.706秒和六位置的准备/验收成本；两模式共同受限。旧v1原预算900秒、实际285.319秒因辅助估价cap提前停止；旧v2原预算900秒、实际899.126秒后停止。这些旧失败完整保留，不被新预算延长或池化。
- 不设置CLI美元估价cap：未知模型回退价目不是真实供应商账单。真实tokens/money总量保持null；CLI-reported usage/cost原字段保存，进程累积cost不跨phase相加，Agent元数据last-message usage不冒充全worker总量。
- 冻结production、SKILL、全部agents/references、hooks、plugin、任务和grader及关键客户端装载/Agent源码SHA；env只保存hash，不复制秘密。运行前与closed source-manifest逐项核对，运行中每轮复核原字节。
- 所有轮使用同一project、approval/合同、原输入、初始四文件bytes/modes、final grader及Python API producer。两种job图的condition分别各稳定一个值，六个batch_condition必须同一值，不错误要求不同job图的condition相等。

## 执行、终态与恢复

- 每轮prepare真实ticket，记录bootstrap prompt、assignment、首工具READY、actual agent/call ID、hook终态、CLI退出、父validate/adopt和final。按真实非空message.id合并stream片段，call_id去重，冲突拒绝，原事件保留。
- B必须同批且存在真实READY至native terminal的正重叠；仅同批或正文COMPLETE不证明成功。结构化Write/Edit域检查按冻结row.files，任意shell仍不是OS文件隔离；所有已观察协议偏离另审，不以controller protocol_ok替代全程合规。
- 所有native attempt终态且CLI退出后才独立validate，通过才adopt；原native.seal重跑同一final。质量、按时和协议分别报告，不填adversarial clear，不声称合同Gate GO。
- Wave.elapsed保留生产原定义；round/cohort墙钟另报。worker_seconds含prepare reservation、CLI冷启动/排队和观察延迟，不当供应商compute。coordination/join/conflict/recovery有发生才计时；未做则skip，不把并发span相加为墙钟。
- 到期cancel活跃ticket并终止所属CLI supervisor。任何CLI退出但attempt prepared/unknown，保留原输出、停止后续轮次，不能用CLI退出码伪造native终态。未派发位置和失败全部保留。
- reset只在原已派发attempt终态、Wave已seal，且当前bytes/modes与上轮归档final digest相同、输入未变时，恢复四个STARTERS和原权限。禁止在未知状态覆盖输出。

## planner和结论

- 只有六轮已seal、全部终态、源/输入未改时才按原守卫恢复baseline，调用原crew.plan读取真实history；无第七波。原截止已过接受stop，不给planner新预算。unknown/failure照旧留在最近窗口。
- 报告全部三对的质量、时间差、worker占用和选择权衡，不能筛最快成功。上下文、输入、条件、工具协议或并发有缺口时，不声称可比净收益。
- 本批仅限当前任务与backend，不证明相对/goal整体优势或通用自主进化，不按结果凑9分。早期v1/v2及Work负例继续单列。

启动入口：python3 -B /tmp/goal_w5_claude_headless_v3.py --execute --output /tmp/goal-w5-claude-auditlog-v3 --f5-ready /tmp/goal-v3-ready.json
