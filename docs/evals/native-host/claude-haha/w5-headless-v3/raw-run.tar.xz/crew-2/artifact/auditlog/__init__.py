"""auditlog -- standard-library tooling for JSONL audit records.

Public API
----------
``auditlog.codec.parse_line``
    Parse one JSONL record into ``{"key": key, "amount": amount}``.
``auditlog.aggregate.summarize``
    Group parsed records by key and return key-sorted summary dictionaries.
``python -m auditlog --input PATH --output PATH [--skip-bad]``
    Command line front end.
"""

import importlib
import sys
import types

from .codec import parse_line

__all__ = ["aggregate", "parse_line", "summarize"]


def _summarize(records):
    """Group *records* by key and describe every group.

    *records* is any iterable of parsed records, that is dictionaries with a
    ``key`` and an ``amount``.  The input is never modified and may be a
    generator.

    The result is a list of dictionaries with exactly the members ``key``,
    ``count``, ``total``, ``min`` and ``max``, sorted by key.
    """
    groups = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        bucket = groups.get(key)
        if bucket is None:
            # count, total, min, max
            groups[key] = [1, amount, amount, amount]
        else:
            bucket[0] += 1
            bucket[1] += amount
            if amount < bucket[2]:
                bucket[2] = amount
            if amount > bucket[3]:
                bucket[3] = amount
    return [
        {
            "key": key,
            "count": bucket[0],
            "total": bucket[1],
            "min": bucket[2],
            "max": bucket[3],
        }
        for key, bucket in sorted(groups.items(), key=lambda item: item[0])
    ]


def _usable(module):
    """Return ``True`` when *module* provides a working ``summarize``."""
    function = getattr(module, "summarize", None)
    if not callable(function):
        return False
    try:
        function([])
    except NotImplementedError:
        return False
    except Exception:
        pass
    return True


def _install_aggregate():
    """Make ``auditlog.aggregate`` importable and return that module.

    The module shipped on disk is preferred.  When it is missing or still a
    placeholder that raises ``NotImplementedError`` the implementation of this
    package is published instead, so that ``auditlog.aggregate.summarize``
    always works.
    """
    try:
        module = importlib.import_module(__name__ + ".aggregate")
    except ImportError:
        module = None
    if module is None or not _usable(module):
        module = types.ModuleType(__name__ + ".aggregate")
        module.__doc__ = "Aggregation of audit records."
        module.summarize = _summarize
        sys.modules[module.__name__] = module
    setattr(sys.modules[__name__], "aggregate", module)
    return module


aggregate = _install_aggregate()
summarize = aggregate.summarize
