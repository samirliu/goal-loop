"""Command line front end of the auditlog package.

Usage::

    python -m auditlog --input PATH --output PATH [--skip-bad]

The input is a UTF-8 JSONL file; blank lines are ignored and every valid
record is grouped by key.  The output holds one JSON object per key.  It is
published atomically, so an existing output file is either replaced as a
whole or left untouched.
"""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line

__all__ = ["main"]


class InvalidRecord(Exception):
    """A record that could not be parsed, together with its physical line."""

    def __init__(self, lineno, reason):
        super().__init__(reason)
        self.lineno = lineno
        self.reason = reason


def build_parser():
    """Return the argument parser of the command line front end."""
    parser = argparse.ArgumentParser(
        prog="auditlog",
        description="Summarize JSONL audit records by key.",
    )
    parser.add_argument(
        "--input", required=True, metavar="PATH", help="JSONL file to read"
    )
    parser.add_argument(
        "--output", required=True, metavar="PATH", help="JSON file to publish"
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def collect(path, skip_bad=False):
    """Read the JSONL file *path* and return ``(records, skipped)``.

    Blank lines are ignored.  Invalid records raise :class:`InvalidRecord`
    unless *skip_bad* is true, in which case they are counted and skipped.
    """
    records = []
    skipped = 0
    with open(path, "r", encoding="utf-8") as handle:
        for lineno, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                records.append(parse_line(line))
            except ValueError as exc:
                if skip_bad:
                    skipped += 1
                    continue
                raise InvalidRecord(lineno, str(exc)) from None
    return records, skipped


def render(rows):
    """Render the summary *rows* as JSON lines."""
    return "".join(json.dumps(row) + "\n" for row in rows)


def publish(path, text):
    """Write *text* to *path* atomically.

    The text is written to a temporary file next to *path* and then moved
    into place, so readers never observe a half written output.
    """
    directory = os.path.dirname(os.path.abspath(path))
    descriptor, temporary = tempfile.mkstemp(
        prefix=".auditlog-", suffix=".tmp", dir=directory
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def main(argv=None):
    """Run the command line front end and return its exit status."""
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        records, skipped = collect(args.input, skip_bad=args.skip_bad)
    except InvalidRecord as exc:
        print(
            "auditlog: {0}:{1}: invalid record on line {1}: {2}".format(
                args.input, exc.lineno, exc.reason
            ),
            file=sys.stderr,
        )
        return 2
    except FileNotFoundError:
        print(
            "auditlog: input file not found: {0}".format(args.input), file=sys.stderr
        )
        return 2
    except IsADirectoryError:
        print(
            "auditlog: input path is a directory: {0}".format(args.input),
            file=sys.stderr,
        )
        return 2
    except UnicodeDecodeError as exc:
        print(
            "auditlog: {0}: input is not valid UTF-8: {1}".format(args.input, exc),
            file=sys.stderr,
        )
        return 2
    except OSError as exc:
        print(
            "auditlog: cannot read {0}: {1}".format(args.input, exc), file=sys.stderr
        )
        return 2

    try:
        publish(args.output, render(summarize(records)))
    except OSError as exc:
        print(
            "auditlog: cannot write {0}: {1}".format(args.output, exc), file=sys.stderr
        )
        return 1

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
