"""Aggregation of valid audit records into per-key summaries.

The public entry point is :func:`summarize`, which consumes the records
produced by :func:`auditlog.codec.parse_line` and reduces them to one
summary dict per distinct key.
"""

__all__ = ["summarize"]


def summarize(records):
    """Group valid audit records by key and summarize each group.

    ``records`` is an iterable of mappings, each holding a nonempty string
    ``key`` and an integer ``amount`` (extra fields are ignored).  The input
    is consumed but never modified.

    Returns a list of dicts sorted by key, each containing exactly the
    keys ``key``, ``count``, ``total``, ``min`` and ``max``.  An empty
    iterable yields an empty list.  Arbitrarily large positive or negative
    integer amounts are handled exactly, since Python integers have
    unbounded precision.
    """
    groups = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        entry = groups.get(key)
        if entry is None:
            # count, total, min, max
            groups[key] = [1, amount, amount, amount]
        else:
            entry[0] += 1
            entry[1] += amount
            if amount < entry[2]:
                entry[2] = amount
            if amount > entry[3]:
                entry[3] = amount

    return [
        {
            "key": key,
            "count": groups[key][0],
            "total": groups[key][1],
            "min": groups[key][2],
            "max": groups[key][3],
        }
        for key in sorted(groups)
    ]
