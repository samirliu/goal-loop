"""Parsing of single JSONL audit records.

A record is a JSON object carrying a nonempty string ``key`` and an integer
``amount``.  Every other member of the object is ignored.  ``bool`` values are
never accepted as amounts even though ``bool`` is a subclass of ``int``.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse *line* and return ``{"key": key, "amount": amount}``.

    The original values are returned unchanged; extra fields of the JSON
    object are dropped.

    :raises ValueError: if *line* does not hold a valid record.
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            text = bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("record is not valid UTF-8: {0}".format(exc)) from None
    elif isinstance(line, str):
        text = line
    else:
        raise ValueError(
            "record must be a string, got {0}".format(type(line).__name__)
        )

    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        # Only the message is kept: the positional detail of the JSON error
        # refers to the record itself and would be confusing next to the
        # physical line number reported by the command line front end.
        raise ValueError("record is not valid JSON: {0}".format(exc.msg)) from None
    except ValueError as exc:
        raise ValueError("record is not valid JSON: {0}".format(exc)) from None

    if not isinstance(payload, dict):
        raise ValueError("record must be a JSON object")

    if "key" not in payload:
        raise ValueError('record is missing "key"')
    key = payload["key"]
    if not isinstance(key, str):
        raise ValueError('"key" must be a string')
    if not key:
        raise ValueError('"key" must not be empty')

    if "amount" not in payload:
        raise ValueError('record is missing "amount"')
    amount = payload["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError('"amount" must be an integer')

    return {"key": key, "amount": amount}
