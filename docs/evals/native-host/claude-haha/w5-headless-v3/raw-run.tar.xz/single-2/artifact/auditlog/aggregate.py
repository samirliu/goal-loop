"""Grouping of audit records by key."""

from collections.abc import Mapping

__all__ = ["summarize"]


def _fields(record):
    """Return the validated ``(key, amount)`` pair of one record."""
    if not isinstance(record, Mapping):
        raise ValueError(f"expected a record mapping, got {type(record).__name__}")
    if "key" not in record:
        raise ValueError('missing "key" field')
    if "amount" not in record:
        raise ValueError('missing "amount" field')

    key = record["key"]
    amount = record["amount"]

    if not isinstance(key, str):
        raise ValueError(f'"key" must be a string, got {type(key).__name__}')
    if not key:
        raise ValueError('"key" must be a nonempty string')
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError(f'"amount" must be an integer, got {type(amount).__name__}')

    return key, amount


def summarize(records):
    """Summarize ``records`` grouped by key.

    ``records`` is any iterable of valid records (a list, a generator, ...);
    it is only read, never modified.  The result is a list of dicts sorted by
    key, each holding exactly ``key``, ``count``, ``total``, ``min`` and
    ``max``.  An empty input yields an empty list.
    """
    groups = {}
    for record in records:
        key, amount = _fields(record)
        stats = groups.get(key)
        if stats is None:
            groups[key] = [1, amount, amount, amount]
        else:
            stats[0] += 1
            stats[1] += amount
            if amount < stats[2]:
                stats[2] = amount
            if amount > stats[3]:
                stats[3] = amount

    return [
        {
            "key": key,
            "count": stats[0],
            "total": stats[1],
            "min": stats[2],
            "max": stats[3],
        }
        for key, stats in sorted(groups.items())
    ]
