"""auditlog: parse and summarize JSONL audit records.

The package exposes two helpers:

``auditlog.codec.parse_line``
    Parse one JSONL record into ``{"key": ..., "amount": ...}`` or raise
    :class:`ValueError`.

``auditlog.aggregate.summarize``
    Group records by key and return key-sorted dicts with ``key``, ``count``,
    ``total``, ``min`` and ``max``.
"""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
