"""Command line interface of the auditlog package.

Usage::

    python -m auditlog --input PATH --output PATH [--skip-bad]

The input is a UTF-8 JSONL stream; blank lines are ignored.  The output holds
one JSON object per key, published atomically.  Without ``--skip-bad`` an
invalid record aborts with exit status 2 and leaves any existing output
untouched; with ``--skip-bad`` invalid records are counted and reported on
stderr as ``{"skipped":N}``.
"""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line

__all__ = ["main"]


class _InvalidRecord(Exception):
    """A physical input line that does not hold a valid record."""

    def __init__(self, lineno, reason, raw):
        super().__init__(reason)
        self.lineno = lineno
        self.reason = reason
        self.raw = raw


def _build_parser():
    parser = argparse.ArgumentParser(
        prog="auditlog",
        description="Summarize JSONL audit records by key.",
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="PATH",
        help="UTF-8 JSONL file with one audit record per line",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="file that receives one JSON object per key",
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def _parse_raw(raw):
    """Return ``(record, error)`` for one physical line.

    ``record`` is ``None`` for a blank line and ``error`` is ``None`` for a
    blank line or a valid record.
    """
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        return None, f"invalid UTF-8 encoding: {exc.reason}"
    if not text.strip():
        return None, None
    try:
        return parse_line(text), None
    except ValueError as exc:
        return None, str(exc)


def _read_records(path, skip_bad):
    """Read ``path`` and return ``(records, skipped)``."""
    records = []
    skipped = 0
    with open(path, "rb") as handle:
        for lineno, raw in enumerate(handle, 1):
            record, error = _parse_raw(raw)
            if error is not None:
                if skip_bad:
                    skipped += 1
                    continue
                raise _InvalidRecord(lineno, error, raw)
            if record is not None:
                records.append(record)
    return records, skipped


def _current_umask():
    mask = os.umask(0)
    os.umask(mask)
    return mask


def _publish(path, groups):
    """Write ``groups`` to ``path`` atomically."""
    directory = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(directory, exist_ok=True)
    handle, temporary = tempfile.mkstemp(dir=directory, prefix=".auditlog-", suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            for group in groups:
                stream.write(json.dumps(group) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o666 & ~_current_umask())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    try:
        directory_fd = os.open(directory, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(directory_fd)
    except OSError:
        pass
    finally:
        os.close(directory_fd)


def main(argv=None):
    """Run the command line interface and return the exit status."""
    args = _build_parser().parse_args(argv)

    try:
        records, skipped = _read_records(args.input, args.skip_bad)
    except FileNotFoundError:
        sys.stderr.write(f"auditlog: input file not found: {args.input}\n")
        return 2
    except IsADirectoryError:
        sys.stderr.write(f"auditlog: input path is a directory: {args.input}\n")
        return 2
    except OSError as exc:
        sys.stderr.write(f"auditlog: cannot read input {args.input}: {exc}\n")
        return 2
    except _InvalidRecord as exc:
        raw = exc.raw
        if len(raw) > 80:
            raw = raw[:80] + b"..."
        sys.stderr.write(
            f"auditlog: invalid record at line {exc.lineno}: {exc.reason} | {raw!r}\n"
        )
        return 2

    try:
        _publish(args.output, summarize(records))
    except OSError as exc:
        sys.stderr.write(f"auditlog: cannot write output {args.output}: {exc}\n")
        return 2

    if args.skip_bad:
        sys.stderr.write(json.dumps({"skipped": skipped}) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
