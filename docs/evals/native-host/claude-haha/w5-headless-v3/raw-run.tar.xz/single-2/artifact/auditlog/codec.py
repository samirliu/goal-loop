"""Parsing of single JSONL audit records.

A valid record is a JSON object carrying a nonempty string ``key`` and an
integer ``amount``.  Any other field is ignored.  Everything that is not a
valid record raises :class:`ValueError`.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse one JSONL audit record.

    ``line`` is the physical text of a single record (surrounding whitespace
    and a trailing newline are tolerated).  The return value is a new dict
    holding exactly the original ``key`` and ``amount`` of the record.

    Raises :class:`ValueError` when the line is not a JSON object with a
    nonempty string ``key`` and an integer ``amount`` (``bool`` is not an
    integer here).
    """
    if isinstance(line, (bytes, bytearray)):
        try:
            line = bytes(line).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"invalid UTF-8 encoding: {exc.reason}") from exc
    if not isinstance(line, str):
        raise ValueError(f"expected a JSON line, got {type(line).__name__}")

    try:
        record = json.loads(line)
    except json.JSONDecodeError as exc:
        # ``exc.msg`` on purpose: the positional detail of JSONDecodeError
        # mentions "line 1", which would be misleading for a JSONL stream.
        raise ValueError(f"invalid JSON: {exc.msg}") from exc
    except ValueError as exc:
        raise ValueError(f"invalid JSON: {exc}") from exc

    if not isinstance(record, dict):
        raise ValueError(f"expected a JSON object, got {type(record).__name__}")

    if "key" not in record:
        raise ValueError('missing "key" field')
    if "amount" not in record:
        raise ValueError('missing "amount" field')

    key = record["key"]
    amount = record["amount"]

    if not isinstance(key, str):
        raise ValueError(f'"key" must be a string, got {type(key).__name__}')
    if not key:
        raise ValueError('"key" must be a nonempty string')
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError(f'"amount" must be an integer, got {type(amount).__name__}')

    return {"key": key, "amount": amount}
