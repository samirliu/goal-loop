"""Aggregation of audit log records into per-key summaries."""

__all__ = ["summarize"]


def summarize(records):
    """Summarise an iterable of records into per-key statistics.

    ``records`` is any iterable of records (a list, a generator, ...) whose
    entries carry a nonempty string ``key`` and an integer ``amount``.  The
    input is only read, never modified.

    The result is a list of dicts ordered by key.  Each dict holds exactly
    the entries ``key``, ``count``, ``total``, ``min`` and ``max``.
    """
    groups = {}
    for record in records:
        key, amount = _fields(record)
        entry = groups.get(key)
        if entry is None:
            groups[key] = {
                "key": key,
                "count": 1,
                "total": amount,
                "min": amount,
                "max": amount,
            }
            continue
        entry["count"] += 1
        entry["total"] += amount
        if amount < entry["min"]:
            entry["min"] = amount
        if amount > entry["max"]:
            entry["max"] = amount
    return [groups[key] for key in sorted(groups)]


def _fields(record):
    """Return the validated ``(key, amount)`` pair of ``record``."""
    if not isinstance(record, dict):
        raise ValueError("record must be a mapping")
    if "key" not in record:
        raise ValueError("record is missing 'key'")
    key = record["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if key == "":
        raise ValueError("'key' must not be empty")
    if "amount" not in record:
        raise ValueError("record is missing 'amount'")
    amount = record["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")
    return key, amount
