"""Parsing of single audit log records.

A record is one line of a UTF-8 JSONL audit log.  Only the ``key`` and
``amount`` fields are meaningful; every other field in the source object is
ignored.
"""

import json

__all__ = ["parse_line"]


def parse_line(line):
    """Parse one JSONL line and return the record it describes.

    The returned dict holds exactly two entries: the original ``key`` (a
    nonempty string) and the original ``amount`` (an integer; ``bool`` is
    rejected even though it is a subclass of ``int``).  Extra fields of the
    source object are ignored.

    A :class:`ValueError` is raised for every invalid record: malformed
    JSON, a JSON value that is not an object, a missing/invalid ``key`` or a
    missing/invalid ``amount``.
    """
    try:
        obj = json.loads(line)
    except ValueError as exc:
        # json.JSONDecodeError is a ValueError already; normalise the text so
        # that the message never mentions a second, JSON-internal line number.
        raise ValueError(_reason(exc)) from exc
    except TypeError as exc:
        raise ValueError("record must be text: {0}".format(exc)) from exc

    if not isinstance(obj, dict):
        raise ValueError("record must be a JSON object")

    if "key" not in obj:
        raise ValueError("record is missing 'key'")
    key = obj["key"]
    if not isinstance(key, str):
        raise ValueError("'key' must be a string")
    if key == "":
        raise ValueError("'key' must not be empty")

    if "amount" not in obj:
        raise ValueError("record is missing 'amount'")
    amount = obj["amount"]
    if isinstance(amount, bool) or not isinstance(amount, int):
        raise ValueError("'amount' must be an integer")

    return {"key": key, "amount": amount}


def _reason(exc):
    """Return a short reason for ``exc`` without JSON-internal line numbers."""
    text = str(exc)
    for separator in (": line ", ", line "):
        if separator in text:
            text = text.split(separator, 1)[0]
            break
    return text.strip() or "invalid JSON"
