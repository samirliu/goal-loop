"""Command line entry point: ``python -m auditlog --input PATH --output PATH``.

Reads a UTF-8 JSONL audit log, groups the records by key and writes one
JSON object per key to the output file.  The output is published atomically:
either the complete summary replaces the target file, or the target file is
left untouched.
"""

import argparse
import json
import os
import sys
import tempfile

try:  # normal package execution: ``python -m auditlog``
    from .aggregate import summarize
    from .codec import parse_line
except ImportError:  # pragma: no cover - loaded without its package
    from auditlog.aggregate import summarize
    from auditlog.codec import parse_line

__all__ = ["main"]

PROG = "auditlog"


class InputError(Exception):
    """Raised when the input cannot be read or a record is invalid."""


def build_parser():
    """Return the argument parser of the ``auditlog`` command."""
    parser = argparse.ArgumentParser(
        prog=PROG,
        description="Summarize a JSONL audit log into one JSON object per key.",
    )
    parser.add_argument(
        "--input",
        required=True,
        metavar="PATH",
        help="path of the JSONL audit log to read",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="PATH",
        help="path of the JSON summary file to write",
    )
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def main(argv=None):
    """Run the command; return the process exit status."""
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        records, skipped = read_records(args.input, args.skip_bad)
    except InputError as exc:
        print("{0}: {1}".format(PROG, exc), file=sys.stderr)
        return 2

    try:
        summary = summarize(records)
    except ValueError as exc:
        print("{0}: invalid record: {1}".format(PROG, exc), file=sys.stderr)
        return 2

    payload = "".join(
        json.dumps(entry, ensure_ascii=False) + "\n" for entry in summary
    )

    try:
        publish(args.output, payload)
    except OSError as exc:
        print(
            "{0}: cannot write output {1}: {2}".format(PROG, args.output, exc),
            file=sys.stderr,
        )
        return 2

    if args.skip_bad:
        print(
            json.dumps({"skipped": skipped}, separators=(",", ":")),
            file=sys.stderr,
        )
    return 0


def read_records(path, skip_bad):
    """Return ``(records, skipped)`` read from the JSONL file ``path``.

    Blank lines are ignored.  An invalid record aborts the read with an
    :class:`InputError` naming its physical line, unless ``skip_bad`` is
    true, in which case it is counted and skipped.
    """
    records = []
    skipped = 0
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            for number, raw in enumerate(handle, start=1):
                if not raw.strip():
                    continue
                try:
                    record = parse_line(raw)
                except ValueError as exc:
                    if skip_bad:
                        skipped += 1
                        continue
                    raise InputError(
                        "line {0}: invalid record: {1}".format(number, exc)
                    ) from None
                records.append(record)
    except InputError:
        raise
    except FileNotFoundError:
        raise InputError("input file not found: {0}".format(path)) from None
    except IsADirectoryError:
        raise InputError("input path is not a file: {0}".format(path)) from None
    except UnicodeDecodeError:
        raise InputError(
            "input file is not valid UTF-8: {0}".format(path)
        ) from None
    except OSError as exc:
        raise InputError(
            "cannot read input {0}: {1}".format(path, exc)
        ) from None
    return records, skipped


def publish(path, payload):
    """Write ``payload`` to ``path`` atomically.

    The content is written to a temporary file next to the target and then
    renamed over it, so the target is never seen half written.
    """
    directory = os.path.dirname(os.path.abspath(path)) or "."
    handle, temporary = tempfile.mkstemp(
        dir=directory, prefix=".{0}-".format(PROG), suffix=".tmp"
    )
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


if __name__ == "__main__":
    sys.exit(main())
