from pathlib import Path
import sys
p=Path(sys.argv[1])
raise SystemExit(0 if p.is_file() and p.read_bytes()==b"READY\n" else 1)
