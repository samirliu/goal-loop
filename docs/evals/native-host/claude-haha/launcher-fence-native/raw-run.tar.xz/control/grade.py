from pathlib import Path
raise SystemExit(0 if all(Path(n).is_file() and Path(n).read_bytes()==b"READY\n" for n in ("out1.txt","out2.txt")) and not any(Path(n).exists() for n in ("forbidden-T1.txt","forbidden-T2.txt")) else 1)
