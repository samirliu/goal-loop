# Goal

## Acceptance criteria

- AC-1 | exact artifact | check: `/opt/homebrew/opt/python@3.14/bin/python3.14 -B /tmp/goal-claude-hooks-launcher-rg1v7ekj/control/grade.py` | expected: exit=0

## Approval

approved: 75e77e63 2026-11-12 auto
