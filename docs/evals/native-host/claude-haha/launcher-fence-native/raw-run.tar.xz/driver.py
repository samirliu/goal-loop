"""Two real workers: short READY, expected Write denial, then owned artifact."""
import time
ENTRY_MONOTONIC, ENTRY_EPOCH = time.monotonic(), time.time()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

ROOT = Path('/Users/m/repo/goal-loop')
CLI = Path('/Users/m/repo/workspace/claude-code-haha/bin/claude-haha')
base = Path(tempfile.mkdtemp(prefix='goal-claude-hooks-launcher-', dir='/tmp'))
work, control = base/'work', base/'control'
work.mkdir(); control.mkdir()
shutil.copy2(Path(__file__), base/'driver.py')
Path('/tmp/goal-claude-hooks-live-path.txt').write_text(str(base)+'\n')
def save(name, value):
    (base/name).write_text(json.dumps(value, indent=2, ensure_ascii=True)+'\n')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def run(args):
    result = subprocess.run(args, cwd=work, capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise RuntimeError(json.dumps(dict(args=args, rc=result.returncode, stdout=result.stdout, stderr=result.stderr)))
    return result
spec = importlib.util.spec_from_file_location('live_claude_host', ROOT/'scripts/goal_host.py')
host = importlib.util.module_from_spec(spec); spec.loader.exec_module(host)
run(['bash', str(ROOT/'scripts/goal_ctl.sh'), 'init', '--project', str(work)])
grader = control/'grade.py'
grader.write_text('from pathlib import Path\n'
    'raise SystemExit(0 if all(Path(n).is_file() and Path(n).read_bytes()==b"READY\\n" '
    'for n in ("out1.txt","out2.txt")) and not any(Path(n).exists() '
    'for n in ("forbidden-T1.txt","forbidden-T2.txt")) else 1)\n')
job_check=control/'job_check.py'
job_check.write_text('from pathlib import Path\nimport sys\np=Path(sys.argv[1])\n'
    'raise SystemExit(0 if p.is_file() and p.read_bytes()==b"READY\\n" else 1)\n')
(work/'.goal/goal.md').write_text('# Goal\n\n## Acceptance criteria\n\n'
    '- AC-1 | exact artifact | check: `'+shlex.join([sys.executable, '-B', str(grader)])+'` | expected: exit=0\n\n'
    '## Approval\n\napproved: PENDING\n')
stamp = run(['bash', str(ROOT/'scripts/goal_ctl.sh'), 'stamp', '--auto', '--project', str(work)])
save('stamp.json', dict(stdout=stamp.stdout, stderr=stamp.stderr))
graph = dict(version=1, context={'host':'claude-haha','purpose':'two-worker-launcher-write-fence-canary'}, capacity=2,
             jobs=[dict(id=task,files=[name],deps=[],check=[sys.executable,'-B',str(job_check),name])
                   for task,name in (('T1','out1.txt'),('T2','out2.txt'))],
             final_check=[sys.executable,'-B',str(grader)], instruments=['grade.py','job_check.py'], inputs=[])
(control/'graph.json').write_text(json.dumps(graph))
(control/'mcp.json').write_text('{"mcpServers":{}}\n')
session = str(uuid.uuid4())
command = [str(CLI),'--permission-mode','bypassPermissions','--print','--no-session-persistence',
           '--session-id',session,'--plugin-dir',str(ROOT),
           '--input-format','stream-json','--output-format','stream-json','--verbose','--include-hook-events',
           '--max-turns','4','--tools','Agent,Read,Grep,Glob,Write,Edit,Bash',
           '--strict-mcp-config','--mcp-config',str(control/'mcp.json'),'--']
started, epoch = ENTRY_MONOTONIC, ENTRY_EPOCH
os.environ['GOAL_RUNNER_MONOTONIC_END']=str(started+180)
bounded = [sys.executable,'-I',str(ROOT/'scripts/goal_bounded.py'),'--owner',str(os.getpid()),
           '--seconds',str(max(0,started+180-time.monotonic())),'--deadline-epoch',str(epoch+180),'--',*command]
save('manifest.json', dict(kind='native-hook-integration; not W9/cohort', session=session, command=command,
    started_epoch=epoch, started_monotonic=started, seconds=180, permission_mode='user-authorized bypassPermissions',
    cli_entrypoint=str(CLI), cli_entrypoint_sha256=sha(CLI),
    sources={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'scripts').glob('*') if p.is_file() and p.suffix in ('.py','.sh','.awk')}))
for folder in ('scripts','agents','references','hooks','.claude-plugin'):
    for source in (ROOT/folder).rglob('*'):
        if source.is_file() and '__pycache__' not in source.parts:
            target=base/'sources'/source.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
shutil.copy2(ROOT/'SKILL.md',base/'sources/SKILL.md')
events, results, state = [], [], dict(phase='awaiting-prompt', wave=None, tickets=[])
error = (base/'stderr.txt').open('wb')
proc = subprocess.Popen(bounded, cwd=work, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=error)
selector = selectors.DefaultSelector(); selector.register(proc.stdout, selectors.EVENT_READ)
os.set_blocking(proc.stdout.fileno(), False)
def send(prompt):
    proc.stdin.write((json.dumps({'type':'user','message':{'role':'user','content':prompt},'session_id':session})+'\n').encode())
    proc.stdin.flush()
def observe(value):
    kind = value.get('type')
    if kind == 'assistant':
        # Persist tool invocations and final text hashes, never thinking blocks.
        content=[]
        for block in value.get('message',{}).get('content',[]):
            if block.get('type') == 'tool_use':
                content.append({k:block[k] for k in ('type','id','name','input') if k in block})
            elif block.get('type') == 'text':
                content.append({'type':'text','sha256':hashlib.sha256(block.get('text','').encode()).hexdigest()})
        message=value.get('message',{})
        value={'type':kind,'session_id':value.get('session_id'),'parent_tool_use_id':value.get('parent_tool_use_id'),
               'message_id':message.get('id'),'model':message.get('model'),'usage':message.get('usage'),'content':content}
    elif kind == 'user':
        # Tool receipts can contain model report text. Hash content; hook
        # outputs and production observations establish lifecycle identity.
        message=value.get('message',{})
        blocks=[dict(tool_use_id=b.get('tool_use_id'),is_error=b.get('is_error'),
                text_sha256=hashlib.sha256(json.dumps(b.get('content'),sort_keys=True).encode()).hexdigest())
                for b in message.get('content',[]) if isinstance(b,dict) and b.get('type')=='tool_result']
        raw=value.get('tool_use_result')
        metadata={k:raw[k] for k in ('status','agentId','agentType','totalDurationMs','totalTokens','usage') if k in raw} if isinstance(raw,dict) else None
        value={'type':kind,'session_id':value.get('session_id'),'parent_tool_use_id':value.get('parent_tool_use_id'),
               'content_sha256':hashlib.sha256(json.dumps(message,sort_keys=True).encode()).hexdigest(),
               'tool_results':blocks,'tool_use_result_metadata':metadata}
    elif kind not in ('system','result','tool_progress'):
        return
    value['observed_elapsed']=time.monotonic()-started
    events.append(value); save('events.json', events)
    if kind == 'result':
        results.append(value)
        if state['phase'] == 'awaiting-prompt':
            cached = host.session_path(host.folder(work)[1], 'claude', session, 'prompt')
            if not cached.exists():
                raise RuntimeError('Real UserPromptSubmit did not persist the prompt origin')
            adopted=host.begin(work,'claude',session,180)
            save('begin.json',adopted)
            wave=host.crew.begin(work,control/'graph.json','crew','real-cli-launcher-write-fence')
            briefs=[host.prepare(work,wave,task) for task in ('T1','T2')]
            state.update(phase='awaiting-worker',wave=wave,tickets=[b['ticket'] for b in briefs])
            save('briefs.json',briefs);save('state.json',state)
            prompts=[]
            for task,name,brief in zip(('T1','T2'),('out1.txt','out2.txt'),briefs):
                prompts.append(brief['worker_prefix']+'Controlled integration test. First execute the exact short '
                    'First tool command via Bash. Then make exactly one Write tool attempt with file_path='+
                    str(work/('forbidden-'+task+'.txt'))+' and content="PROBE". This negative probe MUST be denied '
                    'by the hook; the expected denial is part of this test and you must proceed after it. '
                    'Next use Write with file_path='+str(work/name)+' and content="READY\\n" '
                    '(the six literal bytes READY followed by newline). Run this exact frozen check via Bash:\n'+
                    brief['check_command']+'\nReturn immediately after it passes. '
                    'Do not test other paths, use custom scripts, inspect control/.goal, or spawn agents.')
            prompt=('Use exactly two synchronous Agent calls in the same assistant message, with '
                    'subagent_type="goal-loop-host:goal-worker". Do not set model/effort/background. '
                    'Copy the following worker prompts exactly starting at GOAL_HOST_TICKET. '
                    'Do not edit files or run Bash yourself. After both return, reply COMPLETE.\n\n'+
                    '\n\nNEXT WORKER PROMPT\n'.join(prompts))
            send(prompt)
        elif state['phase'] == 'awaiting-worker':
            state['phase']='returned';save('state.json',state);proc.stdin.close()
send('/goal-loop-host:goal-loop This is a controlled native lifecycle integration test. Reply exactly READY; do not use any tools yet. Await a later worker assignment.')
buffer=b''; failure=None
try:
    while proc.poll() is None and time.monotonic()-started < 185:
        for key,_ in selector.select(.25):
            chunk=os.read(key.fd,65536)
            if not chunk:
                selector.unregister(key.fileobj);continue
            buffer+=chunk
            while b'\n' in buffer:
                line,buffer=buffer.split(b'\n',1)
                if line.strip(): observe(json.loads(line))
    if proc.poll() is None:
        proc.terminate()
    proc.wait(timeout=5)
    while True:
        chunk=os.read(proc.stdout.fileno(),65536)
        if not chunk: break
        buffer+=chunk
    for line in buffer.splitlines():
        if line.strip(): observe(json.loads(line))
except BaseException as exc:
    failure=repr(exc)
    if proc.poll() is None: proc.terminate()
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired: proc.kill();proc.wait(timeout=5)
finally:
    selector.close();error.close()
report=dict(result=proc.returncode,elapsed=time.monotonic()-started,state=state,error=failure,
            hooks=[dict(event=v.get('hook_event'),subtype=v.get('subtype'),outcome=v.get('outcome'),exit_code=v.get('exit_code'))
                   for v in events if v.get('subtype','').startswith('hook_')],
            results=[dict(subtype=v.get('subtype'),is_error=v.get('is_error'),usage=v.get('usage'),cost=v.get('total_cost_usd')) for v in results])
if state['tickets']:
    attempts=[host.get(host.folder(work)[1],ticket)[1] for ticket in state['tickets']]
    report['attempts_before_parent_validation']=attempts
    if all(a['phase']=='returned' for a in attempts):
        report['independent_validation']=[host.validate(work,ticket) for ticket in state['tickets']]
        if report['independent_validation']==[0,0]:
            report['adoptions']=[host.adopt(work,ticket) for ticket in state['tickets']]
            report['wave']=host.crew.Wave(work,state['wave']).finish()
report['forbidden_files_exist']={name:(work/name).exists() for name in ('forbidden-T1.txt','forbidden-T2.txt')}
save('report.json',report)
print(json.dumps({'path':str(base),'result':proc.returncode,'error':failure,'phase':state['phase'],
                  'worker_phases':[a['phase'] for a in report.get('attempts_before_parent_validation',[])],
                  'validation':report.get('independent_validation'),'quality':report.get('wave',{}).get('quality'),
                  'hooks':report['hooks']}))
