#!/usr/bin/env python3
"""Prepare/seal a real-host trial; native tools dispatch the actual workers.

No model client, synthetic inference delay or replacement scheduler lives in
this fixture. Receipts are supplied from the caller's actual host tools.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def encode(value):
    return json.dumps(value, indent=2, sort_keys=True)+'\n'


def prepare(output, mode, reuse=None):
    started = dict(epoch=time.time(), monotonic=time.monotonic())
    output.mkdir(parents=True, exist_ok=False)
    tasks = module('native_crew_tasks', ROOT / 'examples/agent-evals/tasks.py')
    host = module('native_crew_host', ROOT / 'scripts/goal_host.py')
    if reuse is None:
        control = output / 'control'; control.mkdir()
        work = output / 'work'
        tasks.prepare(work, 'medium', 911207)
        shutil.copy2(ROOT / 'examples/agent-evals/grade.py', control / 'grade.py')
        shutil.copy2(Path(__file__).with_name('native_checks.py'), control / 'job_check.py')
    else:
        work = reuse.resolve(strict=True)
        control = work.parent / 'control'
        for old in host.folder(work)[1].glob('attempt-*.json'):
            if host.load(old)['phase'] not in ('returned', 'failed', 'cancelled'):
                raise RuntimeError('active native worker; refusing to reset owned files')
        for name, code in tasks.STARTERS['medium'].items():
            (work/name).write_text(code)
    origin = host.capture('work', 'native-suite', 'tool')
    origin.update(epoch=started['epoch'], monotonic=started['monotonic'])
    session = host.begin(work, 'work', 'native-suite', 3600, origin)
    final = [sys.executable, '-B', str(control/'grade.py'), '--project', '{project}', '--family', 'medium', '--seed', '911207']
    if reuse is None:
        (work / '.goal/goal.md').write_text('# Goal\n\n## Acceptance criteria\n\n'
            '- AC-1 | complete auditlog behavior | check: `'+ ' '.join(s.replace('{project}', '.') for s in final) +
            '` | expected: exit=0\n\n## Approval\n\napproved: PENDING\n')
        stamped = subprocess.run(['bash', str(ROOT/'scripts/goal_ctl.sh'), 'stamp', '--auto', '--project', str(work)],
                                  capture_output=True, text=True, timeout=20)
        (control/'stamp.json').write_text(encode(dict(result=stamped.returncode, stdout=stamped.stdout, stderr=stamped.stderr)))
        if stamped.returncode:
            raise RuntimeError('stamp failed; evidence retained')
    files = ['auditlog/'+n for n in ('codec.py', 'aggregate.py', '__main__.py', '__init__.py')]
    if mode == 'fused':
        jobs = [dict(id='T1', files=files, deps=[], check=final)]
    else:
        jobs = [dict(id='T1', files=[n for n in files if not n.endswith('aggregate.py')], deps=[],
                     check=[sys.executable, '-B', str(control/'job_check.py'), '{project}', 'T1']),
                dict(id='T2', files=['auditlog/aggregate.py'], deps=[],
                     check=[sys.executable, '-B', str(control/'job_check.py'), '{project}', 'T2'])]
    graph = dict(version=1, context=dict(backend='actual-Work-collaboration', task='auditlog-v1',
                                       comparison='serial-delegation-vs-crew; fused-is-separate'),
                 capacity=2, jobs=jobs, final_check=final, instruments=['grade.py', 'job_check.py'],
                 inputs=['TASK.md', 'public.py'])
    path = control/('graph-fused.json' if mode == 'fused' else 'graph.json')
    data = encode(graph)
    if path.exists() and path.read_text() != data:
        raise RuntimeError('frozen graph changed')
    path.write_text(data)
    wave = host.crew.begin(work, path, 'crew' if mode == 'crew' else 'inline', 'native-'+mode)
    manifest = dict(version=1, mode=mode, started=started, project=str(work), control=str(control),
                    session=session, wave=wave, native_receipt_source='actual collaboration tools, explicit bridge',
                    tokens=None, money=None, sources={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in (ROOT/'scripts/goal_host.py', ROOT/'scripts/goal_crew.py', Path(__file__), Path(__file__).with_name('native_checks.py'))})
    (output/'manifest.json').write_text(encode(manifest))
    print(encode(dict(project=str(work), wave=wave, mode=mode)))


def seal(output):
    manifest = json.loads((output/'manifest.json').read_bytes())
    host = module('native_crew_host', ROOT/'scripts/goal_host.py')
    wave = host.crew.Wave(manifest['project'], manifest['wave'])
    result = wave.finish()
    (output/'result.json').write_text(encode(result))
    print(encode({k: result[k] for k in ('quality', 'elapsed', 'worker_seconds', 'stage_seconds', 'tokens', 'money')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'seal'))
    parser.add_argument('output', type=Path)
    parser.add_argument('--mode', choices=('serial', 'crew', 'fused'))
    parser.add_argument('--reuse', type=Path, help='reuse a finished isolated project with the same frozen graph')
    args = parser.parse_args()
    if args.action == 'prepare':
        if args.mode is None:
            parser.error('prepare requires --mode')
        prepare(args.output.resolve(), args.mode, args.reuse)
    else:
        seal(args.output.resolve())
