import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

p = argparse.ArgumentParser()
p.add_argument('--source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
overlay = a.output.parent / 'owner-watch-overlay'
test = overlay / 'test_owner_watch_guard.py'
spec = importlib.util.spec_from_file_location('updated_owner_guard', test)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.SCRIPTS = a.source / 'scripts'
module.WATCH = module.SCRIPTS / 'goal_owner_watch.py'
started = time.monotonic()
with (overlay / 'after-linux.log').open('w') as log:
    old = sys.stdout
    try:
        sys.stdout = log
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromModule(module))
    finally:
        sys.stdout = old
record = dict(uid=os.geteuid(), python=sys.version, nofile=resource.getrlimit(resource.RLIMIT_NOFILE),
              test_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),
              production_sha256=hashlib.sha256(module.WATCH.read_bytes()).hexdigest(),
              tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skipped=[dict(test=str(test), reason=reason) for test, reason in result.skipped],
              elapsed=time.monotonic()-started, passed=result.wasSuccessful(),
              log=str(overlay / 'after-linux.log'))
a.output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
