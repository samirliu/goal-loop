import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location("host",'/Users/m/repo/goal-loop/scripts/goal_host.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
host.ready('/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-v3pdh51q/work','bb94ef9b4c1745cd99113be7380309e2:bf1cf2dd15384b8dbedea30e00e6264c')
import subprocess,sys,time; subprocess.Popen([sys.executable,"-I","-c",'from pathlib import Path; import time; p=Path(\'/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-v3pdh51q/work/heartbeat.log\')\nwhile True:\n with p.open("ab") as f: f.write(b"x"); f.flush()\n time.sleep(.04)\n']); time.sleep(540)
