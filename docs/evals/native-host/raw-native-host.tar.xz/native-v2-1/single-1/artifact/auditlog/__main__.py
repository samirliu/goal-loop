"""Command-line interface for summarizing UTF-8 JSONL audit logs."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _write_output(path, records):
    """Write in the destination directory, then atomically publish the file."""
    destination = Path(path)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=destination.parent,
            prefix="." + destination.name + ".",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary_path = output.name
            for record in records:
                output.write(json.dumps(record) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary_path, destination)
        temporary_path = None
    finally:
        if temporary_path is not None:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)

    records = []
    skipped = 0
    try:
        with open(args.input, "rb") as source:
            for line_number, raw_line in enumerate(source, start=1):
                try:
                    line = raw_line.decode("utf-8")
                    if not line.strip():
                        continue
                    record = parse_line(line)
                except ValueError as exc:
                    if args.skip_bad:
                        skipped += 1
                        continue
                    print(
                        f"auditlog: invalid input at line {line_number}: {exc}",
                        file=sys.stderr,
                    )
                    return 2
                records.append(record)

        _write_output(args.output, summarize(records))
    except (OSError, UnicodeError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
