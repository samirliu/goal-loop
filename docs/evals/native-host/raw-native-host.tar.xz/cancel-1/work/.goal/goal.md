# Goal

## Acceptance criteria

- AC-1 | cancellation diagnostic | check: `true` | expected: exit=0

## Approval

approved: 291b3c4b 2026-11-11 auto
