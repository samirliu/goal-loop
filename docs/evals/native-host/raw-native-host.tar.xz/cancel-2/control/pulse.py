import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location("host",'/Users/m/repo/goal-loop/scripts/goal_host.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
host.ready('/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-ib7rjn0t/work','e8f899b9691d494183f9866245e4ee69:73fef9708b674acf8fb07b7083962862')
import subprocess,sys,time; subprocess.Popen([sys.executable,"-I","-c",'from pathlib import Path; import time; p=Path(\'/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-ib7rjn0t/work/heartbeat.log\')\nwhile True:\n with p.open("ab") as f: f.write(b"x"); f.flush()\n time.sleep(.04)\n']); time.sleep(540)
