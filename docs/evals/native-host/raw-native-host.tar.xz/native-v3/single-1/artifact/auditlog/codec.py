"""Validation and decoding for individual audit log records."""

import json


def parse_line(line):
    """Return the original key and integer amount from a JSON object."""
    try:
        record = json.loads(line)
    except (TypeError, UnicodeError, RecursionError) as exc:
        raise ValueError("invalid JSON record") from exc

    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")

    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")

    return {"key": key, "amount": amount}
