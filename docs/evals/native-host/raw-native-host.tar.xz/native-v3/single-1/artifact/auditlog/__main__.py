"""Command line interface for UTF-8 JSONL audit logs."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _publish(output_path, records):
    """Write beside the destination and replace it only after completion."""
    destination = Path(output_path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=destination.parent,
            prefix="." + destination.name + ".",
            suffix=".tmp",
            delete=False,
        ) as target:
            temporary = target.name
            for record in records:
                target.write(json.dumps(record) + "\n")
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize audit log records")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = 0

    def records():
        nonlocal skipped
        with open(args.input, "rb") as source:
            for line_number, raw_line in enumerate(source, 1):
                try:
                    line = raw_line.decode("utf-8")
                    if not line.strip():
                        continue
                    record = parse_line(line)
                except ValueError as exc:
                    if args.skip_bad:
                        skipped += 1
                        continue
                    raise ValueError(
                        f"invalid record on line {line_number}: {exc}"
                    ) from exc
                yield record

    try:
        result = summarize(records())
        _publish(args.output, result)
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
