"""Aggregate validated audit records without modifying the input."""


def summarize(records):
    """Consume records once and return statistics in key order."""
    groups = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        if key not in groups:
            groups[key] = {
                "key": key,
                "count": 1,
                "total": amount,
                "min": amount,
                "max": amount,
            }
        else:
            group = groups[key]
            group["count"] += 1
            group["total"] += amount
            group["min"] = min(group["min"], amount)
            group["max"] = max(group["max"], amount)

    return [groups[key] for key in sorted(groups)]
