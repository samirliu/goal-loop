"""Validation and decoding for individual audit log records."""

import json


def _integer(text):
    """Parse decimal integers without a process-wide digit limit change."""
    negative = text.startswith("-")
    digits = text[1:] if negative else text
    value = 0
    for offset in range(0, len(digits), 1000):
        part = digits[offset:offset + 1000]
        value = value * (10 ** len(part)) + int(part)
    return -value if negative else value


def _invalid_constant(value):
    raise ValueError("invalid JSON constant: " + value)


def parse_line(line):
    """Return only the original key and amount, raising ValueError if invalid."""
    try:
        record = json.loads(line, parse_int=_integer,
                            parse_constant=_invalid_constant)
    except (TypeError, ValueError, UnicodeError, RecursionError) as error:
        raise ValueError("invalid JSON record") from error
    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
