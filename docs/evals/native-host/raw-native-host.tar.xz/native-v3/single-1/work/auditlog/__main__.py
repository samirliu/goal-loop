"""Command-line JSONL audit log summarizer."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize JSONL audit records")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = 0
    temporary = None
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)

    def records(source):
        nonlocal skipped
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                yield parse_line(line)
            except ValueError as error:
                if args.skip_bad:
                    skipped += 1
                else:
                    raise ValueError(f"line {number}: {error}") from error

    try:
        with open(args.input, "r", encoding="utf-8") as source:
            summaries = summarize(records(source))
        destination = Path(args.output)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n",
            dir=destination.parent, prefix=".auditlog-", suffix=".tmp",
            delete=False,
        ) as output:
            temporary = output.name
            for summary in summaries:
                output.write(json.dumps(summary, ensure_ascii=True) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
        temporary = None
    except (OSError, ValueError, UnicodeError) as error:
        print(f"auditlog: {error}", file=sys.stderr)
        return 2
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
