# Goal

## Acceptance criteria

- AC-1 | complete auditlog behavior | check: `/opt/homebrew/opt/python@3.14/bin/python3.14 -B /private/tmp/goal-native-v3-20261112/single-1/control/grade.py --project . --family medium --seed 911207` | expected: exit=0

## Approval

approved: 50fa3e52 2026-11-12 auto
