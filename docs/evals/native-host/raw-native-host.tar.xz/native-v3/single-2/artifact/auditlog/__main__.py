"""Read JSONL audit records and atomically publish their summaries."""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _decimal(value):
    """Encode even integers larger than the default decimal digit limit."""
    if value == 0:
        return "0"
    negative = value < 0
    value = abs(value)
    chunks = []
    while value:
        value, remainder = divmod(value, 1_000_000_000)
        chunks.append(remainder)
    result = str(chunks.pop())
    result += "".join(f"{chunk:09d}" for chunk in reversed(chunks))
    return ("-" if negative else "") + result


def _encode_summary(record):
    fields = ['"key":' + json.dumps(record["key"], ensure_ascii=True)]
    for name in ("count", "total", "min", "max"):
        fields.append('"' + name + '":' + _decimal(record[name]))
    return "{" + ",".join(fields) + "}\n"


def _publish(output_path, summaries):
    output_path = os.path.abspath(output_path)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=os.path.dirname(output_path),
            prefix=".auditlog-",
            suffix=".tmp",
            delete=False,
        ) as destination:
            temporary_path = destination.name
            for record in summaries:
                destination.write(_encode_summary(record))
            destination.flush()
            os.fsync(destination.fileno())
        os.replace(temporary_path, output_path)
        temporary_path = None
    finally:
        if temporary_path is not None:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize JSONL audit records")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = 0

    def records(source):
        nonlocal skipped
        for line_number, raw_line in enumerate(source, 1):
            try:
                line = raw_line.decode("utf-8")
                if not line.strip():
                    continue
                record = parse_line(line)
            except ValueError as exc:
                if args.skip_bad:
                    skipped += 1
                    continue
                raise ValueError(f"line {line_number}: {exc}") from exc
            yield record

    try:
        with open(args.input, "rb") as source:
            summaries = summarize(records(source))
        _publish(args.output, summaries)
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
