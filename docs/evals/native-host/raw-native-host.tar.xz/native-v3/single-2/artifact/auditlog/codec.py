"""Decode individual audit records."""

import json


def _parse_integer(text):
    """Parse without depending on the interpreter's decimal digit limit."""
    negative = text.startswith("-")
    digits = text[1:] if negative else text
    value = 0
    for start in range(0, len(digits), 9):
        chunk = digits[start : start + 9]
        value = value * (10 ** len(chunk)) + int(chunk)
    return -value if negative else value


def _reject_constant(value):
    raise ValueError("invalid JSON number: " + value)


def parse_line(line):
    """Return a fresh record containing only a valid key and integer amount."""
    try:
        record = json.loads(
            line, parse_int=_parse_integer, parse_constant=_reject_constant
        )
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValueError("invalid JSON object") from exc
    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
