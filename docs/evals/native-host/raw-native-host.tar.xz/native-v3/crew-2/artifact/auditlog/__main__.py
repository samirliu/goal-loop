"""Aggregate UTF-8 JSONL records into an atomically published output."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)

    records = []
    skipped = 0
    try:
        with open(args.input, "rb") as source:
            for line_number, raw_line in enumerate(source, start=1):
                try:
                    line = raw_line.decode("utf-8")
                    if not line.strip():
                        continue
                    record = parse_line(line)
                except ValueError as exc:
                    if args.skip_bad:
                        skipped += 1
                        continue
                    print(f"line {line_number}: {exc}", file=sys.stderr)
                    return 2
                records.append(record)
    except OSError as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2

    rows = summarize(records)
    destination = Path(args.output)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=destination.parent,
            prefix=".auditlog-",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary = output.name
            for row in rows:
                output.write(json.dumps(row, ensure_ascii=True, separators=(",", ":")))
                output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
        temporary = None
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
