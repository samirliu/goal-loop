def parse_line(line):
    """Parse one JSON object and keep its validated key and amount."""
    import json

    def reject_constant(value):
        raise ValueError("invalid JSON constant: " + value)

    try:
        record = json.loads(line, parse_constant=reject_constant)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid JSON object") from exc
    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if not isinstance(amount, int) or isinstance(amount, bool):
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
