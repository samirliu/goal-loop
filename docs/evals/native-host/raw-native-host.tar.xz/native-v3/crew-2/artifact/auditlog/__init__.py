"""Parse and summarize audit-log records."""

from .codec import parse_line

__all__ = ["parse_line"]
