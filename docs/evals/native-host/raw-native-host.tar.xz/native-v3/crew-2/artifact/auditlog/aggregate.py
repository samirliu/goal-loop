def summarize(records):
    summaries = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        if key not in summaries:
            summaries[key] = {
                "key": key,
                "count": 1,
                "total": amount,
                "min": amount,
                "max": amount,
            }
        else:
            summary = summaries[key]
            summary["count"] += 1
            summary["total"] += amount
            summary["min"] = min(summary["min"], amount)
            summary["max"] = max(summary["max"], amount)
    return [summaries[key] for key in sorted(summaries)]
