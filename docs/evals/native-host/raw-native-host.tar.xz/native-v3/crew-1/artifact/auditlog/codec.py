"""Validation for individual audit-log records."""

import json


def parse_line(line):
    """Return the key and integer amount from a JSON object.

    Extra fields are ignored. Invalid JSON and invalid record shapes raise
    ValueError so callers can handle both kinds of malformed input alike.
    """
    try:
        record = json.loads(line)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid JSON: {exc}") from exc

    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")

    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if not isinstance(amount, int) or isinstance(amount, bool):
        raise ValueError("amount must be an integer")

    return {"key": key, "amount": amount}
