def summarize(records):
    """Return per-key statistics in key order without modifying records."""
    summaries = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        summary = summaries.get(key)
        if summary is None:
            summaries[key] = {
                "key": key,
                "count": 1,
                "total": amount,
                "min": amount,
                "max": amount,
            }
        else:
            summary["count"] += 1
            summary["total"] += amount
            summary["min"] = min(summary["min"], amount)
            summary["max"] = max(summary["max"], amount)
    return [summaries[key] for key in sorted(summaries)]
