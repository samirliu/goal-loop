"""Summarize UTF-8 JSONL audit logs."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _publish(rows, output):
    """Replace the destination only after the whole output is written."""
    destination = Path(output)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
        ) as stream:
            temporary = stream.name
            for row in rows:
                json.dump(row, stream, ensure_ascii=True, separators=(",", ":"))
                stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="UTF-8 JSONL input path")
    parser.add_argument("--output", required=True, help="summary JSONL output path")
    parser.add_argument("--skip-bad", action="store_true")
    arguments = parser.parse_args(argv)

    records = []
    skipped = 0
    try:
        with open(arguments.input, "rb") as source:
            for line_number, raw_line in enumerate(source, 1):
                try:
                    line = raw_line.decode("utf-8")
                    if not line.strip():
                        continue
                    record = parse_line(line)
                except ValueError as exc:
                    if arguments.skip_bad:
                        skipped += 1
                        continue
                    raise ValueError(f"line {line_number}: {exc}") from exc
                records.append(record)

        _publish(summarize(records), arguments.output)
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2

    if arguments.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
