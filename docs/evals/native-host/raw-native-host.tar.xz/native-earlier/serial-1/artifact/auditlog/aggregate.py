def summarize(records):
    """Return key-sorted summaries without modifying the input records."""
    summaries = {}
    for record in records:
        key = record["key"]
        amount = record["amount"]
        if key in summaries:
            summary = summaries[key]
            summary["count"] += 1
            summary["total"] += amount
            summary["min"] = min(summary["min"], amount)
            summary["max"] = max(summary["max"], amount)
        else:
            summaries[key] = {
                "key": key,
                "count": 1,
                "total": amount,
                "min": amount,
                "max": amount,
            }
    return [summaries[key] for key in sorted(summaries)]
