"""Read audit JSONL and atomically publish grouped results."""

import argparse
import json
import os
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _read_records(path, skip_bad):
    records = []
    skipped = 0
    # Decode each physical line separately so UTF-8 errors have a line number.
    with open(path, "rb") as source:
        for line_number, raw_line in enumerate(source, 1):
            try:
                line = raw_line.decode("utf-8")
                if not line.strip():
                    continue
                record = parse_line(line)
            except (UnicodeError, ValueError) as exc:
                if not skip_bad:
                    raise ValueError(f"line {line_number}: {exc}") from exc
                skipped += 1
                continue
            records.append(record)
    return records, skipped


def _write_output(path, groups):
    destination = os.path.abspath(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=os.path.dirname(destination),
            prefix=".auditlog-",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary = output.name
            for group in groups:
                json.dump(group, output, separators=(",", ":"))
                output.write("\n")
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    try:
        records, skipped = _read_records(args.input, args.skip_bad)
        _write_output(args.output, summarize(records))
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}, separators=(",", ":")), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
