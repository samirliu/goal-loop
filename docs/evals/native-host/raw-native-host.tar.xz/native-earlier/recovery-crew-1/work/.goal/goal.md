# Goal

## Acceptance criteria

- AC-1 | complete auditlog behavior | check: `/opt/homebrew/opt/python@3.14/bin/python3.14 -B /private/tmp/goal-native-crew-20261111/recovery-crew-1/control/grade.py --project . --family medium --seed 911207` | expected: exit=0

## Approval

approved: c5d57000 2026-11-11 auto
