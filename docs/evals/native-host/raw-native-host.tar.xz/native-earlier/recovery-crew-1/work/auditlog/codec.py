"""Decode and validate individual audit records."""

import json


def _invalid_constant(value):
    raise ValueError(f"invalid JSON constant: {value}")


def parse_line(line):
    """Return the original key and integer amount from a JSON object."""
    try:
        record = json.loads(line, parse_constant=_invalid_constant)
    except (TypeError, RecursionError) as exc:
        raise ValueError("invalid JSON record") from exc

    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")

    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")

    return {"key": key, "amount": amount}
