"""Summarize UTF-8 JSONL audit records from the command line."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _records(source, skip_bad, report):
    for line_number, raw in enumerate(source, 1):
        try:
            line = raw.decode("utf-8")
            if not line.strip():
                continue
            record = parse_line(line)
        except ValueError as exc:
            if skip_bad:
                report["skipped"] += 1
                continue
            raise ValueError(f"invalid input at line {line_number}: {exc}") from exc
        yield record


def _write_atomic(path, groups):
    destination = Path(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary = Path(output.name)
            for group in groups:
                output.write(json.dumps(group) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="UTF-8 JSONL input path")
    parser.add_argument("--output", required=True, help="summary output path")
    parser.add_argument("--skip-bad", action="store_true", help="skip invalid rows")
    args = parser.parse_args(argv)
    report = {"skipped": 0}

    try:
        with open(args.input, "rb") as source:
            groups = summarize(_records(source, args.skip_bad, report))
        _write_atomic(args.output, groups)
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2

    if args.skip_bad:
        print(json.dumps(report), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
