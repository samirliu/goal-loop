import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location("host",'/Users/m/repo/goal-loop/scripts/goal_host.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
host.ready('/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-kj13zz48/work','f10331baebc44d3e84486d592e420c76:d9f983b9a57940e6a9d3c014d08284c1')
import subprocess,sys,time; subprocess.Popen([sys.executable,"-I","-c",'from pathlib import Path; import time; p=Path(\'/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-host-native-cancel-kj13zz48/work/heartbeat.log\')\nwhile True:\n with p.open("ab") as f: f.write(b"x"); f.flush()\n time.sleep(.04)\n']); time.sleep(540)
