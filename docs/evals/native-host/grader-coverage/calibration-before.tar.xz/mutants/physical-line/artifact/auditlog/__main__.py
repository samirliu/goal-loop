"""Command line entry point.

Usage::

    python -m auditlog --input PATH --output PATH [--skip-bad]

The input is a UTF-8 JSONL file; blank lines are ignored.  The output is
one JSON object per key, published atomically.  Without ``--skip-bad`` an
invalid record is fatal: the process exits with status 2, names the
physical line on stderr and leaves any existing output untouched.  With
``--skip-bad`` invalid records are dropped and ``{"skipped": N}`` is
reported on stderr.
"""

import argparse
import json
import os
import sys
import uuid

from .aggregate import summarize
from .codec import parse_line

__all__ = ["main"]

EXIT_OK = 0
EXIT_ERROR = 2


class _InputError(Exception):
    """A fatal problem with the input file."""


def _build_parser():
    parser = argparse.ArgumentParser(
        prog="auditlog",
        description="Summarise a JSONL audit log by key.",
    )
    parser.add_argument("--input", required=True, metavar="PATH", help="UTF-8 JSONL input file")
    parser.add_argument("--output", required=True, metavar="PATH", help="file receiving the summary")
    parser.add_argument(
        "--skip-bad",
        action="store_true",
        help="skip invalid records instead of failing",
    )
    return parser


def _load(path, skip_bad):
    """Read ``path`` and return ``(records, skipped)``."""
    try:
        with open(path, "rb") as handle:
            raw = handle.read()
    except FileNotFoundError as exc:
        raise _InputError("input file not found: {}".format(path)) from exc
    except IsADirectoryError as exc:
        raise _InputError("input path is a directory: {}".format(path)) from exc
    except OSError as exc:
        raise _InputError("cannot read input file {}: {}".format(path, exc.strerror or exc)) from exc

    records = []
    skipped = 0

    # Physical lines are separated by "\n"; blank lines carry no record.
    for number, raw_line in enumerate(raw.split(b"\n"), start=1):
        try:
            line = raw_line.decode("utf-8")
        except UnicodeDecodeError:
            if skip_bad:
                skipped += 1
                continue
            raise _InputError(
                "invalid record on line {}: record is not valid UTF-8".format(number)
            ) from None

        if number == 1 and line.startswith("\ufeff"):
            line = line[1:]

        if not line.strip():
            continue

        try:
            record = parse_line(line)
        except ValueError as exc:
            if skip_bad:
                skipped += 1
                continue
            raise _InputError("invalid record on line {}: {}".format(3, exc)) from None

        records.append(record)

    return records, skipped


def _publish(path, summary):
    """Write ``summary`` to ``path`` atomically."""
    target = os.path.abspath(path)
    directory = os.path.dirname(target) or "."
    temporary = os.path.join(
        directory, ".auditlog-{}-{}.tmp".format(os.getpid(), uuid.uuid4().hex)
    )

    try:
        with open(temporary, "x", encoding="utf-8", newline="\n") as handle:
            for item in summary:
                handle.write(json.dumps(item, ensure_ascii=False))
                handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise

    try:
        fd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def main(argv=None):
    """Run the command line interface and return its exit status."""
    args = _build_parser().parse_args(argv)

    try:
        records, skipped = _load(args.input, args.skip_bad)
    except _InputError as exc:
        print("auditlog: {}".format(exc), file=sys.stderr)
        return EXIT_ERROR

    try:
        summary = summarize(records)
    except ValueError as exc:
        print("auditlog: {}".format(exc), file=sys.stderr)
        return EXIT_ERROR

    try:
        _publish(args.output, summary)
    except OSError as exc:
        print("auditlog: cannot write output file {}: {}".format(args.output, exc.strerror or exc), file=sys.stderr)
        return EXIT_ERROR

    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)

    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
