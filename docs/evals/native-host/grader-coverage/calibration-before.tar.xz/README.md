# Original auditlog TASK: posthoc grader blind-spot calibration

This is posthoc evidence. The original v3 21-check scores, live project, frozen
453-file recording, production source, tests and grader were not changed.
No model, network or full suite was used. All execution occurred on copies in
/tmp, using the frozen original grade.py and seed 911207.

The single-1 archived artifact calibrated the baseline: original grader 21/21,
independent seven-case probe 7/7. Five separate single-defect mutants each still
received 21/21 from that original grader. The new probe rejected precisely the
corresponding mutated requirement:

| Original requirement | Coverage gap | Actual calibrated counterexample |
| --- | --- | --- |
| tasks.py:25 missing input exits 2 | grade.py:68/72/80 always create source | mutant exits 1; old21/21; missing-input probe rejects |
| tasks.py:23 names physical line | grade.py:75 only seeks character 3 | bad JSON on line13 reports line3; old21/21; line13 probe rejects |
| tasks.py:16-18 original integer amount | grade.py:53 uses small amounts and equality | 9007199254740993 becomes 9007199254740992; old21/21; parse-large rejects |
| tasks.py:20/22/24 complete summary after skip | grade.py:78 checks only length/count | skip output has only count fields; old21/21; complete-fields probe rejects |
| tasks.py:21 UTF-8 JSONL | grade.py:55/68 default JSON escapes non-ASCII | literal UTF-8 中 incorrectly rejected; old21/21; literal-utf8 probe rejects |

All six actual archived artifacts independently passed the seven posthoc probes
(42/42), including bool=False rejection and a generator/large-integer summary.
This does not prove full specification coverage or add these cases to the
preregistered 21. The observation is an oracle coverage gap, not a detected bug
in these six actual artifacts. The original TASK has no medium input-mutation
prohibition; none is added. Its existing iter(rows) check already covers a
one-shot iterator, so generator coverage is not described as entirely missing.

Atomic publication (tasks.py:26) remains a separate coverage limitation: the
old strict parse-failure test does not exclude parse-first/direct-write code.
No timing-sensitive visibility test, fsync durability requirement, specific
os.replace mechanism or unpromised permission/symlink policy is introduced here.

Each original and mutant has its copied artifact, exact command/return code,
stdout/stderr, old grader report where run, and full new probe report. Mutants
also retain precise source patches. frozen-before.json/frozen-after.json agree
on all file names, bytes, modes and SHA hashes. The driver tool log is the
returned tool output with a command/exit envelope, not a redirected shell log.
probe.py.txt and driver.py.txt are the exact executed diagnostic programs.
