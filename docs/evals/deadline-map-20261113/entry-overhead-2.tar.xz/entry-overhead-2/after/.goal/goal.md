# Goal

## Objective

verified answer

## Acceptance criteria

- AC-1 | answer is forty-two | check: `python3 check.py` | expected: exit=0

## Approval

approved: 078582b0 2026-11-13 auto
