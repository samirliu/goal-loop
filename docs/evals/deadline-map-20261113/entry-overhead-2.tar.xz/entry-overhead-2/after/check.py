from pathlib import Path
raise SystemExit(0 if Path("answer").read_bytes()==b"42\n" else 1)
