"""Validation of individual audit-log records."""

import json


def _invalid_constant(value):
    raise ValueError("invalid JSON constant: " + value)


def parse_line(line):
    """Return the key and integer amount from a JSON object.

    Extra fields are discarded. Booleans are deliberately not amounts.
    """
    try:
        record = json.loads(line, parse_constant=_invalid_constant)
    except (ValueError, TypeError, UnicodeError) as exc:
        raise ValueError("invalid JSON record") from exc
    if not isinstance(record, dict):
        raise ValueError("record must be an object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
