"""Aggregate validated records without retaining the input rows."""


def summarize(records):
    """Return count, total, minimum and maximum for each sorted key."""
    groups = {}
    for record in records:
        key, amount = record["key"], record["amount"]
        if key not in groups:
            groups[key] = {
                "key": key, "count": 1, "total": amount,
                "min": amount, "max": amount,
            }
        else:
            group = groups[key]
            group["count"] += 1
            group["total"] += amount
            group["min"] = min(group["min"], amount)
            group["max"] = max(group["max"], amount)
    return [groups[key] for key in sorted(groups)]
