"""Command-line JSONL summarizer with atomic output publication."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize audit-log JSONL records")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = 0

    def records(source):
        nonlocal skipped
        for number, raw in enumerate(source, 1):
            try:
                line = raw.decode("utf-8")
                if not line.strip():
                    continue
                yield parse_line(line)
            except (ValueError, UnicodeError) as exc:
                if args.skip_bad:
                    skipped += 1
                else:
                    raise ValueError(f"line {number}: {exc}") from exc

    temporary = None
    try:
        with args.input.open("rb") as source:
            groups = summarize(records(source))
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", delete=False,
            dir=args.output.parent, prefix=".auditlog-", suffix=".tmp",
        ) as destination:
            temporary = destination.name
            for group in groups:
                destination.write(json.dumps(group, ensure_ascii=True) + "\n")
            destination.flush()
            os.fsync(destination.fileno())
        os.replace(temporary, args.output)
        temporary = None
    except (OSError, ValueError, UnicodeError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except OSError:
                pass
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
