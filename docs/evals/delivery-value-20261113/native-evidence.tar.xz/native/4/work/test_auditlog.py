"""Behavioral checks for validation and safe CLI publication."""

import json
import contextlib
import io
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from auditlog import parse_line, summarize


class AuditLogTests(unittest.TestCase):
    def test_atomic_publish_failure_preserves_output(self):
        from auditlog.__main__ import main
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "in", Path(directory) / "out"
            source.write_text('{"key":"a","amount":2}\n', encoding="utf-8")
            output.write_text("keep", encoding="utf-8")
            with patch("auditlog.__main__.os.replace", side_effect=OSError("publish failed")):
                with contextlib.redirect_stderr(io.StringIO()) as errors:
                    code = main(["--input", str(source), "--output", str(output)])
            self.assertEqual(code, 2)
            self.assertIn("publish failed", errors.getvalue())
            self.assertEqual(output.read_text(), "keep")
            self.assertEqual(list(Path(directory).glob(".auditlog-*")), [])

    def test_validation(self):
        for row in ["null", "[]", "1", '"text"', "{}",
                    '{"key":"","amount":1}', '{"key":1,"amount":1}',
                    '{"key":"a","amount":true}', '{"key":"a","amount":1.0}',
                    '{"key":"a","amount":"1"}', '{"key":"a","amount":null}',
                    '{"key":"a","amount":NaN}', '{"key":"a","amount":1} trailing']:
            with self.subTest(row=row), self.assertRaises(ValueError):
                parse_line(row)
        self.assertEqual(parse_line('{"key":"  ","amount":-2,"other":0}'),
                         {"key": "  ", "amount": -2})

    def test_aggregation(self):
        source = iter([{"key": "z", "amount": 0}, {"key": "a", "amount": -4},
                       {"key": "a", "amount": 7}, {"key": "z", "amount": -3}])
        self.assertEqual(summarize(source), [
            {"key": "a", "count": 2, "total": 3, "min": -4, "max": 7},
            {"key": "z", "count": 2, "total": -3, "min": -3, "max": 0}])
        self.assertEqual(summarize(iter(())), [])

    def test_cli(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "in", Path(directory) / "out"
            args = [sys.executable, "-B", "-m", "auditlog", "--input", str(source),
                    "--output", str(output)]
            output.write_text("keep", encoding="utf-8")
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(output.read_text(), "keep")
            source.write_bytes(b'\n{"key":"b","amount":2}\n \n{bad\n')
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("line 4", result.stderr)
            self.assertEqual(output.read_text(), "keep")
            result = subprocess.run(args + ["--skip-bad"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stderr), {"skipped": 1})
            self.assertEqual(json.loads(output.read_text()),
                             {"key": "b", "count": 1, "total": 2, "min": 2, "max": 2})
            source.write_bytes(b' \n\n')
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(output.read_bytes(), b"")
            source.write_bytes(b'{"key":"a","amount":1}\n\xff\n')
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("line 2", result.stderr)
            source.write_text('{"key":"雪","amount":3}\n', encoding="utf-8")
            same = args[:-1] + [str(source)]
            result = subprocess.run(same, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(source.read_text())["key"], "雪")
            self.assertEqual(list(Path(directory).glob(".auditlog-*")), [])


if __name__ == "__main__":
    unittest.main()
