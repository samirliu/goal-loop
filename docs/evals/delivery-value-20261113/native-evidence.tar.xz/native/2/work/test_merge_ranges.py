"""Independent contract checks; run directly with Python's standard library."""
from copy import deepcopy
from itertools import product

from solution import merge_ranges


def check(ranges, expected):
    saved = deepcopy(ranges)
    actual = merge_ranges(ranges)
    assert actual == expected, (ranges, actual, expected)
    assert ranges == saved, (ranges, saved)
    assert all(type(pair) is list and len(pair) == 2 for pair in actual)
    if actual:
        actual[0][0] -= 1
        assert ranges == saved, "output aliases an input interval"


check([], [])
check([[1, 1], [-5, -5]], [])
check([[3, 5], [1, 3], [5, 9], [2, 4]], [[1, 9]])
check([[2, 3], [-5, -2], [4, 5]], [[-5, -2], [2, 3], [4, 5]])
check([[1, 10], [1, 10], [2, 4]], [[1, 10]])
check([[-10**100, -1], [-1, 10**100]], [[-10**100, 10**100]])
check([(1, 2), (2, 4)], [[1, 4]])

invalid = [None, 1, True, "12", {}, (1, 2),
           [None], [1], [[1]], [[1, 2, 3]], ["12"], [{1: 2, 3: 4}],
           [[3, 1]], [[True, 1]], [[1, False]], [[True, True]],
           [[1.0, 2]], [[1, 2.0]], [["1", 2]], [[1, None]],
           [[0, 0], [2, 1]], [[0, 2], [False, 0]]]
for ranges in invalid:
    saved = deepcopy(ranges)
    try:
        merge_ranges(ranges)
    except ValueError:
        pass
    else:
        raise AssertionError(("invalid input accepted", ranges))
    assert ranges == saved

# Each integer cell represents [x,x+1); this gives a separate union oracle.
small = [[a, b] for a in range(-2, 3) for b in range(a, 3)]
for count in range(4):
    for group in product(small, repeat=count):
        ranges = list(group)
        cells = {x for a, b in ranges for x in range(a, b)}
        expected = []
        for x in sorted(cells):
            if expected and expected[-1][1] == x:
                expected[-1][1] = x + 1
            else:
                expected.append([x, x + 1])
        check(ranges, expected)

print("CONTRACT PASS: boundaries, invalid inputs, preservation, 3616 exhaustive cases")
