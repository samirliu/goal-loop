def merge_ranges(ranges):
    """Return sorted unions of half-open integer intervals without mutation.

    Empty intervals are ignored. Invalid input raises ValueError; bools are
    rejected even though Python considers them integer instances.
    """
    if not isinstance(ranges, list):
        raise ValueError("ranges must be a list of interval pairs")

    intervals = []
    for pair in ranges:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError("each interval must be a pair")
        start, end = pair
        if any(isinstance(bound, bool) or not isinstance(bound, int)
               for bound in (start, end)):
            raise ValueError("interval endpoints must be integers")
        if start > end:
            raise ValueError("interval start must not exceed its end")
        if start < end:
            intervals.append([start, end])

    intervals.sort()
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged
