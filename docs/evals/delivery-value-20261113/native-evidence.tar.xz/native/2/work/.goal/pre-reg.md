# Pre-registration

## Hypothesis and counterevidence

Validate every pair before processing; sort copied nonempty intervals, then
coalesce touching and overlapping bounds. Public examples, independent cell-set
union checks and input preservation checks should pass. Any malformed input
accepted, lost coverage, spurious coverage, or mutation falsifies this approach.

## Scope and ruling

Single serial task T1; no objective optimization or strategy comparison.
Ruling: require an outer list and accept list or tuple pairs — the contract names
a list of pairs; tuples are valid pairs, while strings, mappings and scalars are
malformed. Integer subclasses are valid except bool. Risk: callers outside the
specified input contract receive ValueError.

## Kill lines

No further implementation wave before this landed work is settled. Reserve time
for close-iteration and a fresh original audit/Gate receipt. On failure, report
the failed check and repair only within solution.py or project tests.

## Degrade line

Only original Gate GO permits a completion claim. Report unresolved evidence
without replacing it with work-plan ticks or assumptions.
