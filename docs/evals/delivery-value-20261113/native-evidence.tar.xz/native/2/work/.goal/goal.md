# Goal

## Objective

Implement merge_ranges in solution.py with strict integer endpoint validation, preservation of input, and sorted unions of nonempty half-open intervals.

## Acceptance criteria

- AC-1 | Public examples and independent boundary, invalid-input, preservation and exhaustive small-domain checks pass | check: `python3 public.py && python3 test_merge_ranges.py` | expected: exit=0

## Approval

approved: 0ef89d2f 2026-11-13 auto
