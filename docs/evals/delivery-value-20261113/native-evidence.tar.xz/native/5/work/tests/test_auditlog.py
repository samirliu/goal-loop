import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from auditlog.codec import parse_line
from auditlog.aggregate import summarize
from auditlog.__main__ import _publish


class AuditlogTests(unittest.TestCase):
    def test_validation(self):
        for value in ["null", "[]", "true", "1", '"text"', "{broken",
                      "{}", '{"key":"","amount":1}',
                      '{"key":3,"amount":1}', '{"key":"a"}',
                      '{"key":"a","amount":true}',
                      '{"key":"a","amount":false}',
                      '{"key":"a","amount":1.0}',
                      '{"key":"a","amount":"2"}',
                      '{"key":"a","amount":null}',
                      '{"key":"a","amount":NaN}',
                      '{"key":"a","amount":1} trailing']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_line(value)
        self.assertEqual(parse_line('{"key":"  ","amount":-4,"extra":3}'),
                         {"key": "  ", "amount": -4})
        self.assertEqual(parse_line('{"key":"雪","amount":0}'),
                         {"key": "雪", "amount": 0})

    def test_aggregation(self):
        records = [{"key": "z", "amount": -5},
                   {"key": "a", "amount": 0},
                   {"key": "z", "amount": 10},
                   {"key": "a", "amount": -2},
                   {"key": "雪", "amount": 10**50}]
        original = [row.copy() for row in records]
        self.assertEqual(summarize(iter(records)), [
            {"key": "a", "count": 2, "total": -2, "min": -2, "max": 0},
            {"key": "z", "count": 2, "total": 5, "min": -5, "max": 10},
            {"key": "雪", "count": 1, "total": 10**50,
             "min": 10**50, "max": 10**50}])
        self.assertEqual(records, original)
        self.assertEqual(summarize(iter([])), [])

    def cli(self, source, output, *extra):
        return subprocess.run([sys.executable, "-B", "-m", "auditlog",
                               "--input", str(source), "--output", str(output),
                               *extra], capture_output=True, text=True)

    def test_cli_success(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "in", Path(folder) / "out"
            source.write_text('\n {"key":"雪","amount":-7}\r\n'
                              '{"key":"a","amount":3}\n'
                              '{"key":"雪","amount":9}', encoding="utf-8")
            output.write_text("old")
            result = self.cli(source, output)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stderr, "")
            self.assertEqual(result.stdout, "")
            self.assertEqual([json.loads(line) for line in output.read_text().splitlines()], [
                {"key": "a", "count": 1, "total": 3, "min": 3, "max": 3},
                {"key": "雪", "count": 2, "total": 2, "min": -7, "max": 9}])
            self.assertEqual(sorted(p.name for p in Path(folder).iterdir()), ["in", "out"])

    def test_strict_physical_line_and_preservation(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "in", Path(folder) / "out"
            for bad in [b"{broken", b'{"key":"a","amount":true}', b"\xff"]:
                source.write_bytes(b'\n\n{"key":"x","amount":1}\n' + bad + b"\n")
                output.write_bytes(b"keep\x00exact")
                result = self.cli(source, output)
                self.assertEqual(result.returncode, 2)
                self.assertIn("line 4", result.stderr)
                self.assertEqual(output.read_bytes(), b"keep\x00exact")
                self.assertEqual(sorted(p.name for p in Path(folder).iterdir()), ["in", "out"])

    def test_skip_bad_counts(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "in", Path(folder) / "out"
            source.write_bytes(b'\n{bad\n{"key":"b","amount":2}\n'
                               b'{"key":"b","amount":false}\n\xff\n  \n')
            result = self.cli(source, output, "--skip-bad")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stderr), {"skipped": 3})
            self.assertEqual(json.loads(output.read_text()),
                             {"key": "b", "count": 1, "total": 2, "min": 2, "max": 2})

    def test_empty_and_all_bad(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "in", Path(folder) / "out"
            for content, skipped in [("", 0), ("\n \n\t\n", 0), ("null\n[]\n", 2)]:
                source.write_text(content)
                output.write_text("old")
                result = self.cli(source, output, "--skip-bad")
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(output.read_bytes(), b"")
                self.assertEqual(json.loads(result.stderr), {"skipped": skipped})

    def test_missing_input_preserves_output(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder) / "missing", Path(folder) / "out"
            output.write_text("keep")
            result = self.cli(source, output)
            self.assertEqual(result.returncode, 2)
            self.assertTrue(result.stderr)
            self.assertEqual(output.read_text(), "keep")

    def test_same_input_and_output(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "in"
            source.write_text('{"key":"x","amount":1}\n')
            result = self.cli(source, source)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(source.read_text())["count"], 1)

    def test_atomic_replacement_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "out"
            output.write_text("keep")
            with patch("auditlog.__main__.os.replace", side_effect=OSError("replace failed")):
                with self.assertRaises(OSError):
                    _publish(output, [{"key": "a"}])
            self.assertEqual(output.read_text(), "keep")
            self.assertEqual([p.name for p in Path(folder).iterdir()], ["out"])

    def test_output_error_is_controlled(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "in"
            source.write_text('{"key":"x","amount":1}\n')
            result = self.cli(source, Path(folder) / "missing" / "out")
            self.assertEqual(result.returncode, 2)
            self.assertNotIn("Traceback", result.stderr)


if __name__ == "__main__":
    unittest.main()
