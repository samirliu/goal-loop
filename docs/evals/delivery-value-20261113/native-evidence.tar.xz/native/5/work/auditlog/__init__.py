"""Validation and aggregation of JSONL audit records."""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
