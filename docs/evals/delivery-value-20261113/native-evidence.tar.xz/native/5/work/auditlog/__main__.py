"""Command-line JSONL audit summarizer."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _publish(output, groups):
    """Write beside the destination and atomically replace it after success."""
    destination = Path(output)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", delete=False,
            dir=destination.parent, prefix=".auditlog-", suffix=".tmp"
        ) as stream:
            temporary = stream.name
            for group in groups:
                stream.write(json.dumps(group, ensure_ascii=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize JSONL audit records")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = 0
    try:
        # Decode each physical line separately so even encoding errors have a
        # reliable line number and can be skipped without losing nearby rows.
        with open(args.input, "rb") as source:
            def records():
                nonlocal skipped
                for number, raw in enumerate(source, 1):
                    try:
                        line = raw.decode("utf-8")
                        if not line.strip():
                            continue
                        record = parse_line(line)
                    except ValueError as exc:
                        if not args.skip_bad:
                            raise ValueError(f"line {number}: {exc}") from exc
                        skipped += 1
                    else:
                        yield record
            groups = summarize(records())
        _publish(args.output, groups)
    except (OSError, ValueError, UnicodeError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
