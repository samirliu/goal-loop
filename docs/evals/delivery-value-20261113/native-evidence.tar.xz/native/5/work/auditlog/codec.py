"""Decode and validate individual audit records."""

import json


def _reject_constant(value):
    raise ValueError(f"invalid JSON constant: {value}")


def parse_line(line):
    """Return a record's original key and integer amount, or raise ValueError."""
    try:
        record = json.loads(line, parse_constant=_reject_constant)
    except (TypeError, ValueError, UnicodeError) as exc:
        raise ValueError("invalid JSON record") from exc
    if not isinstance(record, dict):
        raise ValueError("record must be an object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if type(amount) is not int:
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
