"""Validation and decoding for audit-log JSON records."""

import json


def _reject_constant(value):
    raise ValueError("invalid JSON constant: " + value)


def parse_line(line):
    """Decode a record, retaining only its original key and integer amount.

    Invalid JSON, non-object records, empty/non-string keys, and non-integer
    amounts (including booleans) raise ValueError.
    """
    try:
        record = json.loads(line, parse_constant=_reject_constant)
    except (ValueError, TypeError, RecursionError) as exc:
        raise ValueError("invalid JSON record: " + str(exc)) from exc

    if not isinstance(record, dict):
        raise ValueError("record must be a JSON object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if not isinstance(amount, int) or isinstance(amount, bool):
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
