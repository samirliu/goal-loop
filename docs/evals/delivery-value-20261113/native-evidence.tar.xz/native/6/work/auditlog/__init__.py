"""Standard-library JSONL audit-log validation and aggregation."""

from .aggregate import summarize
from .codec import parse_line

__all__ = ["parse_line", "summarize"]
