"""Command-line JSONL audit-log summarization with atomic publication."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _load_groups(input_path, skip_bad):
    skipped = 0

    def records():
        nonlocal skipped
        # Decode each physical line independently so malformed UTF-8 has the
        # same line reporting and skip behavior as malformed JSON.
        with input_path.open("rb") as source:
            for line_number, raw_line in enumerate(source, 1):
                try:
                    line = raw_line.decode("utf-8")
                    if not line.strip():
                        continue
                    record = parse_line(line)
                except ValueError as exc:
                    if not skip_bad:
                        raise ValueError(f"line {line_number}: {exc}") from exc
                    skipped += 1
                    continue
                yield record

    groups = summarize(records())
    return groups, skipped


def _write_groups(output_path, groups):
    temporary_path = None
    try:
        # A sibling temporary file keeps the final replace on one filesystem.
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=output_path.parent,
            prefix=f".{output_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as output:
            temporary_path = output.name
            for group in groups:
                # ASCII escaping also safely represents escaped surrogates
                # accepted by the JSON decoder without losing the key value.
                output.write(json.dumps(group) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary_path, output_path)
        temporary_path = None
    finally:
        if temporary_path is not None:
            try:
                os.unlink(temporary_path)
            except FileNotFoundError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description="Summarize JSONL audit records by key.")
    parser.add_argument("--input", required=True, type=Path, help="UTF-8 JSONL input")
    parser.add_argument("--output", required=True, type=Path, help="summary JSONL output")
    parser.add_argument("--skip-bad", action="store_true", help="skip invalid input rows")
    args = parser.parse_args(argv)

    try:
        groups, skipped = _load_groups(args.input, args.skip_bad)
        _write_groups(args.output, groups)
    except (OSError, ValueError) as exc:
        print(f"auditlog: {exc}", file=sys.stderr)
        return 2
    if args.skip_bad:
        print(json.dumps({"skipped": skipped}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
