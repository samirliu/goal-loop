import copy
import itertools
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_empty_nested_touching_and_large(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[3, 3], [-8, -8]]), [])
        self.assertEqual(
            merge_ranges([[8, 11], [2, 5], [1, 9], [-9, -3], [-3, 1]]),
            [[-9, 11]],
        )
        bound = 10**200
        self.assertEqual(
            merge_ranges([[-bound, -bound + 1], [bound, bound + 1]]),
            [[-bound, -bound + 1], [bound, bound + 1]],
        )

    def test_rejects_invalid_inputs_and_preserves_them(self):
        for bad in (
            None, 3, "12", {}, [[1]], [[1, 2, 3]], [None], ["12"],
            [[True, 2]], [[0, False]], [[1.0, 2]], [[1, 2.0]],
            [["1", 2]], [[3, 2]], [[None, 2]], [[0, 0], [4, 3]],
        ):
            with self.subTest(bad=bad):
                original = copy.deepcopy(bad)
                with self.assertRaises(ValueError):
                    merge_ranges(bad)
                self.assertEqual(bad, original)

    def test_no_input_or_output_aliases(self):
        pair = [1, 4]
        source = [[8, 10], pair, [4, 7], [4, 4]]
        original = copy.deepcopy(source)
        result = merge_ranges(source)
        self.assertEqual(result, [[1, 7], [8, 10]])
        self.assertEqual(source, original)
        result[0][0] = -100
        self.assertEqual(source, original)
        pair[1] = 99
        self.assertEqual(result, [[-100, 7], [8, 10]])

    def test_exhaustive_small_intervals_against_cell_union(self):
        pairs = [[a, b] for a in range(-2, 3) for b in range(a, 3)]
        for count in range(4):
            for sample in itertools.product(pairs, repeat=count):
                source = [list(pair) for pair in sample]
                occupied = {n for a, b in source for n in range(a, b)}
                expected = []
                for n in sorted(occupied):
                    if expected and expected[-1][1] == n:
                        expected[-1][1] = n + 1
                    else:
                        expected.append([n, n + 1])
                self.assertEqual(merge_ranges(source), expected)
                self.assertEqual(source, list(sample))


if __name__ == "__main__":
    unittest.main()
