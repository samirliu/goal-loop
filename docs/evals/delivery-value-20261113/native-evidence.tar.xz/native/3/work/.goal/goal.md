# Goal

## Objective

Implement merge_ranges according to TASK.md, preserving input and correctly
merging integer half-open intervals while rejecting invalid values.

## Acceptance criteria

- AC-1 | Public examples and exhaustive independent interval-union checks pass | check: `python3 public.py && python3 -m unittest -v test_solution.py` | expected: exit=0

## Approval

approved: d968ee5c 2026-11-13 auto
