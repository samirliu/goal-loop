# work-plan (controller ticks; NEVER a GO signal)

# format: - [ ] T1 <scope> | owner=<name> | files=<paths>
# done:   - [x] T1 ...

- [x] T1 Implement interval validation and union with independent checks | owner=/root/delivery_3 | files=solution.py,test_solution.py
