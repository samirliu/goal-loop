def merge_ranges(ranges):
    """Return the sorted union of half-open integer intervals.

    Touching intervals coalesce. Validate all pairs before discarding empty
    intervals, and never modify input objects.
    """
    if not isinstance(ranges, list):
        raise ValueError("ranges must be a list of pairs")

    intervals = []
    for pair in ranges:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise ValueError("each range must contain exactly two bounds")
        start, end = pair
        if (
            not isinstance(start, int)
            or isinstance(start, bool)
            or not isinstance(end, int)
            or isinstance(end, bool)
        ):
            raise ValueError("range bounds must be integers, excluding bools")
        if start > end:
            raise ValueError("range start must not exceed its end")
        if start < end:
            intervals.append((start, end))

    intervals.sort()
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
