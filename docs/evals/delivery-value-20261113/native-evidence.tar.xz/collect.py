import argparse,importlib.util,json,pathlib,time
p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('position',type=int);a=p.parse_args();r=a.root
parent=pathlib.Path('/Users/m/.codex/sessions/2026/11/13/rollout-2026-11-13T13-01-35-01a1d348-5480-7601-ace5-8b01be0530a0.jsonl')
name='/root/delivery_'+str(a.position);launch=terminal=None
for line in parent.open():
 v=json.loads(line).get('payload',{})
 if v.get('type') not in ('function_call_output','custom_tool_call_output'):continue
 try:o=json.loads(v.get('output',''))
 except (ValueError,TypeError):continue
 if isinstance(o,dict) and o.get('task_name')==name:launch=o
 if isinstance(o,dict) and isinstance(o.get('agents'),list):
  z=[x for x in o['agents'] if x.get('agent_name')==name]
  if z and isinstance(z[0].get('agent_status'),dict) and any(k in z[0]['agent_status'] for k in ('completed','error','cancelled','interrupted','shutdown')):terminal=o
if launch is None or terminal is None:raise RuntimeError('raw launch/terminal receipt not available')
sessions=[]
for f in (pathlib.Path.home()/'.codex/sessions/2026/11/13').glob('*.jsonl'):
 with f.open() as stream:meta=json.loads(next(stream)).get('payload',{})
 if meta.get('agent_path')==name:sessions.append(meta['id'])
if len(sessions)!=1:raise RuntimeError('native identity missing/ambiguous')
for kind,value in [('launch',launch),('terminal',terminal)]:
 (r/str(a.position)/('host-'+kind+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('frozen_driver',r/'frozen/evaluate_delivery.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
print(json.dumps(d.finish(r,a.position,sessions[0])))
