#!/usr/bin/env bash
# goal_ctl.sh - in-session controller helper of goal-loop. One entry point per
# bookkeeping step. This script is the CONTROLLER's writing hand: it decides
# nothing; goal_gate.sh stays the only arbiter and is never written to.
# Usage:
#   bash goal_ctl.sh init  --project DIR [--max-iterations=N]
#   bash goal_ctl.sh stamp --project DIR [--auto] [--time-budget=N]
#   bash goal_ctl.sh bind  --project DIR            # verdict lines on stdin
#   bash goal_ctl.sh status --project DIR           # human progress summary
#   bash goal_ctl.sh context --project DIR [--auto] [--brief]
#   bash goal_ctl.sh close-iteration --project DIR --task ID --files LIST
#        --checks-pass N --checks-fail N --checks-unverifiable N
#        [--progress yes|no] [--exit-signal yes|no] [--error-signature none]
#        [--false-complete no] [--dry yes|no] [--no-gate]
#        [--score N] [--judge-score N] [--strategy-delta TEXT] [--strategy TEXT]
#        [--adversarial clear|finding] [--adversarial-note TEXT]
#        [--fault CLASS] [--fault-outcome OUTCOME] [--fault-note TEXT]
#        [--operation-id ID]  # stable identity when retrying the same close
#        (--dry is REQUIRED on exit: forge contracts: yes = this round's
#         panel+critic produced no new evidence-backed finding)
#        (--score: objective:maximize|minimize value; --strategy-delta REQUIRED when
#         the new breaker is HALF_OPEN/OPEN — R10; --strategy is an optional
#         one-word label for the attack direction this wave tried - eval-drive
#         v2.8: status derives per-strategy score slopes from it)
#        (--fault: a worker in this wave died/stalled/broke. CLASS is
#         stall|tool-error|death|provider-fatal, OUTCOME is what the
#         controller did about it: resume|re-run|take-over. The pair maps to
#         exactly one task= suffix, which ctl writes for you - a suffix can
#         never be self-declared, and a fault can never be silent.)
set -u
export LC_ALL=C.UTF-8

here=$(cd "$(dirname "$0")" && pwd)
_goal_ctl_args=("$@")
cmd="" project="." auto=0 brief=0 no_gate=0 max_iterations=12 time_budget=""
task="" files="" cp="" cf="" cu="" progress=yes exit_signal=no errsig=none fcomplete=no dry=""
score="" judge_score="" strategy_delta="" strategy="" adversarial="" adv_note=""
fault="" fault_outcome="" fault_note=""
operation_id="" operation_id_seen=0

while [ $# -gt 0 ]; do
  case "$1" in
    init|stamp|bind|close-iteration|status|context|recover|migrate) cmd="$1" ;;
    --project) [ $# -ge 2 ] || { echo "CTL: ERROR missing-project-arg" >&2; exit 4; }; project="$2"; shift ;;
    --auto) auto=1 ;;
    --brief) brief=1 ;;
    --time-budget=*) time_budget="${1#*=}" ;;
    --no-gate) no_gate=1 ;;
    --max-iterations=*) max_iterations="${1#*=}" ;;
    --task) [ $# -ge 2 ] || { echo "CTL: ERROR missing-task" >&2; exit 4; }; task="$2"; shift ;;
    --files) [ $# -ge 2 ] || { echo "CTL: ERROR missing-files" >&2; exit 4; }; files="$2"; shift ;;
    --checks-pass) [ $# -ge 2 ] || { echo "CTL: ERROR missing-checks-pass" >&2; exit 4; }; cp="$2"; shift ;;
    --checks-fail) [ $# -ge 2 ] || { echo "CTL: ERROR missing-checks-fail" >&2; exit 4; }; cf="$2"; shift ;;
    --checks-unverifiable) [ $# -ge 2 ] || { echo "CTL: ERROR missing-checks-unverifiable" >&2; exit 4; }; cu="$2"; shift ;;
    --progress) [ $# -ge 2 ] || { echo "CTL: ERROR missing-progress" >&2; exit 4; }; progress="$2"; shift ;;
    --exit-signal) [ $# -ge 2 ] || { echo "CTL: ERROR missing-exit-signal" >&2; exit 4; }; exit_signal="$2"; shift ;;
    --error-signature) [ $# -ge 2 ] || { echo "CTL: ERROR missing-error-signature" >&2; exit 4; }; errsig="$2"; shift ;;
    --false-complete) [ $# -ge 2 ] || { echo "CTL: ERROR missing-false-complete" >&2; exit 4; }; fcomplete="$2"; shift ;;
    --dry) [ $# -ge 2 ] || { echo "CTL: ERROR missing-dry" >&2; exit 4; }; dry="$2"; shift ;;
    --score) [ $# -ge 2 ] || { echo "CTL: ERROR missing-score" >&2; exit 4; }; score="$2"; shift ;;
    --judge-score) [ $# -ge 2 ] || { echo "CTL: ERROR missing-judge-score" >&2; exit 4; }; judge_score="$2"; shift ;;
    --strategy-delta) [ $# -ge 2 ] || { echo "CTL: ERROR missing-strategy-delta" >&2; exit 4; }; strategy_delta="$2"; shift ;;
    --strategy) [ $# -ge 2 ] || { echo "CTL: ERROR missing-strategy" >&2; exit 4; }; strategy="$2"; shift ;;
    --adversarial) [ $# -ge 2 ] || { echo "CTL: ERROR missing-adversarial-verdict" >&2; exit 4; }; adversarial="$2"; shift ;;
    --adversarial-note) [ $# -ge 2 ] || { echo "CTL: ERROR missing-adversarial-note" >&2; exit 4; }; adv_note="$2"; shift ;;
    --fault) [ $# -ge 2 ] || { echo "CTL: ERROR missing-fault-class" >&2; exit 4; }; fault="$2"; shift ;;
    --fault-outcome) [ $# -ge 2 ] || { echo "CTL: ERROR missing-fault-outcome" >&2; exit 4; }; fault_outcome="$2"; shift ;;
    --fault-note) [ $# -ge 2 ] || { echo "CTL: ERROR missing-fault-note" >&2; exit 4; }; fault_note="$2"; shift ;;
    --operation-id) [ $# -ge 2 ] || { echo 'CTL: ERROR missing-operation-id' >&2; exit 4; }; operation_id="$2"; operation_id_seen=1; shift ;;
    --help|-h) sed -n '2,22p' "$0"; exit 0 ;;
    *) echo "CTL: ERROR unknown-flag:$1" >&2; exit 4 ;;
  esac
  shift
done
[ -n "$cmd" ] || { echo "CTL: ERROR no-command (init|stamp|bind|close-iteration|status)" >&2; exit 4; }
if [ "$operation_id_seen" -eq 1 ]; then
  case "$cmd" in init|stamp|bind|close-iteration) : ;; *) echo 'CTL: ERROR operation-id-needs-writer-command' >&2; exit 4 ;; esac
  printf '%s' "$operation_id" | grep -qE '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$' \
    || { echo 'CTL: ERROR invalid-operation-id (1-128 ASCII letters/digits/._-, start with letter/digit)' >&2; exit 4; }
fi

sd="$project/.goal"
[ "$brief" -eq 0 ] || [ "$cmd" = context ] || { echo 'CTL: ERROR brief-needs-context' >&2; exit 4; }
if [ "$cmd" = context ]; then
  # The read-only compiler owns its directory lock and can describe recovery
  # while a transaction is pending. Normal controller readers still refuse it.
  context_args=()
  [ "$auto" -ne 1 ] || context_args+=(--auto)
  [ "$brief" -ne 1 ] || context_args+=(--brief)
  exec python3 -I "$here/goal_context.py" show "$project" "${context_args[@]}"
fi
if [ "$cmd" = init ]; then
  gp_init_max="$max_iterations"
  case "$gp_init_max" in ''|*[!0-9]*) echo 'CTL: ERROR bad-max-iterations' >&2; exit 4 ;; esac
fi
if [ "$cmd" = init ] && [ ! -d "$sd" ]; then
  mkdir -p "$sd" || exit 4
fi
if [ -d "$sd" ] && [ "${GOAL_ACCESS_EXEC_PID:-}" != "$$" ]; then
  access_mode="write"; case "$cmd" in status|context) access_mode="read" ;; esac
  case "$cmd" in init|recover|migrate) access_mode="$cmd" ;; esac
  exec python3 -I "$here/goal_store.py" access-exec "$sd" "$access_mode" "$here/goal_ctl.sh" "${_goal_ctl_args[@]}"
fi
if [ "$cmd" != recover ] && [ -e "$sd/store/pending" ]; then
  echo 'CTL: ERROR recovery-required (run recover before further ledger operations)' >&2
  exit 4
fi
# shellcheck source=goal_parse.sh
. "$here/goal_parse.sh"       # one grammar, one home (v2.7) - shared with goal_gate.sh
r(){ gp_r; }
# MUST match goal_gate.sh hash_std - stamp and verify share one digest rule
hash_std(){ gp_hash_std; }
state_get(){ gp_state_get "$project" "$1"; }
if [ -n "$operation_id" ] && { [ "$cmd" = init ] || [ "$cmd" = stamp ]; }; then
  python3 -I "$here/goal_store.py" mutation-retry "$sd" "$cmd" "${_goal_ctl_args[@]}"; replay_rc=$?
  [ "$replay_rc" -eq 100 ] || exit "$replay_rc"
fi
if [ "$cmd" = stamp ] && [ -n "$time_budget" ]; then
  gp_is_natural "$time_budget" || { echo "CTL: ERROR bad-time-budget:$time_budget" >&2; exit 4; }
  time_budget=$(printf '%s' "$time_budget" | sed 's/^0*//')
  [ -n "$time_budget" ] || time_budget=0
fi

case "$cmd" in
  migrate)
    python3 -I "$here/goal_store.py" migrate-views "$sd" || exit 4
    if [ "$(gp_contract_mode "$project")" = forge ]; then
      python3 -I "$here/goal_forge.py" adopt --project "$project" || exit 4
    fi
    exit 0 ;;
  recover)
    python3 -I "$here/goal_store.py" close-journal "$sd" recover || exit 4
    echo 'CTL: RECOVER ok (checks were not replayed)'
    exit 0 ;;
  init)
    [ -d "$sd" ] || mkdir -p "$sd/logs"
    if [ -f "$sd/goal.md" ] || [ -f "$sd/state.rec" ]; then echo "CTL: ERROR already-initialized ($sd)" >&2; exit 2; fi
    mutation_id=$(python3 -I "$here/goal_store.py" mutation-journal "$sd" begin init "${_goal_ctl_args[@]}") || exit 4
    printf 'iteration=0\nbreaker=CLOSED\nfalse_completes=0\nreplans=0\nno_progress_streak=0\nlast_progress_iteration=0\nmax_iterations=%s\nno_progress_limit=2\nmax_replans=2\nper_check_fail_cap=3\npanel_max=4\ndry_streak=0\ndry_limit=3\ncheck_timeout=120\ntime_budget=0\ndeadline=0\n' "$max_iterations" > "$sd/state.rec" || exit 4
    : > "$sd/loop-log.md" || exit 4
    : > "$sd/verdicts.rec" || exit 4
    mkdir -p "$sd/evidence" || exit 4
    # work-plan skeleton (SB-8): an empty file is a trap - Write/Edit tools
    # refuse to overwrite unread empty files and controllers waste a turn
    # inventing the format. The schema is fixed; seed it once.
    {
      printf '# work-plan (controller ticks; NEVER a GO signal)\n\n'
      printf '# format: - [ ] T1 <scope> | owner=<name> | files=<paths>\n'
      printf '# done:   - [x] T1 ...\n'
    } > "$sd/work-plan.md" || exit 4
    python3 -I "$here/goal_store.py" mutation-journal "$sd" finish || exit 4
    echo "CTL: INIT ok operation=$mutation_id - fill $sd/goal.md, then: goal_ctl.sh stamp --project $project" ;;

  stamp)
    [ -f "$sd/goal.md" ] || { echo "CTL: ERROR no-goal-md" >&2; exit 4; }
    if grep -qE '^approved: [0-9a-f]{6,}' "$sd/goal.md"; then
      echo "CTL: ERROR already-stamped (R3: one stamp; amendments go to the user)" >&2; exit 2
    fi
    [ "$(grep -c '^approved: ' "$sd/goal.md")" = 1 ] \
      || { echo "CTL: ERROR stamp-refused: goal.md needs one 'approved: <placeholder>' line" >&2; exit 4; }
    gp_watch_validate "$project" || { echo "CTL: ERROR stamp-refused: invalid watch path" >&2; exit 2; }
    # AC grammar at t=0 (SB-1): one AC = one line carrying check: AND expected:.
    # Multi-line check commands push expected: onto a continuation the parser
    # never sees, and the loop only learns contract-malformed mid-wave - after
    # workers have already burned a round. Refuse the stamp instead.
    for ac_id in $(gp_all_ac_ids "$project"); do
      body=$(gp_ac_line_for "$project" "$ac_id")
      [ -n "$body" ] || { echo "CTL: ERROR stamp-refused: $ac_id vanished from the AC section (unparseable)" >&2; exit 2; }
      printf '%s\n' "$body" | grep -q 'expected:' \
        || { echo "CTL: ERROR stamp-refused: $ac_id is not a single-line AC (no expected: on the AC line - put the whole check in one line inside backticks; do not wrap it)" >&2; exit 2; }
      printf '%s\n' "$body" | grep -q 'check:' \
        || { echo "CTL: ERROR stamp-refused: $ac_id has no check: field (every AC needs a failable named check)" >&2; exit 2; }
      exp=$(gp_ac_expected "$project" "$ac_id" | tr -d '[:space:]')
      [ -n "$exp" ] \
        || { echo "CTL: ERROR stamp-refused: $ac_id expected: token is empty after parse (single-line AC required)" >&2; exit 2; }
    done
    forge_freeze=""
    # The declared finite probe scope is approved with the existing freeze.
    if [ "$(gp_contract_mode "$project")" = forge ]; then
      forge_freeze=$(python3 -I "$here/goal_forge.py" freeze --project "$project") || {
        echo 'CTL: ERROR stamp-refused: forge needs a valid .goal/forge-plan.json' >&2
        exit 2
      }
    fi
    # forge contracts: baseline must cover every delta metric AC BEFORE the
    # stamp - t=0 exposure, never a mid-loop rc=4 surprise (v1.5)
    if grep -qE '^exit: *forge' "$sd/goal.md" 2>/dev/null; then
      if ! bl=$(bash "$here/goal_gate.sh" --baseline-check --project "$project" 2>&1); then
        printf '%s\n' "$bl" >&2
        echo "CTL: ERROR stamp-refused: baseline validation failed (forge contract) - run the metric checks against the pre-work artifact and write .goal/baseline.md" >&2
        exit 2
      fi
    fi
    # the objective must point at a score-producing AC (expected: maximize|
    # minimize); pointing it at a judged/exit AC can never yield a score and
    # only surfaces mid-loop as score-missing - catch the mismatch at t=0.
    oac=$(gp_objective_ac "$project")
    if [ -n "$oac" ]; then
      oexp=$(gp_ac_expected "$project" "$oac" | tr -d '[:space:]')
      case "$oexp" in
        maximize|minimize) : ;;
        *) echo "CTL: ERROR stamp-refused: objective points at $oac whose expected= is not maximize|minimize (it would never produce a score)" >&2; exit 2 ;;
      esac
    fi
    # Calibration fixtures (v2.6): calib: belongs to JUDGED ACs only, needs
    # both fixtures, and the fixture files must exist in the tree NOW - t=0
    # exposure so the loop never discovers mid-run that the yardstick is gone.
    # Grammar (backtick decoys stripped) comes from the shared parser.
    for ac_id in $(gp_all_ac_ids "$project"); do
      [ "$(gp_ac_calib_declared "$project" "$ac_id")" = yes ] || continue
      exp=$(gp_ac_expected "$project" "$ac_id" | tr -d '[:space:]')
      [ "$exp" = judged ] || { echo "CTL: ERROR stamp-refused: $ac_id declares calib: but expected= is not judged (calibration measures a seat, not a command)" >&2; exit 2; }
      cg=$(gp_ac_calib_good "$project" "$ac_id")
      cb=$(gp_ac_calib_bad "$project" "$ac_id")
      { [ -n "$cg" ] && [ -n "$cb" ]; } || { echo "CTL: ERROR stamp-refused: $ac_id calib: needs BOTH good= and bad= fixtures" >&2; exit 2; }
      [ -f "$project/$cg" ] || { echo "CTL: ERROR stamp-refused: $ac_id good fixture $cg not found in the tree" >&2; exit 2; }
      [ -f "$project/$cb" ] || { echo "CTL: ERROR stamp-refused: $ac_id bad fixture $cb not found in the tree" >&2; exit 2; }
      # same file on both ends = one ruler claiming to measure both directions:
      # the pair's PASS+FAIL requirement is then a permanent block. Catch at t=0.
      [ "$cg" != "$cb" ] || { echo "CTL: ERROR stamp-refused: $ac_id calib: good= and bad= name the SAME file $cg (one ruler cannot calibrate both ways)" >&2; exit 2; }
    done
    # External tokens (v2.9): external: is ADDITIVE (the in-tree check: floor
    # is still required), so window: without external: measures nothing -
    # refuse the half-declaration at t=0 instead of letting it decay into an
    # ignored decoration later.
    for ac_id in $(gp_all_ac_ids "$project"); do
      [ -n "$(gp_ac_window "$project" "$ac_id")" ] || continue
      [ -n "$(gp_ac_external_cmd "$project" "$ac_id")" ] \
        || { echo "CTL: ERROR stamp-refused: $ac_id declares window: but no external: (window caches an out-of-tree check - declare both or neither)" >&2; exit 2; }
    done
    # Horizon hard constraint (v2.9): an objective layer is a gradient - with
    # no horizon AC (judged + calib) guarding what the number does not see,
    # the contract is a Goodhart machine by design. Refuse the stamp unless
    # the contract explicitly says why that blind spot is acceptable.
    if [ -n "$(gp_objective_ac "$project")" ]; then
      horizon_ok=0
      for ac_id in $(gp_all_ac_ids "$project"); do
        [ "$(gp_ac_expected "$project" "$ac_id" | tr -d '[:space:]')" = judged ] || continue
        [ "$(gp_ac_calib_declared "$project" "$ac_id")" = yes ] && horizon_ok=1 && break
      done
      if [ "$horizon_ok" -ne 1 ] && [ -z "$(gp_horizon_waived "$project")" ]; then
        echo "CTL: ERROR stamp-refused: objective contract has no horizon layer (needs >=1 judged AC with calib: guarding the objective's blind spot) - or declare why the blind spot is acceptable with a line: horizon-waived: <reason>" >&2
        exit 2
      fi
    fi
    h=$(gp_ac_body_hash "$project")
    mutation_id=$(python3 -I "$here/goal_store.py" mutation-journal "$sd" begin stamp "${_goal_ctl_args[@]}") || exit 4
    # Budget knobs written in goal.md BIND at stamp. They used to be
    # decorative (contract said max_iterations=10, state.rec kept 12) -
    # that is a silent contract lie. Parse key=value tokens; CLI --time-budget
    # still wins over a wallclock= token.
    for key in max_iterations no_progress_limit max_replans per_check_fail_cap panel_max dry_limit check_timeout wallclock; do
      val=$(r < "$sd/goal.md" | sed -nE "s/.*(^|[[:space:]])${key}=([0-9]+).*/\2/p" | tail -1)
      [ -n "$val" ] || continue
      val=$(printf '%s' "$val" | sed 's/^0*//')
      [ -n "$val" ] || val=0
      case "$key" in
        wallclock)
          [ -n "${time_budget:-}" ] || time_budget=$val
          ;;
        *)
          { grep -vE "^${key}=" "$sd/state.rec"; printf '%s=%s\n' "$key" "$val"; } > "$sd/state.rec.new" \
            && mv "$sd/state.rec.new" "$sd/state.rec" || exit 4
          ;;
      esac
    done
    case "${time_budget:-}" in                            # optional wall-clock fuse, stamped at approval
      ''|0) : ;;
      *) gp_is_natural "$time_budget" || { echo "CTL: ERROR bad-time-budget:$time_budget" >&2; exit 4; }
         { grep -vE '^(time_budget|deadline)=' "$sd/state.rec"
           printf 'time_budget=%s\ndeadline=%s\n' "$time_budget" "$(( $(date +%s) + time_budget ))"
         } > "$sd/state.rec.new" && mv "$sd/state.rec.new" "$sd/state.rec" || exit 4 ;;
    esac
    # Dual-encode freeze (harness engineering): pin check/probe SCRIPT bodies,
    # not just the AC line text. goal.md hash cannot see a swapped check.sh.
    # Sidecar file: close-iteration rewrites state.rec wholesale and would drop
    # a state.rec key; this freeze must survive every close.
    # NOTE: never use case patterns with ')' inside $( ) - /*) closes the sub.
    freeze=""
    freeze=$(
      {
        r < "$sd/goal.md" | sed -nE 's/.*check: *`([^`]*)`.*/\1/p'
        r < "$sd/goal.md" | sed -nE 's/.*probe: *`([^`]*)`.*/\1/p'
      } | tr ' \t' '\n\n' | grep -E '\.(sh|py|rb|js)$' | sort -u | while IFS= read -r scr; do
        [ -n "$scr" ] || continue
        f="$project/$scr"
        [ "${scr#/}" != "$scr" ] && f="$scr"
        [ -f "$f" ] || continue
        h=$(gp_hash_std < "$f" | cut -c1-8)
        printf '%s=%s;' "$scr" "$h"
      done
    )
    printf '%s\n' "$freeze$forge_freeze" > "$sd/check_freeze" || exit 4
    if [ -n "$forge_freeze" ]; then
      mkdir -p "$sd/evidence/raw" || exit 4
      python3 -I "$here/goal_forge.py" archive --project "$project" --expected "$forge_freeze" \
        > "$sd/evidence/raw/0.txt" || exit 4
    fi
    marker=""; [ "$auto" -eq 1 ] && marker=" auto"
    gp_sed_inplace "s/^approved: .*/approved: $h $(date +%F)$marker/" "$sd/goal.md" \
      || { echo "CTL: ERROR stamp-failed: could not write the approved: line" >&2; exit 4; }
    # sed silently no-ops when the goal.md has no approved: placeholder line -
    # the whole stamp then pretends success while the contract stays
    # unstamped. Fail loud instead (the contract template always ships one).
    grep -E '^approved:' "$sd/goal.md" | head -1 | grep -qE '[0-9a-f]{6,}' \
      || { echo "CTL: ERROR stamp-refused: goal.md has no 'approved: <placeholder>' line to write the hash onto" >&2; exit 4; }
    # Goal-agnostic run defaults: seed pre-reg if the controller has not.
    # Template lives in assets/ (kill lines, strategy slots, degrade). Never
    # overwrite an authored pre-reg.
    if [ ! -f "$sd/pre-reg.md" ] && [ -f "$here/../assets/pre-reg.template.md" ]; then
      {
        echo "# pre-reg.md — seeded at stamp $(date +%F)"
        echo
        sed "s/^T0 = .*/T0 = $(date +%FT%T)/" "$here/../assets/pre-reg.template.md"
      } > "$sd/pre-reg.md" || exit 4
    fi
    python3 -I "$here/goal_store.py" mutation-journal "$sd" finish || exit 4
    grep -E '^approved:' "$sd/goal.md" | head -1 ;;

  bind)
    python3 -I "$here/goal_store.py" bind-mutation "$sd" "${_goal_ctl_args[@]}" || exit 4 ;;

  close-iteration)
    if [ -n "$operation_id" ]; then
      python3 -I "$here/goal_store.py" close-retry "$sd" "${_goal_ctl_args[@]}"; replay_rc=$?
      [ "$replay_rc" -eq 100 ] || exit "$replay_rc"
    fi
    # Reject malformed receipts before any ledger or evidence mutation.
    case "$adversarial" in
      ''|clear|finding) : ;;
      *) echo "CTL: ERROR bad-adversarial:$adversarial (use clear|finding)" >&2; exit 4 ;;
    esac
    for v in "$task" "$files" "$cp" "$cf" "$cu"; do
      [ -n "$v" ] || { echo "CTL: ERROR close-iteration needs --task --files --checks-pass --checks-fail --checks-unverifiable" >&2; exit 4; }
    done
    for v in "$cp" "$cf" "$cu"; do
      gp_is_natural "$v" || { echo "CTL: ERROR bad-check-count:$v" >&2; exit 4; }
    done
    case "$progress" in yes|no) : ;; *) echo "CTL: ERROR bad-progress:$progress" >&2; exit 4 ;; esac
    case "$exit_signal" in yes|no) : ;; *) echo "CTL: ERROR bad-exit-signal:$exit_signal" >&2; exit 4 ;; esac
    case "$fcomplete" in yes|no) : ;; *) echo "CTL: ERROR bad-false-complete:$fcomplete" >&2; exit 4 ;; esac
    case "$dry" in ''|yes|no) : ;; *) echo "CTL: ERROR bad-dry:$dry" >&2; exit 4 ;; esac
    case "$strategy" in *'|'*) echo 'CTL: ERROR bad-strategy-label' >&2; exit 4 ;; esac
    case "$errsig" in *$'\n'*|*$'\r'*) echo 'CTL: ERROR bad-error-signature' >&2; exit 4 ;; esac
    case "$files" in *$'\n'*|*$'\r'*) echo 'CTL: ERROR bad-files-list' >&2; exit 4 ;; esac
    if [ "$progress" = no ]; then
      delta_check=$(printf '%s' "$strategy_delta" | tr '\n\r\t' '   ' | sed 's/^ *//;s/ *$//')
      case "$delta_check" in ''|none) echo 'CTL: ERROR missing-strategy-delta' >&2; exit 4 ;; esac
    fi
    [ -f "$sd/loop-log.md" ] || { echo "CTL: ERROR no-loop-log" >&2; exit 4; }
    # --files is evidence of what landed (SB-6). A missing path is usually a
    # typo or a scope lie; warn loud but do not refuse the bookkeeping write -
    # the gate's check-mutated-tree already owns the "did it really land" side.
    miss=0; miss_names=""
    for f in $(printf '%s' "$files" | tr ',' ' '); do
      [ -n "$f" ] || continue
      [ -e "$project/$f" ] || [ -e "$f" ] || { miss=$((miss+1)); miss_names="$miss_names $f"; }
    done
    if [ "$miss" -gt 0 ]; then
      # False-tick tooth: if work-plan has [x] naming a missing path, refuse
      # even a bookkeeping close - the tick is a lie on disk (seen live:
      # ch-001..012 never landed). Unrelated --files stubs stay WARN so
      # non-ticked bookkeeping is not blocked.
      lie=0
      for f in $miss_names; do
        if [ -f "$sd/work-plan.md" ] && grep -E '^- \[x\]' "$sd/work-plan.md" 2>/dev/null | grep -qF "$f"; then
          lie=1
        fi
      done
      if [ "$lie" = 1 ]; then
        echo "CTL: ERROR missing-claimed-file:${miss_names# } (work-plan [x] names paths that do not exist - untick or land the files)" >&2
        exit 4
      fi
      echo "CTL: WARN missing-claimed-file:${miss_names# } (listed in --files but not under $project)" >&2
      echo "CTL: NOTE files-missing=$miss (bookkeeping continues; fix the list or the artifacts)" >&2
    fi
    # forge bookkeeping: validate BEFORE anything is written - a rc=4 refusal
    # must never leave an orphan loop-log block (checker finding, v1.2)
    if grep -qE '^exit: *forge' "$sd/goal.md" 2>/dev/null; then
      [ -n "$dry" ] || { echo "CTL: ERROR forge-contract-needs-dry (close-iteration --dry yes|no)" >&2; exit 4; }
    fi
    if [ "$dry" = yes ] && [ "${cf:-0}" != 0 ]; then
      echo "CTL: ERROR inconsistent-dry (--dry yes with checks-fail=$cf)" >&2; exit 4
    fi
    # task= is ledger law (R12/A1): wave ids must carry their backend. A bare
    # T<n> means an ordinary one-shot subagent wave - normalize it (crew:1)
    # instead of letting the self-audit refuse the claim after the fact.
    case "$task" in
      '') echo "CTL: ERROR missing-task (ledger needs --task T<n> or T<n>[backend:N])" >&2; exit 4 ;;
      T[0-9]*)
        if printf '%s' "$task" | grep -qE '^T[0-9]+$'; then
          task="${task}[crew:1]"
        fi
        ;;
    esac
    # Worker-fault bookkeeping. The task= suffix is NEVER self-declared: a
    # declared fault (class x outcome) maps to exactly one suffix and ctl
    # writes it, so "recovered" cannot be claimed without a fault behind it
    # and a fault cannot be swallowed silently. The fault row lands in
    # .goal/evidence/faults.rec next to the block it belongs to.
    fsuf=$(gp_task_recovery "$task")
    if [ -z "$fsuf" ]; then fb=$(gp_task_fallback "$task"); [ -n "$fb" ] && fsuf="fallback:$fb"; fi
    if [ -n "$fault" ] || [ -n "$fault_outcome" ]; then
      [ -n "$fault" ] && [ -n "$fault_outcome" ] \
        || { echo "CTL: ERROR fault-needs-both (--fault CLASS --fault-outcome OUTCOME)" >&2; exit 4; }
      gp_fault_class_ok "$(gp_fault_classes)" "$fault" \
        || { echo "CTL: ERROR bad-fault-class:$fault (use one of: $(gp_fault_classes))" >&2; exit 4; }
      fsuf2=$(gp_fault_suffix "$fault" "$fault_outcome")
      [ -n "$fsuf2" ] \
        || { echo "CTL: ERROR bad-fault-outcome:$fault/$fault_outcome (legal pairs: stall/resume, tool-error/resume, stall/re-run, tool-error/re-run, death/re-run, provider-fatal/take-over)" >&2; exit 4; }
      [ -z "$fsuf" ] || [ "$fsuf" = "$fsuf2" ] \
        || { echo "CTL: ERROR fault-suffix-mismatch (task carries ($fsuf) but $fault/$fault_outcome maps to ($fsuf2))" >&2; exit 4; }
      fsuf="$fsuf2"
      task=$(printf '%s' "$task" | sed -E 's/ *\((fallback:[a-z0-9-]+|stall-recovered|tool-error-fixed|re-run:(stall|tool-error|death))\)$//')
      task="$task ($fsuf)"
    else
      [ -z "$fsuf" ] \
        || { echo "CTL: ERROR unbacked-task-suffix ($fsuf) - a wave suffix must come from a declared fault: close-iteration --fault CLASS --fault-outcome OUTCOME" >&2; exit 4; }
    fi
    gp_task_ok "$task" \
      || { echo "CTL: ERROR bad-task:$task (schema: T<n>[crew:N], bare T<n> normalizes to crew:1)" >&2; exit 4; }
    # R10: any no-progress landing sets HALF_OPEN/OPEN and must carry a
    # strategy change - otherwise the loop is grinding without revising.
    if [ "$progress" != yes ]; then
      case "$strategy_delta" in
        ''|none) echo "CTL: ERROR missing-strategy-delta (progress=no needs --strategy-delta 'what you are changing')" >&2; exit 4 ;;
      esac
    fi
    # score bookkeeping (objective: maximize|minimize) - validator in goal_parse.sh
    if [ -n "$score" ]; then
      gp_is_score "$score" || { echo "CTL: ERROR bad-score:$score" >&2; exit 4; }
    fi
    if [ -n "$judge_score" ]; then
      gp_is_score "$judge_score" || { echo "CTL: ERROR bad-judge-score:$judge_score" >&2; exit 4; }
    fi
    # Normalize before validation so whitespace cannot masquerade as a label.
    strat_show=$(printf '%s' "${strategy:-none}" | tr '\n\r\t' '   ')
    case "$strat_show" in ''|*[![:print:]]*) strat_show=none ;; esac
    strat_show=$(printf '%s' "$strat_show" | sed -E 's/^ +//; s/ +$//')
    [ -n "$strat_show" ] || strat_show=none
    # Attribution writer tooth (v2.9): an objective loop is a search - every
    # wave must say which direction it attacks, or the eval plane can never
    # attribute slope to strategy and the EFFICIENCY advisories run blind.
    # Mechanical (writer-side), so the advisory always has data when it fires.
    if [ -n "$(gp_objective_ac "$project")" ]; then
      case "$strat_show" in
        ''|none) echo "CTL: ERROR missing-strategy-label (objective contracts must label every wave: close-iteration --strategy <attack direction>)" >&2; exit 4 ;;
      esac
      printf '%s' "$strat_show" | grep -qE '^[A-Za-z0-9][A-Za-z0-9._-]*$' \
        || { echo 'CTL: ERROR bad-strategy-label (objective labels must be single ASCII tokens)' >&2; exit 4; }
      # Cold-start baseline: the FIRST score row turns the eval loop on.
      # Without it there is no slope, no STRATEGY-PICK, and multi-worker
      # expansion is just file generation.
      if [ ! -s "$sd/scores.rec" ]; then
        case "$score" in
          ''|none) echo "CTL: ERROR missing-score (objective cold-start: first close-iteration must pass --score N so scores.rec has a baseline before further waves)" >&2; exit 4 ;;
        esac
      fi
    fi
    # Serialize real controller writers. Re-run preflight under the lock so
    # state-dependent checks and iteration allocation observe the same writer.
    if [ "${GOAL_CLOSE_EXEC_PID:-}" != "$$" ]; then
      exec python3 -I "$here/goal_store.py" writer-exec "$sd" "$here/goal_ctl.sh" "${_goal_ctl_args[@]}"
    fi
    digest=$(bash "$here/goal_gate.sh" --digest --project "$project") || { echo "CTL: ERROR digest-unavailable" >&2; exit 4; }
    it=$(state_get iteration); [ -n "$it" ] || it=0
    new=$((it+1))
    # The score is MEASURED, never self-reported: ctl reruns the objective AC
    # (gate --verify, stateless) and records the observed value. A mismatch
    # from the controller is noted; an unmeasurable instrument records none
    # and the gate refuses any claim lacking a score.
    obj_ac=$(gp_objective_ac "$project")
    obj_dir=$(gp_objective_dir "$project")
    [ -n "$obj_dir" ] || obj_dir=maximize
    if [ -n "$obj_ac" ] && [ -n "$score" ]; then
      mobs=""
      if measured=$(bash "$here/goal_gate.sh" --verify "$obj_ac" --project "$project" 2>/dev/null); then
        mobs=$(printf '%s\n' "$measured" | sed -nE "s/^GATE: VERIFY ${obj_ac}[|]PASS[|]observed=([-0-9.]+) .*$/\1/p")
      fi
      if [ -n "$mobs" ]; then
        [ "$mobs" = "$score" ] || echo "CTL: NOTE score-measured-override (claimed=$score measured=$mobs)" >&2
        score="$mobs"
      else
        echo "CTL: WARN objective-unmeasurable:$obj_ac (recording score=none)" >&2
        score=""
      fi
    fi
    # R10 value must be single-line or it shreds the key=value block
    sdelta_show=$(printf '%s' "${strategy_delta:-none}" | tr '\n\r\t' '   ')
    case "$sdelta_show" in ''|*[![:print:]]*) sdelta_show=none ;; esac
    [ -n "$sdelta_show" ] || sdelta_show=none
    # R13 sidecar: iter|score|judge (either may be 'none'). Two comparable
    # points later let the gate refuse DIVERGENCE:score-vs-judge claims.
    # v2.8: written AFTER task validation - a refused close must not orphan a
    # score row with no iteration block behind it.
    # v2.9: 4th field = strategy label (empty rows = legacy 3-field, readers
    # stay field-indexed so both shapes parse). Attribution: slope per label.
    python3 -I "$here/goal_store.py" close-journal "$sd" begin || exit 4
    printf '%s|%s|%s|%s\n' "$new" "${score:-none}" "${judge_score:-none}" "$strat_show" >> "$sd/scores.rec" || exit 4
    printf '%s\n' "## iteration $new" "task=$task" "files_modified=$files" \
      "checks_pass=$cp" "checks_fail=$cf" "checks_unverifiable=$cu" \
      "error_signature=$errsig" "progress=$progress" "exit_signal=$exit_signal" \
      "false_complete=$fcomplete" "digest=$digest" \
      "score=${score:-none}" "strategy_delta=$sdelta_show" "strategy=$strat_show" >> "$sd/loop-log.md" || exit 4
    if [ "$progress" = yes ]; then
      streak=0; breaker=CLOSED; lpi=$new
    else
      streak=$(( $(state_get no_progress_streak) + 1 )); lpi=$(state_get last_progress_iteration)
      npl=$(state_get no_progress_limit); [ -n "$npl" ] || npl=2
      if [ "$streak" -gt "$npl" ]; then breaker=OPEN; else breaker=HALF_OPEN; fi
    fi
    # forge bookkeeping: --dry is mandatory there and must be consistent
    fc=$(state_get false_completes); [ -n "$fc" ] || fc=0
    # The MECHANICAL ratchet below owns the false-complete count when the
    # gate runs. A manual --false-complete yes next to it used to DOUBLE-COUNT
    # (the first caught claim instantly BLOCKed the loop - defeating R1's
    # "two catches" rule). The flag only still means something with --no-gate,
    # where nothing else counts; with the gate running, note and defer.
    if [ "$fcomplete" = yes ]; then
      if [ "$no_gate" -eq 1 ]; then
        fc=$((fc+1))
      else
        echo "CTL: NOTE false-complete-flag-ignored (the gate ratchet counts catches mechanically)" >&2
      fi
    fi
    mi=$(state_get max_iterations); [ -n "$mi" ] || mi=$max_iterations
    drys=$(state_get dry_streak); [ -n "$drys" ] || drys=0
    # Raw observations stay in scores.rec. Only the full quality qualification
    # below may advance the objective water mark; an infeasible score cannot.
    best=$(state_get best_score); [ -n "$best" ] || best=none
    best_basis=$(state_get best_score_basis)
    quality_score=$(state_get last_quality_score)
    quality_judge=$(state_get last_quality_judge)
    if [ "$dry" = yes ]; then drys=$((drys+1)); else drys=0; fi
    dlimit=$(state_get dry_limit); [ -n "$dlimit" ] || dlimit=3
    ctmo=$(state_get check_timeout); [ -n "$ctmo" ] || ctmo=120
    tb=$(state_get time_budget); [ -n "$tb" ] || tb=0
    dl=$(state_get deadline); [ -n "$dl" ] || dl=0
    printf 'iteration=%s\nbreaker=%s\nfalse_completes=%s\nreplans=%s\nno_progress_streak=%s\nlast_progress_iteration=%s\nmax_iterations=%s\nno_progress_limit=%s\nmax_replans=2\nper_check_fail_cap=3\npanel_max=4\ndry_streak=%s\ndry_limit=%s\ncheck_timeout=%s\ntime_budget=%s\ndeadline=%s\nbest_score=%s\nbest_score_basis=%s\nlast_quality_score=%s\nlast_quality_judge=%s\n' \
      "$new" "$breaker" "$fc" "$(state_get replans)" "$streak" "$lpi" "$mi" "$(state_get no_progress_limit)" "$drys" "$dlimit" "$ctmo" "$tb" "$dl" "$best" "$best_basis" "$quality_score" "$quality_judge" > "$sd/state.rec" || exit 4
    # Two-pass + sensor dump (harness engineering). Raw verify output is the
    # mechanical evidence a claim must carry; the adversarial receipt is the
    # second pass and is written only when the controller has run one
    # (--adversarial clear|finding). Never auto-clear.
    mkdir -p "$sd/evidence/raw" || exit 4
    verify_rc=0
    GOAL_RAW_OUTPUT_ITERATION="$new" bash "$here/goal_gate.sh" --verify --project "$project" > "$sd/evidence/raw/$new.txt" 2>&1 || verify_rc=$?
    [ -s "$sd/evidence/raw/$new.txt" ] || { printf 'CTL: WARN raw-empty (verify produced no output - claim will fail raw-evidence-missing)\n' > "$sd/evidence/raw/$new.txt" || exit 4; }
    if [ "$dry" = yes ] && [ "$(gp_contract_mode "$project")" = forge ]; then
      forge_record=$(python3 -I "$here/goal_forge.py" run --project "$project" --iteration "$new" --artifact "$digest" --floor-result "$verify_rc")
      forge_rc=$?
      printf '%s\n' "$forge_record" >> "$sd/evidence/raw/$new.txt" || exit 4
      [ "$forge_rc" -eq 0 ] || [ "$forge_rc" -eq 2 ] || exit 4
      if [ "$forge_rc" -ne 0 ]; then
        gp_sed_inplace 's/^dry_streak=.*/dry_streak=0/' "$sd/state.rec" || exit 4
        echo 'CTL: NOTE forge-not-dry (executed probes found a finding, failed, or exhausted their budget)' >&2
      fi
    fi
    if [ -n "$adversarial" ]; then
      case "$adversarial" in
        clear|finding) : ;;
        *) echo "CTL: ERROR bad-adversarial:$adversarial (use clear|finding)" >&2; exit 4 ;;
      esac
      # Notes are untrusted text, not additional pipe-delimited receipts.
      adv_note_show=$(printf '%s' "${adv_note:-none}" | tr '|\n\r' '   ')
      printf '%s|%s|%s|%s\n' "$new" "$digest" "$adversarial" "$adv_note_show" >> "$sd/evidence/adversarial.rec" || exit 4
    fi
    # Worker-fault receipt: written in the same breath as the block it belongs
    # to, so a fault can never outlive its bookkeeping (audit A11 checks both
    # directions: a suffix without a fault row, and a fault row without a
    # block). Evidence dir - exempt from both digests (R6).
    if [ -n "$fault" ]; then
      mkdir -p "$sd/evidence" || exit 4
      fbase=$(printf '%s' "$task" | sed -E 's/ *\([^)]*\)$//')
      fnote=$(printf '%s' "${fault_note:-none}" | tr '|\n\r' '   ')
      printf '%s|%s|%s|%s|%s\n' "$fbase" "$fault" "$fsuf" "$fnote" "$(date +%s)" >> "$sd/evidence/faults.rec" || exit 4
      echo "CTL: FAULT task=$fbase class=$fault suffix=($fsuf) note=$fnote"
    fi
    if [ -n "$obj_ac" ]; then
      python3 -I "$here/goal_store.py" qualify-objective "$sd" || exit 4
    fi
    if [ "$no_gate" -eq 1 ]; then
      python3 -I "$here/goal_store.py" close-journal "$sd" finish 0 || exit 4
      echo "CTL: CLOSE ok iter=$new digest=$digest operation=$GOAL_CLOSE_OPERATION"
      exit 0
    fi
    # False-complete ratchet, mechanized: a claim that the gate catches failing
    # IS a false complete - counting it used to depend on the controller
    # obeying the NOTE and appending false_complete=yes by hand. Two catches
    # now BLOCK the loop automatically (gate rule fc>=2). Only NO-GO (rc=2)
    # claims count; BLOCKED/rc=4 mean other failures.
    # Capture the gate's verdict: the reason/hint pair lands in state.rec so
    # `status` can print a mechanical NEXT= later. Streams are split-captured
    # and replayed (stdout->stdout, stderr->stderr) so the pass-through stays
    # byte-identical to the old direct call; the real gate rc survives.
    g_out=$(mktemp "${TMPDIR:-/tmp}/ctl-gate-out.XXXXXX") || g_out=/tmp/ctl-gate-out.$$
    g_err=$(mktemp "${TMPDIR:-/tmp}/ctl-gate-err.XXXXXX") || g_err=/tmp/ctl-gate-err.$$
    bash "$here/goal_gate.sh" --check --project "$project" >"$g_out" 2>"$g_err"; grc=$?
    cat "$g_out"; cat "$g_err" >&2
    gate_out=$(cat "$g_out" "$g_err")
    rm -f "$g_out" "$g_err"
    last_reason=$(printf '%s\n' "$gate_out" | grep -E '^GATE: (NO-GO|BLOCKED|ERROR)' | tail -1 | sed -nE 's/.*reason=([^ ]*).*/\1/p')
    last_hint=$(printf '%s\n' "$gate_out" | grep -E '^GATE: NO-GO' | tail -1 | sed -nE 's/.*hint=([^ ]*).*/\1/p')
    { grep -vE '^last_(reason|hint)=' "$sd/state.rec" 2>/dev/null
      printf 'last_reason=%s\nlast_hint=%s\n' "${last_reason:-ok}" "${last_hint:-}"; } > "$sd/state.rec.new" \
      && mv "$sd/state.rec.new" "$sd/state.rec" || exit 4
    # deferred-pending never counts: the gate said "in-tree settled, one
    # out-of-tree fact is still pending" (R18) - waiting honestly on a slow
    # source is not a false complete. Counting waits would BLOCK a loop whose
    # CRM simply hasn't settled yet: the ratchet catches lies, not patience.
    if [ "$grc" -eq 2 ] && [ "$exit_signal" = yes ]; then
      case "$last_reason" in
        deferred-pending:*) echo "CTL: NOTE deferred-wait-not-counted ($last_reason) - patience is not a false complete" >&2 ;;
        digest-version-mismatch:*) echo "CTL: NOTE digest-migration-not-counted ($last_reason) - rebind evidence using the current digest" >&2 ;;
        # contract-malformed is a drafting defect, not a lying claim (SB-2).
        # Counting it toward the false-complete ratchet BLOCKs a loop whose
        # author wrapped a check command across lines - the ratchet exists to
        # catch manufactured passes, not typos in the yardstick.
        contract-malformed:*) echo "CTL: NOTE contract-defect-not-counted ($last_reason) - a broken yardstick is not a false complete; restamp after fixing the AC line" >&2 ;;
        *)
        fc=$(( $(state_get false_completes) + 1 ))
        { grep -vE '^false_completes=' "$sd/state.rec"; printf 'false_completes=%s\n' "$fc"; } > "$sd/state.rec.new" \
          && mv "$sd/state.rec.new" "$sd/state.rec" || exit 4
        echo "CTL: NOTE false-complete-counted=$fc (gate caught a failing claim; two catches BLOCK the loop - fix the artifact, do not re-claim)" >&2
        ;;
      esac
    fi
    python3 -I "$here/goal_store.py" close-journal "$sd" finish "$grc" || exit 4
    echo "CTL: CLOSE ok iter=$new digest=$digest operation=$GOAL_CLOSE_OPERATION"
    exit "$grc" ;;

  status)
    [ ! -e "$sd/store/pending" ] || { echo 'CTL: ERROR recovery-required' >&2; exit 4; }
    [ -f "$sd/state.rec" ] || { echo "CTL: STATUS no active goal-loop ledger ($sd/state.rec missing)" >&2; exit 4; }
    if [ "$(gp_contract_mode "$project")" = forge ]; then
      python3 -I "$here/goal_forge.py" status --project "$project" || echo 'CTL: FORGE coverage=unverified'
    fi
    g(){ state_get "$1"; }
    left="off"
    d=$(g deadline); if [ -n "$d" ] && [ "$d" != 0 ]; then left=$(( d - $(date +%s) ))s; [ "$left" = "" ] && left=0s; fi
    # STEP line (v2.7): the loop's four steps are a cycle; "where am I" is
    # derived from ledger facts (stamp present? blocks written? claim present?
    # gate verdict recorded), not asked of the controller. This is the
    # recall-free answer to "what does the loop do next" at ANY point, not
    # only right after a NO-GO.
    stamped=0; grep -qE '^approved: [0-9a-f]{6,}' "$sd/goal.md" 2>/dev/null && stamped=1
    blocks=0; [ -s "$sd/loop-log.md" ] && blocks=$(grep -cE '^## iteration' "$sd/loop-log.md")
    claimed=0; tail -n 40 "$sd/loop-log.md" 2>/dev/null | grep -qE '^exit_signal=yes' && claimed=1
    # Goal-agnostic: work without a bookkeeping row is an unbooked wave.
    ticked=0; [ -f "$sd/work-plan.md" ] && ticked=$(grep -cE '^- \[x\]' "$sd/work-plan.md" 2>/dev/null || echo 0)
    case "$ticked" in ''|*[!0-9]*) ticked=0 ;; esac
    unbooked=0
    [ "$blocks" -eq 0 ] && [ "$ticked" -gt 0 ] && unbooked=1
    if [ "$stamped" -eq 0 ]; then
      step="1-contract: goal.md not stamped - fill ACs, smoke checks, then ctl stamp"
    elif [ "$unbooked" = 1 ]; then
      step="3-join: work-plan is ticked but loop-log has no iteration - close-iteration before any further dispatch"
    elif [ "$blocks" -eq 0 ]; then
      step="2-dispatch: stamped, no iteration blocks yet - brief the first wave (then close-iteration)"
    elif [ "$claimed" = 1 ]; then
      step="4-branch: last block claims done - run gate --check, then deliver or follow NEXT"
    else
      step="3-join: work landed but not claimed - review evidence, close-iteration with exit-signal"
    fi
    echo "CTL: STEP $step (stamped=$stamped blocks=$blocks claim=$claimed)"
    printf 'CTL: STATUS iter=%s/%s breaker=%s dry_streak=%s/%s best_score=%s time_left=%s\n' \
      "$(g iteration)" "$(g max_iterations)" "$(g breaker)" "$(g dry_streak)" "$(g dry_limit)" "$(g best_score)" "$left"
    lb=$(awk '
      /^## iteration/ { delete l; next }
      { line=$0; sub(/\r$/,"",line)
        if (line ~ /=/) { p=index(line,"="); l[substr(line,1,p-1)]=substr(line,p+1) } }
    END { printf "task=%s checks=%s pass / %s fail / %s unverifiable progress=%s digest=%s",
      l["task"], l["checks_pass"], l["checks_fail"], l["checks_unverifiable"], l["progress"], l["digest"] }
    ' "$sd/loop-log.md" 2>/dev/null)
    echo "CTL: LAST $lb"
    # All open queue items (controller must tick [x] on join). A single
    # "NEXT" line hid the rest and after a NO-GO kept pointing at finished work.
    open=$(grep -E '^- \[ \]' "$sd/work-plan.md" 2>/dev/null | sed 's/^- \[ \] //' | cut -c1-120)
    if [ -n "$open" ]; then
      echo "CTL: OPEN ($(printf '%s\n' "$open" | wc -l | tr -d ' ') items)"
      printf '%s\n' "$open" | sed 's/^/CTL:   - /'
    else
      echo "CTL: OPEN none (all tasks closed)"
    fi
    # ---- eval-drive attribution inputs (shared by STRATEGY-PICK + EFFICIENCY)
    obj_ac=$(gp_objective_ac "$project")
    obj_dir=$(gp_objective_dir "$project")
    tol=$( [ -n "$obj_ac" ] && gp_ac_tolerance "$project" "$obj_ac" )
    tol=${tol:-0}
    # Shared kernel emits CTL: EFFICIENCY, eval-gap:, promote: and
    # attribution-unused: together with the pick; NEXT consumes that same pick.
    nps=$(g no_progress_streak); drys=$(g dry_streak)
    case "${nps:-0}" in ''|*[!0-9]*) nps=0;; esac
    case "${drys:-0}" in ''|*[!0-9]*) drys=0;; esac
    stalled=0
    [ "$nps" -ge 1 ] && stalled=1
    [ "$(gp_contract_mode "$project")" = forge ] && [ "$drys" -ge 1 ] && stalled=1
    # Dispersion is not stored in scores.rec; do not pretend the tolerance
    # alone establishes a usable direction when sd:/var: is declared.
    uncertain=0
    if [ -n "$obj_ac" ]; then
      [ -z "$(gp_ac_sd_re "$project" "$obj_ac")$(gp_ac_var_re "$project" "$obj_ac")" ] || uncertain=1
    fi
    strategy_advice=""; pick_prefer=""; pick_avoid=""
    if [ -n "$obj_ac" ] || [ "$stalled" = 1 ] || [ -s "$sd/loop-log.md" ]; then
      sf=/dev/null; [ -s "$sd/scores.rec" ] && sf="$sd/scores.rec"
      lf=/dev/null; [ -s "$sd/loop-log.md" ] && lf="$sd/loop-log.md"
      strategy_advice=$(gawk -v obj="${obj_dir:-none}" -v tol="$tol" -v stalled="$stalled" -v uncertain="$uncertain" \
        -f "$here/goal_strategy.awk" "$sf" "$lf") || {
        echo "CTL: ERROR strategy-analysis-failed" >&2; exit 4;
      }
      pick_line=$(printf '%s\n' "$strategy_advice" | sed -n 's/^CTL: STRATEGY-PICK //p')
      if [ -n "$pick_line" ]; then
        pick_prefer=$(printf '%s\n' "$pick_line" | sed -n 's/^prefer=\([^ ]*\).*/\1/p')
        pick_avoid=$(printf '%s\n' "$pick_line" | sed -n 's/^prefer=[^ ]* avoid=\(.*\)$/\1/p')
        echo "CTL: STRATEGY-PICK $pick_line"
      fi
    fi
    pick_txt=""
    if [ -n "${pick_prefer:-}" ] || [ -n "${pick_avoid:-}" ]; then
      pick_txt="STRATEGY-PICK prefer=${pick_prefer:-none} avoid=${pick_avoid:-none}"
    fi
    # NEXT= is the mechanical routing the controller must otherwise remember
    # from the gate's hint token: state.rec carries the pair recorded by the
    # last close-iteration, and this maps it to one sentence. No judgment:
    # the mapping lives in one place and matches references/gate.md section 3.
    # When attribution already names a direction, replan/delta routes paste it.
    lr=$(g last_reason); lh=$(g last_hint)
    # Deadline crossed with no books = do not pretend "nothing pending".
    dl_now=$(g deadline); tb_now=$(g time_budget)
    case "$dl_now" in ''|*[!0-9]*) dl_now=0 ;; esac
    case "$tb_now" in ''|*[!0-9]*) tb_now=0 ;; esac
    expired=0
    [ "$dl_now" -gt 0 ] && [ "$(date +%s)" -ge "$dl_now" ] && expired=1
    if [ "${unbooked:-0}" = 1 ]; then
      echo "CTL: NEXT reason=unbooked-wave hint=close-iteration"
      echo "CTL:   -> close-iteration now (work-plan ticked / work product exists but no loop-log row) - do NOT dispatch another wave first"
    elif [ "$expired" = 1 ] && [ "${blocks:-0}" -eq 0 ]; then
      echo "CTL: NEXT reason=deadline-expired hint=close-iteration"
      echo "CTL:   -> wallclock expired with zero books: close-iteration on what landed (or degrade-deliver) - do NOT dispatch another wave"
    elif [ "$expired" = 1 ] && { [ -z "$lr" ] || [ "$lr" = ok ]; }; then
      echo "CTL: NEXT reason=deadline-expired hint=graceful-deliver"
      echo "CTL:   -> wallclock expired: claim what passes (GO+NOTE) or fix and claim - do not expand scope"
    elif [ -z "$lr" ] || [ "$lr" = ok ]; then
      echo "CTL: NEXT (nothing pending at last gate check - claim when ready)"
    else
      case "$lh" in
        fix-AC)              next="dispatch a fixer scoped to the open-FAIL AC's files" ;;
        run-adversarial)     next="run a second-pass adversarial review, then close-iteration --adversarial clear|finding --adversarial-note ..." ;;
        close-open-item)     next="work-plan still has open item(s): land them, or record the worker fault - close-iteration --fault CLASS --fault-outcome OUTCOME (resume|re-run|take-over)" ;;
        fix-adversarial-finding) next="fix the finding named in adversarial.rec, re-review, close-iteration --adversarial clear" ;;
        attach-raw)          next="re-run checks and leave the real output in .goal/evidence/raw/<iter>.txt (close-iteration writes this automatically)" ;;
        bind-seat)           next="dispatch a cold judging seat - do NOT send a coder" ;;
        fix-instrument)      next="repair the probe/verify instrument; the number is untrusted" ;;
        bind-calib-grades)   next="grade the calib fixtures and bind AC-N#good=PASS / AC-N#bad=FAIL this iteration" ;;
        fix-calib-fixture)   next="restore the named calibration fixture (or restamp with valid paths)" ;;
        restore-best)        next="return the tree to best_score state before claiming" ;;
        continue-forge)      next="keep forging: dry_streak < dry_limit, run another exhaustion round" ;;
        write-strategy-delta) next="record what genuinely changes next${pick_txt:+ ($pick_txt)}, then close-iteration" ;;
        rebind-judged)       next="re-run the judging seat at the current digest and bind fresh" ;;
        write-ledger-block)  next="close-iteration wrote nothing or an illegal task id - write the ledger block (task=T<n>[backend:N])" ;;
        set-exit-signal)     next="the block never claimed exit - close-iteration --exit-signal yes" ;;
        redesign-AC)         next="the metric and the cold seat disagree: rewrite the AC or its direction" ;;
        proposal-to-user)    next="the contract changed: propose an amendment, do not apply it" ;;
        graceful-deliver)    next="time fuse expired: deliver the passing work as best-so-far and stop" ;;
        replan-or-stop)      next="same error signature twice: change strategy (HALF_OPEN)${pick_txt:+ — $pick_txt} or stop and report" ;;
        *)                   next="read reason=$lr (hint=$lh) and route literally" ;;
      esac
      echo "CTL: NEXT reason=$lr hint=${lh:-none}"
      echo "CTL:   -> $next"
    fi
    [ -z "$strategy_advice" ] || printf '%s\n' "$strategy_advice" | sed '/^CTL: STRATEGY-PICK /d'
    # Runtime records are observations, not completion evidence. Missing or
    # damaged telemetry reports unknown without changing the product ledger.
    python3 -I "$here/goal_trace.py" summary "$project" || true
    exit 0 ;;
esac
