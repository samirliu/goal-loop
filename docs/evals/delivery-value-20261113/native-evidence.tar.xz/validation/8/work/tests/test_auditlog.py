"""Independent contract checks, including failure paths and publication."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from auditlog import parse_line, summarize
from auditlog.__main__ import _publish


class AuditTests(unittest.TestCase):
    def test_validation(self):
        for invalid in ('', '{', '[]', 'null', 'true', '{}',
                        '{"key":"","amount":1}',
                        '{"key":2,"amount":1}',
                        '{"key":"a","amount":true}',
                        '{"key":"a","amount":1.0}',
                        '{"key":"a","amount":"2"}',
                        '{"key":"a","amount":NaN}'):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                parse_line(invalid)
        self.assertEqual(parse_line('{"key":"  Ä ","amount":-7,"x":0}'),
                         {"key": "  Ä ", "amount": -7})

    def test_aggregate(self):
        source = [{"key": "z", "amount": -3}, {"key": "a", "amount": 0},
                  {"key": "z", "amount": 9}, {"key": "z", "amount": -4}]
        original = [dict(record) for record in source]
        self.assertEqual(summarize(iter(source)), [
            {"key": "a", "count": 1, "total": 0, "min": 0, "max": 0},
            {"key": "z", "count": 3, "total": 2, "min": -4, "max": 9}])
        self.assertEqual(source, original)
        self.assertEqual(summarize(iter(())), [])

    def test_cli(self):
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory)/"in", Path(directory)/"out"
            args = [sys.executable, "-B", "-m", "auditlog", "--input",
                    str(source), "--output", str(output)]
            output.write_text("sentinel", encoding="utf-8")
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(output.read_text(), "sentinel")
            source.write_bytes(b'\n{"key":"z","amount":3}\n \n{bad\n'
                               b'{"key":"a","amount":-2}\n\xff\n')
            result = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("line 4", result.stderr)
            self.assertEqual(output.read_text(), "sentinel")
            result = subprocess.run(args + ["--skip-bad"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stderr), {"skipped": 2})
            self.assertEqual([json.loads(row)["key"] for row in output.read_text().splitlines()],
                             ["a", "z"])
            source.write_text(" \n\t\n", encoding="utf-8")
            result = subprocess.run(args + ["--skip-bad"], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stderr), {"skipped": 0})
            self.assertEqual(output.read_bytes(), b"")
            source.write_text('{"key":"same","amount":4}', encoding="utf-8")
            same = args[:-1] + [str(source)]
            result = subprocess.run(same, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(source.read_text())["total"], 4)

    def test_failed_atomic_replacement(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)/"out"
            output.write_text("sentinel")
            with patch("auditlog.__main__.os.replace", side_effect=OSError("failure")):
                with self.assertRaises(OSError):
                    _publish([{"key": "a", "total": 1}], output)
            self.assertEqual(output.read_text(), "sentinel")
            self.assertEqual(list(Path(directory).iterdir()), [output])


if __name__ == "__main__":
    unittest.main()
