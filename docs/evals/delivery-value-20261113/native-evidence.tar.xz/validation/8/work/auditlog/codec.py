"""Decode and validate individual audit records."""

import json


def _invalid_constant(value):
    raise ValueError("invalid JSON constant: " + value)


def parse_line(line):
    """Return the key and integer amount from a JSON object.

    Extra object fields are ignored. All malformed records raise ValueError.
    """
    try:
        record = json.loads(line, parse_constant=_invalid_constant)
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise ValueError("invalid JSON record") from exc
    if not isinstance(record, dict):
        raise ValueError("record must be an object")
    key = record.get("key")
    amount = record.get("amount")
    if not isinstance(key, str) or not key:
        raise ValueError("key must be a nonempty string")
    if not isinstance(amount, int) or isinstance(amount, bool):
        raise ValueError("amount must be an integer")
    return {"key": key, "amount": amount}
