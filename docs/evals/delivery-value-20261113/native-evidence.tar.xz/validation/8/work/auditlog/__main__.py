"""Command-line JSONL summarizer with atomic output publication."""

import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

from .aggregate import summarize
from .codec import parse_line


def _records(source, skip_bad, skipped):
    for number, raw in enumerate(source, 1):
        try:
            line = raw.decode("utf-8")
            if not line.strip():
                continue
            record = parse_line(line)
        except (ValueError, UnicodeError) as exc:
            if not skip_bad:
                raise ValueError(f"line {number}: {exc}") from exc
            skipped[0] += 1
            continue
        yield record


def _publish(groups, destination):
    destination = Path(destination)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n",
            dir=destination.parent, prefix=".auditlog-", suffix=".tmp",
            delete=False,
        ) as output:
            temporary = output.name
            for group in groups:
                output.write(json.dumps(group, ensure_ascii=True) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
        temporary = None
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--skip-bad", action="store_true")
    args = parser.parse_args(argv)
    skipped = [0]
    try:
        with open(args.input, "rb") as source:
            groups = summarize(_records(source, args.skip_bad, skipped))
        _publish(groups, args.output)
    except (OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if args.skip_bad:
        print(json.dumps({"skipped": skipped[0]}), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
