import copy
import random
import unittest

from solution import merge_ranges


class MergeRangesTests(unittest.TestCase):
    def test_order_overlap_and_touching(self):
        self.assertEqual(
            merge_ranges([[9, 10], [3, 6], [1, 3], [2, 4], [10, 11], [-8, -5]]),
            [[-8, -5], [1, 6], [9, 11]],
        )

    def test_empty_and_nested(self):
        self.assertEqual(merge_ranges([]), [])
        self.assertEqual(merge_ranges([[3, 3], [-1, -1]]), [])
        self.assertEqual(merge_ranges([[0, 8], [2, 4], [0, 8], [5, 5]]), [[0, 8]])

    def test_large_bounds(self):
        huge = 10 ** 200
        self.assertEqual(merge_ranges([[huge, huge + 2], [-huge, -huge + 3]]),
                         [[-huge, -huge + 3], [huge, huge + 2]])

    def test_preserves_input_and_does_not_alias(self):
        original = [[4, 8], [1, 4], [9, 9]]
        before = copy.deepcopy(original)
        output = merge_ranges(original)
        self.assertEqual(original, before)
        output[0][0] = -100
        self.assertEqual(original, before)

    def test_invalid_inputs(self):
        for bad in (None, True, 4, '12', {},
                    [None], [True], [4], [[]], [[1]], [[1, 2, 3]],
                    ['12'], [{1, 2}], [{0: 1, 1: 2}],
                    [[True, 3]], [[0, False]], [[1.0, 3]],
                    [[0, '3']], [[0, None]], [[3, 2]],
                    [[2, 2], [False, False]], [[0, 1], [3, 2]]):
            with self.subTest(bad=bad):
                before = copy.deepcopy(bad)
                with self.assertRaises(ValueError):
                    merge_ranges(bad)
                self.assertEqual(bad, before)

    def test_randomized_independent_union(self):
        rng = random.Random(8193)
        for _ in range(400):
            intervals = [sorted([rng.randint(-15, 15), rng.randint(-15, 15)])
                         for _ in range(rng.randrange(25))]
            before = copy.deepcopy(intervals)
            points = sorted({point for start, end in intervals
                             for point in range(start, end)})
            expected = []
            for point in points:
                if expected and expected[-1][1] == point:
                    expected[-1][1] = point + 1
                else:
                    expected.append([point, point + 1])
            self.assertEqual(merge_ranges(intervals), expected)
            self.assertEqual(intervals, before)


if __name__ == '__main__':
    unittest.main()
