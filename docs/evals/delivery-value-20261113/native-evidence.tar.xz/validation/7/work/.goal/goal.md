# Goal

## Objective

Implement solution.merge_ranges as specified in TASK.md, preserving input and strictly validating interval bounds.

## Acceptance criteria

- AC-1 | The supplied public behavior passes | check: `PYTHONDONTWRITEBYTECODE=1 python3 public.py` | expected: exit=0
- AC-2 | Edge cases, invalid input, ownership, and independent randomized union checks pass | check: `python3 -B test_solution.py` | expected: exit=0

## Approval

approved: ce28b77b 2026-11-13 auto
