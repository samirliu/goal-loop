# work-plan (controller ticks; NEVER a GO signal)

# format: - [x] T1 <scope> | owner=<name> | files=<paths>
# done:   - [x] T1 ...

- [x] T1 Implement and verify merge_ranges | owner=/root/delivery_7 | files=solution.py,test_solution.py
