# Goal contract - implement solution.merge_ranges

Status: APPROVED         <!-- flipped by the stamp d7decbbc (auto) -->

## Objective

Implement `solution.merge_ranges(ranges)` as specified by TASK.md: take a list
of half-open `[start, end]` integer pairs, reject bools, non-integers,
malformed pairs and start>end with ValueError, ignore empty intervals, return
a sorted list of nonempty `[start, end]` lists merging overlapping and
touching intervals, preserve the input, and support negative and arbitrarily
large integer bounds.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | the mandated public harness for merge_ranges passes | check: `python3 public.py` | expected: exit=0
- AC-2 | the extended behaviour suite covering every TASK.md rule passes | check: `python3 test_solution.py` | expected: exit=0

## Out of scope

- TASK.md and public.py are frozen inputs and are not modified.
- No third-party dependencies and no network access; the standard library only.

## Budget knobs (override before approval if needed; BIND AT STAMP)

max_iterations=12  no_progress_limit=2  max_replans=2
per_check_fail_cap=3  panel_max=4  dry_limit=3  check_timeout=120

## Approval

Approval mode: auto

approved: d7decbbc 2026-11-13 auto
