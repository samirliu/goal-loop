"""Merging of half-open integer intervals.

`merge_ranges` takes a list of ``[start, end]`` pairs describing half-open
intervals and returns the same coverage as a sorted list of merged, nonempty
``[start, end]`` lists.
"""

from collections.abc import Sequence

__all__ = ["merge_ranges"]


def _is_integer(value):
    # bool is a subclass of int; the contract rejects it explicitly.
    return isinstance(value, int) and not isinstance(value, bool)


def _bounds(pair):
    """Validate one ``[start, end]`` pair and return its integer bounds."""
    if isinstance(pair, (str, bytes, bytearray)) or not isinstance(pair, Sequence):
        raise ValueError("interval must be a two-element sequence: %r" % (pair,))
    if len(pair) != 2:
        raise ValueError("interval must have exactly two elements: %r" % (pair,))
    start, end = pair[0], pair[1]
    if not _is_integer(start) or not _is_integer(end):
        raise ValueError("interval bounds must be integers: %r" % (pair,))
    if start > end:
        raise ValueError("interval start must not exceed its end: %r" % (pair,))
    return start, end


def merge_ranges(ranges):
    """Merge overlapping and touching half-open integer intervals.

    Empty intervals (start == end) cover nothing and are ignored. The input
    is never mutated; the result is a fresh list of fresh two-element lists.
    """
    try:
        items = list(ranges)
    except TypeError:
        raise ValueError(
            "ranges must be an iterable of [start, end] pairs: %r" % (ranges,)
        ) from None

    intervals = []
    for pair in items:
        start, end = _bounds(pair)
        if start == end:
            continue
        intervals.append((start, end))

    intervals.sort()
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            # overlapping or touching the previous interval
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
