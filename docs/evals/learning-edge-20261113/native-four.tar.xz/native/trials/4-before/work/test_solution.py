"""Extended behaviour suite for solution.merge_ranges.

public.py exercises the headline cases; this suite covers the remaining
TASK.md rules (every rejection reason, empty intervals, extreme bounds) and
the input-preservation requirement.
"""

from solution import merge_ranges


def expect_value_error(value):
    try:
        merge_ranges(value)
    except ValueError:
        return
    except Exception as exc:
        raise AssertionError(
            "expected ValueError, got %r for %r" % (exc, value)
        )
    raise AssertionError("expected ValueError, got no exception for %r" % (value,))


def main():
    # --- merging semantics --------------------------------------------
    assert merge_ranges([]) == []
    assert merge_ranges([[1, 2]]) == [[1, 2]]
    # touching endpoints merge into one half-open interval
    assert merge_ranges([[1, 4], [4, 8]]) == [[1, 8]]
    # overlapping intervals merge
    assert merge_ranges([[1, 5], [3, 8]]) == [[1, 8]]
    # nested intervals merge
    assert merge_ranges([[1, 10], [3, 4]]) == [[1, 10]]
    # result is sorted regardless of input order
    assert merge_ranges([[9, 10], [1, 2], [5, 6]]) == [[1, 2], [5, 6], [9, 10]]
    # empty intervals are ignored, not merged in
    assert merge_ranges([[9, 9], [1, 3]]) == [[1, 3]]
    assert merge_ranges([[3, 3]]) == []
    assert merge_ranges([[1, 2], [2, 2], [2, 3]]) == [[1, 3]]

    # --- negative and arbitrarily large bounds ------------------------
    assert merge_ranges([[-10, -5], [-7, -2]]) == [[-10, -2]]
    assert merge_ranges([[-(10 ** 30), -(10 ** 30) + 3]]) == [
        [-(10 ** 30), -(10 ** 30) + 3]
    ]
    assert merge_ranges([[10 ** 40, 10 ** 40 + 2]]) == [[10 ** 40, 10 ** 40 + 2]]
    assert merge_ranges([[-2, 0], [0, 2]]) == [[-2, 2]]

    # --- rejection rules ----------------------------------------------
    for bad in (
        [[3, 1]],                 # start > end
        [[True, 4]],              # bool bound
        [[4, True]],              # bool bound
        [[1, 2, 3]],              # malformed pair
        [[1]],                    # malformed pair
        [[]],                     # malformed pair
        [5],                      # not a pair
        [[1, 2.0]],               # non-integer bound
        [["1", "2"]],             # non-integer bounds
        [[None, 2]],              # non-integer bound
        [[1, 2], [3, 1]],         # one bad pair among good ones
        ["ab"],                   # not a pair
        [None],                   # not iterable
        ({1, 2},),                # unordered pair
    ):
        expect_value_error(bad)

    # --- the input is preserved ---------------------------------------
    original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
    snapshot = [list(pair) for pair in original]
    merged = merge_ranges(original)
    assert original == snapshot
    assert merged == [[-4, -1], [1, 8]]
    for row in merged:
        assert all(row is not source for source in original)
    assert all(isinstance(row, list) and len(row) == 2 for row in merged)

    # --- tuples are accepted as pairs ---------------------------------
    assert merge_ranges([(1, 4), (4, 8)]) == [[1, 8]]

    print("EXTENDED PASS")


main()
