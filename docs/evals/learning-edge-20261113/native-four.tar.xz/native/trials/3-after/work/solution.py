"""Merge overlapping / touching half-open integer intervals.

`merge_ranges(ranges)` takes a sequence of ``[start, end]`` integer pairs
describing half-open intervals ``[start, end)`` and returns a new, sorted list
of nonempty ``[start, end]`` lists where overlapping and touching intervals
have been merged.

Contract (from TASK.md):
  * bools, non-integers, malformed pairs and ``start > end`` are rejected
    with ``ValueError``;
  * empty intervals (``start == end``) are ignored, not rejected;
  * the input is preserved (never mutated);
  * negative and arbitrarily large integer bounds are supported.
"""

__all__ = ["merge_ranges"]

# Container types accepted for one interval.  A pair is anything of length two
# that is a list or a tuple; everything else is malformed.
_PAIR_TYPES = (list, tuple)

# Types that are iterable but never a valid interval container.  Rejecting
# them explicitly avoids the confusing "string is a sequence of chars" path.
_STRING_TYPES = (str, bytes, bytearray)


def _as_pair(item):
    """Return ``(start, end)`` for a well-formed pair, else raise ValueError."""
    if isinstance(item, _STRING_TYPES) or not isinstance(item, _PAIR_TYPES):
        raise ValueError(
            "interval must be a [start, end] pair, got {0!r}".format(item)
        )
    if len(item) != 2:
        raise ValueError(
            "interval must have exactly two elements, got {0!r}".format(item)
        )
    return item[0], item[1]


def _as_bound(value):
    """Return ``value`` as an int, rejecting bools and non-integers."""
    # bool is a subclass of int, so it has to be excluded explicitly.
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(
            "interval bounds must be integers, got {0!r}".format(value)
        )
    return value


def merge_ranges(ranges):
    """Merge half-open ``[start, end)`` integer intervals.

    Overlapping and merely touching intervals (one ending exactly where the
    next begins) are merged.  Empty intervals are dropped.  The result is a
    fresh list of fresh lists; the input is left untouched.

    Raises:
        ValueError: if a pair is malformed, a bound is not an integer (bool
            included), or ``start > end``.
    """
    if isinstance(ranges, _STRING_TYPES):
        raise ValueError(
            "ranges must be a sequence of [start, end] pairs, got {0!r}".format(
                ranges
            )
        )
    try:
        items = list(ranges)
    except TypeError:
        raise ValueError(
            "ranges must be an iterable of [start, end] pairs, got {0!r}".format(
                ranges
            )
        ) from None

    intervals = []
    for item in items:
        start, end = _as_pair(item)
        start = _as_bound(start)
        end = _as_bound(end)
        if start > end:
            raise ValueError(
                "interval start must not exceed end, got [{0!r}, {1!r}]".format(
                    start, end
                )
            )
        if start == end:
            # Empty half-open interval: ignored, not an error.
            continue
        intervals.append([start, end])

    intervals.sort(key=lambda interval: (interval[0], interval[1]))

    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            # Overlapping or touching the previous interval.
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
