"""Adversarial / edge-case suite for solution.merge_ranges.

Run:  python3 -B test_solution.py   (exit 0 = all cases pass)

The suite attacks the contract from TASK.md directly instead of trusting the
public acceptance script: malformed input classes, empty-interval handling,
input preservation, extreme bounds and a randomized differential check
against an independent set-based reference implementation.
"""

import random
import unittest

from solution import merge_ranges


class TestPublicBehaviour(unittest.TestCase):
    def test_public_example(self):
        original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
        self.assertEqual(merge_ranges(original), [[-4, -1], [1, 8]])

    def test_huge_bounds(self):
        big = 10 ** 30
        self.assertEqual(merge_ranges([[big, big + 2]]), [[big, big + 2]])

    def test_single_interval(self):
        self.assertEqual(merge_ranges([[1, 2]]), [[1, 2]])

    def test_empty_input(self):
        self.assertEqual(merge_ranges([]), [])


class TestMerging(unittest.TestCase):
    def test_overlap(self):
        self.assertEqual(merge_ranges([[1, 5], [3, 7]]), [[1, 7]])

    def test_touching_endpoints_merge(self):
        self.assertEqual(merge_ranges([[1, 4], [4, 8]]), [[1, 8]])

    def test_adjacent_but_not_touching_stay_split(self):
        self.assertEqual(merge_ranges([[1, 2], [3, 4]]), [[1, 2], [3, 4]])

    def test_nested_interval(self):
        self.assertEqual(merge_ranges([[1, 10], [3, 4]]), [[1, 10]])

    def test_transitive_chain(self):
        self.assertEqual(merge_ranges([[1, 4], [4, 7], [6, 9]]), [[1, 9]])

    def test_duplicate_intervals(self):
        self.assertEqual(merge_ranges([[1, 5], [1, 5]]), [[1, 5]])

    def test_unsorted_input_is_sorted(self):
        self.assertEqual(
            merge_ranges([[9, 12], [-3, 1], [4, 6]]), [[-3, 1], [4, 6], [9, 12]]
        )

    def test_output_is_sorted_and_disjoint(self):
        merged = merge_ranges([[5, 9], [1, 3], [2, 4], [10, 12]])
        self.assertEqual(merged, [[1, 4], [5, 9], [10, 12]])
        for left, right in zip(merged, merged[1:]):
            self.assertLess(left[1], right[0])

    def test_empty_intervals_ignored(self):
        self.assertEqual(merge_ranges([[5, 5]]), [])
        self.assertEqual(merge_ranges([[0, 0], [1, 3], [3, 3], [2, 4]]), [[1, 4]])

    def test_empty_interval_does_not_break_a_real_one(self):
        self.assertEqual(merge_ranges([[1, 2], [2, 2], [2, 3]]), [[1, 3]])

    def test_output_pairs_are_lists(self):
        for pair in merge_ranges([[1, 2], [4, 5]]):
            self.assertIsInstance(pair, list)
            self.assertEqual(len(pair), 2)


class TestNegativeAndLargeBounds(unittest.TestCase):
    def test_negative_intervals(self):
        self.assertEqual(merge_ranges([[-10, -5], [-7, -2]]), [[-10, -2]])

    def test_negative_and_positive_are_not_joined_across_zero(self):
        self.assertEqual(merge_ranges([[-5, -1], [1, 5]]), [[-5, -1], [1, 5]])

    def test_interval_spanning_zero(self):
        self.assertEqual(merge_ranges([[-3, 3]]), [[-3, 3]])

    def test_very_large_bounds(self):
        big = 10 ** 100
        self.assertEqual(
            merge_ranges([[-big, big]]),
            [[-big, big]],
        )

    def test_large_bounds_merge_without_precision_loss(self):
        big = 2 ** 70
        self.assertEqual(merge_ranges([[big, big + 5], [big + 3, big + 9]]),
                         [[big, big + 9]])

    def test_no_float_rounding(self):
        big = 2 ** 53 + 1
        merged = merge_ranges([[big, big + 1]])
        self.assertEqual(merged, [[big, big + 1]])
        self.assertIsInstance(merged[0][0], int)


class TestRejections(unittest.TestCase):
    def _assert_value_error(self, payload):
        with self.assertRaises(ValueError):
            merge_ranges(payload)

    def test_start_greater_than_end(self):
        self._assert_value_error([[3, 1]])

    def test_start_greater_than_end_among_valid_pairs(self):
        self._assert_value_error([[1, 2], [3, 1]])

    def test_bool_bounds_rejected(self):
        self._assert_value_error([[True, 4]])
        self._assert_value_error([[1, False]])
        self._assert_value_error([[False, True]])

    def test_float_bounds_rejected(self):
        self._assert_value_error([[1.5, 4]])
        self._assert_value_error([[1, 4.0]])
        self._assert_value_error([[1.0, 2.0]])

    def test_non_integer_bounds_rejected(self):
        self._assert_value_error([[None, 4]])
        self._assert_value_error([[1, "4"]])
        self._assert_value_error([["a", "b"]])
        self._assert_value_error([[1, [2]]])

    def test_malformed_pairs_rejected(self):
        self._assert_value_error([[1, 2, 3]])
        self._assert_value_error([[1]])
        self._assert_value_error([[]])
        self._assert_value_error([5])
        self._assert_value_error(["ab"])
        self._assert_value_error([None])
        self._assert_value_error([[[1, 2], 3]])

    def test_non_iterable_input_rejected(self):
        self._assert_value_error(None)
        self._assert_value_error(5)

    def test_string_input_rejected(self):
        self._assert_value_error("abc")

    def test_empty_interval_is_ignored_not_rejected(self):
        # Contrast with start > end: equal bounds are legal but empty.
        self.assertEqual(merge_ranges([[3, 3]]), [])


class TestInputPreservation(unittest.TestCase):
    def test_input_list_and_pairs_not_mutated(self):
        original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
        snapshot = [list(pair) for pair in original]
        merge_ranges(original)
        self.assertEqual(original, snapshot)

    def test_input_pair_objects_are_not_reused(self):
        original = [[1, 5]]
        merged = merge_ranges(original)
        self.assertIsNot(merged[0], original[0])
        merged[0][0] = 999
        self.assertEqual(original, [[1, 5]])

    def test_input_order_preserved(self):
        original = [[9, 12], [1, 3], [4, 6]]
        merge_ranges(original)
        self.assertEqual(original, [[9, 12], [1, 3], [4, 6]])


class TestDifferentialAgainstReference(unittest.TestCase):
    """Randomized comparison against an independent set-based reference."""

    @staticmethod
    def _reference(pairs):
        points = set()
        for start, end in pairs:
            if start < end:
                points.update(range(start, end))
        if not points:
            return []
        merged = []
        for point in sorted(points):
            if merged and point <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], point + 1)
            else:
                merged.append([point, point + 1])
        return merged

    def test_random_inputs_match_reference(self):
        rng = random.Random(20261113)
        for _ in range(500):
            count = rng.randint(0, 8)
            pairs = []
            for _ in range(count):
                start = rng.randint(-20, 20)
                end = rng.randint(-20, 20)
                if start > end:
                    start, end = end, start
                pairs.append([start, end])
            self.assertEqual(
                merge_ranges([list(p) for p in pairs]),
                self._reference(pairs),
                msg="pairs={0!r}".format(pairs),
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
