"""Merge overlapping or touching half-open integer intervals.

``merge_ranges`` takes a sequence of ``[start, end]`` integer pairs describing
half-open intervals ``[start, end)`` and returns the maximal intervals left
after merging every pair that overlaps or whose endpoints touch.

The input is never modified, and every returned interval is non-empty
(``start < end``) and sorted by start.
"""

from collections.abc import Sequence

__all__ = ["merge_ranges"]


def _endpoints(pair):
    """Return the two integer endpoints of ``pair`` or raise ValueError."""
    if isinstance(pair, (str, bytes, bytearray)) or not isinstance(pair, Sequence):
        raise ValueError("range pair must be a two-item sequence: %r" % (pair,))
    if len(pair) != 2:
        raise ValueError("range pair must hold exactly two items: %r" % (pair,))
    start, end = pair[0], pair[1]
    for value in (start, end):
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("range endpoints must be plain integers: %r" % (value,))
    if start > end:
        raise ValueError("range start must not exceed its end: %r" % (pair,))
    return start, end


def merge_ranges(ranges):
    """Merge overlapping or touching half-open intervals.

    Args:
        ranges: An iterable of ``[start, end]`` integer pairs.  Endpoints may
            be negative and arbitrarily large.  ``start == end`` denotes an
            empty interval and is ignored.

    Returns:
        A sorted list of non-empty ``[start, end]`` lists.

    Raises:
        ValueError: If the input is not an iterable of pairs, if a pair does
            not hold exactly two items, if an endpoint is a bool or a
            non-integer, or if a pair has ``start > end``.
    """
    if isinstance(ranges, (str, bytes, bytearray)):
        raise ValueError("ranges must be an iterable of [start, end] pairs")
    try:
        pairs = list(ranges)
    except TypeError:
        raise ValueError("ranges must be an iterable of [start, end] pairs") from None

    spans = []
    for pair in pairs:
        start, end = _endpoints(pair)
        if start == end:
            continue  # empty interval contributes nothing to the union
        spans.append((start, end))

    spans.sort()
    merged = []
    for start, end in spans:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
