# Goal contract - merge overlapping or touching half-open integer intervals

Status: DRAFT

## Objective

Implement `solution.merge_ranges(ranges)` exactly as TASK.md specifies: given a list of `[start,end]` integer pairs describing half-open intervals, reject bools, non-integers, malformed pairs and `start > end` with ValueError, ignore empty intervals, and return a sorted list of non-empty `[start,end]` lists with overlaps and touching endpoints merged. The input must be preserved and negative / arbitrarily large bounds must work.

## Exit policy

exit: threshold

## Acceptance criteria

- AC-1 | the public acceptance script passes | check: `PYTHONDONTWRITEBYTECODE=1 python3 public.py` | expected: exit=0
- AC-2 | the local contract suite passes (overlap, touching endpoints, gaps, empty intervals, malformed input rejected with ValueError, input preserved, negative and large bounds, brute-force differential) | check: `PYTHONDONTWRITEBYTECODE=1 python3 local_tests.py` | expected: exit=0

## Out of scope

- Any edit to TASK.md, public.py, the goal-loop skill, or anything outside this project directory.
- Network access, MCP tools, external dependencies, or model overrides.

## Budget knobs

max_iterations=12  no_progress_limit=2  max_replans=2
per_check_fail_cap=3  panel_max=4  dry_limit=3  check_timeout=120

## Approval

Approval mode: auto

approved: cf88ddd0 2026-11-13 auto
