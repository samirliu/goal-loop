# work-plan (controller ticks; NEVER a GO signal)

# format: - [ ] T1 <scope> | owner=<name> | files=<paths>
# done:   - [x] T1 ...

- [x] T1 implement solution.merge_ranges plus the local contract suite | owner=controller | files=solution.py,local_tests.py
