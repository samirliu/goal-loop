# pre-reg.md — seeded at stamp 2026-11-13

T0 = 2026-11-13T00:35:16
budget: max_iterations=12 wallclock=179s (remaining of the host 360s prompt budget)

## Hypothesis and counterevidence

Change the one mechanism `solution.merge_ranges` (was `raise NotImplementedError`)
because TASK.md names a complete, failable contract and `python3 public.py` fails
outright on the stub.
Predict AC-1 (public script) and AC-2 (local contract suite) both reach exit=0 and
the tree digest moves exactly once, at the first landing of solution.py/local_tests.py.
Reject if any rejection shape (bool, float, short/long pair, reversed pair) fails to
raise ValueError, if the input list is mutated, or if the merged result is not a
sorted list of non-empty `[start,end]` lists.
Counterevidence considered: a "touching" merge that also swallows a 1-unit gap
(`a <= end + 1` instead of `a <= end`) would pass the public example while silently
over-covering the union - the brute-force point-union differential in AC-2 is the
instrument that detects it, not the public script.

## Strategy labels (objective contracts)

This is an `exit: threshold` contract (no objective score), so there is no slope to
attribute; `prefer=none` is the honest label here - one wave, one delivery, no
strategy sweep to run.

- `none` - expected benefit: none (single-pass threshold task); failure condition:
  AC-1/AC-2 fail; scope: the whole contract.

## Kill lines

- `iteration=0` with landed work or >=50% wallclock: close books before dispatch.
- Retry `avoid=` without a changed hypothesis and `strategy_delta`.
- Claim without adversarial clear, raw output, or untouched check scripts.
- Change the metric/check mid-run to raise the score.

## Success digits

Report accepted deliveries / all trials, score trajectory, and gate evidence.
For efficiency: total elapsed time and token/cost telemetry including evals,
joins, retries and failures; unavailable values are unknown, never zero.
Wave count alone cannot establish cost efficiency or parallel speedup.

## Reusable-policy promotion (only when changing the skill/strategy itself)

Freeze baseline/candidate, graders, task split and equal budgets before trials.
Keep held-out answers away from workers; use paired fresh states and repeats.
Report acceptance rate + all-trial cost / accepted deliveries + median/p90
time to delivery; failures are budget-censored, not excluded.
Retain incumbent on floor regression or no held-out benefit; keep failed trials.

## Degrade line

On budget expiry: report what passes + remaining evidence gaps and continuation
paths. Only gate GO is completion; partial delivery is not GO.

## Wave record (written at booking, honest order)

The single wave T1 was produced in-session before the stamp (quickstart lane: one
task, one end-to-end check, no crew). The stamp froze the checks AFTER the landing,
so the pre-registration above is a reconstruction of the hypothesis the wave
actually executed, not a pre-dispatch prediction. The falsifiable part - the
brute-force point-union differential and the rejection shapes - was still run
against the landed artifact before booking.
