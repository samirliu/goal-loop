"""Local acceptance tests for solution.merge_ranges (TASK.md contract).

Run with:  python3 -B local_tests.py
Exits 0 when every assertion holds, non-zero otherwise.
"""

import copy
import random

from solution import merge_ranges


def brute_force(intervals):
    """Reference union built from the occupied integer points."""
    occupied = sorted({x for a, b in intervals for x in range(a, b)})
    expected = []
    for x in occupied:
        if expected and expected[-1][1] == x:
            expected[-1][1] = x + 1
        else:
            expected.append([x, x + 1])
    return expected


def rejects(bad):
    try:
        merge_ranges(bad)
    except ValueError:
        return
    raise AssertionError("expected ValueError for %r" % (bad,))


def test_public_example():
    original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
    assert merge_ranges(original) == [[-4, -1], [1, 8]]
    assert original == [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]


def test_empty_input():
    assert merge_ranges([]) == []


def test_empty_intervals_ignored():
    assert merge_ranges([[5, 5]]) == []
    assert merge_ranges([[5, 5], [1, 3], [3, 3]]) == [[1, 3]]


def test_overlap_and_touching():
    assert merge_ranges([[1, 5], [3, 7]]) == [[1, 7]]
    assert merge_ranges([[1, 5], [5, 7]]) == [[1, 7]]  # touching endpoints
    assert merge_ranges([[1, 3], [4, 6]]) == [[1, 3], [4, 6]]  # gap kept
    assert merge_ranges([[1, 3], [3, 6], [6, 9]]) == [[1, 9]]


def test_result_shape_is_lists():
    out = merge_ranges([[1, 3], [2, 4]])
    assert isinstance(out, list)
    assert all(isinstance(item, list) for item in out)
    assert out == [[1, 4]]


def test_sorted_output():
    assert merge_ranges([[10, 12], [-5, -3], [0, 1]]) == [[-5, -3], [0, 1], [10, 12]]


def test_input_preserved():
    original = [[4, 8], [1, 4], [2, 3], [-4, -1]]
    snapshot = copy.deepcopy(original)
    merge_ranges(original)
    assert original == snapshot


def test_negative_and_large_bounds():
    assert merge_ranges([[-10 ** 40, -10 ** 40 + 2], [10 ** 40, 10 ** 40 + 1]]) == [
        [-10 ** 40, -10 ** 40 + 2],
        [10 ** 40, 10 ** 40 + 1],
    ]
    assert merge_ranges([[-10 ** 30, 10 ** 30]]) == [[-10 ** 30, 10 ** 30]]


def test_rejects_malformed():
    for bad in ([[2, 1]], [[True, 4]], [[0, 1.0]], [[1]], [[1, 2, 3]], [[]],
                [[1, "2"]], [[None, 3]], [[4, False]], [["a", "b"]]):
        rejects(bad)


def test_rejects_non_iterable():
    rejects(5)
    rejects(None)


def test_matches_brute_force():
    rng = random.Random(20261113)
    for size in range(40):
        intervals = [sorted([rng.randrange(-15, 16), rng.randrange(-15, 16)])
                     for _ in range(size)]
        original = copy.deepcopy(intervals)
        assert merge_ranges(intervals) == brute_force(intervals)
        assert intervals == original


def main():
    tests = [value for name, value in sorted(globals().items()) if name.startswith("test_")]
    for test in tests:
        test()
    print("LOCAL PASS (%d tests)" % len(tests))


if __name__ == "__main__":
    main()
