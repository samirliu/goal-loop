"""Interval merging for half-open integer ranges."""


def _as_pair(item):
    """Return (start, end) for a well-formed pair, else raise ValueError."""
    if isinstance(item, (str, bytes, bytearray)):
        raise ValueError("each range must be a [start, end] pair of integers")
    try:
        pair = list(item)
    except TypeError:
        raise ValueError("each range must be a [start, end] pair of integers")
    if len(pair) != 2:
        raise ValueError("each range must be a [start, end] pair of integers")
    start, end = pair
    for value in (start, end):
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("range bounds must be integers, not booleans")
    if start > end:
        raise ValueError("range start must not exceed range end")
    return start, end


def merge_ranges(ranges):
    """Merge half-open [start, end) integer intervals.

    Overlapping and touching intervals are merged into one interval. Empty
    intervals (start == end) are ignored. The input is never mutated.
    """
    if isinstance(ranges, (str, bytes, bytearray)):
        raise ValueError("ranges must be a list of [start, end] pairs")
    try:
        items = list(ranges)
    except TypeError:
        raise ValueError("ranges must be a list of [start, end] pairs")

    parsed = []
    for item in items:
        start, end = _as_pair(item)
        if start == end:
            continue  # empty interval: ignored, not an error
        parsed.append((start, end))
    parsed.sort()

    merged = []
    for start, end in parsed:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])
    return merged
