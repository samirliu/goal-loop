# Goal contract - implement solution.merge_ranges per TASK.md

Status: DRAFT            <!-- flip to APPROVED only by the stamp below -->

## Objective

Implement `solution.merge_ranges(ranges)` exactly as TASK.md requires: merge a
list of half-open `[start,end)` integer intervals into a sorted list of
nonempty `[start,end]` lists, merging overlapping and touching intervals,
ignoring empty intervals, rejecting bools, non-integers, malformed pairs and
`start>end` with ValueError, preserving the caller's input, and supporting
negative and arbitrarily large integer bounds.

## Exit policy

exit: threshold
<!-- threshold (default): deliver when every AC floor passes. -->

## Acceptance criteria

<!-- Level 0 (default): statement | check: `<cmd>` | expected: exit=0
     - AC-N | <yes/no statement> | check: `<command>` | expected: <spec>
     - the command runs at project root and must not modify the tree
     - `-B` keeps the interpreter from writing __pycache__ into the tree,
       so the gate's digest stays stable across the rerun batch -->

- AC-1 | merge_ranges merges overlapping and touching half-open integer intervals into a sorted list of nonempty [start,end] lists, ignores empty intervals, supports negative and arbitrarily large bounds, and leaves the caller's input unchanged | check: `python3 -B test_solution.py semantics` | expected: exit=0
- AC-2 | merge_ranges rejects bools, non-integers, malformed pairs and start>end with ValueError, and treats start==end as an ignorable empty interval rather than an error | check: `python3 -B test_solution.py validation` | expected: exit=0
- AC-3 | the frozen public harness for merge_ranges passes unchanged | check: `python3 -B public.py` | expected: exit=0

## Out of scope

- Changing TASK.md, public.py, or anything outside solution.py, the optional
  test file, and this project's .goal metadata.
- Performance tuning, non-integer bounds, or input formats beyond a list of
  integer pairs.

## Budget knobs (override before approval if needed; BIND AT STAMP)

max_iterations=12  no_progress_limit=2  max_replans=2
per_check_fail_cap=3  panel_max=4  dry_limit=3  check_timeout=120
wallclock=360
<!-- in-session wall-clock fuse: the deadline is seeded into state.rec at
     stamping, enforced by the gate as rc=3 time-budget-exhausted -->

## Approval

Approval mode: auto   <!-- the session authorized automatic stamping and
     execution; the contract summary was shown before stamping -->

approved: 13bf36ca 2026-11-13 auto

<!-- Write the stamp ONLY after the user explicitly approves. The gate
     recomputes it; a mismatch is contract-tampered (R3). After stamping:
     propose amendments, never apply them in place. -->
