"""Edge-case tests for solution.merge_ranges.

Run one group:  python3 -B test_solution.py semantics
                python3 -B test_solution.py validation
"""

import random
import sys

from solution import merge_ranges

FAILURES = []


def check(label, condition):
    if not condition:
        FAILURES.append(label)


def check_eq(label, got, want):
    check("%s: got %r want %r" % (label, got, want), got == want)


def semantics():
    check_eq("empty input", merge_ranges([]), [])
    check_eq("single range", merge_ranges([[1, 5]]), [[1, 5]])
    check_eq("overlap merges", merge_ranges([[1, 5], [4, 8]]), [[1, 8]])
    check_eq("touching merges", merge_ranges([[1, 4], [4, 8]]), [[1, 8]])
    check_eq("contained absorbed", merge_ranges([[1, 10], [3, 4]]), [[1, 10]])
    check_eq("chain merges", merge_ranges([[1, 2], [2, 3], [3, 4]]), [[1, 4]])
    check_eq("disjoint kept apart", merge_ranges([[1, 2], [5, 6]]), [[1, 2], [5, 6]])
    check_eq("unsorted sorted", merge_ranges([[8, 10], [1, 3]]), [[1, 3], [8, 10]])
    check_eq("negative bounds", merge_ranges([[-5, -1], [-4, -2]]), [[-5, -1]])
    check_eq("negative crossing zero", merge_ranges([[-3, 2], [0, 5]]), [[-3, 5]])
    check_eq("empty interval ignored", merge_ranges([[5, 5], [1, 3]]), [[1, 3]])
    check_eq("only empty intervals", merge_ranges([[5, 5], [-2, -2]]), [])
    check_eq("huge bounds", merge_ranges([[10 ** 30, 10 ** 30 + 2]]),
             [[10 ** 30, 10 ** 30 + 2]])
    check_eq("huge bounds touching", merge_ranges([[10 ** 30, 10 ** 30 + 2],
                                                  [10 ** 30 + 2, 10 ** 30 + 9]]),
             [[10 ** 30, 10 ** 30 + 9]])
    check_eq("negative huge bounds", merge_ranges([[-(10 ** 25), -(10 ** 25) + 3]]),
             [[-(10 ** 25), -(10 ** 25) + 3]])

    # Tuples are valid pairs too.
    check_eq("tuple pairs accepted", merge_ranges([(1, 4), (4, 6)]), [[1, 6]])

    # Output shape: lists, sorted, nonempty.
    source = [[5, 9], [1, 3]]
    source_ids = [id(pair) for pair in source]
    out = merge_ranges(source)
    check("inner elements are lists", all(isinstance(pair, list) for pair in out))
    check("pairs have length 2", all(len(pair) == 2 for pair in out))
    check("pairs are nonempty", all(pair[0] < pair[1] for pair in out))
    check("output sorted by start", out == sorted(out, key=lambda p: p[0]))
    check("returned lists are fresh objects",
          all(id(pair) not in source_ids for pair in out))

    # Input preservation (values AND identity of the caller's lists).
    original = [[4, 8], [1, 4], [2, 3], [-4, -1], [9, 9]]
    snapshot = [list(pair) for pair in original]
    original_ids = [id(pair) for pair in original]
    result = merge_ranges(original)
    check_eq("input unchanged", original, snapshot)
    check("input inner list objects untouched",
          [id(pair) for pair in original] == original_ids)
    check("input inner lists not aliased into result",
          all(id(pair) not in original_ids for pair in result))
    result[0][0] = 12345
    check_eq("mutating result leaves input alone", original, snapshot)

    # Independent reference: compare covered integer points on small ranges.
    rng = random.Random(20261113)
    for trial in range(300):
        pairs = []
        for _ in range(rng.randint(0, 8)):
            lo = rng.randint(-8, 8)
            hi = lo + rng.randint(0, 4)
            pairs.append([lo, hi])
        covered = set()
        for lo, hi in pairs:
            covered.update(range(lo, hi))
        merged = merge_ranges(pairs)
        merged_covered = set()
        for lo, hi in merged:
            merged_covered.update(range(lo, hi))
        check("reference covered set trial %d" % trial, merged_covered == covered)
        check("reference no gaps trial %d" % trial,
              all(merged[i][1] < merged[i + 1][0] for i in range(len(merged) - 1)))
        check("reference sorted trial %d" % trial,
              merged == sorted(merged, key=lambda p: p[0]))


def expect_value_error(label, payload):
    try:
        merge_ranges(payload)
    except ValueError:
        return
    except Exception as exc:  # wrong exception type
        FAILURES.append("%s: raised %s, want ValueError" % (label, type(exc).__name__))
        return
    FAILURES.append("%s: no exception, want ValueError" % label)


def validation():
    expect_value_error("bool start", [[True, 4]])
    expect_value_error("bool end", [[1, False]])
    expect_value_error("both bool", [[True, True]])
    expect_value_error("float start", [[1.5, 4]])
    expect_value_error("float end", [[1, 4.0]])
    expect_value_error("integral float", [[1.0, 4.0]])
    expect_value_error("str start", [["1", 4]])
    expect_value_error("str end", [[1, "4"]])
    expect_value_error("none bound", [[None, 4]])
    expect_value_error("none end", [[1, None]])
    expect_value_error("three element pair", [[1, 2, 3]])
    expect_value_error("one element pair", [[1]])
    expect_value_error("empty pair", [[]])
    expect_value_error("non sequence pair", [7])
    expect_value_error("dict pair", [{"a": 1, "b": 2}])
    expect_value_error("string pair", ["ab"])
    expect_value_error("bytes pair", [b"ab"])
    expect_value_error("nested pair", [[[1, 2], [3, 4]]])
    expect_value_error("start greater than end", [[3, 1]])
    expect_value_error("start greater than end negative", [[-1, -4]])
    expect_value_error("top level string", "ab")
    expect_value_error("top level int", 5)
    expect_value_error("top level none", None)
    expect_value_error("top level dict", {"a": 1})
    expect_value_error("bad pair among good ones", [[1, 2], [True, 3]])

    # start == end is an empty interval, not an error.
    check_eq("empty interval not an error", merge_ranges([[5, 5]]), [])
    check_eq("empty interval among valid ones", merge_ranges([[1, 2], [7, 7]]), [[1, 2]])

    # Rejection happens before any value is returned.
    try:
        merge_ranges([[1, 2], [9, 3]])
    except ValueError:
        pass
    else:
        FAILURES.append("inverted range: no exception")


def main(argv):
    groups = {"semantics": semantics, "validation": validation}
    if len(argv) != 2 or argv[1] not in groups:
        sys.stderr.write("usage: python3 -B test_solution.py {%s}\n"
                         % "|".join(sorted(groups)))
        return 2
    groups[argv[1]]()
    if FAILURES:
        for failure in FAILURES:
            sys.stderr.write("FAIL: %s\n" % failure)
        sys.stderr.write("%d failure(s) in %s\n" % (len(FAILURES), argv[1]))
        return 1
    print("TESTS PASS (%s)" % argv[1])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
