#!/usr/bin/env bash
# goal_gate.sh - the EXTERNAL arbiter of goal-loop. It decides; it never
# writes state. Since v1.2 it also RERUNS the contract's DETERMINISTIC named
# checks itself (inline at --check, standalone via --verify). Those commands
# come from the stamped, smoke-run contract; a tree digest taken before and
# after the rerun fails check-mutated-tree if any check modified the tree.
# Verdicts for judged ACs still come from the checker seats (stored records,
# digest-bound). The gate remains the only authority on "done".
# Usage:
#   bash goal_gate.sh --check  [--project DIR]              # 0 GO / 2 NO-GO / 3 BLOCKED / 4 state error
#   bash goal_gate.sh --digest [--project DIR]              # print tree digest
#   bash goal_gate.sh --verify [--project DIR] [AC-ID ...]  # rerun deterministic checks; 0 all-pass / 2 FAIL-or-broken / 4 state error
#   bash goal_gate.sh --baseline-check [--project DIR]      # forge contracts: baseline.md covers every delta metric AC; 0 ok / 2 problem
#   bash goal_gate.sh --checkpoint [--project DIR]          # qualify an intermediate artifact without a completion claim
set -u
export LC_ALL=C.UTF-8

usage(){ sed -n '2,14p' "$0"; }

project="." mode="" positional=""
_goal_gate_args=("$@")
while [ $# -gt 0 ]; do
  case "$1" in
    --check)  mode=check ;;
    --digest) mode=digest ;;
    --verify) mode=verify ;;
    --baseline-check) mode=baseline ;;
    --checkpoint) mode=checkpoint ;;
    --quality) mode=quality ;;
    --project) [ $# -ge 2 ] || { echo "GATE: NO-GO reason=missing-project-arg" >&2; exit 4; }; project="$2"; shift ;;
    --help|-h) usage; exit 0 ;;
    -*) echo "GATE: NO-GO reason=unknown-flag:$1" >&2; exit 4 ;;
    *) positional="$positional $1" ;;                  # AC-IDs for --verify
  esac
  shift
done

[ -n "$mode" ] || { echo "GATE: NO-GO reason=no-mode (use --check, --digest, --verify, --baseline-check or --checkpoint)" >&2; exit 4; }
[ -z "${positional# }" ] || [ "$mode" = verify ] || { echo "GATE: NO-GO reason=unknown-arg:$positional" >&2; exit 4; }

sd="$project/.goal"
here=$(cd "$(dirname "$0")" && pwd)
if [ "$mode" != digest ] && { [ "${GOAL_ACCESS_EXEC_PID:-}" != "$$" ] || [ -z "${GOAL_GATE_SHELL_EPOCH:-}" ]; }; then
  # Capture before the lock interpreter starts. GNU date has fractional time;
  # BSD date uses the system zsh clock, or the already-required Python. Avoid
  # rounding a three-second settlement down by a whole second. The lock's
  # same-PID exec retains this observation; supervised child re-entry is
  # additionally capped by GOAL_RUNNER_MONOTONIC_END.
  _goal_gate_shell_epoch=$(date +%s.%N) || exit 4
  case "$_goal_gate_shell_epoch" in
    *[!0-9.]*|'')
      if [ -x /bin/zsh ]; then
        _goal_gate_shell_epoch=$(/bin/zsh -fc 'zmodload zsh/datetime; print -r -- $EPOCHREALTIME') || exit 4
      else
        _goal_gate_shell_epoch=$(python3 -I -S -c 'import time; print(time.time())') || exit 4
      fi ;;
  esac
  GOAL_GATE_SHELL_EPOCH=$_goal_gate_shell_epoch
  export GOAL_GATE_SHELL_EPOCH
fi
if [ "$mode" != digest ] && [ -d "$sd" ] && [ "${GOAL_ACCESS_EXEC_PID:-}" != "$$" ]; then
  exec python3 -I "$here/goal_store.py" access-exec "$sd" gate "$here/goal_gate.sh" "${_goal_gate_args[@]}"
fi
# The parent owns the ledger lock throughout measurement. User commands must
# not inherit its descriptor: background grandchildren otherwise retain it
# after the owner dies. Keep owner metadata so nested writes fail closed.
# Every call below is already in a command substitution or explicit subshell.
# Do not add another subshell here: its waiting parent would retain the lock.
drop_check_locks(){
  for check_fd in "${GOAL_ACCESS_FD:-}" "${GOAL_CLOSE_LOCK_FD:-}"; do
    case "$check_fd" in ''|*[!0-9]*) continue ;; esac
    [ "$check_fd" -ge 3 ] || continue
    eval "exec ${check_fd}<&-"
  done
}
check_run(){
  local phase=$1 ac=$2; shift 2
  drop_check_locks
  exec python3 -I "$here/goal_bounded.py" --owner "$$" --seconds "$tmo" --kind measurement \
    --label "$phase:$ac" --artifact "$digest" -- "$@"
}
if [ "$mode" != digest ] && [ -e "$sd/store/pending" ] && [ "${GOAL_ACCESS_MODE:-}" != write ]; then
  echo 'GATE: ERROR reason=recovery-required' >&2
  exit 4
fi
# shellcheck source=goal_parse.sh
. "$here/goal_parse.sh"                            # one grammar, one home (v2.7)
r(){ gp_r; }                                       # CR scrubber for every read
hash_std(){ gp_hash_std; }

# Shared, versioned content identity; failure is never a partial digest.
tree_digest(){ gp_tree_digest "$project"; }

ac_body_hash(){ gp_ac_body_hash "$project"; }       # R3 frozen surface - single definition
state_get(){ gp_state_get "$project" "$1"; }

ledger_digest(){
  # Canonical evidence shares the managed-view capture path. Only the raw
  # stream currently being written by the owning controller is excluded.
  python3 -I "$here/goal_store.py" guard-digest "$sd"
}

last_block(){                                          # last loop-log block as key=value lines
  [ -f "$sd/loop-log.md" ] || return 1
  gawk '
    /^## iteration/{ split($0,a," "); cur=a[3]; order[++c]=cur; next }
    cur!="" { line=$0; sub(/\r$/,"",line)
      if (line ~ /=/) { p=index(line,"="); k=substr(line,1,p-1); v=substr(line,p+1); last[cur,k]=v } }
    END{ if (c==0) exit 5
      id=order[c]; printf "block_iteration=%s\n", id
      for (idx in last) { n=split(idx,parts,SUBSEP); if (n==2 && parts[1]==id) printf "%s=%s\n", parts[2], last[idx] }
    }' "$sd/loop-log.md"
}

latest_verdicts(){                                     # id|verdict|iter|digest|evidence, latest per id
  gp_latest_verdicts "$project"
}

fail(){
  # reason=$1 ; optional hint token routes the controller's next batch
  # (open-FAIL -> fix that AC's domain; not-covered -> dispatch the seat).
  # The hint is mechanical routing, not case knowledge.
  if [ "${deadline_expired:-0}" = 1 ]; then
    blocked "time-budget-exhausted (claim did not pass - stop burning time; extend = user-approved rewrite of deadline= in state.rec)"
  fi
  reason="$1"
  case "$reason" in
    open-FAIL:*)             hint=fix-AC ;;
    not-covered:*)           hint=bind-seat ;;
    check-broken:*)          hint=fix-instrument ;;
    probe-failed:*)          hint=fix-instrument ;;
    score-regressed:*)       hint=restore-best ;;
    not-dry:*)               hint=continue-forge ;;
    missing-strategy-delta*) hint=write-strategy-delta ;;
    verdicts-stale:*)        hint=rebind-judged ;;
    digest-version-mismatch:*) hint=rebind-judged ;;
    verdict-conflict:*)      hint=rebind-judged ;;
    score-missing:*)         hint=objective-not-metric ;;
    judge-score-missing:*)   hint=bind-seat ;;
    not-claimed:*)           hint=set-exit-signal ;;
    not-claimed)             hint=set-exit-signal ;;   # bare reason, no AC suffix
    empty-loop-log)          hint=write-ledger-block ;;
    bad-task:*)              hint=write-ledger-block ;;
    DIVERGENCE:*)            hint=redesign-AC ;;
    contract-tampered:*)     hint=proposal-to-user ;;
    check-script-tampered:*) hint=fix-instrument ;;
    adversarial-missing:*)   hint=run-adversarial ;;
    open-items:*)            hint=close-open-item ;;
    adversarial-finding:*)   hint=fix-adversarial-finding ;;
    raw-evidence-missing:*)  hint=attach-raw ;;
    calibration-missing:*)   hint=bind-calib-grades ;;
    calibration-*)           hint=fix-calib-fixture ;;
    deferred-pending:*)      hint=wait-for-source ;;
    time-budget-exhausted*)  hint=graceful-deliver ;;
    stagnation*|repeated-error*) hint=replan-or-stop ;;
    *)                       hint=see-reason ;;
  esac
  echo "GATE: NO-GO reason=$reason hint=$hint" >&2
  exit 2
}
blocked(){ echo "GATE: BLOCKED reason=$1" >&2; exit 3; }
# time-budget fuse: a wall-clock overrun must not confiscate completed work.
# 1) green claim still delivers (GO + NOTE); 2) any failure after the fuse
# escalates to BLOCKED so the loop stops instead of grinding another wave.
deadline_expired=0
state_err(){ echo "GATE: ERROR reason=$1" >&2; exit 4; }

# ---- contract parsing (v1.2) ----------------------------------------------
# AC line grammar:  - AC-N | statement | check: `<command>` | expected: <spec>
# expected spec: exit=0 (default) | <op><number> | judged      (no "|" inside)
# AC lines are NOT parsed by "|" splitting (commands contain pipes); the
# command is the backtick-quoted span, the expectation is the line tail.
# Contract grammar lives in scripts/goal_parse.sh (v2.7); these wrappers keep
# the call sites readable and every rule defined exactly once.
contract_mode(){ gp_contract_mode "$project"; }
all_ac_ids(){ gp_all_ac_ids "$project"; }
ac_line_for(){ gp_ac_line_for "$project" "$1"; }
ac_check_cmd(){ gp_ac_check_cmd "$project" "$1"; }
ac_expected(){ gp_ac_expected "$project" "$1"; }
ac_baseline_marker(){ gp_ac_baseline_marker "$project" "$1"; }
# Verifier-of-the-verifier (R9): any metric/maximize/minimize AC may carry a probe:
# check that must PASS before its number is trusted.
ac_probe_cmd(){ gp_ac_probe_cmd "$project" "$1"; }
# Optional measurement tokens (v2.5): metric: pins WHERE the number comes from;
# tolerance: gives water-mark compares a noise band.
ac_metric_re(){ gp_ac_metric_re "$project" "$1"; }
ac_tolerance(){ gp_ac_tolerance "$project" "$1"; }
# External/deferred layer (v2.9): external: settles an AC against an
# out-of-tree source; window: = cache validity in seconds (default 3600).
ac_external_cmd(){ gp_ac_external_cmd "$project" "$1"; }
ac_window(){ gp_ac_window "$project" "$1"; }
# Significance layer (v2.9): sd:/var: name WHERE the measurement's dispersion
# comes from, so the water-mark band is computed from data instead of the AC
# author's memory of typical noise (z=2 law in the regression check).
ac_sd_re(){ gp_ac_sd_re "$project" "$1"; }
ac_var_re(){ gp_ac_var_re "$project" "$1"; }
# Calibration fixtures (v2.6, judged ACs): `calib: good=<f1> bad=<f2>` names a
# known-good and a known-bad artifact of the AC's subject. A seat may claim
# PASS only after grading both correctly (#good=PASS, #bad=FAIL, same
# iteration+digest). A too-lenient seat passes the good fixture but fails the
# bad one, and the claim is refused mechanically.
# Backtick spans are command text, not calib declarations: strip them first
# so an AC whose check greps the literal "calib:" is not mistaken for calibrated.
ac_calib_line(){ gp_ac_calib_line "$project" "$1"; }
ac_calib_good(){ gp_ac_calib_good "$project" "$1"; }
ac_calib_bad(){ gp_ac_calib_bad "$project" "$1"; }
ac_calib_declared(){ gp_ac_calib_declared "$project" "$1"; }
sha256_std(){ gp_sha256_std "$1"; }
strip_ansi(){ gp_strip_ansi; }
extract_metric(){ gp_extract_metric "$1" "$2"; }
# Optional contract-level objective: maximize|minimize AC-N  (score-regressed guard).
# objective_dir: "maximize" (higher is better) or "minimize" (lower is better).
objective_ac(){ gp_objective_ac "$project"; }
objective_dir(){ gp_objective_dir "$project"; }
# Baseline validation (forge only): every delta metric AC needs a
# .goal/baseline.md line `AC-N | ... | repeats=<N>=2 | cmd=<check verbatim>`.
# The cmd match is the "same yardstick" rule made mechanical; repeats>=2
# mechanizes the noise-floor discipline. Absent marker -> delta.
baseline_validate(){                                   # fail-fast via fail(); forge paths only
  need=0
  for id in $(all_ac_ids); do
    cls=$(classify_expected "$(ac_expected "$id")")
    case "$cls" in metric*) [ "$(ac_baseline_marker "$id")" = abs ] || need=1 ;; esac
  done
  [ "$need" = 1 ] || return 0                          # no delta metric AC -> no baseline owed
  bl="$sd/baseline.md"
  [ -f "$bl" ] || fail "missing-baseline (forge: run every metric check against the pre-work artifact - the smoke run IS the measurement - and write .goal/baseline.md: AC-id | observed=<v> | repeats=<N>=2 | cmd=<check verbatim>)"
  for id in $(all_ac_ids); do
    cls=$(classify_expected "$(ac_expected "$id")")
    case "$cls" in metric*) : ;; *) continue ;; esac
    [ "$(ac_baseline_marker "$id")" = abs ] && continue
    cmd=$(ac_check_cmd "$id")
    line=$(r < "$bl" | grep -E "^$id \|.*cmd=" | tail -1)
    [ -n "$line" ] || fail "missing-baseline:$id (no baseline row for a delta metric AC)"
    bcmd=$(printf '%s' "$line" | sed -nE 's/^.* cmd=(.*)[[:space:]]*$/\1/p')
    [ "$bcmd" = "$cmd" ] || fail "baseline-cmd-mismatch:$id (baseline must be measured by the AC's own check command, verbatim)"
    rep=$(printf '%s' "$line" | sed -nE 's/^.* repeats=([0-9]+).*$/\1/p')
    { [ -n "$rep" ] && [ "$rep" -ge 2 ]; } || fail "baseline-weak:$id (repeats>=2 required - single runs game the metric)"
  done
}
classify_expected(){ gp_classify_expected "$1"; }       # grammar in goal_parse.sh

run_one_check(){                                       # $1 id $2 class $3 op $4 num -> "id|VERDICT|detail"
  # Both call sites use line=$(run_one_check ...). Drop locks in that outer
  # waiting shell too; the main gate retains ownership until it terminates.
  drop_check_locks
  id="$1"; cls="$2"; m_op="${3:-}"; m_num="${4:-}"
  cmd=$(ac_check_cmd "$id")
  if [ -z "$cmd" ]; then printf '%s|BROKEN|no check command in AC line\n' "$id"; return; fi
  # External layer (v2.9): `external:` is ADDITIVE verification on a
  # deterministic AC - the in-tree check: floor still runs and can still
  # FAIL on its own; the external command settles the AC against an
  # out-of-tree source (CRM query, prod metric, async reviewer verdict).
  # rc 75 (EX_TEMPPOAL) means "not ready yet" -> DEFERRED: neither pass nor
  # fail, the loop waits instead of spinning. `window:` = cache validity:
  # inside it the last recorded verdict IS the measurement; outside it the
  # gate reruns the query. This is what makes a day-to-settle business fact
  # an AC: the loop keeps working, the gate keeps counting, and the query
  # costs one call per window instead of one per gate exit.
  #
  # The cache lives in .goal/evidence/deferred.rec: evidence is exempt from
  # BOTH digests, so a cache write during a rerun batch trips neither
  # check-mutated-tree nor check-mutated-ledger (R6: evidence is where
  # measurement artifacts legitimately live).
  ext_state=""; ext_note=""
  ecmd=$(ac_external_cmd "$id")
  if [ -n "$ecmd" ]; then
    win=$(ac_window "$id"); win=${win:-3600}
    gp_is_natural "$win" || { printf '%s|BROKEN|window must be whole seconds (got: %s)\n' "$id" "$win"; return; }
    rec=$(gp_defer_latest "$project" | gawk -F'|' -v w="$id" '$1==w{print $2"|"$3"|"$4}')
    cv=$(printf '%s' "$rec" | cut -d'|' -f1); ct=$(printf '%s' "$rec" | cut -d'|' -f2)
    now=$(date +%s); ct=${ct:-0}
    if { [ "$cv" = PASS ] || [ "$cv" = FAIL ]; } && [ $(( now - ct )) -le "$win" ]; then
      ext_state="$cv"; ext_note="window=${win}s cached age=$(( now - ct ))s"
    elif [ "$cv" = DEFERRED ] && [ $(( now - ct )) -lt "$win" ]; then
      ext_state=DEFERRED; ext_note="not-ready ${ct:+$(( now - ct ))}s ago (window=${win}s)"
    else
      ec_err=$(mktemp "${TMPDIR:-/tmp}/goal-ecmd-err.XXXXXX" 2>/dev/null) || ec_err=/tmp/ecmd-err.$$
      (cd "$project" 2>/dev/null && check_run external "$id" bash -c "$ecmd" >/dev/null 2>"$ec_err"); ec_rc=$?
      ec_tail=$(r < "$ec_err" | tail -3 | tr '\n' ' ' | sed 's/[[:space:]]*$//' | cut -c1-160)
      rm -f "$ec_err"
      case "$ec_rc" in
        75)        ext_state=DEFERRED; ext_note="source not ready (rc=75), retry after window" ;;
        0)         ext_state=PASS; ext_note="external ok" ;;
        124|127)   ext_state=BROKEN; ext_note="external cmd rc=$ec_rc $ec_tail" ;;
        *)         ext_state=FAIL; ext_note="external rc=$ec_rc $ec_tail" ;;
      esac
      printf '%s|%s|%s|%s\n' "$id" "$ext_state" "$now" "$ext_note" >> "$(gp_defer_path "$project")" \
        || { printf '%s|BROKEN|external receipt write failed\n' "$id"; return; }
    fi
    [ "$ext_state" = FAIL ]   && { printf '%s|FAIL|external (out-of-tree claim): %s\n' "$id" "$ext_note"; return; }
    [ "$ext_state" = BROKEN ] && { printf '%s|BROKEN|external: %s\n' "$id" "$ext_note"; return; }
  fi
  # R9 verifier-of-the-verifier: metric/maximize numbers are untrustworthy
  # unless their probe (instrument alive) passes first.
  line=""
  case "$cls" in metric*|maximize|minimize)
    pcmd=$(ac_probe_cmd "$id")
    if [ -n "$pcmd" ]; then
      perr=$(mktemp "${TMPDIR:-/tmp}/goal-probe-err.XXXXXX" 2>/dev/null) || perr=/tmp/probe-err.$$
      ( cd "$project" 2>/dev/null && check_run probe "$id" bash -c "$pcmd" >/dev/null 2>"$perr" )
      prc=$?
      perr_tail=$(r < "$perr" | tail -2 | tr '\n' ' ' | sed 's/[[:space:]]*$//' | cut -c1-120)
      rm -f "$perr"
      if [ "$prc" -ne 0 ]; then
        printf '%s|BROKEN|probe-failed:rc=%s (measurement untrusted - fix the instrument before the number) %s\n' "$id" "$prc" "$perr_tail"
        return
      fi
    fi ;;
  esac
  # stdout stays the MEASUREMENT channel; stderr is captured to a side file so
  # a failure is never diagnosed by guessing (an eval system that says "failed"
  # with no reason violates fail-loud). Streams stay separated on purpose.
  gate_err=$(mktemp "${TMPDIR:-/tmp}/goal-gate-err.XXXXXX" 2>/dev/null) || gate_err=/tmp/gate-err.$$
  out=$(cd "$project" 2>/dev/null && check_run check "$id" bash -c "$cmd" 2>"$gate_err"); rc=$?
  err_tail=$(r < "$gate_err" | tail -3 | tr '\n' ' ' | sed 's/[[:space:]]*$//' | cut -c1-160)
  rm -f "$gate_err"
  [ -n "$err_tail" ] || err_tail=""
  case "$cls" in
    metric\ *|maximize|minimize)
      [ "$rc" -eq 0 ] || { printf '%s|BROKEN|measurement command did not finish successfully (rc=%s) %s\n' "$id" "$rc" "$err_tail"; return; } ;;
  esac
  out=$(printf '%s\n' "$out" | r)                    # CR scrub: Windows-native checks print CRLF
  metric=$(ac_metric_re "$id")
  clean=$(printf '%s\n' "$out" | strip_ansi)
  if [ -n "$metric" ]; then
    mval=$(extract_metric "$clean" "$metric")
  else
    mval=""
  fi
  # Significance layer (v2.9): sd: carries a stddev capture, var: a variance
  # capture. Both are instruments: declared and matching nothing is BROKEN
  # (same fail-loud law as metric probes), never a silently dropped band.
  sdre=$(ac_sd_re "$id"); varre=$(ac_var_re "$id")
  spread=""
  if [ -n "$sdre" ]; then
    v=$(extract_metric "$clean" "$sdre")
    [ -n "$v" ] || { printf '%s|BROKEN|sd regex matched nothing: %s\n' "$id" "$sdre"; return; }
    spread=$(awk -v s="$v" 'BEGIN{print (s<0)?-s:s}')
  elif [ -n "$varre" ]; then
    v=$(extract_metric "$clean" "$varre")
    [ -n "$v" ] || { printf '%s|BROKEN|var regex matched nothing: %s\n' "$id" "$varre"; return; }
    spread=$(awk -v s="$v" 'BEGIN{s=(s<0)?-s:s; print sqrt(s)}')
  fi
  case "$cls" in
    exit0)
      if [ "$rc" -eq 0 ]; then line="$id|PASS|exit=0"
      elif [ "$rc" -eq 127 ] || [ "$rc" -eq 124 ]; then line="$id|BROKEN|check not executable (rc=$rc) $err_tail"
      elif [ "$rc" -gt 128 ]; then line="$id|BROKEN|check killed (rc=$rc, signal) $err_tail"
      else line="$id|FAIL|exit=$rc $err_tail"; fi ;;
    rc\ *)                                            # negative assertion: rc==N passes
      want=${cls#rc }
      if [ "$rc" -eq "$want" ]; then line="$id|PASS|exit=$rc"
      elif [ "$rc" -eq 124 ] && [ "$want" != 124 ]; then line="$id|BROKEN|timed out (rc=124) $err_tail"
      elif [ "$rc" -eq 127 ] && [ "$want" != 127 ]; then line="$id|BROKEN|check not executable (rc=127) $err_tail"
      else line="$id|FAIL|exit=$rc expect=exit=$want $err_tail"; fi ;;
    metric\ *|maximize|minimize)
      last="$mval"
      if [ -z "$last" ] && [ -n "$metric" ]; then
        printf '%s|BROKEN|metric regex matched nothing: %s %s\n' "$id" "$metric" "$err_tail"; return
      fi
      if [ -z "$last" ]; then
        last=$(printf '%s\n' "$clean" | grep -vE '^[[:space:]]*$' | tail -1)
      fi
      if ! [[ "$last" =~ ^-?([0-9]+(\.[0-9]*)?|\.[0-9]+)$ ]]; then
        printf '%s|BROKEN|no number in output: %s %s\n' "$id" "${last:-<empty>}" "$err_tail"; return
      fi
      # The raw decimal may omit a leading or trailing zero. Keep the
      # persisted score in the same grammar as scores.rec and CLI scores.
      case "$last" in
        .*) last="0$last" ;;
        -.*) last="-0${last#-}" ;;
        *.) last="${last%.}" ;;
      esac
      if [ "$cls" = maximize ] || [ "$cls" = minimize ]; then
        line="$id|PASS|observed=$last${spread:+ spread=$spread} expect=$cls"
      else
        v=$(awk -v a="$last" -v b="$m_num" -v o="$m_op" \
            'BEGIN{ok=(o==">=")?(a>=b):(o=="<=")?(a<=b):(o==">")?(a>b):(o=="<")?(a<b):(o=="==")?(a==b):(a!=b); print ok?"PASS":"FAIL"}')
        line="$id|$v|observed=$last expect=$m_op$m_num"
      fi
      ;;
    *)
      printf '%s|BROKEN|unroutable expectation class\n' "$id"; return ;;
  esac
  # Merge with the external layer (v2.9). Out-of-tree FAIL/BROKEN already
  # returned. What is left: an in-tree FAIL/BROKEN stays decisive (the floor
  # is not masked by "something is still pending"), and DEFERRED means
  # "everything in-tree settled, one business fact is still pending" - the
  # loop waits for it, that is not a failure and not a delivery.
  if [ "$ext_state" = DEFERRED ]; then
    bv=$(printf '%s' "$line" | cut -d'|' -f2)
    [ "$bv" = PASS ] && line="$id|DEFERRED|in-tree settled, awaiting external: $ext_note"
  fi
  printf '%s\n' "$line"
}

# -0. state present and complete -----------------------------------------
# Fail BEFORE tree_digest: walking an accidental cwd (e.g. $HOME) to learn
# "no goal here" is the wrong cost shape -- and --check with no ledger must
# stay instant. --digest still works with no .goal (it is a pure tree hash).
if [ "$mode" != digest ]; then
  [ -d "$sd" ] || state_err "no-goal-dir"
  [ -f "$sd/goal.md" ] || state_err "no-goal-md"
  GOAL_TRACE_PROJECT=$(cd "$project" && pwd) || state_err invalid-project
  export GOAL_TRACE_PROJECT
  # Establish one envelope before hashing/preparation, not a fresh timeout
  # per AC. An inherited envelope also caps a nested gate's final settlement.
  gate_budget=$(python3 -I "$here/goal_runner.py" gate-limit "$sd") || state_err budget-unavailable
  read -r gate_cap deadline_expired <<< "$gate_budget"
  if { [ "$mode" = checkpoint ] || [ "$mode" = quality ]; } && [ "$deadline_expired" = 1 ]; then
    blocked time-budget-exhausted
  fi
  if [ "$gate_cap" != none ]; then
    export GOAL_RUNNER_MONOTONIC_END="$gate_cap"
  fi
  if [ "${GOAL_GATE_SUPERVISED:-}" != 1 ]; then
      # Retain access descriptors with the supervisor; its child acquires a
      # validated borrowed context. Fresh access clears ambient bypass markers.
      gate_kind=verification; [ "$mode" != check ] || gate_kind=acceptance
      GOAL_GATE_SUPERVISED=1 python3 -I "$here/goal_bounded.py" --owner "$$" \
        --kind "$gate_kind" --label "$mode" -- bash "$here/goal_gate.sh" "${_goal_gate_args[@]}"; gate_rc=$?
      if [ "$gate_rc" -eq 124 ]; then
        if [ "$mode" = check ] || [ "$mode" = checkpoint ] || [ "$mode" = quality ]; then blocked time-budget-exhausted; fi
        echo 'GATE: NO-GO reason=verification-time-budget-exhausted' >&2; exit 2
      fi
      exit "$gate_rc"
  fi
fi

digest=$(tree_digest) || state_err "unreadable-project"
# ledger state before the rerun batch (the tree guard is blind to .goal/)
ld_check0=none
if [ -d "$sd" ] && [ "$mode" != digest ]; then ld_check0=$(ledger_digest) || state_err unreadable-ledger; fi
if [ "$mode" = digest ]; then echo "$digest"; exit 0; fi

[ -f "$sd/goal.md" ] || state_err "no-goal-md"
tmo=$(state_get check_timeout); [ -n "$tmo" ] || tmo=120
gp_is_natural "$tmo" || state_err "bad-check-timeout:$tmo"

if [ "$mode" = verify ]; then
  # an AC id that is not in the contract is a usage error, not a verdict -
  # silently "skipping" a typo'd id would let --verify AC-9 report all-clear
  # while the real ACs were never measured.
  for rid in $positional; do
    printf '%s\n' "$(all_ac_ids)" | grep -qx "$rid" \
      || { echo "GATE: NO-GO reason=unknown-ac-id:$rid (no such AC in the contract)" >&2; exit 4; }
  done
  want="$positional "
  d0="$digest"; ld0=$(ledger_digest) || state_err unreadable-ledger
  nfail=0; nbroken=0; nchecked=0; npending=0
  for id in $(all_ac_ids); do
    if [ -n "${want// /}" ]; then case "$want" in *" $id "*) ;; *) continue ;; esac; fi
    cls=$(classify_expected "$(ac_expected "$id")")
    if [ "$cls" = judged ]; then echo "GATE: VERIFY $id|SKIP|judged"; continue; fi
    line=$(run_one_check "$id" "$cls" ${cls#metric})
    echo "GATE: VERIFY $line"
    nchecked=$((nchecked+1))
    case "$line" in
      *'|FAIL|'*)    nfail=$((nfail+1)) ;;
      *'|BROKEN|'*)  nbroken=$((nbroken+1)) ;;
      *'|DEFERRED|'*) npending=$((npending+1)) ;;
    esac
  done
  d1=$(tree_digest)
  [ "$d0" = "$d1" ] || { echo "GATE: NO-GO reason=check-mutated-tree:before=$d0 after=$d1" >&2; exit 2; }
  # the ledger is digest-excluded from the tree, so a check editing goal.md /
  # state.rec / verdicts.rec mid-rerun is invisible to the tree guard: same
  # before/after rule, over the LEDGER state files (evidence/ stays free).
  ld1=$(ledger_digest) || state_err unreadable-ledger
  [ "$ld0" = "$ld1" ] || { echo "GATE: NO-GO reason=check-mutated-ledger:before=$ld0 after=$ld1 (a check wrote the ledger mid-run - only .goal/evidence/ is fair game)" >&2; exit 2; }
  [ "$nchecked" -gt 0 ] || { echo "GATE: VERIFY-OK nothing-deterministic"; exit 0; }
  if [ $((nfail+nbroken)) -eq 0 ]; then
    # DEFERRED rows are surfaced even on an otherwise-clean verify: --verify
    # answers "is every measurement green?" and a pending out-of-tree fact is
    # NOT green - the controller needs the line or it will re-query blind.
    if [ "$npending" -gt 0 ]; then
      echo "GATE: VERIFY-OK checked=$nchecked pending=$npending (external sources not settled - claim is NOT ready)"
      exit 0
    fi
    echo "GATE: VERIFY-OK checked=$nchecked"; exit 0
  fi
  echo "GATE: NO-GO reason=verify-failures:fail=$nfail broken=$nbroken" >&2
  exit 2
fi

if [ "$mode" = baseline ]; then
  # stamp-time validation: contract + baseline.md only; no state needed
  contract_mode=$(contract_mode)
  if [ "$contract_mode" != forge ]; then echo "GATE: BASELINE-OK not-forge"; exit 0; fi
  baseline_validate
  echo "GATE: BASELINE-OK"
  exit 0
fi

required="iteration breaker false_completes replans no_progress_streak max_iterations no_progress_limit"
for k in $required; do
  [ -n "$(state_get "$k")" ] || state_err "missing-key:$k"
done
exit_mode=$(contract_mode)
if [ "$exit_mode" = forge ]; then
  for k in dry_streak dry_limit; do
    [ -n "$(state_get "$k")" ] || state_err "missing-key:$k (required for exit: forge)"
  done
fi
iter=$(state_get iteration); breaker=$(state_get breaker)
fc=$(state_get false_completes); streak=$(state_get no_progress_streak)
maxit=$(state_get max_iterations); npl=$(state_get no_progress_limit)
# the numeric counters must actually be numbers (a corrupted or hand-edited
# state.rec with iteration=banana must never reach an arithmetic comparison);
# breaker is the only word-valued key in this set.
for k in iteration false_completes no_progress_streak max_iterations no_progress_limit replans; do
  gp_is_natural "$(state_get "$k")" || state_err "unparseable-state:$k=$(state_get "$k") (numeric key not numeric)"
done
case "$breaker" in CLOSED|HALF_OPEN|OPEN) : ;; *) state_err "unparseable-state:breaker=$breaker" ;; esac

# -1. contract frozen by a matching stamp (R3) ----------------------------
stamp=$(r < "$sd/goal.md" | grep -E '^approved: [0-9a-f]{6,}' | tail -1 | awk '{print $2}')
[ -n "$stamp" ] || fail "no-approval"
body=$(ac_body_hash)
[ "${stamp:0:8}" = "$body" ] || fail "contract-tampered:stam=$stamp recomputed=$body"

# -1b. dual-encode: check/probe script bodies are frozen at stamp. goal.md
# alone cannot pin a bash check.sh - swapping the script after stamp was a
# silent metric edit (R3 spirit on the instrument body, not just the AC line).
freeze_now=""
if [ -f "$sd/goal.md" ]; then
  freeze_now=$(
    {
      r < "$sd/goal.md" | sed -nE 's/.*check: *`([^`]*)`.*/\1/p'
      r < "$sd/goal.md" | sed -nE 's/.*probe: *`([^`]*)`.*/\1/p'
    } | tr ' \t' '\n\n' | grep -E '\.(sh|py|rb|js)$' | sort -u | while IFS= read -r scr; do
      [ -n "$scr" ] || continue
      f="$project/$scr"
      [ "${scr#/}" != "$scr" ] && f="$scr"
      [ -f "$f" ] || continue
      h=$(gp_hash_std < "$f" | cut -c1-8)
      printf '%s=%s;' "$scr" "$h"
    done
  )
fi
freeze_st=""
[ -f "$sd/check_freeze" ] && freeze_st=$(r < "$sd/check_freeze")
if [ "$exit_mode" = forge ]; then
  forge_freeze=$(python3 -I "$here/goal_forge.py" freeze --project "$project") || fail "forge-plan-invalid:see probe scope"
  freeze_now="$freeze_now$forge_freeze"
fi
norm_freeze(){ printf '%s' "$1" | tr ';' '\n' | sed '/^$/d' | sort | tr '\n' ';'; }
if [ "$(norm_freeze "$freeze_now")" != "$(norm_freeze "$freeze_st")" ]; then
  fail "check-script-tampered:stamped=$(norm_freeze "$freeze_st") now=$(norm_freeze "$freeze_now")"
fi

# -2..-4b. breaker, budget (forge: fuse), stagnation, grind ---------------
[ "$breaker" = OPEN ] && blocked "breaker-open"
[ "${fc:-0}" -ge 2 ] && blocked "false-completes>=2"
dl=$(state_get deadline)                               # optional wall-clock fuse (v1.3)
case "$dl" in
  ''|0) : ;;
  *) gp_is_natural "$dl" || state_err "bad-deadline:$dl"
     now=$(date +%s)
     # Overrun is a CONTINUATION fuse, not a delivery veto: flag it here;
     # fail() escalates to BLOCKED, a green claim still GO (see fail/GO).
     [ "$now" -gt "$dl" ] && deadline_expired=1 ;;
esac
if { [ "$mode" = checkpoint ] || [ "$mode" = quality ]; } && [ "${deadline_expired:-0}" = 1 ]; then
  blocked time-budget-exhausted
fi
if [ "$exit_mode" = forge ]; then
  [ "${iter:-0}" -le "${maxit:-12}" ] || blocked "budget-fuse:iter=$iter max=$maxit (forge: budget is a fuse - extend it or deliver best-so-far)"
  baseline_validate                                   # belt+braces: baseline.md must still cover every delta metric AC
else
  [ "${iter:-0}" -le "${maxit:-12}" ] || fail "budget-exhausted:iter=$iter max=$maxit"
fi
[ "${streak:-0}" -le "${npl:-2}" ] || blocked "stagnation:streak=$streak limit=$npl"

# -4b. repeated-error grind (SKILL.md phase 2 step 8, mechanized): the last
# two loop blocks carrying the SAME non-none error_signature means the loop
# is grinding on one wall -> BLOCKED, hand back. none/empty never triggers.
sigs=$(awk '
  /^## iteration/ { if (cur != "") prev = cursig; cur = $3; cursig = ""; next }
  cur != "" { line = $0; sub(/\r$/, "", line)
              if (line ~ /^error_signature=/) { p = index(line, "="); cursig = substr(line, p + 1) } }
  END { print prev; print cursig }' "$sd/loop-log.md" 2>/dev/null)
sig_a=$(printf '%s\n' "$sigs" | sed -n '1p')
sig_b=$(printf '%s\n' "$sigs" | sed -n '2p')
if [ -n "$sig_a" ] && [ -n "$sig_b" ] && [ "$sig_a" = "$sig_b" ] && [ "$sig_b" != "none" ]; then
  blocked "repeated-error:sig=$sig_b"
fi

# -5..-9. dual condition on the last loop block + verdicts (R1,R5,R7) ----
lb=$(last_block) || fail "empty-loop-log"
# Canonical loop-log key set (schema doc: references/gate.md section 1).
# last_block() consumes key=value lines generically, so the set is declared
# here: it keeps parser and schema doc mutually named and advisory-checks
# presence (exit codes unchanged; exit_signal and digest stay hard-checked).
loop_keys="task files_modified checks_pass checks_fail checks_unverifiable error_signature progress exit_signal false_complete digest score strategy_delta"
missing_lk=""
for k in $loop_keys; do
  printf '%s\n' "$lb" | grep -qE "^$k=" || missing_lk="$missing_lk $k"
done
[ -z "$missing_lk" ] || echo "GATE: NOTE loop-log-missing-keys:${missing_lk# }" >&2
claim=$(printf '%s\n' "$lb" | grep -E '^exit_signal=' | tail -1 | cut -d= -f2-)
[ "$claim" = yes ] || [ "$mode" = checkpoint ] || [ "$mode" = quality ] || fail "not-claimed"
# (5c/5d two-pass + raw run immediately before GO - after mechanical ACs)
# R12 tooth at the arbiter (v2.7): the CLAIMING block must carry a schema-valid
# task= id. ctl enforces this at write time, but a hand-written ledger block
# (the documented rescue path) could smuggle an id past the audit. History
# blocks stay readable for v1.x-compatible ledgers - only what claims done
# is held to the law.
lbt=$(printf '%s\n' "$lb" | grep -E '^task=' | tail -1 | cut -d= -f2-)
if ! gp_task_ok "$lbt"; then
  # bare T<n> is a v1.x ledger form: valid but noted (ctl normalizes it at write).
  printf '%s' "$lbt" | grep -qE '^T[0-9]+$' \
    || fail "bad-task:$lbt (claiming block needs task=T<n>[crew:N]; see R12)"
  echo "GATE: NOTE task-id-legacy (bare $lbt: wave backend not stated; write it as T<n>[crew:1])" >&2
fi
lbdigest=$(printf '%s\n' "$lb" | grep -E '^digest=' | tail -1 | cut -d= -f2-)
# Old worktree identities cannot be compared with v2. Migration requires fresh
# bookkeeping and judging, but is not evidence that the controller lied.
if [[ "$digest" == v2-* ]] && printf '%s' "$lbdigest" | grep -qE '^[0-9a-f]{1,12}$'; then
  fail "digest-version-mismatch:block (close a fresh iteration and rebind judged evidence)"
fi
# A stale claim IS a false complete; the ratchet (ctl close-iteration) counts
# it automatically - no manual bookkeeping asked of the controller anymore.
[ "$lbdigest" = "$digest" ] || { echo "GATE: NOTE false-complete suspected; already counted by the ratchet - fix the artifact and let the claim pass, do not re-claim unchanged" >&2; fail "verdicts-stale:block=$lbdigest current=$digest"; }

ac_ids=$(all_ac_ids)
[ -n "$ac_ids" ] || fail "contract-empty:no AC ids"
# a duplicated AC id is never silently resolved (the parser would pick one of
# the two lines by luck): same id twice = malformed contract.
dups=$(r < "$sd/goal.md" | grep -oE '^- AC-[0-9]+' | sort | uniq -d)
[ -z "$dups" ] || fail "contract-malformed:duplicate AC id(s): ${dups#- } (one line per AC id)"
# fail-closed contract sanity: an AC line whose expected:/check: tokens are
# missing (typo'd or half-written) must never silently default to exit=0 and
# get a free PASS - a silent hole in the eval surface is the worst defect class.
for id in $ac_ids; do
  [ -n "$(ac_expected "$id")" ] || fail "contract-malformed:$id (no expected: token - write expected: exit=0|<op><num>|maximize|minimize|judged)"
  [ -n "$(ac_check_cmd "$id")" ] || fail "contract-malformed:$id (no check: \`command\` - every AC needs a failable named check)"
done
lv=$(latest_verdicts)
total=0; passn=0; unv=0
observed_score=""
observed_spread=""
primary=$(objective_ac)
for id in $ac_ids; do
  cls=$(classify_expected "$(ac_expected "$id")")
  if [ "$cls" != judged ]; then
    # Deterministic AC: the gate reruns the check NOW. Stored verdicts for
    # these ids are mid-loop bookkeeping only; the rerun is the evidence.
    line=$(run_one_check "$id" "$cls" ${cls#metric})
    v=$(printf '%s' "$line" | cut -d'|' -f2)
    detail=$(printf '%s' "$line" | cut -d'|' -f3-)
    case "$v" in
      PASS)   total=$((total+1)); passn=$((passn+1))
              if [ "$id" = "$primary" ]; then
                observed_score=$(printf '%s' "$detail" | sed -nE 's/.*observed=([0-9.\-]+).*$/\1/p' | tail -1)
                observed_spread=$(printf '%s' "$detail" | sed -nE 's/.*spread=([0-9.]+).*$/\1/p' | tail -1)
              fi ;;
      DEFERRED)
              # An external fact is still pending. The loop must not deliver
              # (not-claimable) but the wait is not a failure: no false-
              # complete pressure, no breaker push - a distinct NO-GO reason
              # routes the controller to WAIT, not to dispatch another wave.
              fail "deferred-pending:$id ($detail)" ;;
      FAIL)   fail "open-FAIL:$id (gate rerun: $detail)" ;;
      BROKEN) fail "check-broken:$id ($detail)" ;;
      *)      fail "check-unknown:$id ($line)" ;;
    esac
    continue
  fi
  # Judged AC: the stored seat verdict must be fresh (R7) and evidenced (R5).
  # Contradiction gate (v2.7): two seat rows bound to the SAME (iter,digest)
  # that disagree mean the judge plane contradicts itself on unchanged tree
  # state (R2 makes re-judging illegal here) - mechanically a conflict.
  [ "$(gp_verdict_conflict "$project" "$id" "$iter" "$digest")" = yes ] \
    && fail "verdict-conflict:$id (two verdicts bound to iter=$iter digest=$digest disagree - resolve the seats and rebind)"
  rec=$(printf '%s\n' "$lv" | gawk -F'|' -v want="$id" '$1==want{print}')
  v=$(printf '%s' "$rec" | cut -d'|' -f2)
  vi=$(printf '%s' "$rec" | cut -d'|' -f3)
  vd=$(printf '%s' "$rec" | cut -d'|' -f4)
  ev=$(printf '%s' "$rec" | cut -d'|' -f5-)
  [ -n "$v" ] || fail "not-covered:$id"
  if [[ "$digest" == v2-* ]] && printf '%s' "$vd" | grep -qE '^[0-9a-f]{1,12}$'; then
    fail "digest-version-mismatch:$id (rebind judged evidence against current content)"
  fi
  [ "$vi" = "$iter" ] && [ "$vd" = "$digest" ] || fail "not-covered:$id (verdict bound to iter=$vi digest=$vd)"
  [ "$v" != FAIL ] || fail "open-FAIL:$id"
  total=$((total+1))
  if [ "$v" = PASS ]; then
    [ -n "$ev" ] || fail "evidence-missing:$id"
    # Mechanical binding (v2.5): the evidence must cite the exact artifact it
    # saw - `artifact: <path>` and `digest: <sha256-hex>`. The gate recomputes
    # and compares. A verdict that does not name what it examined, or names a
    # file whose bytes changed since, is worthless: verdict-unbound.
    # greedy match to the digest: token - artifact paths with spaces are
    # legal file names; stopping at whitespace silently loses the path.
    art=$(gp_ev_artifact "$ev"); dig=$(gp_ev_digest "$ev")
    [ -n "$art" ] && [ -n "$dig" ] || fail "verdict-unbound:$id (PASS evidence must cite artifact: <path> and digest: <sha256> - the seat must say WHAT it judged)"
    if [ -f "$project/$art" ]; then
      now=$(sha256_std "$project/$art")
      case "$now" in "$dig"*) : ;; *) fail "verdict-unbound:$id (artifact $art changed since the verdict - digest mismatch)" ;; esac
    else
      fail "verdict-unbound:$id (artifact file $art not found)"
    fi
    # Calibration gate (v2.6, R9 applied to the judgment plane): if the AC
    # declared fixtures, the seat owed correct grades on both. A declared
    # fixture that never exists is a BROKEN instrument (fail-loud), never a
    # silent exemption - same fail-closed rule as metric probes.
    cg=$(ac_calib_good "$id"); cb=$(ac_calib_bad "$id")
    if [ -n "$cg" ] || [ -n "$cb" ]; then
      [ -n "$cg" ] && [ -n "$cb" ] || fail "calibration-malformed:$id (calib: needs BOTH good= and bad= fixtures)"
      [ -f "$project/$cg" ] || fail "calibration-broken:$id (good fixture $cg not found - instrument, not artifact)"
      [ -f "$project/$cb" ] || fail "calibration-broken:$id (bad fixture $cb not found - instrument, not artifact)"
      # fixtures are TREE state: their bytes must match the binding - reuse
      # the same verdict-unbound machinery per fixture via the ledger rule.
      g_rec=$(printf '%s\n' "$lv" | gawk -F'|' -v want="$id#good" '$1==want{print}')
      b_rec=$(printf '%s\n' "$lv" | gawk -F'|' -v want="$id#bad"  '$1==want{print}')
      gv=$(printf '%s' "$g_rec" | cut -d'|' -f2); gvi=$(printf '%s' "$g_rec" | cut -d'|' -f3); gvd=$(printf '%s' "$g_rec" | cut -d'|' -f4)
      bv=$(printf '%s' "$b_rec" | cut -d'|' -f2); bvi=$(printf '%s' "$b_rec" | cut -d'|' -f3); bvd=$(printf '%s' "$b_rec" | cut -d'|' -f4)
      # Evidence must name the fixture the grade was read from (R5 spirit):
      # an unbound grade is an invented grade, same as an unbound PASS.
      # v2.7 strengthening - EXCLUSIVE citation: the good row quotes cg and
      # never cb (and vice versa). A single blob quoting both fixture paths
      # used to satisfy both rows at once; exclusivity forces the seat to
      # say which artifact each grade actually saw.
      gve=$(printf '%s' "$g_rec" | cut -d'|' -f5-)
      bve=$(printf '%s' "$b_rec" | cut -d'|' -f5-)
      { [ "$gv" = PASS ] && [ "$gvi" = "$iter" ] && [ "$gvd" = "$digest" ] \
        && printf '%s' "$gve" | grep -qF "$cg" && ! printf '%s' "$gve" | grep -qF "$cb"; } \
        || fail "calibration-missing:$id/good (needs a fresh PASS verdict this iteration whose evidence quotes ONLY the good fixture $cg)"
      { [ "$bv" = FAIL ] && [ "$bvi" = "$iter" ] && [ "$bvd" = "$digest" ] \
        && printf '%s' "$bve" | grep -qF "$cb" && ! printf '%s' "$bve" | grep -qF "$cg"; } \
        || fail "calibration-missing:$id/bad (known-bad fixture $cb needs a fresh FAIL verdict in the current iteration quoting ONLY $cb - a seat that cannot reject the bad case cannot be trusted on the real one)"
    fi
    # Judge-score duty at the arbiter (v2.7): R13's divergence guard is only
    # alive while numeric judge scores are recorded. The moment a ledger
    # records ANY comparable judge score (field 3 numeric at or before this
    # iteration), a judged PASS claimed with judge=none on the same row is a
    # seat saying "done" without its score - refuse it. A ledger that has
    # never used the judge plane (v1.x / quickstart) is exempt but carries a
    # NOTE; exemption is ledger state, not amnesia.
    if [ -f "$sd/scores.rec" ]; then
      ever=$(r < "$sd/scores.rec" | gawk -F'|' -v it="$iter" '
        $3 ~ /^-?[0-9]+(\.[0-9]+)?$/ && $1+0 <= it+0 {c++} END{print c+0}')
      crow=$(r < "$sd/scores.rec" | gawk -F'|' -v it="$iter" '$1+0==it+0{row=$0} END{print row}')
      cjs=$(printf '%s' "$crow" | cut -d'|' -f3)
      if printf '%s' "$cjs" | grep -qE '^-?[0-9]+(\.[0-9]+)?$'; then
        : # this claim carries its score - R13 is alive, nothing owed
      elif [ "$ever" -gt 0 ]; then
        fail "judge-score-missing:$id (the ledger records numeric judge scores but this claim row is judge=none - close-iteration --judge-score N is mandatory when claiming a judged AC; R13 depends on it)"
      else
        echo "GATE: NOTE judge-score-unrecorded ($id claimed without a numeric judge score; R13 stays inert - record --judge-score N to activate the divergence guard)" >&2
      fi
    fi
    passn=$((passn+1))
  elif [ "$v" = UNVERIFIABLE ]; then
    case "$ev" in *PROBE=*REASON=*) ;; *) fail "evidence-missing:$id (PROBE/REASON required)" ;; esac
    unv=$((unv+1))
  else
    fail "bad-verdict:$id=$v"
  fi
done
[ $((unv*3)) -le "$total" ] || fail "unverifiable-excessive:unv=$unv total=$total"
if { [ "$mode" = checkpoint ] || [ "$mode" = quality ]; } && [ "$unv" -gt 0 ]; then
  fail "checkpoint-unverifiable:unv=$unv"
fi

# -10. guard against checks that mutated the tree mid-verification --------
digest2=$(tree_digest)
[ "$digest" = "$digest2" ] || fail "check-mutated-tree:before=$digest after=$digest2"
# .goal is digest-excluded from the tree, so the tree guard is blind there:
# a check editing goal.md/state.rec/verdicts.rec mid-run would measure one
# state and report another while leaving the tree pristine. The ledger gets
# its own before/after digest; evidence/ is the only directory checks may
# write (R6), so it stays out of the hash.
ld2=$(ledger_digest) || state_err unreadable-ledger
[ "$ld_check0" = "$ld2" ] || fail "check-mutated-ledger:before=$ld_check0 after=$ld2 (a check wrote the ledger mid-run - only .goal/evidence/ is fair game)"

# -11. forge: floors alone are not an exit; exhaustion is -----------------
if [ "$exit_mode" = forge ] && [ "$mode" != checkpoint ] && [ "$mode" != quality ]; then
  dry=$(state_get dry_streak); dl=$(state_get dry_limit)
  [ "${dry:-0}" -ge "${dl:-3}" ] || fail "not-dry:dry_streak=${dry:-0} limit=$dl (forge exits on verification exhaustion, not on floors alone)"
fi

# -12. strategy-delta duty (R10): landing on HALF_OPEN without a recorded
# strategy change is make-work; refuse the claim until one is written.
if [ "$breaker" = HALF_OPEN ]; then
  sdelt=$(printf '%s\n' "$lb" | grep -E '^strategy_delta=' | tail -1 | cut -d= -f2-)
  case "$sdelt" in
    ''|none) fail "missing-strategy-delta (breaker=HALF_OPEN requires strategy_delta= <what you are changing>)" ;;
  esac
fi

# -13. optimize objective: never deliver a score worse than the best seen (R11).
# direction: maximize = high-water mark (current >= best);
#            minimize = low-water mark  (current <= best).
if [ -n "$primary" ]; then
  [ -n "$observed_score" ] || fail "score-missing:$primary (objective score needs a numeric observed score)"
  best=$(state_get best_score)
  basis=$(python3 -I "$here/goal_store.py" watermark-basis "$sd") || state_err watermark-basis-unavailable
  if [ "$(state_get best_score_basis)" != "$basis" ]; then
    case "$best" in ''|none) : ;; *) echo "GATE: NOTE legacy-watermark-unqualified:value=$best" >&2 ;; esac
    best=none
  fi
  pdir=$(objective_dir); [ -n "$pdir" ] || pdir=maximize
  # Relative tolerance absorbs benchmark noise (same code varies +-5% across
  # runs; an exact water-mark would false-alarm "regressed" every round and
  # teach the controller to distrust the metric). Inside the noise band the
  # score is treated as holding, not moving.
  tol=$(ac_tolerance "$primary"); case "$tol" in ''|*[!0-9.]*) tol=0 ;; esac
  # Significance band (v2.9): with sd:/var: declared, the band is z*spread
  # (z=2) or the declared tolerance, whichever is WIDER. The data says what
  # noise this measurement carries; the author may still floor it. Without a
  # spread declaration the band is exactly the v2.5 tolerance law.
  if [ -n "$observed_spread" ]; then
    band=$(awk -v s="$observed_spread" -v t="$tol" -v b="${best:-1}" \
           'BEGIN{a=(b<0)?-b:b; if(a<1)a=1; print (2*s/a>t)?(2*s/a):t}')
    src="band=z2*spread=$observed_spread"
  else
    band="$tol"; src="tol=$tol"
  fi
  if [ "$mode" != quality ] && [ -n "$best" ] && [ "$best" != "none" ]; then
    # Noise band = b +/- |b|*t. Multiplying (1-t)*b flips the band on
    # NEGATIVE water marks (b=-10,t=.1 -> band -9, so -10 reads "regressed");
    # absolute value keeps the band on the correct side in every sign.
    if [ "$pdir" = minimize ]; then
      awk -v c="$observed_score" -v b="$best" -v t="$band" 'BEGIN{a=(b<0)?-b:b; exit !(c+0 <= b+0 + a*t)}' \
        || fail "score-regressed:current=$observed_score best=$best dir=minimize $src (restore the best-scoring state or do not claim)"
    else
      awk -v c="$observed_score" -v b="$best" -v t="$band" 'BEGIN{a=(b<0)?-b:b; exit !(c+0 >= b+0 - a*t)}' \
        || fail "score-regressed:current=$observed_score best=$best dir=maximize $src (restore the best-scoring state or do not claim)"
    fi
  fi
fi

# -14. score<->judge divergence (R13): the objective may improve while the
# cold seat falls - that is optimizing the wrong thing. Objective contracts
# compare against the latest qualified pair; raw failed attempts cannot
# contaminate recovery. Legacy non-objective records retain the raw-pair rule.
# Quality direction: maximize -> higher score is better; minimize -> lower
# score is better. Judge score is always higher-is-better. Opposite quality
# directions -> refuse the claim. Flat is "unverified movement", not
# divergence; <2 comparable points -> skip (no pair to compare).
if [ -f "$sd/scores.rec" ]; then
  rdir=$(objective_dir); [ -n "$rdir" ] || rdir=maximize
  pair=$(r < "$sd/scores.rec" | awk -F'|' '
    $2 ~ /^-?[0-9]+(\.[0-9]+)?$/ && $3 ~ /^-?[0-9]+(\.[0-9]+)?$/ {
      s1=s2; j1=j2; s2=$2+0; j2=$3+0; n++
    }
    END { if (n >= 2) printf "%s %s %s %s\n", s1, j1, s2, j2 }')
  # Objective comparisons use the latest qualified pair. Failed attempts remain
  # visible in scores.rec but cannot make a valid rollback look divergent.
  if [ -n "$primary" ]; then
    pair=""
    qs=$(state_get last_quality_score)
    bj=$(state_get last_quality_judge)
    cj=$(r < "$sd/scores.rec" | awk -F'|' -v i="$iter" '$1==i {j=$3} END{print j}')
    [ "$(state_get best_score_basis)" = "$basis" ] || qs=none
    if printf '%s\n' "${qs:-none}" "${bj:-none}" "${cj:-none}" | awk '
      $0 !~ /^-?[0-9]+(\.[0-9]+)?$/ {bad=1} END{exit bad}'; then
      pair="$qs $bj $observed_score $cj"
    fi
  fi
  if [ -n "$pair" ]; then
    set -- $pair
    awk -v s1="$1" -v j1="$2" -v s2="$3" -v j2="$4" -v d="$rdir" \
      'BEGIN{
        sd = (d=="minimize") ? (s1-s2) : (s2-s1);   # quality delta of score
        jd = j2-j1;                                  # quality delta of judge
        exit !(sd*jd < 0)
      }' \
      && fail "DIVERGENCE:score-vs-judge score:$1->$3 judge:$2->$4 dir=$rdir (objective and cold-seat moving apart - the metric is pulling away from perceived quality; redesign the AC or the direction)"
  fi
fi

if [ "$mode" = quality ]; then
  [ -n "$primary" ] && [ -n "$observed_score" ] || fail "quality-objective-required"
  [ "${deadline_expired:-0}" != 1 ] || blocked time-budget-exhausted
  echo "GATE: QUALITY-OK digest=$digest iter=$iter score=$observed_score"
  exit 0
fi

if [ "${deadline_expired:-0}" = 1 ]; then
  echo "GATE: NOTE time-budget-exhausted (graceful delivery of passing work)"
fi
# Eval self-hardening notes (v2.5, advisory only - never block a GO).
# 1) Static tautology suspects: deterministic checks whose command cannot fail
#    (bare true/echo/cat) would pass every round and make the gate decorative.
#    judged ACs are exempt (their check generates evidence, the seats judge).
taut=""
for id in $ac_ids; do
  cls=$(classify_expected "$(ac_expected "$id")")
  [ "$cls" = judged ] && continue
  cmd=$(ac_check_cmd "$id")
  # cannot-fail shapes only: bare true/:/echo with no pipes, no test, no
  # redirects (cat/echo file can fail - missing artifact is a real outcome).
  if printf '%s' "$cmd" | grep -qE '^(true|:|:)[[:space:]]*$' ||
     printf '%s' "$cmd" | grep -qE '^echo [^|<>]*$'; then
    taut="$taut $id"
  fi
done
[ -z "$taut" ] || echo "GATE: NOTE tautology-suspect:${taut# } (check cannot fail across rounds - strengthen it or the gate is decorative)" >&2
# 2) Metric-flat: the objective score has sat at the water-mark for >=3
#    rounds - a ceiling metric with delta-style ambitions is unreachable and
#    the loop grinds. (Same code, same number: flat is not regressed.)
if [ -n "$primary" ] && [ -f "$sd/scores.rec" ] && [ -n "$observed_score" ]; then
  # count trailing rows pinned to the current score
  flat=$(r < "$sd/scores.rec" | awk -F'|' -v s="$observed_score" '
    { if ($2 ~ /^-?[0-9]+(\.[0-9]+)?$/ && $2+0 == s+0) c++; else if ($2 ~ /^-?[0-9]+(\.[0-9]+)?$/) c=0 }
    END { print c+0 }')
  [ "${flat:-0}" -ge 3 ] && echo "GATE: NOTE metric-flat ($primary pinned at $observed_score for $flat rounds - if the objective demands strict improvement, the metric may be saturated (ceiling); raise its headroom or accept floor+forge)" >&2
fi

# -5b2. owed work blocks the claim. An unticked work-plan item at claim time
# means a worker died, stalled, or was never dispatched - or an item was
# abandoned without saying so. Without this check the drop was invisible: the
# wave closed clean and the gate said GO. Land the item, or close it out loud
# with a recorded fault (close-iteration --fault CLASS --fault-outcome ...).
wp_open=0
if [ -f "$sd/work-plan.md" ]; then
  wp_open=$(grep -cE '^- \[ \]' "$sd/work-plan.md" 2>/dev/null || echo 0)
  case "$wp_open" in ''|*[!0-9]*) wp_open=0 ;; esac
fi
[ "$wp_open" -eq 0 ] || [ "$mode" = checkpoint ] \
  || fail "open-items:$wp_open (work-plan still has unticked item(s): finish them, or close them with a recorded fault - close-iteration --fault CLASS --fault-outcome OUTCOME)"

# -5c. two-pass adversarial (harness engineering): a claim needs a second
# pass bound to THIS (iter, digest). The creator cannot mark its own homework.
# Receipt: .goal/evidence/adversarial.rec  fields iter|digest|verdict|note
#   verdict=clear -> allow; finding -> refuse; missing/stale -> refuse.
# Runs after the mechanical ACs so open-FAIL/not-covered still report themselves.
advf="$sd/evidence/adversarial.rec"
# BIND the receipt to the CLAIMING block's iteration (loop-log header), not
# state.rec - hand-written ledgers can have state.iteration=0 with ## iteration 1.
claim_iter=$(r < "$sd/loop-log.md" | awk '/^## iteration /{n=$3} END{print n+0}')
[ "$claim_iter" = 0 ] && claim_iter=$iter
adv_ok=0; adv_note=""
if [ -f "$advf" ]; then
  adv_line=$(r < "$advf" | awk -F'|' -v it="$claim_iter" -v dg="$digest" '
    $1+0==it+0 && $2==dg { row=$0 }
    END { print row }')
  if [ -n "$adv_line" ]; then
    adv_v=$(printf '%s\n' "$adv_line" | cut -d'|' -f3)
    adv_note=$(printf '%s\n' "$adv_line" | cut -d'|' -f4)
    case "$adv_v" in
      clear) adv_ok=1 ;;
      finding) fail "adversarial-finding:${adv_note:-see adversarial.rec}" ;;
      *) fail "adversarial-missing:bad-verdict:$adv_v" ;;
    esac
  fi
fi
[ "$adv_ok" = 1 ] || fail "adversarial-missing:need .goal/evidence/adversarial.rec row ${claim_iter}|${digest}|clear|<note> after a second-pass review"

# -5d. raw sensor dump (harness engineering: the fix must carry mechanical
# evidence). Claiming iteration needs a non-empty evidence/raw/<iter>.txt
# holding the actual check output - prose "it passed" is not a sensor.
rawf="$sd/evidence/raw/${claim_iter}.txt"
[ -s "$rawf" ] || fail "raw-evidence-missing:need non-empty .goal/evidence/raw/${claim_iter}.txt with the real check output"

coverage=""
if [ "$exit_mode" = forge ] && [ "$mode" != checkpoint ]; then
  python3 -I "$here/goal_forge.py" audit --project "$project" --iteration "$iter" --limit "$dl" --artifact "$digest" \
    || fail "forge-coverage-unverified:see executed probe scope"
  coverage=" coverage=declared"
fi
outcome=GO
[ "$mode" != checkpoint ] || outcome=CHECKPOINT-OK
if [ -n "$primary" ]; then
  echo "GATE: $outcome digest=$digest iter=$iter ac=$total pass=$passn unverified=$unv mode=$exit_mode score=$observed_score best=${best:-$observed_score}$coverage"
  exit 0
fi

echo "GATE: $outcome digest=$digest iter=$iter ac=$total pass=$passn unverified=$unv mode=$exit_mode$coverage"
exit 0
