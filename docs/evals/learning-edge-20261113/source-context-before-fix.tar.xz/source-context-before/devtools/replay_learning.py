#!/usr/bin/env python3
"""Replay two observable defects against frozen before/after source trees."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess


def observe(root):
    spec=importlib.util.spec_from_file_location('replay_fixture',root/'tests/test_crew.py')
    f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    case=f.Crew();case.setUp()
    try:
        case.write_graph(deps=True)
        wave=case.fresh('crew','dependency-counterexample')
        wave.event('T1','dispatch');case.work(wave,'T1')
        (case.project/'a.out').write_text('corrupted after acceptance')
        refused=False;error=None
        try:wave.event('T2','dispatch')
        except ValueError as e:refused=True;error=str(e)
        marker=case.project/'client-was-invoked'
        client=case.project/'fake-client'
        client.write_text('#!/bin/sh\ntouch "'+str(marker)+'"\n');client.chmod(0o755)
        run=subprocess.run(['bash',str(root/'scripts/goal_loop.sh'),'--continue','--max-iterations=1',
            '--wallclock=3','--project',str(case.project)],capture_output=True,text=True,
            env=dict(os.environ,CLAUDE_BIN=str(client)),timeout=12)
        return dict(stale_parent_refused=refused,dependency_error=error,
                    installed_entry_invoked_client=marker.exists(),entry_result=run.returncode,
                    entry_stdout=run.stdout,entry_stderr=run.stderr)
    finally:case.doCleanups()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline',type=Path,required=True);p.add_argument('--current',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    result={name:observe(root.resolve()) for name,root in [('before',args.baseline),('after',args.current)]}
    result['verified']=(not result['before']['stale_parent_refused'] and result['before']['installed_entry_invoked_client']
                        and result['after']['stale_parent_refused'] and not result['after']['installed_entry_invoked_client']
                        and result['after']['entry_result']==4)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,sort_keys=True))
    raise SystemExit(0 if result['verified'] else 1)
