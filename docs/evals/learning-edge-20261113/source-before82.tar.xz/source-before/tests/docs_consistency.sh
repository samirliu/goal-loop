#!/usr/bin/env bash
# docs_consistency.sh - form-level regression for the skill's documentation.
# Protocol changes are cheap to make and expensive to notice when they rot;
# this catches the mechanical rot classes in seconds:
#   C1 every referenced skill-internal file exists
#   C2 the version markers agree with the VERSION file
#   C3 every numbered TOC entry has a matching ## heading
#   C5 iron-rule literals stay wired (work-queue vs court, ledger keys,
#      closed task= suffix vocabulary)
#   C6 case knowledge stays out of generic skill surfaces
#   C7 rule compaction: five invariants + packs + legacy index retained
# Run from anywhere:  bash tests/docs_consistency.sh
# Exit 0 = consistent. (Semantic review still belongs to humans + the loop.)
set -u
export LC_ALL=C.UTF-8

here=$(cd "$(dirname "$0")/.." && pwd)
cd "$here"
fail=0
ok(){ echo "  ok   - $1"; }
bad(){ fail=1; echo "  FAIL - $1"; }

# C1 file-reference resolution (docs may cite skill-internal paths, or paths
# of OTHER installed skills - e.g. the packager of skill-creator). External
# references are verified only when other skills ARE installed locally;
# on machines without them (CI runners) they degrade to a skip - a bare
# environment must not fail the check for a reference it cannot see.
#
# Mid-path matches are the trap: `contract-forge/tests/run_fixtures.sh` greps
# as `tests/run_fixtures.sh`, which looks internal and then "breaks" on a
# minimal install that does not ship companions/. Keep the optional skill
# prefix, and treat a citation as external when its source line names another
# skill / companions/ / ~/.claude/skills/.
missing=0; skipped=0
skills_dir="$HOME/.claude/skills"
while IFS= read -r line; do
  [ -n "$line" ] || continue
  case "$line" in
    *contract-forge*|*companions/*|*"$skills_dir"*|*skill-creator*|*mattpocock*) ext_line=1 ;;
    *) ext_line=0 ;;
  esac
  while IFS= read -r r; do
    [ -n "$r" ] || continue
    r=$(printf '%s' "$r" | sed 's/[.,;:)]*$//')
    [ -f "$r" ] && continue
    if [ -f "companions/$r" ] || ls companions/*/"$r" >/dev/null 2>&1; then
      ok "C1 companion reference resolves: $r"
      continue
    fi
    if [ -d "$skills_dir" ] && { [ -f "$skills_dir/$r" ] || ls "$skills_dir/"*/"$r" >/dev/null 2>&1; }; then
      ok "C1 external reference resolves: $r"
      continue
    fi
    # Cited as another skill / install layout and that skill is not here.
    if [ "$ext_line" -eq 1 ]; then
      skipped=$((skipped+1))
      continue
    fi
    bad "C1 broken reference: $r"; missing=$((missing+1))
  done <<EOF
$(printf '%s\n' "$line" | grep -ohE '([A-Za-z0-9_.-]+/)?(references|scripts|assets|tests)/[A-Za-z0-9_][A-Za-z0-9_./-]*' | sort -u)
EOF
done < <(grep -hE '(references|scripts|assets|tests)/[A-Za-z0-9_]' \
        SKILL.md INTEGRATION.md references/*.md assets/goal.contract.md 2>/dev/null | sort -u)
[ "$missing" -eq 0 ] && ok "C1 all internal cited files exist (external skipped=$skipped)"

# C2 version agreement with the VERSION file
if [ -f VERSION ]; then
  V=$(tr -d '[:space:]' < VERSION)
  grep -q "(v$V)" SKILL.md && ok "C2 SKILL.md title says v$V" || bad "C2 SKILL.md title does not say (v$V)"
else
  bad "C2 VERSION file missing"
fi

# C3 numbered TOC entries (from the Contents line ONLY) have matching ## headings
for f in references/*.md; do
  cont=$(grep '^Contents:' "$f") || continue
  for n in $(printf '%s\n' "$cont" | grep -oE '\[[0-9]+' | tr -d '[' | sort -un); do
    grep -qE "^## $n( |:|\$)" "$f" && ok "C3 $f TOC $n has a heading" || bad "C3 $f TOC entry $n has no ## heading"
  done
done

# C5 iron-rule literals: the words the law depends on stay in the live docs.
# The dispatch surface is one-shot subagents; the load-bearing literals are the
# "work queue != court" split, the ledger-key discipline, and the closed
# task= suffix vocabulary. Silent drift here re-opens the hole they closed.
while IFS='|' read -r f needle; do
  [ -n "$f" ] || continue
  if grep -qF -- "$needle" "$f" 2>/dev/null; then
    ok "C5 $f has: $needle"
  else
    bad "C5 $f missing: $needle"
  fi
done <<'EOF'
references/crew.md|NEVER a GO signal
references/crew.md|work-plan.md
references/crew.md|No `isolation: worktree`
references/crew.md|Do not invent new loop-log keys
references/gate.md|never WRITE `.goal/`
references/crew.md|INLINED
SKILL.md|禁止
SKILL.md|worktree
references/gate.md|R9
references/gate.md|R10
references/gate.md|R11
references/gate.md|probe:
references/gate.md|R12
SKILL.md|goal_audit.sh
references/crew.md|calibration anchors
SKILL.md|指标批评席
references/gate.md|R13
references/gate.md|DIVERGENCE
scripts/goal_gate.sh|DIVERGENCE
scripts/goal_ctl.sh|judge-score
scripts/goal_gate.sh|probe-failed
scripts/goal_gate.sh|score-regressed
scripts/goal_gate.sh|missing-strategy-delta
scripts/goal_ctl.sh|strategy-delta
scripts/goal_parse.sh|(exit|objective|horizon-waived):
scripts/goal_ctl.sh|gp_ac_body_hash
scripts/goal_gate.sh|gp_ac_body_hash
scripts/goal_ctl.sh|gp_hash_std
SKILL.md|minimize
references/gate.md|low-water for minimize
scripts/goal_parse.sh|minimize)  echo "minimize"
scripts/goal_gate.sh|dir=minimize
scripts/goal_ctl.sh|obj_dir
SKILL.md|盖戳时绑定
scripts/goal_ctl.sh|BIND at stamp
scripts/goal_gate.sh|hint=fix-AC
scripts/goal_gate.sh|verdict-unbound
scripts/goal_gate.sh|contract-malformed
scripts/goal_ctl.sh|false-complete-counted
scripts/goal_gate.sh|calibration-missing
scripts/goal_gate.sh|calibration-broken
references/gate.md|R15
references/gate.md|calibration-missing
references/crew.md|calibration is MANDATORY
assets/goal.contract.md|calib:
SKILL.md|calib:
SKILL.md|小任务快车道
scripts/goal_ctl.sh|CTL: NEXT
scripts/goal_ctl.sh|last_hint=
references/gate.md|crew:1]
scripts/goal_ctl.sh|bad-task:
scripts/goal_gate.sh|check-mutated-ledger
scripts/goal_gate.sh|ledger_digest
scripts/goal_gate.sh|unknown-ac-id
scripts/goal_gate.sh|duplicate AC id
scripts/goal_gate.sh|unparseable-state:
scripts/goal_ctl.sh|never produce a score
scripts/goal_ctl.sh|stamp-refused: goal.md has no
scripts/goal_ctl.sh|false-complete-flag-ignored
references/gate.md|check-mutated-ledger
references/gate.md|NEGATIVE water marks
scripts/goal_gate.sh|metric-flat
scripts/goal_gate.sh|extract_metric
scripts/goal_gate.sh|strip_ansi
scripts/goal_gate.sh|tolerance
references/gate.md|R14
SKILL.md|hint=
SKILL.md|bind-seat
scripts/goal_gate.sh|graceful delivery of passing work
SKILL.md|不没收已通过的交付
references/gate.md|strategy=<label>
references/gate.md|peer-notes
references/crew.md|peer-notes
references/patterns.md|complex-goal contract shapes
SKILL.md|--strategy
SKILL.md|peer-notes
SKILL.md|EFFICIENCY
scripts/goal_ctl.sh|--strategy
scripts/goal_ctl.sh|strat_show
scripts/goal_ctl.sh|CTL: EFFICIENCY
scripts/goal_ctl.sh|eval-gap:
scripts/goal_ctl.sh|promote:
scripts/goal_ctl.sh|attribution-unused:
scripts/goal_audit.sh|recovery-vocabulary
scripts/goal_parse.sh|stall-recovered
references/crew.md|stall-recovered
references/crew.md|tool-error-fixed
references/crew.md|re-run:stall
references/crew.md|`[ ]` (OPEN)
references/crew.md|fallback:provider-fatal
scripts/goal_audit.sh|fallback-vocabulary
SKILL.md|--fault
references/crew.md|breakpoint brief
references/crew.md|take-over
references/crew.md|faults.rec
references/crew.md|open-items
references/gate.md|faults.rec
references/gate.md|open-items
scripts/goal_ctl.sh|CTL: FAULT
scripts/goal_ctl.sh|bad-fault-class
scripts/goal_ctl.sh|unbacked-task-suffix
scripts/goal_audit.sh|unbacked-suffix
scripts/goal_audit.sh|unbooked-fault
scripts/goal_gate.sh|open-items
scripts/goal_gate.sh|close-open-item
scripts/goal_parse.sh|gp_fault_suffix
examples/quickstart-one-shot/run.sh|--adversarial clear
EOF

# C6 generality: case knowledge stays in examples/. Generic skill surfaces
# must not name any validation case or its domain recipe.
leak=$(grep -nE 'tsp-minimize|logcli|svg-dash|goal-loop-case-|波音|b747|threejs|THREEJS|goal-loop-747' \
        SKILL.md references/*.md references/packs/*.md scripts/*.sh tests/*.sh assets/* 2>/dev/null | grep -v '^tests/docs_consistency.sh:' || true)
if [ -z "$leak" ]; then
  ok "C6 no case knowledge leaked into generic skill files"
else
  bad "C6 case knowledge leaked: $leak"
fi

# C7 rule compaction: five invariants stay on the always-on surface; packs
# remain the only depth; SKILL.md must not reintroduce R-numbers.
for needle in GATE BIND PROVE GRADIENT FENCE; do
  grep -q "$needle" SKILL.md && ok "C7 SKILL has invariant $needle" || bad "C7 SKILL missing $needle"
done
if grep -qE 'R[0-9]+' SKILL.md; then
  bad "C7 SKILL.md reintroduced R-numbers (legacy index lives in references/gate.md)"
else
  ok "C7 SKILL.md free of R-numbers"
fi
for p in instrument gradient external; do
  [ -f "references/packs/$p.md" ] && ok "C7 pack exists: $p.md" || bad "C7 pack missing: $p.md"
done
for needle in GATE BIND PROVE GRADIENT FENCE; do
  grep -q "$needle" references/gate.md && ok "C7 gate.md maps $needle" || bad "C7 gate.md missing $needle"
done
for r in R1 R2 R3 R4 R5 R6 R7 R8 R9 R10 R11 R12 R13 R14 R15 R16 R17 R18 R19; do
  grep -q "\*\*$r\*\*" references/gate.md && ok "C7 legacy $r retained" || bad "C7 legacy $r missing from gate.md"
done
for needle in instrument.md gradient.md external.md; do
  grep -q "$needle" SKILL.md && ok "C7 SKILL activates pack $needle" || bad "C7 SKILL missing pack $needle"
done

echo "== docs consistency: $([ $fail -eq 0 ] && echo CONSISTENT || echo DRIFT) =="
exit $fail
