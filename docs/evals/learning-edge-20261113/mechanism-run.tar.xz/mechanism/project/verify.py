from pathlib import Path
import sys
for n in (sys.argv[1:] or ["a", "b"]):
 if Path(n+".out").read_bytes()!=Path(n+".in").read_bytes(): raise SystemExit(1)
