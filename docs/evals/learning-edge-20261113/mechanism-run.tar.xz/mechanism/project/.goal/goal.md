# Goal

## Acceptance criteria

- AC-1 | both copies match input bytes | check: `python3 verify.py` | expected: exit=0

## Approval

approved: c9023cf4 2026-11-13 auto
