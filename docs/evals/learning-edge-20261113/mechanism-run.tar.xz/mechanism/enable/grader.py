import json,sys
json.load(sys.stdin)
print(json.dumps(dict(floor=True,horizon=True,score=1)))
