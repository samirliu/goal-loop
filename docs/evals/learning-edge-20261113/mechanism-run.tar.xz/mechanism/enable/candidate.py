# candidate
import json,sys
v=json.load(sys.stdin)
m=v["context"].get("workload")=="two-copies" and len(v["jobs"])==2
print(json.dumps(dict(match=m,choice="serial" if m else "baseline",reason="scoped startup-cost hypothesis")))
