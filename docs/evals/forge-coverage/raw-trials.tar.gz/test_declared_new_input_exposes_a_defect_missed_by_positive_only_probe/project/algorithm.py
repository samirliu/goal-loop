def dedupe(items):
    return sorted({x for x in items if x >= 0})
