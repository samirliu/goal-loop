import json,sys,time
from pathlib import Path
from algorithm import dedupe
if Path(".goal/evidence/slow").exists(): time.sleep(5)
items=json.load(sys.stdin)
expected=[]
for value in sorted(items):
    if value not in expected: expected.append(value)
actual=dedupe(items)
print(json.dumps(dict(expected=expected,actual=actual)))
sys.exit(0 if expected == actual else 1)
