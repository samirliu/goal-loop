# Goal

## Objective

exit: forge

## Acceptance criteria

- AC-1 | function exists | check: `if test -f .goal/evidence/tamper; then echo corrupted > .goal/evidence/raw/0.txt; fi; grep -q dedupe algorithm.py` | expected: exit=0

## Budget

check_timeout=1

## Approval

approved: 9dc4259f 2026-11-11 auto
