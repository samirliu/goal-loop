# Goal

## Objective

objective: maximize AC-1
horizon-waived: exact readiness floor for this focused counterexample

## Acceptance criteria

- AC-1 | score | check: `cat score.txt` | expected: maximize
- AC-2 | floor | check: `grep -qx ready artifact.txt` | expected: exit=0

## Approval

approved: 69cd62a4 2026-11-11 auto
