"""Content identity stays within an explicitly selected Git subproject."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

GATE = Path(__file__).resolve().parents[1] / 'scripts/goal_gate.sh'


class WorktreeScope(unittest.TestCase):
    def digest(self, project, env=None):
        result = subprocess.run(['bash', str(GATE), '--digest', '--project', str(project)],
                                env=env, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertRegex(result.stdout, r'^v2-[0-9a-f]{64}\n$')
        self.assertNotIn('unbound variable', result.stderr)
        return result.stdout

    def test_dirty_parent_files_do_not_bind_subproject(self):
        with tempfile.TemporaryDirectory(prefix='goal-subproject-') as tmp:
            root = Path(tmp)
            subprocess.run(['git', 'init', '-q', str(root)], check=True, capture_output=True)
            child = root / 'component'; child.mkdir()
            (root / 'parent.txt').write_text('outside\n')
            artifact = child / 'artifact.txt'; artifact.write_text('inside\n')
            subprocess.run(['git', '-C', str(root), 'add', '.'], check=True, capture_output=True)
            before = self.digest(child)
            (root / 'parent.txt').write_text('outside changed\n')
            self.assertEqual(before, self.digest(child))
            artifact.write_text('inside changed\n')
            self.assertNotEqual(before, self.digest(child))

    def test_linked_worktree_uses_the_selected_worktree_bytes(self):
        with tempfile.TemporaryDirectory(prefix='goal-linked-tree-') as tmp:
            root, linked = Path(tmp) / 'root', Path(tmp) / 'linked'
            root.mkdir()
            subprocess.run(['git', 'init', '-q', str(root)], check=True, capture_output=True)
            (root / 'artifact.txt').write_text('original\n')
            subprocess.run(['git', '-C', str(root), 'add', '.'], check=True, capture_output=True)
            subprocess.run(['git', '-C', str(root), '-c', 'user.name=test', '-c', 'user.email=test@example.invalid',
                            'commit', '-qm', 'fixture'], check=True, capture_output=True)
            subprocess.run(['git', '-C', str(root), 'worktree', 'add', '-q', '-b', 'fixture-linked', str(linked)],
                           check=True, capture_output=True)
            self.assertTrue((linked / '.git').is_file())
            original, selected = self.digest(root), self.digest(linked)
            self.assertEqual(original, selected)
            (linked / 'artifact.txt').write_text('linked changed\n')
            self.assertNotEqual(selected, self.digest(linked))
            self.assertEqual(original, self.digest(root))

    def test_cleanup_handles_shell_special_temporary_directory_path(self):
        with tempfile.TemporaryDirectory(prefix='goal-temp-') as tmp:
            root = Path(tmp)
            project = root / 'project'; project.mkdir()
            (project / 'artifact.txt').write_text('artifact\n')
            scratch = root / "temporary ' quoted $() space"
            scratch.mkdir()
            (scratch / 'keep.txt').write_text('caller-owned\n')
            self.digest(project, env=dict(os.environ, TMPDIR=str(scratch)))
            self.assertEqual((scratch / 'keep.txt').read_text(), 'caller-owned\n')
            # macOS git/xcrun may also create its own cache in TMPDIR. Only
            # assert cleanup of the private prefixes this implementation owns.
            self.assertFalse(any(path.name.startswith(('goal-tree.', 'goal-watch.')) for path in scratch.iterdir()))


if __name__ == '__main__':
    unittest.main()
