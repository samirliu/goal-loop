# SPDX-License-Identifier: MIT

"""Compatibility and inheritance coverage for class-level keyword-only fields."""

import ast
import inspect

from pathlib import Path

import pytest

import attr
import attrs

from attr._compat import PY_3_10_PLUS


MODERN = [
    attrs.define,
    attr.define,
    attrs.mutable,
    attr.mutable,
    attrs.frozen,
    attr.frozen,
]


@pytest.mark.parametrize("decorate", MODERN)
def test_modern_inheritance_settings(decorate, slots):
    """Each generation resolves its own fields without changing older ones."""

    @decorate(slots=slots)
    class Base:
        _key: int = attrs.field(alias="record_key")
        flag: int = attrs.field(kw_only=True, default=0)

    @decorate(slots=slots, kw_only=True)
    class Middle(Base):
        label: str
        positional: int = attrs.field(kw_only=False, alias="number")
        unspecified: int = attrs.field(kw_only=None)
        defaulted: int = 9
        items: list = attrs.field(factory=list)
        ignored: int = attrs.field(init=False, default=10)

    @decorate(slots=slots)
    class Leaf(Middle):
        extra: int

    first = Leaf(1, 2, 3, label="label", unspecified=4)
    second = Leaf(1, 2, 3, label="label", unspecified=4)
    assert (1, 2, 3, "label", 4, 9, 10) == (
        first._key,
        first.positional,
        first.extra,
        first.label,
        first.unspecified,
        first.defaulted,
        first.ignored,
    )
    assert first.items == []
    assert first.items is not second.items
    if PY_3_10_PLUS:
        assert ("_key", "positional", "extra") == Leaf.__match_args__
        assert ("_key",) == Base.__match_args__
    assert attrs.fields(Base)._key.kw_only is False
    for field in attrs.fields(Leaf):
        assert isinstance(field.kw_only, bool)
        if field.init:
            expected = (
                inspect.Parameter.KEYWORD_ONLY
                if field.kw_only
                else inspect.Parameter.POSITIONAL_OR_KEYWORD
            )
            assert inspect.signature(Leaf).parameters[field.alias].kind == expected
    with pytest.raises(TypeError):
        Leaf(1, 2, 3, "label", unspecified=4)


@pytest.mark.parametrize(
    ("decorate", "default_force"),
    [
        (attrs.define, False),
        (attr.define, False),
        (attrs.frozen, False),
        (attr.s, True),
        (attr.attrs, True),
    ],
)
@pytest.mark.parametrize("force", [None, False, True])
@pytest.mark.parametrize("class_kw", [False, True])
def test_force_switch(decorate, default_force, force, class_kw, slots):
    """Both APIs can choose either behavior; forcing requires class kw_only."""
    options = {} if force is None else {"force_kw_only": force}

    @decorate(slots=slots)
    class Base:
        base = attr.ib()
        keyword = attr.ib(kw_only=True, default=0)

    @decorate(slots=slots, kw_only=class_kw, **options)
    class Child(Base):
        own = attr.ib()
        explicit = attr.ib(kw_only=False)
        unspecified = attr.ib(kw_only=None)

    forcing = class_kw and (default_force if force is None else force)
    resolved = attrs.fields_dict(Child)
    assert resolved["base"].kw_only is forcing
    assert resolved["explicit"].kw_only is forcing
    assert resolved["own"].kw_only is class_kw
    assert resolved["unspecified"].kw_only is class_kw
    assert resolved["keyword"].kw_only is True
    assert attrs.fields(Base).base.kw_only is False
    values = {"base": 1, "own": 2, "explicit": 3, "unspecified": 4, "keyword": 5}
    positional = [values[f.name] for f in resolved.values() if not f.kw_only]
    keywords = {f.alias: values[f.name] for f in resolved.values() if f.kw_only}
    instance = Child(*positional, **keywords)
    assert attrs.asdict(instance) == values
    if PY_3_10_PLUS:
        assert Child.__match_args__ == tuple(
            f.name for f in resolved.values() if not f.kw_only
        )
    parameters = inspect.signature(Child).parameters
    for f in resolved.values():
        assert (
            parameters[f.alias].kind is inspect.Parameter.KEYWORD_ONLY
        ) is f.kw_only


def test_multiple_inheritance(slots):
    """A diamond keeps positional and keyword-only settings from both branches."""

    @attrs.define(slots=False)
    class Root:
        root: int

    @attrs.define(slots=False, kw_only=True)
    class Left(Root):
        left: int

    @attrs.define(slots=False)
    class Right(Root):
        right: int

    @attrs.define(slots=slots, kw_only=True)
    class Leaf(Left, Right):
        leaf: int

    instance = Leaf(1, 2, left=3, leaf=4)
    assert (1, 2, 3, 4) == (
        instance.root, instance.right, instance.left, instance.leaf
    )
    if PY_3_10_PLUS:
        assert ("root", "right") == Leaf.__match_args__
    assert [False, False, True, True] == [a.kw_only for a in attrs.fields(Leaf)]


def test_redefined_field_is_owned_by_subclass(slots):
    """An override resolves the subclass setting and leaves its base unchanged."""

    @attrs.define(slots=slots)
    class Base:
        value: int

    @attrs.define(slots=slots, kw_only=True)
    class Child(Base):
        value: int

    @attrs.define(slots=slots, kw_only=True)
    class Positional(Child):
        value: int = attrs.field(kw_only=False)

    assert attrs.fields(Base).value.kw_only is False
    assert attrs.fields(Child).value.kw_only is True
    assert attrs.fields(Positional).value.kw_only is False
    assert Positional(1).value == Child(value=1).value
    if PY_3_10_PLUS:
        assert ("value",) == Positional.__match_args__


@pytest.mark.parametrize("decorate", [attrs.define, attr.s])
@pytest.mark.parametrize("default", [attr.ib(default=1), attr.ib(factory=int)])
def test_positional_order_validation(decorate, default, slots):
    """Preserved positional fields still enforce required-after-default rules."""

    @decorate(slots=slots)
    class Base:
        value = default

    with pytest.raises(ValueError, match="No mandatory attributes allowed"):

        @decorate(slots=slots, kw_only=True, force_kw_only=False)
        class Child(Base):
            required = attr.ib(kw_only=False)

    @decorate(slots=slots, kw_only=True, force_kw_only=False)
    class KeywordChild(Base):
        required = attr.ib()

    assert KeywordChild(required=2).required == 2


@pytest.mark.parametrize("force", [False, True])
def test_generated_attrs_init(force, slots):
    """init=False uses the same field settings for the generated attrs init."""

    @attrs.define(slots=slots, frozen=True)
    class Base:
        _key: int = attrs.field(alias="key")

    @attrs.define(
        slots=slots,
        frozen=True,
        init=False,
        kw_only=True,
        force_kw_only=force,
    )
    class Child(Base):
        name: str
        value: int = attrs.field(kw_only=False)

        def __init__(self):
            if force:
                self.__attrs_init__(key=1, value=2, name="name")
            else:
                self.__attrs_init__(1, 2, name="name")

    assert (1, 2, "name") == (Child()._key, Child().value, Child().name)
    with pytest.raises(attrs.exceptions.FrozenInstanceError):
        Child().value = 3


def test_reused_field_does_not_keep_first_class_setting(slots):
    """Resolving an unspecified field does not mutate a reusable field spec."""
    field = attrs.field(kw_only=None)

    @attrs.define(slots=slots, kw_only=True, these={"value": field})
    class Keyword:
        pass

    @attrs.define(slots=slots, these={"value": field})
    class Positional:
        pass

    assert attrs.fields(Keyword).value.kw_only is True
    assert attrs.fields(Positional).value.kw_only is False
    assert Keyword(value=1).value == Positional(1).value


@pytest.mark.parametrize(
    ("module", "field_name"), [(attr, "attrib"), (attrs, "field")]
)
def test_public_field_stubs_accept_unspecified(module, field_name):
    """Every field overload permits None; resolved Attribute stays boolean."""
    stub = ast.parse(Path(module.__file__).with_suffix(".pyi").read_text())
    overloads = [
        node
        for node in stub.body
        if isinstance(node, ast.FunctionDef) and node.name == field_name
    ]
    assert len(overloads) == 4
    for node in overloads:
        argument = next(
            arg
            for arg in node.args.args + node.args.kwonlyargs
            if arg.arg == "kw_only"
        )
        assert ast.unparse(argument.annotation) == "bool | None"


@pytest.mark.parametrize("base_decorate", [attrs.define, attr.s])
def test_forced_settings_survive_later_inheritance(base_decorate, slots):
    """Later modern classes preserve intermediate keyword-only settings."""

    @base_decorate(slots=slots)
    class Base:
        key = attr.ib()

    @base_decorate(slots=slots, kw_only=True, force_kw_only=True)
    class Middle(Base):
        name = attr.ib()

    @attrs.define(slots=slots)
    class Leaf(Middle):
        extra: int

    assert attrs.fields(Base).key.kw_only is False
    assert attrs.fields(Middle).key.kw_only is True
    assert attrs.fields(Leaf).key.kw_only is True
    assert attrs.fields(Leaf).key.inherited is True
    if PY_3_10_PLUS:
        assert ("extra",) == Leaf.__match_args__
    instance = Leaf(3, key=1, name="two")
    assert (1, "two", 3) == (instance.key, instance.name, instance.extra)


def test_diamond_prefers_actual_override(slots):
    """A branch's inherited field cannot hide the other branch's own override."""

    @attrs.define(slots=False)
    class Root:
        key: int

    @attrs.define(slots=False, kw_only=True, force_kw_only=True)
    class Left(Root):
        pass

    @attrs.define(slots=False)
    class Right(Root):
        key: str = attrs.field(kw_only=False, alias="right_key")

    @attrs.define(slots=slots)
    class Leaf(Left, Right):
        extra: int

    if PY_3_10_PLUS:
        assert ("key", "extra") == Leaf.__match_args__
    assert attrs.fields(Leaf).key.kw_only is False
    assert attrs.fields(Leaf).key.alias == "right_key"
    assert attrs.fields(Leaf).key.type is str
    assert Leaf("value", 2).key == "value"
