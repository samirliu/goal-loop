# work-plan (controller ticks; NEVER a GO signal)

- [x] T1 Implement and verify keyword-only inheritance migration | owner=controller | files=src/attr/_make.py,src/attr/_next_gen.py,src/attr/__init__.pyi,src/attrs/__init__.pyi,tests/test_kw_only_migration.py
