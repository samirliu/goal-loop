# Goal

## Objective

Implement TASK.md in full: modern attrs decorators resolve unspecified own field keyword-only settings from the class, preserve explicit positional settings and inherited fields, and expose force_kw_only for either API with legacy-compatible defaults. Constructors, attributes, aliases, match arguments, field stubs, defaults, factories, frozen behavior and positional ordering validation must remain consistent. Review regression evidence before delivery.

## Acceptance criteria

- AC-1 | The modern positional base field remains positional in a keyword-only subclass and the complete migration contract in TASK.md is implemented and reviewed | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 8ad4dd12 2026-11-13 auto
