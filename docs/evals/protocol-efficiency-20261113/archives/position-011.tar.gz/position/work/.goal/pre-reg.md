# Migration hypothesis

Resolve unspecified field settings at class construction, preserving explicit and inherited settings unless force_kw_only and kw_only are both true. Public failure is TypeError for NamedRecord(7, name="seven"). Prediction: public check passes and legacy regression tests remain green. Counterevidence: inherited fields change unexpectedly, default ordering escapes validation, or constructors and fields disagree. Scope is package source and focused tests; no workers. Preserve original deadlines and reserve time for review, booking, audit and Gate.
