from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))
from typing import Literal, Union
from attrs import define
from cattrs import Converter
from cattrs.gen import make_dict_structure_fn, make_dict_unstructure_fn, override

@define
class Created:
    kind: Literal['created']
@define
class Deleted:
    kind: Literal['deleted']
converter = Converter()
for cls in (Created, Deleted):
    options = {'kind': override(rename='eventType')}
    converter.register_structure_hook(cls, make_dict_structure_fn(cls, converter, **options))
    converter.register_unstructure_hook(cls, make_dict_unstructure_fn(cls, converter, **options))
assert converter.structure(converter.unstructure(Created('created')), Union[Created, Deleted]) == Created('created')

print('public check passed')
