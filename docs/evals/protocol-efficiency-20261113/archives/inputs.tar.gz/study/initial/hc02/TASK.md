# Round-trip renamed event discriminators through cattrs

An event consumer configures generated structure and unstructure hooks to rename the Python literal discriminator `kind` to a wire key such as `type`. Serializing one event works, but structuring its serialized payload as a union fails because union selection looks for the Python field name.

Repair the union selection behavior so it uses the serialized discriminator names configured on the generated hooks. It must work with attrs classes and dataclasses, `BaseConverter` and `Converter`, and both detailed-validation settings. The same Python attribute can be renamed to different keys in different members, in which case normal unique-key disambiguation must still work. Different attribute names renamed to the same wire key must work too. An empty-string rename is a legitimate wire key. Explicit overrides passed to `create_default_dis_func` must behave consistently with hook-discovered overrides.

Retain literal-value discrimination, ordinary unrenamed unions and error behavior for invalid or genuinely ambiguous inputs. The public check is a small renamed event round trip; add focused tests as useful.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
