from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / '.'))
import asyncio
from tenacity import AsyncRetrying, stop_after_attempt
from tenacity import asyncio as policies

async def main():
    calls = []
    async def work():
        calls.append(len(calls) + 1)
        return calls[-1]
    async def pending(value):
        return value < 3
    result = await AsyncRetrying(retry=policies.retry_if_result(pending), stop=stop_after_attempt(4))(work)
    assert result == 3 and calls == [1, 2, 3]
asyncio.run(main())

print('public check passed')
