# Awaitable retry policies in an asynchronous service

The async retry controller supports coroutine work but its policy path is not consistently awaitable. A service needs to decide whether to retry by consulting async result/exception predicates, and use awaitable wait/stop policies and lifecycle callbacks. Repair this behavior across the controller, policy composition, and decorator dispatch.

Required behavior:

- `AsyncRetrying` accepts synchronous or async retry, wait and stop policies, with synchronous or async callbacks. Direct calls and `async for` attempts preserve results, retry limits and original exceptions.
- Provide async `retry_if_result`, `retry_if_exception`, `retry_any`, `retry_all`, and their base strategy under `tenacity.asyncio`, with the strategy module importable as `tenacity.asyncio.retry`. Async result predicates run only for successful outcomes; async exception predicates run only for failures.
- Async and existing synchronous strategies compose in either order using `|` and `&`. Keep left-to-right short circuiting, including skipping an async predicate that must not run.
- The decorator recognizes an object with async `__call__` and partials of coroutine functions, while retaining ordinary function behavior, wrapper metadata, and the existing synchronous policy exports.

The public check is one small service path. Add focused tests as useful; retain existing compatible behavior.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
