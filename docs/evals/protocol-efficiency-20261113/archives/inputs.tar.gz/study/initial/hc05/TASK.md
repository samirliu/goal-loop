# Preserve multipart uploads across partial boundary reads

Real multipart requests are split into input chunks. When a data chunk contains an earlier LF and ends in CR (or in a partial CRLF/boundary prefix), the streaming decoder can emit or lose part of the payload or delimiter. This corrupts otherwise valid uploads and affects request-level form parsing.

Repair data/boundary buffering in the multipart decoder and verify the complete form-parser path. With part headers available and data arriving in chunks, field values and file bytes must be identical across a delimiter split after CR, embedded newlines in payloads, and boundary-like content which is not an actual delimiter. This includes the parser's normal 64 KiB reads and smaller configured data buffers. Complete versus partial boundaries, final epilogues, and decoder `NeedData` progression must remain correct. Preserve payload trailing newlines rather than stripping them to hide the defect. Existing empty-part handling, form limits and malformed-input handling must continue working.

The public check covers one small upload split across a delimiter. Add focused tests as useful.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
