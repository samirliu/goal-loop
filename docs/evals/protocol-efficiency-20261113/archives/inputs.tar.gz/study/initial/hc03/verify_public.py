from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))
import click
from click.testing import CliRunner

@click.command()
@click.option('--enabled', is_flag=True, envvar='HOLDOUT_ENABLED')
def cli(enabled):
    click.echo(repr(enabled))
result = CliRunner().invoke(cli, [], env={'HOLDOUT_ENABLED': 'false'})
assert result.exit_code == 0, result.output
assert result.output == 'False\n', result.output

print('public check passed')
