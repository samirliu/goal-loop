# Reconcile flag values, defaults and environment configuration

A deployment CLI has both boolean flags and string-valued flags. Click currently mixes the absence of a configured value with explicit false values, and a flag's environment value can activate it unexpectedly. Repair option construction and environment conversion together.

Required contract:

- For `is_flag=True`, correctly reconcile `type`, `default` and `flag_value`, including explicit `False` and `None`, and types given as Python types or Click parameter types. Inactive boolean flags use `False` absent a true default. Inactive string flags with no real default produce `'False'`; active string flags with no real activation value produce `'True'`. A real configured default or activation value must survive conversion. Boolean declarations containing invalid boolean defaults or activation values must report a parameter error.
- A flag envvar recognizes the conventional true tokens (`1`, `true`, `t`, `yes`, `y`, `on`) and false tokens (`0`, `false`, `f`, `no`, `n`, `off`), ignoring case and surrounding whitespace for these boolean tokens. Empty/unset environment values make no contribution, so the configured default applies. For a string-valued flag, unrecognized environment values produce the inactive false value, and exact equality to its string `flag_value` also activates it; that equality remains case- and whitespace-sensitive. Ordinary boolean parameter errors remain strict.
- Preserve normal non-flag envvar conversion, explicit command-line precedence, multiple options, paired boolean flags, parameter metadata, and established parameter errors.

The public check demonstrates one false environment token. Test the interacting defaults and types, not just that example.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
