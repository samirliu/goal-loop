import json

import pytest
from tinydb import Query, TinyDB
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage, MemoryStorage
from tinydb.table import Document


@pytest.mark.parametrize('storage_kind',['memory','json','cached-json'])
def test_stale_batch_transform_cache_commit_and_reopen(tmp_path,storage_kind):
    path=tmp_path/'ledger.json'
    if storage_kind=='memory':
        db=TinyDB(storage=MemoryStorage)
    else:
        storage=JSONStorage if storage_kind=='json' else CachingMiddleware(JSONStorage)
        db=TinyDB(path,storage=storage)
    first,second,third=db.insert_multiple([
        {'amount':100,'status':'pending'},
        {'amount':200,'status':'pending'},
        {'amount':300,'status':'pending'},
    ])
    untouched=db.table('configuration')
    untouched.insert({'keep':True})
    pending=Query().status=='pending'
    assert len(db.search(pending))==3
    calls=[]
    def process(document):
        calls.append(document['amount'])
        document['amount']+=5
        document['status']='done'
    ids=(value for value in [900,second,901,first,902])
    assert db.update(process,doc_ids=ids)==[second,first]
    assert calls==[200,100]
    assert [document.doc_id for document in db.search(pending)]==[third]
    assert db.remove(doc_ids=(value for value in [903,second,904]))==[second]
    assert db.get(doc_id=second) is None
    assert [document.doc_id for document in db.search(pending)]==[third]
    before=[dict(document) for document in db.all()]
    assert db.update({'amount':999},doc_ids=[1000,1001])==[]
    assert db.remove(doc_ids=[1002,1003])==[]
    assert [dict(document) for document in db.all()]==before
    assert untouched.all()==[{'keep':True}]
    db.close()
    if storage_kind!='memory':
        disk=json.loads(path.read_text())
        assert disk['_default']=={str(first):{'amount':105,'status':'done'},str(third):{'amount':300,'status':'pending'}}
        reopened=TinyDB(path)
        assert reopened.get(doc_id=first)['amount']==105
        assert reopened.get(doc_id=second) is None
        assert reopened.table('configuration').all()==[{'keep':True}]
        reopened.close()


def test_explicit_id_upsert_and_condition_path_after_missing_batches():
    db=TinyDB(storage=MemoryStorage)
    existing=db.insert({'amount':1,'category':'a'})
    assert db.update({'amount':2},doc_ids=[existing,42])==[existing]
    assert db.upsert(Document({'amount':3,'category':'a'},doc_id=existing))==[existing]
    assert db.upsert(Document({'amount':8,'category':'b'},doc_id=50))==[50]
    assert len(db)==2
    assert db.update({'seen':True},Query().category=='b')==[50]
    assert db.get(doc_id=existing)=={'amount':3,'category':'a'}
    assert db.get(doc_id=50)=={'amount':8,'category':'b','seen':True}
    assert db.remove(Query().category=='b')==[50]
    assert [document.doc_id for document in db.all()]==[existing]
    db.close()
