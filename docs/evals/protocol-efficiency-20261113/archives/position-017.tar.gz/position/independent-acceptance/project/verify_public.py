from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / '.'))
from tinydb import TinyDB
from tinydb.storages import MemoryStorage

db = TinyDB(storage=MemoryStorage)
first, second = db.insert_multiple([{'status':'pending'}, {'status':'pending'}])
assert db.update({'status':'done'}, doc_ids=[first, 999, second]) == [first, second]
assert [doc['status'] for doc in db.all()] == ['done','done']
db.close()

print('public check passed')
