# Apply stale-ID batches consistently and persist the result

A background job reads a list of document IDs, then updates or removes that batch after some documents have already disappeared. `get(doc_id=...)` and `get(doc_ids=...)` already skip missing documents, but update/remove can raise `KeyError` midway, leaving an in-memory mutation which was never committed to storage.

Make explicit-ID update and removal skip missing IDs consistently. They must return only the IDs actually affected and operate on all existing targets even if missing IDs precede, follow, or interrupt them. Both a field mapping and a callable update must work, including a one-shot ID iterable. Keep condition-based and unconditional operations compatible. Missing-only batches must return an empty list without changing documents. Query caches must reflect successful mixed operations; JSON storage must contain the complete result after closing/reopening, including when used through caching middleware. Upsert by an explicit `Document` ID must continue updating existing documents and inserting missing documents correctly.

This requirement concerns stale IDs, not rollback of arbitrary user callback exceptions. The public check covers a mixed update against memory storage. Add focused tests as useful.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
