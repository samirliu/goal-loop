# Goal

## Objective

Apply stale explicit-ID update and removal batches to every existing target, skipping missing IDs and returning only affected IDs. Preserve mapping and callable updates, one-shot iterables, condition-based and unconditional behavior, missing-only no-ops, query cache invalidation, JSON persistence including caching middleware, and Document-ID upsert behavior.

## Acceptance criteria

- AC-1 | A mixed explicit-ID update skips stale IDs and updates all existing targets | check: `env TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python PYTHONDONTWRITEBYTECODE=1 /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0
- AC-2 | Focused stale-ID tests and the existing regression suite pass for update, remove, persistence, caching and upsert compatibility | check: `/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B -m pytest -q -o addopts= -p no:cacheprovider tests` | expected: exit=0

## Approval

approved: d5958254 2026-11-13 auto
