# work-plan (controller ticks; NEVER a GO signal)

- [x] T1 Apply stale explicit-ID batches consistently and verify persistence, cache invalidation and compatibility | owner=controller | files=tinydb/table.py,tests/test_stale_ids.py
