# Pre-registration: stale explicit-ID batches

## Hypothesis and counterevidence

The public smoke test raised KeyError: 999 while updating a mixed ID batch.
Check membership before each explicit-ID mutation and collect only IDs whose
operation succeeds. Keep the common storage write/cache invalidation path.
Reject the change if later existing targets are skipped, a missing-only batch
changes documents, callback exceptions are swallowed, or reopen loses changes.

## Strategy and budget

Single serial task T1; no worker dispatch or optimization objective.
Original execution deadline: 1794565569.983297.
Original outer deadline: 1794565689.983297; no clock restart.

## Kill and degrade lines

Close the books after the implementation and actual review, before dispatching
another wave. If checks fail, fix only the scoped package/tests changes; do not
alter TASK.md, verify_public.py, configuration or dependencies. Report any
unresolved behavior if the deadline prevents verification.
