import pytest

from tinydb import TinyDB, where
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from tinydb.table import Document


MIXED_IDS = [
    [99, 2, 1],
    [2, 99, 1],
    [2, 1, 99],
    [99, 2, 98, 1, 97],
]


@pytest.mark.parametrize('doc_ids', MIXED_IDS)
@pytest.mark.parametrize('callable_update', [False, True])
def test_update_skips_stale_ids(db, doc_ids, callable_update):
    old_query = where('int') == 1
    new_query = where('int') == 2
    assert len(db.search(old_query)) == 3
    assert db.search(new_query) == []

    calls = []

    def increment(document):
        calls.append(document['char'])
        document['int'] += 1

    fields = increment if callable_update else {'int': 2}
    ids = (doc_id for doc_id in doc_ids)
    assert db.update(fields, doc_ids=ids) == [2, 1]
    assert list(ids) == []
    assert [doc.doc_id for doc in db.search(old_query)] == [3]
    assert [doc.doc_id for doc in db.search(new_query)] == [1, 2]
    assert db.get(doc_id=3) == {'int': 1, 'char': 'c'}
    if callable_update:
        assert calls == ['b', 'a']


@pytest.mark.parametrize('doc_ids', MIXED_IDS)
def test_remove_skips_stale_ids(db, doc_ids):
    query = where('int') == 1
    assert len(db.search(query)) == 3

    ids = (doc_id for doc_id in doc_ids)
    assert db.remove(doc_ids=ids) == [2, 1]
    assert list(ids) == []
    assert [doc.doc_id for doc in db.search(query)] == [3]
    assert db.get(doc_ids=[1, 2]) == []
    assert db.get(doc_id=3) == {'int': 1, 'char': 'c'}


@pytest.mark.parametrize('doc_ids', [[], [99, 98]])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_no_existing_ids_leave_documents_unchanged(db, doc_ids, operation):
    before = db.all()
    query = where('int') == 1
    assert db.search(query) == before
    calls = []

    def update(document):
        calls.append(document)
        document['int'] += 1

    ids = (doc_id for doc_id in doc_ids)
    if operation == 'remove':
        affected = db.remove(doc_ids=ids)
    else:
        fields = update if operation == 'callable' else {'int': 2}
        affected = db.update(fields, doc_ids=ids)

    assert affected == []
    assert db.all() == before
    assert db.search(query) == before
    assert calls == []


def test_stale_ids_do_not_hide_callback_errors(db):
    def update(document):
        raise KeyError('callback failure')

    with pytest.raises(KeyError, match='callback failure'):
        db.update(update, doc_ids=iter([99, 1]))


@pytest.mark.parametrize('cached', [False, True])
@pytest.mark.parametrize('callable_update', [False, True])
def test_mixed_batches_persist_after_reopening(tmp_path, cached, callable_update):
    path = tmp_path / 'stale-ids.json'
    with TinyDB(path) as db:
        first, stale, second, survivor = db.insert_multiple(
            {'value': value} for value in range(4)
        )
        db.remove(doc_ids=[stale])
        db.table('other').insert({'unchanged': True})

    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        old_query = where('value') < 3
        new_query = where('value') == 10
        assert len(db.search(old_query)) == 2
        assert db.search(new_query) == []

        def update(document):
            document['value'] = 10

        fields = update if callable_update else {'value': 10}
        ids = iter([stale, second, 99, first, stale])
        assert db.update(fields, doc_ids=ids) == [second, first]
        assert db.search(old_query) == []
        assert [doc.doc_id for doc in db.search(new_query)] == [first, second]

    with TinyDB(path) as db:
        assert db.get(doc_id=first) == {'value': 10}
        assert db.get(doc_id=second) == {'value': 10}
        assert db.get(doc_id=survivor) == {'value': 3}
        assert db.get(doc_id=stale) is None
        assert db.table('other').all() == [{'unchanged': True}]

    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        query = where('value') == 10
        assert len(db.search(query)) == 2
        ids = iter([stale, second, 99, first, stale])
        assert db.remove(doc_ids=ids) == [second, first]
        assert db.search(query) == []

    with TinyDB(path) as db:
        assert db.all() == [{'value': 3}]
        assert db.all()[0].doc_id == survivor
        assert db.table('other').all() == [{'unchanged': True}]

    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        assert db.upsert(Document({'updated': True}, survivor)) == [survivor]
        assert db.upsert(Document({'restored': True}, first)) == [first]

    with TinyDB(path) as db:
        assert db.get(doc_id=survivor) == {'value': 3, 'updated': True}
        assert db.get(doc_id=first) == {'restored': True}
        assert len(db) == 2
