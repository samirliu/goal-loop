import inspect
import os
from pathlib import Path
import subprocess
import sys
import attr
import attrs
import pytest


@pytest.mark.parametrize('slots',[False,True])
@pytest.mark.parametrize('frozen',[False,True])
def test_modern_record_hierarchy_signatures_aliases_and_matching(slots,frozen):
    @attrs.define(slots=slots,frozen=frozen)
    class Entity:
        identifier: int
    @attrs.define(slots=slots,frozen=frozen,kw_only=True)
    class Order(Entity):
        _amount: int = attrs.field(alias='amount',kw_only=False)
        state: str = 'pending'
    @attrs.define(slots=slots,frozen=frozen)
    class AuditedOrder(Order):
        revision: int = 1
    order=AuditedOrder(17,500,revision=3,state='open')
    assert (order.identifier,order._amount,order.state,order.revision)==(17,500,'open',3)
    params=inspect.signature(AuditedOrder).parameters
    for name in ('identifier','amount','revision'):
        assert params[name].kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert params['state'].kind is inspect.Parameter.KEYWORD_ONLY
    assert AuditedOrder.__match_args__ == ('identifier','_amount','revision')
    assert attrs.fields(AuditedOrder).identifier.kw_only is False
    assert attrs.fields(AuditedOrder)._amount.kw_only is False
    assert attrs.fields(AuditedOrder).state.kw_only is True
    with pytest.raises(TypeError):
        Order(1,2,'open')
    assert attrs.evolve(order,amount=600)._amount == 600


@pytest.mark.parametrize('decorate,force',[(attr.s,False),(attrs.define,True)])
def test_explicit_compatibility_switch_works_across_apis(decorate,force):
    @attr.s
    class Base:
        identifier=attr.ib()
    @decorate(kw_only=True,force_kw_only=force)
    class Child(Base):
        amount=attr.ib(kw_only=False)
        tag=attr.ib()
    params=inspect.signature(Child).parameters
    expected=inspect.Parameter.KEYWORD_ONLY if force else inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert params['identifier'].kind is expected
    assert params['amount'].kind is expected
    assert params['tag'].kind is inspect.Parameter.KEYWORD_ONLY
    child=Child(identifier=9,amount=8,tag='x') if force else Child(9,8,tag='x')
    assert child.identifier == 9


def test_legacy_default_and_invalid_positional_order_are_preserved():
    @attr.s
    class Base:
        base=attr.ib(default=7)
    @attr.s(kw_only=True)
    class Legacy(Base):
        required=attr.ib(kw_only=False)
    assert Legacy(required=2).base == 7
    with pytest.raises(TypeError):
        Legacy(7,required=2)
    with pytest.raises(ValueError,match='mandatory'):
        @attrs.define(kw_only=True)
        class Broken:
            optional: int=attrs.field(default=1,kw_only=False)
            required: int=attrs.field(kw_only=False)


def test_downstream_field_stubs_accept_unspecified_kw_only(tmp_path):
    source=tmp_path/'consumer.py'
    source.write_text('import attr\nimport attrs\na = attrs.field(kw_only=None)\nb = attr.ib(kw_only=None)\n')
    env={**os.environ,'MYPYPATH':str(Path(__file__).resolve().parent/'src')}
    config=tmp_path/'mypy.ini'
    config.write_text('[mypy]\nfollow_imports = silent\n')
    command=[sys.executable,'-m','mypy','--config-file',str(config),'--no-incremental','--cache-dir',str(tmp_path/'cache'),str(source)]
    result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=25)
    assert result.returncode==0,result.stdout+result.stderr
    source.write_text('import attrs\nattrs.field(kw_only="yes")\n')
    invalid=subprocess.run(command,env=env,capture_output=True,text=True,timeout=25)
    assert invalid.returncode!=0
    assert 'kw_only' in invalid.stdout
