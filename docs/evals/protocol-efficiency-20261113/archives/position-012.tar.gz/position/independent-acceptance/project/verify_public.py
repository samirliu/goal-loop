from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))
import inspect
import attrs

@attrs.define
class Record:
    key: int
@attrs.define(kw_only=True)
class NamedRecord(Record):
    name: str
record = NamedRecord(7, name='seven')
assert record.key == 7 and record.name == 'seven'
assert inspect.signature(NamedRecord).parameters['key'].kind is inspect.Parameter.POSITIONAL_OR_KEYWORD

print('public check passed')
