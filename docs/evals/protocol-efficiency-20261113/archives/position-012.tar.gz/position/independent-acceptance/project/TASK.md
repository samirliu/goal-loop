# Migrate keyword-only inheritance without breaking the legacy API

The modern attrs API needs dataclasses-style keyword-only behavior. Currently a class-level `kw_only=True` also changes inherited positional fields and ignores an explicit field-level `kw_only=False`. Implement the migration while preserving the legacy `attr.s` behavior by default.

Required contract:

- For modern `attrs.define` / `attr.define` (and derived modern decorators), class-level `kw_only=True` affects only fields introduced in that class whose field setting is unspecified. Explicit field-level `kw_only=False` stays positional; inherited fields keep their previous setting. These rules must hold across multiple inheritance levels, with slots and without them.
- Expose a class-decorator `force_kw_only` compatibility switch. `True` restores the previous behavior of forcing all inherited and own fields to keyword-only when the class requests `kw_only=True`. Default it to `False` for modern decorators and `True` for legacy `attr.s` / `attr.attrs`. An explicit switch must allow either API to select either behavior.
- Resolved `Attribute.kw_only`, generated constructors, `__match_args__`, and aliases must agree. Public field type stubs must accept `None` as the unspecified keyword-only setting. Ordinary defaults/factories, frozen classes and generated init behavior remain compatible. Keep the existing error for a mandatory positional field following a positional field with a default.

The public check demonstrates a positional base field inherited into a modern keyword-only subclass. Add focused tests as useful.

The evaluation controller provides `TASK_PYTHON`, the prepared local interpreter. From the project root run `"$TASK_PYTHON" verify_public.py`. Dependencies are already installed; no package installation is necessary. You have 780 execution seconds and at most two internal workers; final acceptance has a separate 120-second allowance.

Keep implementation edits within the package source and tests. Do not change `TASK.md`, `verify_public.py`, dependency/environment files, or unrelated documentation. A hidden behavior grader also runs genuine upstream regression/integration tests.
