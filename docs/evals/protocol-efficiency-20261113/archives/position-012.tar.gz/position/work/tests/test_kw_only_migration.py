# SPDX-License-Identifier: MIT

"""Keyword-only defaults and compatibility across the public APIs."""

import inspect

import pytest

import attr
import attrs

from attr._compat import PY_3_10_PLUS


@pytest.mark.parametrize(
    "decorator",
    [
        attrs.define,
        attr.define,
        attrs.mutable,
        attr.mutable,
        attrs.frozen,
        attr.frozen,
    ],
)
def test_modern_fields_and_aliases(decorator, slots):
    """Own defaults, explicit positional fields, and inherited fields agree."""

    @decorator(slots=slots)
    class Base:
        _key: int = attrs.field(alias="key")
        base_kw: int = attrs.field(default=11, kw_only=True)

    @decorator(kw_only=True, slots=slots)
    class Child(Base):
        name: str
        _value: int = attrs.field(kw_only=False, alias="value")
        count: int = 3
        items: list = attrs.field(factory=list, kw_only=None)
        hidden: int = attrs.field(init=False, default=42)

    fields = attrs.fields(Child)
    assert [False, True, True, False, True, True, True] == [
        field.kw_only for field in fields
    ]
    assert all(isinstance(field.kw_only, bool) for field in fields)
    assert attrs.fields(Base)._key.kw_only is False
    assert fields._key.inherited is True
    assert fields._value.inherited is False
    if PY_3_10_PLUS:
        assert ("_key", "_value") == Child.__match_args__
    parameters = inspect.signature(Child).parameters
    assert ["key", "value", "base_kw", "name", "count", "items"] == list(
        parameters
    )
    assert parameters["key"].kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert parameters["value"].kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert parameters["name"].kind is inspect.Parameter.KEYWORD_ONLY

    child = Child(1, 2, name="child")
    assert (1, 2, "child", 11, 3, [], 42) == (
        child._key,
        child._value,
        child.name,
        child.base_kw,
        child.count,
        child.items,
        child.hidden,
    )
    assert child.items is not Child(1, 2, name="other").items
    with pytest.raises(TypeError):
        Child(1, 2, "child")


@pytest.mark.parametrize(
    ("decorator", "default_force"),
    [
        (attr.s, True),
        (attr.attrs, True),
        (attr.attributes, True),
        (attr.dataclass, True),
        (attrs.define, False),
        (attrs.mutable, False),
        (attrs.frozen, False),
        (attr.define, False),
        (attr.frozen, False),
    ],
)
@pytest.mark.parametrize("force_kw_only", [None, False, True])
@pytest.mark.parametrize("kw_only", [False, True])
def test_compatibility_switch(
    decorator, default_force, force_kw_only, kw_only, slots
):
    """Both decorator families can select either keyword-only policy."""
    options = {} if force_kw_only is None else {"force_kw_only": force_kw_only}
    force = default_force if force_kw_only is None else force_kw_only

    @decorator(slots=slots)
    class Base:
        inherited: int = attr.ib(kw_only=False)

    @decorator(slots=slots, kw_only=kw_only, **options)
    class Child(Base):
        unspecified: int = attr.ib(kw_only=None)
        positional: int = attr.ib(kw_only=False)
        keyword: int = attr.ib(kw_only=True)

    expected = [kw_only and force, kw_only, kw_only and force, True]
    fields = attrs.fields(Child)
    assert expected == [field.kw_only for field in fields]
    assert attrs.fields(Base).inherited.kw_only is False
    if PY_3_10_PLUS:
        assert tuple(
            field.name for field in fields if not field.kw_only
        ) == Child.__match_args__
    values = dict(inherited=1, unspecified=2, positional=3, keyword=4)
    args = [values[field.name] for field in fields if not field.kw_only]
    kwargs = {
        field.alias: values[field.name] for field in fields if field.kw_only
    }
    assert (1, 2, 3, 4) == attrs.astuple(Child(*args, **kwargs))
    assert all(
        inspect.signature(Child).parameters[field.alias].kind
        is (
            inspect.Parameter.KEYWORD_ONLY
            if field.kw_only
            else inspect.Parameter.POSITIONAL_OR_KEYWORD
        )
        for field in fields
    )


@pytest.mark.parametrize("force_middle", [False, True])
@pytest.mark.parametrize("kw_leaf", [False, True])
def test_effective_settings_survive_multiple_levels(
    slots, frozen, force_middle, kw_leaf
):
    """A leaf preserves its parent's settings, including forced ones."""

    @attrs.define(slots=slots, frozen=frozen)
    class Base:
        key: int

    @attrs.define(
        slots=slots,
        frozen=frozen,
        kw_only=True,
        force_kw_only=force_middle,
    )
    class Middle(Base):
        middle: int = attrs.field(kw_only=None)
        positional: int = attrs.field(kw_only=False)

    @attrs.define(slots=slots, frozen=frozen, kw_only=kw_leaf)
    class Leaf(Middle):
        leaf: int

    @attrs.define(slots=slots, frozen=frozen)
    class Last(Leaf):
        last: int

    assert [force_middle, True, force_middle] == [
        field.kw_only for field in attrs.fields(Middle)
    ]
    assert [force_middle, True, force_middle, kw_leaf, False] == [
        field.kw_only for field in attrs.fields(Last)
    ]
    assert attrs.fields(Base).key.kw_only is False
    assert (1, 2, 3, 4, 5) == attrs.astuple(
        Last(key=1, middle=2, positional=3, leaf=4, last=5)
    )


def test_diamond_respects_field_declaration(slots):
    """An inherited setting cannot shadow another branch's own declaration."""

    @attrs.define(slots=False)
    class Base:
        key: int = 1

    @attrs.define(slots=False, kw_only=True, force_kw_only=True)
    class Left(Base):
        left: int = 2

    @attrs.define(slots=False)
    class Right(Base):
        key: int = attrs.field(default=3, kw_only=False)
        right: int = 4

    @attrs.define(slots=slots, kw_only=True)
    class Leaf(Left, Right):
        leaf: int = 5

    assert ["key", "right", "left", "leaf"] == [
        field.name for field in attrs.fields(Leaf)
    ]
    assert [False, False, True, True] == [
        field.kw_only for field in attrs.fields(Leaf)
    ]
    if PY_3_10_PLUS:
        assert ("key", "right") == Leaf.__match_args__
    assert (6, 7, 2, 5) == attrs.astuple(Leaf(6, 7))
    assert attrs.fields(Left).key.kw_only is True
    assert attrs.fields(Right).key.kw_only is False


@pytest.mark.parametrize("decorator", [attrs.define, attr.s])
@pytest.mark.parametrize("factory", [False, True])
def test_positional_default_still_rejects_mandatory_field(
    decorator, slots, factory
):
    """Keyword-only defaults preserve positional argument ordering rules."""
    default = {"factory": int} if factory else {"default": 0}

    @decorator(slots=slots)
    class Base:
        value = attrs.field(**default)

    with pytest.raises(ValueError, match="No mandatory attributes allowed"):

        @decorator(slots=slots, kw_only=True, force_kw_only=False)
        class Child(Base):
            required = attrs.field(kw_only=False)

    @decorator(slots=slots, kw_only=True, force_kw_only=False)
    class Valid(Base):
        required = attrs.field()

    assert (0, 1) == attrs.astuple(Valid(required=1))


def test_generated_attrs_init(slots, frozen):
    """Custom init keeps aliases, conversion, and factories working."""

    @attrs.define(slots=slots, frozen=frozen)
    class Base:
        _key: int = attrs.field(alias="key", converter=int)

    @attrs.define(slots=slots, frozen=frozen, kw_only=True, init=False)
    class Child(Base):
        name: str = attrs.field(converter=str)
        code: int = attrs.field(kw_only=False, default=3)
        items: list = attrs.field(factory=list)
        derived: str = attrs.field(
            init=False,
            default=attrs.Factory(
                lambda self: f"{self.name}:{self._key}", takes_self=True
            ),
        )

        def __init__(self, key, name):
            self.__attrs_init__(key, name=name)

    child = Child("1", 2)
    assert (1, "2", 3, [], "2:1") == attrs.astuple(child)
    params = inspect.signature(Child.__attrs_init__).parameters
    assert ["self", "key", "code", "name", "items"] == list(params)
    assert params["key"].kind is inspect.Parameter.POSITIONAL_OR_KEYWORD
    assert params["name"].kind is inspect.Parameter.KEYWORD_ONLY
    if frozen:
        with pytest.raises(attrs.exceptions.FrozenInstanceError):
            child.name = "changed"


def test_redeclared_fields_use_own_class_default(slots):
    """Redeclaring a field resolves its setting from the new class."""

    @attrs.define(slots=slots, kw_only=True)
    class Base:
        key: int

    @attrs.define(slots=slots)
    class Child(Base):
        key: int = attrs.field(kw_only=None)

    @attrs.define(slots=slots, kw_only=True)
    class Leaf(Child):
        name: str

    assert attrs.fields(Base).key.kw_only is True
    assert attrs.fields(Child).key.kw_only is False
    assert attrs.fields(Leaf).key.kw_only is False
    assert (1, "name") == attrs.astuple(Leaf(1, name="name"))


def test_these_and_reused_field(slots):
    """An unspecified field can be reused under different class defaults."""
    shared = attrs.field()

    @attrs.define(
        slots=slots,
        kw_only=True,
        these={"key": shared, "value": attrs.field(kw_only=False)},
    )
    class Keyword:
        pass

    @attrs.define(slots=slots, these={"key": shared})
    class Positional:
        pass

    assert attrs.fields(Keyword).key.kw_only is True
    assert attrs.fields(Keyword).value.kw_only is False
    assert attrs.fields(Positional).key.kw_only is False
    assert (1, 2) == attrs.astuple(Keyword(2, key=1))
    assert (3,) == attrs.astuple(Positional(3))
