from dataclasses import dataclass
from typing import Literal, Union

import pytest
from attrs import define
from cattrs import BaseConverter, Converter
from cattrs.disambiguators import create_default_dis_func
from cattrs.gen import make_dict_structure_fn, make_dict_unstructure_fn, override


@pytest.mark.parametrize('converter_cls', [BaseConverter, Converter])
@pytest.mark.parametrize('detailed', [True, False])
@pytest.mark.parametrize('decorate', [define, dataclass])
@pytest.mark.parametrize('wire_key', ['event/type', ''])
def test_event_batch_roundtrip(converter_cls, detailed, decorate, wire_key):
    @decorate
    class Approved:
        kind: Literal['approved']
        amount: int
    @decorate
    class Rejected:
        kind: Literal['rejected']
        amount: int
    converter = converter_cls(detailed_validation=detailed)
    for cls in (Approved, Rejected):
        overrides = {'kind': override(rename=wire_key), 'amount': override(rename='gross')}
        converter.register_structure_hook(cls, make_dict_structure_fn(cls, converter, **overrides))
        converter.register_unstructure_hook(cls, make_dict_unstructure_fn(cls, converter, **overrides))
    events = [Approved('approved', 130), Rejected('rejected', 0), Approved('approved', 2)]
    payload = [converter.unstructure(event) for event in events]
    assert payload == [{wire_key:'approved','gross':130},{wire_key:'rejected','gross':0},{wire_key:'approved','gross':2}]
    assert converter.structure(payload, list[Union[Approved, Rejected]]) == events


def test_unknown_literal_is_not_silently_selected():
    @define
    class Opened:
        kind: Literal['opened']
    @define
    class Closed:
        kind: Literal['closed']
    choose = create_default_dis_func(Converter(), Opened, Closed, overrides={'kind':override(rename='wire')})
    assert choose({'wire':'opened'}) is Opened
    assert choose({'wire':'closed'}) is Closed
    with pytest.raises(KeyError):
        choose({'wire':'other'})
    with pytest.raises(KeyError):
        choose({'kind':'opened'})


@pytest.mark.parametrize('detailed', [False, True])
def test_different_serialized_keys_fall_back_to_unique_field(detailed):
    @define
    class Receipt:
        kind: Literal['receipt']
    @define
    class Invoice:
        kind: Literal['invoice']
    converter = Converter(detailed_validation=detailed)
    for cls, key in [(Receipt,'receiptKind'),(Invoice,'invoiceKind')]:
        converter.register_structure_hook(cls,make_dict_structure_fn(cls,converter,kind=override(rename=key)))
    assert converter.structure({'receiptKind':'receipt'},Union[Receipt,Invoice]) == Receipt('receipt')
    assert converter.structure({'invoiceKind':'invoice'},Union[Receipt,Invoice]) == Invoice('invoice')
