# Goal

## Objective

Repair cattrs union selection to honor serialized discriminator names from generated hook overrides and explicit overrides, including attrs/dataclasses, both converters, validation modes, shared and distinct wire keys, and the empty-string key. Preserve literal discrimination, ordinary unions, and invalid or ambiguous input errors. Review the implementation and run focused and existing regression tests.

## Acceptance criteria

- AC-1 | Renamed event round trips through generated cattrs hooks and union selection | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python PYTHONDONTWRITEBYTECODE=1 /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 0eb559a0 2026-11-13 auto
