# work-plan (controller ticks; NEVER a GO signal)

# format: - [ ] T1 <scope> | owner=<name> | files=<paths>
# done:   - [x] T1 ...

- [x] T1 Repair serialized union discriminator selection and verify regressions | owner=controller | files=src/cattrs/disambiguators.py,tests/test_disambiguators.py
