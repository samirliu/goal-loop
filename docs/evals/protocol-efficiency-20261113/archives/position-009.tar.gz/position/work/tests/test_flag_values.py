import pytest

import click
from click.core import ParameterSource


def flag_command(**attrs):
    @click.command()
    @click.option("--value", is_flag=True, **attrs)
    def cli(value):
        return value

    return cli


@pytest.mark.parametrize("type", [None, bool, click.BOOL, click.types.BoolParamType()])
@pytest.mark.parametrize(
    ("attrs", "inactive", "active"),
    [
        ({}, False, True),
        ({"default": None}, False, True),
        ({"default": False}, False, True),
        ({"default": True}, True, False),
        ({"default": "false"}, False, True),
        ({"default": " TRUE "}, True, False),
        ({"flag_value": None}, False, True),
        ({"flag_value": False}, False, False),
        ({"flag_value": True}, False, True),
        ({"default": True, "flag_value": False}, True, False),
        ({"default": False, "flag_value": False}, False, False),
        ({"default": None, "flag_value": False}, False, False),
        ({"default": True, "flag_value": True}, True, True),
    ],
)
def test_boolean_flag_values(runner, type, attrs, inactive, active):
    cli = flag_command(type=type, **attrs)
    for args, expected in [([], inactive), (["--value"], active)]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value is expected


@pytest.mark.parametrize("type", [str, click.STRING, click.types.StringParamType()])
@pytest.mark.parametrize(
    ("attrs", "inactive", "active"),
    [
        ({}, "False", "True"),
        ({"default": None}, "False", "True"),
        ({"default": False}, "False", "True"),
        ({"default": True}, "True", "True"),
        ({"default": "standby"}, "standby", "True"),
        ({"default": ""}, "", "True"),
        ({"flag_value": None}, "False", "True"),
        ({"flag_value": False}, "False", "False"),
        ({"flag_value": "live"}, "False", "live"),
        ({"default": "standby", "flag_value": "live"}, "standby", "live"),
        ({"default": None, "flag_value": "live"}, "False", "live"),
        ({"default": "standby", "flag_value": False}, "standby", "False"),
        ({"default": "standby", "flag_value": ""}, "standby", ""),
        ({"default": True, "flag_value": "live"}, "live", "live"),
    ],
)
def test_string_flag_values(runner, type, attrs, inactive, active):
    cli = flag_command(type=type, **attrs)
    for args, expected in [([], inactive), (["--value"], active)]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value == expected
        assert isinstance(result.return_value, str)


@pytest.mark.parametrize(
    ("attrs", "inactive", "active"),
    [
        ({"flag_value": "live"}, "False", "live"),
        ({"default": "standby", "flag_value": "live"}, "standby", "live"),
        ({"flag_value": 8}, 0, 8),
        ({"default": 4, "flag_value": 8}, 4, 8),
    ],
)
def test_inferred_flag_values(runner, attrs, inactive, active):
    cli = flag_command(**attrs)
    for args, expected in [([], inactive), (["--value"], active)]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value == expected


@pytest.mark.parametrize("type", [bool, click.BOOL])
@pytest.mark.parametrize("invalid", ["invalid", "", 2, [], {"value": True}])
@pytest.mark.parametrize("attribute", ["default", "flag_value"])
def test_invalid_boolean_flag_values(runner, type, invalid, attribute):
    cli = flag_command(type=type, **{attribute: invalid})
    args = ["--value"] if attribute == "flag_value" else []
    result = runner.invoke(cli, args)
    assert result.exit_code == 2
    assert "Invalid value for '--value'" in result.output
    assert "is not a valid boolean" in result.output


@pytest.mark.parametrize("token", ["1", "true", "t", "yes", "y", "on"])
@pytest.mark.parametrize("decorate", [str, str.upper, lambda s: f" \t{s.title()}\n"])
@pytest.mark.parametrize("type", [bool, str])
def test_true_flag_envvar(runner, token, decorate, type):
    attrs = {"flag_value": "live"} if type is str else {}
    cli = flag_command(type=type, envvar="FLAG_VALUE", **attrs)
    result = runner.invoke(
        cli, env={"FLAG_VALUE": decorate(token)}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == ("live" if type is str else True)


@pytest.mark.parametrize("token", ["0", "false", "f", "no", "n", "off"])
@pytest.mark.parametrize("decorate", [str, str.upper, lambda s: f" \t{s.title()}\n"])
@pytest.mark.parametrize("type", [bool, str])
def test_false_flag_envvar_overrides_default(runner, token, decorate, type):
    attrs = {"flag_value": "live", "default": "standby"} if type is str else {
        "default": True
    }
    cli = flag_command(type=type, envvar="FLAG_VALUE", **attrs)
    result = runner.invoke(
        cli, env={"FLAG_VALUE": decorate(token)}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == ("False" if type is str else False)


@pytest.mark.parametrize("env_value", [None, ""])
@pytest.mark.parametrize("type, default", [(bool, True), (str, "standby")])
def test_empty_flag_environment_uses_default(runner, env_value, type, default):
    cli = flag_command(type=type, default=default, envvar="FLAG_VALUE")
    result = runner.invoke(
        cli, env={"FLAG_VALUE": env_value}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == default


@pytest.mark.parametrize(
    ("flag_value", "env_value", "expected"),
    [
        ("live", "live", "live"),
        ("live", "LIVE", "False"),
        ("live", " live ", "False"),
        ("live", "unexpected", "False"),
        ("live", "   ", "False"),
        (" live ", " live ", " live "),
        ("false", "false", "false"),
        ("false", "False", "False"),
        ("off", "off", "off"),
        ("off", " OFF ", "False"),
        (None, "yes", "True"),
        (None, "no", "False"),
        (False, "yes", "False"),
        ("", "yes", ""),
    ],
)
def test_string_flag_environment_matching(runner, flag_value, env_value, expected):
    cli = flag_command(
        type=str, flag_value=flag_value, default="standby", envvar="FLAG_VALUE"
    )
    result = runner.invoke(
        cli, env={"FLAG_VALUE": env_value}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == expected


@pytest.mark.parametrize("is_flag", [False, True])
def test_boolean_environment_errors_remain_strict(runner, is_flag):
    @click.command()
    @click.option("--value", type=bool, is_flag=is_flag, envvar="FLAG_VALUE")
    def cli(value):
        return value

    result = runner.invoke(cli, env={"FLAG_VALUE": "unexpected"})
    assert result.exit_code == 2
    assert "is not a valid boolean" in result.output

    if is_flag:
        result = runner.invoke(
            cli, ["--value"], env={"FLAG_VALUE": "unexpected"}, standalone_mode=False
        )
        assert result.exception is None
        assert result.return_value is True


def test_cli_overrides_invalid_default(runner):
    cli = flag_command(type=bool, default="invalid", flag_value=True)
    result = runner.invoke(cli, ["--value"], standalone_mode=False)
    assert result.exception is None
    assert result.return_value is True


def test_string_flag_cli_overrides_environment(runner):
    cli = flag_command(type=str, flag_value="live", envvar="FLAG_VALUE")
    result = runner.invoke(
        cli, ["--value"], env={"FLAG_VALUE": "false"}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == "live"


@pytest.mark.parametrize("auto", [False, True])
def test_flag_envvar_precedence_and_source(runner, auto):
    @click.command()
    @click.option(
        "--value",
        is_flag=True,
        default=True,
        envvar=None if auto else ["FIRST", "VALUE"],
    )
    @click.pass_context
    def cli(ctx, value):
        return value, ctx.get_parameter_source("value")

    env = {"AUTO_VALUE": "false"} if auto else {"FIRST": "", "VALUE": "false"}
    result = runner.invoke(
        cli, env=env, auto_envvar_prefix="AUTO", standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == (False, ParameterSource.ENVIRONMENT)

    result = runner.invoke(
        cli, ["--value"], env=env, auto_envvar_prefix="AUTO", standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == (False, ParameterSource.COMMANDLINE)


def test_paired_boolean_environment_and_command_line(runner):
    @click.command()
    @click.option("--value/--no-value", default=True, envvar="FLAG_VALUE")
    def cli(value):
        return value

    for args, env, expected in [
        ([], "false", False),
        ([], "true", True),
        (["--value"], "false", True),
        (["--no-value"], "true", False),
    ]:
        result = runner.invoke(
            cli, args, env={"FLAG_VALUE": env}, standalone_mode=False
        )
        assert result.exception is None
        assert result.return_value is expected


def test_multiple_flags_and_ordinary_envvar_values(runner):
    @click.command()
    @click.option("--boolean", is_flag=True, multiple=True, envvar="BOOLEAN")
    @click.option(
        "--string", flag_value="live value", multiple=True, envvar="STRING"
    )
    @click.option("--ordinary", multiple=True, envvar="ORDINARY")
    def cli(boolean, string, ordinary):
        return boolean, string, ordinary

    result = runner.invoke(
        cli,
        env={"BOOLEAN": "true false", "STRING": "yes", "ORDINARY": "true false"},
        standalone_mode=False,
    )
    assert result.exception is None
    assert result.return_value == ((True, False), ("live value",), ("true", "false"))

    result = runner.invoke(cli, ["--string", "--string"], standalone_mode=False)
    assert result.exception is None
    assert result.return_value == ((), ("live value", "live value"), ())


def test_grouped_flag_default_marker(runner):
    @click.command()
    @click.option("--upper", "case", flag_value="upper", default=True)
    @click.option("--lower", "case", flag_value="lower")
    def cli(case):
        return case

    for args, expected in [([], "upper"), (["--lower"], "lower")]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value == expected


def test_flag_default_map_and_metadata(runner):
    cli = flag_command(type=str, default="standby", flag_value="live")
    result = runner.invoke(cli, default_map={"value": "mapped"}, standalone_mode=False)
    assert result.exception is None
    assert result.return_value == "mapped"
    info = cli.params[0].to_info_dict()
    assert info["default"] == "standby"
    assert info["flag_value"] == "live"
    assert info["is_flag"] is True
    assert info["type"] == {"param_type": "String", "name": "text"}


def test_required_flag_still_requires_a_value(runner):
    cli = flag_command(type=bool, required=True)
    result = runner.invoke(cli)
    assert result.exit_code == 2
    assert "Missing option '--value'" in result.output
