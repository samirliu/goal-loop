import pytest

from tinydb import TinyDB, where
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from tinydb.table import Document


@pytest.mark.parametrize('target_ids', [
    [999, 2, 1],
    [2, 999, 1],
    [2, 1, 999],
    [998, 2, 999, 1, 1000],
])
@pytest.mark.parametrize('one_shot', [False, True])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_mixed_stale_ids(db, target_ids, one_shot, operation):
    old_query = where('int') == 1
    new_query = where('int') == 2
    assert len(db.search(old_query)) == 3
    assert db.search(new_query) == []
    ids = iter(target_ids) if one_shot else target_ids
    called = []

    def update(document):
        called.append(document['char'])
        document['int'] += 1

    if operation == 'remove':
        result = db.remove(doc_ids=ids)
        assert db.get(doc_ids=[1, 2]) == []
    else:
        fields = update if operation == 'callable' else {'int': 2}
        result = db.update(fields, doc_ids=ids)
        assert db.get(doc_id=1) == {'int': 2, 'char': 'a'}
        assert db.get(doc_id=2) == {'int': 2, 'char': 'b'}

    assert result == [2, 1]
    assert [doc.doc_id for doc in db.search(old_query)] == [3]
    expected_new = [] if operation == 'remove' else [1, 2]
    assert [doc.doc_id for doc in db.search(new_query)] == expected_new
    assert db.get(doc_id=3) == {'int': 1, 'char': 'c'}
    assert called == (['b', 'a'] if operation == 'callable' else [])


@pytest.mark.parametrize('target_ids', [[], [999], [998, 999]])
@pytest.mark.parametrize('empty_table', [False, True])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_stale_ids_without_existing_targets(db, target_ids, empty_table,
                                          operation):
    if empty_table:
        db.truncate()
    before = [(doc.doc_id, dict(doc)) for doc in db]

    def unexpected_update(document):
        pytest.fail('Callable must not run for missing documents')

    ids = iter(target_ids)
    if operation == 'remove':
        result = db.remove(doc_ids=ids)
    else:
        fields = unexpected_update if operation == 'callable' else {'int': 2}
        result = db.update(fields, doc_ids=ids)

    assert result == []
    assert [(doc.doc_id, dict(doc)) for doc in db] == before


@pytest.mark.parametrize('cached', [False, True])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_stale_ids_persist_after_reopening(tmp_path, cached, operation):
    path = tmp_path / 'stale.json'
    documents = {
        11: {'status': 'pending', 'attempts': 0},
        22: {'status': 'pending', 'attempts': 0},
        33: {'status': 'pending', 'attempts': 0},
    }
    with TinyDB(path) as db:
        db.insert_multiple(Document(doc, doc_id) for doc_id, doc
                           in documents.items())

    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        pending = where('status') == 'pending'
        done = where('status') == 'done'
        assert len(db.search(pending)) == 3
        assert db.search(done) == []
        ids = iter([999, 33, 998, 11, 997])

        def update(document):
            document['status'] = 'done'
            document['attempts'] += 1

        if operation == 'remove':
            assert db.remove(doc_ids=ids) == [33, 11]
            del documents[11]
            del documents[33]
            assert db.search(done) == []
        else:
            fields = update if operation == 'callable' else {'status': 'done'}
            assert db.update(fields, doc_ids=ids) == [33, 11]
            for doc_id in [11, 33]:
                documents[doc_id]['status'] = 'done'
                if operation == 'callable':
                    documents[doc_id]['attempts'] += 1
            assert [doc.doc_id for doc in db.search(done)] == [11, 33]
        assert [doc.doc_id for doc in db.search(pending)] == [22]

    # Reopen without middleware to verify that close flushed the full result.
    with TinyDB(path) as db:
        assert {doc.doc_id: dict(doc) for doc in db} == documents


@pytest.mark.parametrize('cached', [False, True])
def test_upsert_explicit_id_persists(tmp_path, cached):
    path = tmp_path / 'upsert.json'
    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        assert db.upsert(Document({'status': 'old', 'keep': True}, 41)) == [41]
        assert db.upsert(Document({'status': 'updated'}, 41)) == [41]
        assert db.upsert(Document({'status': 'new'}, 99)) == [99]
        assert db.insert({'status': 'next'}) == 100

    with TinyDB(path) as db:
        assert {doc.doc_id: dict(doc) for doc in db} == {
            41: {'status': 'updated', 'keep': True},
            99: {'status': 'new'},
            100: {'status': 'next'},
        }


def test_remove_repeated_ids_skips_already_removed_documents(db):
    assert db.remove(doc_ids=iter([2, 999, 1, 2])) == [2, 1]
    assert [doc.doc_id for doc in db] == [3]
