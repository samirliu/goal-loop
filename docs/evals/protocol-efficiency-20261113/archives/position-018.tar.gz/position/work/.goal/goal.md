# Goal

## Objective

Make explicit-ID TinyDB update and removal skip missing IDs in every batch position, return only affected IDs, and finish all existing targets. Support mapping and callable updates and one-shot ID iterables. Preserve condition-based and unconditional behavior and explicit-Document upsert. Missing-only batches must return an empty list without document changes; mixed operations must invalidate query caches and persist complete results through JSON storage and caching middleware after close/reopen. Callback-exception rollback is outside this requirement. Implement only package/test changes and verify with focused and existing regression tests.

## Acceptance criteria

- AC-1 | Stale-ID batches update existing targets successfully; complete business behavior is reviewed with regression and persistence tests | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python PYTHONDONTWRITEBYTECODE=1 /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: f5bd54b5 2026-11-13 auto
