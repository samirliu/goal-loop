# pre-reg.md — seeded at stamp 2026-11-13

# pre-reg.md — generated at stamp

T0 = 2026-11-13T18:23:13
budget: max_iterations=<> wallclock=<seconds or off>

## Hypothesis and counterevidence

Change <one mechanism> because <raw trace + failing reproducer>.
Predict <metric movement>; reject if <observable failure condition>.
First measured score anchors the trajectory; it does not prove a strategy.

## Strategy labels (objective contracts)

Derive 2–4 short labels from this objective; one primary label per wave.
For each: expected benefit / failure condition / scope of applicability.
`prefer=none` means gather evidence; do not guess a winning label.
Joint crew results belong to the wave, not to individual workers.

## Kill lines

- `iteration=0` with landed work or >=50% wallclock: close books before dispatch.
- Retry `avoid=` without a changed hypothesis and `strategy_delta`.
- Claim without adversarial clear, raw output, or untouched check scripts.
- Change the metric/check mid-run to raise the score.

## Success digits

Report accepted deliveries / all trials, score trajectory, and gate evidence.
For efficiency: total elapsed time and token/cost telemetry including evals,
joins, retries and failures; unavailable values are unknown, never zero.
Wave count alone cannot establish cost efficiency or parallel speedup.

## Reusable-policy promotion (only when changing the skill/strategy itself)

Freeze baseline/candidate, graders, task split and equal budgets before trials.
Keep held-out answers away from workers; use paired fresh states and repeats.
Report acceptance rate + all-trial cost / accepted deliveries + median/p90
time to delivery; failures are budget-censored, not excluded.
Retain incumbent on floor regression or no held-out benefit; keep failed trials.

## Degrade line

On budget expiry: report what passes + remaining evidence gaps and continuation
paths. Only gate GO is completion; partial delivery is not GO.

## T1 preregistration

Observed baseline: verify_public.py exits 1 with KeyError: 999 between two existing targets, before _update_table writes storage or clears query caches.
Hypothesis: skip absent IDs inside the explicit-ID updater and collect only successful updates/removals; leave _update_table's commit/cache behavior intact.
Counterevidence: any remaining target skipped, incorrect returned IDs, callable invoked for a missing target, changed missing-only documents, stale query results, failed close/reopen, or an upsert/regression failure.
Execution: serial, no workers. Reserve time for actual source/test review, close-iteration, audit, and fresh Gate. Operation ID: context-i1-a8056a446223562af125.
Ruling: retain existing per-occurrence update order and snapshot the requested iterable once; missing IDs are skipped at application time. Reordering or deduplication would change existing callable behavior.
