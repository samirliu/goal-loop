# work-plan (controller ticks; NEVER a GO signal)

- [x] T1 Make stale-ID batches complete and persist | owner=controller | files=tinydb/table.py tests/test_stale_ids.py
