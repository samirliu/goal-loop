# mypy: disable-error-code="no-untyped-def,no-untyped-call,attr-defined"
import asyncio
import functools
import importlib
import inspect
import operator
import typing

import pytest

import tenacity
from tenacity import AsyncRetrying, RetryCallState, RetryError
from tenacity import asyncio as policies

from .test_asyncio import asynctest


def make_state():
    return RetryCallState(AsyncRetrying(), None, (), {})


@asynctest
async def test_async_strategy_exports_and_outcome_gating():
    module = importlib.import_module("tenacity.asyncio.retry")
    for name in (
        "retry_base",
        "retry_if_result",
        "retry_if_exception",
        "retry_any",
        "retry_all",
    ):
        assert getattr(policies, name) is getattr(module, name)
    assert tenacity.retry_if_result is not policies.retry_if_result  # type: ignore[comparison-overlap]
    with pytest.raises(TypeError):
        policies.retry_base()  # type: ignore[abstract]

    seen = []

    async def result_predicate(value):
        seen.append(value)
        return value == 42

    async def exception_predicate(error):
        seen.append(error)
        return isinstance(error, ValueError)

    result_policy = policies.retry_if_result(result_predicate)
    exception_policy = policies.retry_if_exception(exception_predicate)
    state = make_state()
    for policy in (result_policy, exception_policy):
        with pytest.raises(RuntimeError, match="before outcome was set"):
            await policy(state)
    state.set_result(42)
    assert await result_policy(state) is True
    assert await exception_policy(state) is False
    assert seen == [42]

    error = ValueError("temporary")
    state.set_exception((ValueError, error, None))
    assert await result_policy(state) is False
    assert await exception_policy(state) is True
    assert seen == [42, error]


@pytest.mark.parametrize("combine", [operator.or_, operator.and_])
@pytest.mark.parametrize("async_first", [False, True])
@pytest.mark.parametrize("first_result", [False, True])
@pytest.mark.parametrize("second_result", [False, True])
@asynctest
async def test_mixed_composition_short_circuits(
    combine, async_first, first_result, second_result
):
    seen = []

    def strategy(name, value, asynchronous):
        def predicate(result):
            seen.append(name)
            return value

        async def async_predicate(result):
            await asyncio.sleep(0)
            return predicate(result)

        if asynchronous:
            return policies.retry_if_result(async_predicate)
        return tenacity.retry_if_result(predicate)

    left = strategy("left", first_result, async_first)
    right = strategy("right", second_result, not async_first)
    state = make_state()
    state.set_result("value")
    assert await combine(left, right)(state) is combine(first_result, second_result)
    short_circuited = first_result if combine is operator.or_ else not first_result
    assert seen == (["left"] if short_circuited else ["left", "right"])


@asynctest
async def test_explicit_and_nested_composites():
    state = make_state()
    state.set_result(1)

    async def must_not_run(value):
        pytest.fail("short circuited predicate was called")

    skip = policies.retry_if_result(must_not_run)
    yes = tenacity.retry_always
    no = tenacity.retry_never
    assert await policies.retry_any()(state) is False
    assert await policies.retry_all()(state) is True
    assert await policies.retry_any(no, yes, skip)(state) is True
    assert await policies.retry_all(yes, no, skip)(state) is False
    assert await (no | (yes | skip))(state) is True
    assert await ((no & skip) | yes)(state) is True
    assert await (yes & (no & skip))(state) is False


@pytest.mark.parametrize("iterate", [False, True])
@pytest.mark.parametrize("return_awaitable", [False, True])
@asynctest
async def test_awaitable_policies_and_lifecycle_order(iterate, return_awaitable):
    events = []
    calls = 0

    def adapt(callback):
        if return_awaitable:
            return lambda *args: callback(*args)
        return callback

    async def before(state):
        await asyncio.sleep(0)
        events.append(("before", state.attempt_number))

    async def after(state):
        await asyncio.sleep(0)
        events.append(("after", state.attempt_number))

    async def before_sleep(state):
        await asyncio.sleep(0)
        assert state.next_action.sleep == 0.25
        events.append(("before_sleep", state.attempt_number))

    async def retry_policy(state):
        await asyncio.sleep(0)
        events.append(("retry", state.attempt_number))
        return state.outcome.result() < 3

    async def wait(state):
        await asyncio.sleep(0)
        events.append(("wait", state.attempt_number))
        return 0.25

    async def stop(state):
        await asyncio.sleep(0)
        assert state.upcoming_sleep == 0.25
        events.append(("stop", state.attempt_number))
        return state.attempt_number >= 4

    async def sleep(delay):
        await asyncio.sleep(0)
        assert delay == 0.25
        events.append(("sleep", None))

    async def work():
        nonlocal calls
        calls += 1
        events.append(("work", calls))
        return calls

    controller = AsyncRetrying(
        retry=adapt(retry_policy),
        wait=adapt(wait),
        stop=adapt(stop),
        before=adapt(before),
        after=adapt(after),
        before_sleep=adapt(before_sleep),
        sleep=sleep,
    )
    if iterate:
        async for attempt in controller:
            with attempt:
                result = await work()
            attempt.retry_state.set_result(result)
    else:
        result = await controller(work)
    assert result == 3
    assert calls == 3
    expected: typing.List[typing.Tuple[str, typing.Optional[int]]] = []
    for number in (1, 2):
        expected.extend(
            (name, number)
            for name in (
                "before", "work", "retry", "after", "wait", "stop", "before_sleep"
            )
        )
        expected.append(("sleep", None))
    expected.extend((name, 3) for name in ("before", "work", "retry"))
    assert events == expected
    assert controller.statistics["attempt_number"] == 3
    assert controller.statistics["idle_for"] == 0.5


@pytest.mark.parametrize("iterate", [False, True])
@pytest.mark.parametrize("finish", ["reraise", "retry_error", "callback"])
@asynctest
async def test_async_exception_retries_preserve_limits_and_exceptions(iterate, finish):
    error = ValueError("original exception")
    seen = []
    callback_seen = []
    sentinel = object()
    attempts = 0

    async def retry_error(exception):
        await asyncio.sleep(0)
        seen.append(exception)
        return True

    async def callback(state):
        await asyncio.sleep(0)
        callback_seen.append(state.outcome.exception())
        return sentinel

    async def work():
        nonlocal attempts
        attempts += 1
        raise error

    controller = AsyncRetrying(
        retry=policies.retry_if_exception(retry_error),
        stop=tenacity.stop_after_attempt(2),
        reraise=finish == "reraise",
        retry_error_callback=callback if finish == "callback" else None,
    )

    async def run():
        if iterate:
            async for attempt in controller:
                with attempt:
                    await work()
        else:
            return await controller(work)

    if finish == "callback":
        result = await run()
        if not iterate:
            assert result is sentinel
        assert callback_seen == [error]
    else:
        with pytest.raises(ValueError if finish == "reraise" else RetryError) as caught:
            await run()
        if finish == "reraise":
            assert caught.value is error
        else:
            assert caught.value.last_attempt.exception() is error
            assert caught.value.__cause__ is error
    assert attempts == 2
    assert seen == [error, error]


@pytest.mark.parametrize("iterate", [False, True])
@asynctest
async def test_nonretryable_exception_is_reraised_without_result_predicate(iterate):
    error = LookupError("do not retry")

    async def predicate(result):
        pytest.fail("result predicate ran for an exception")

    async def work():
        raise error

    controller = AsyncRetrying(retry=policies.retry_if_result(predicate))
    with pytest.raises(LookupError) as caught:
        if iterate:
            async for attempt in controller:
                with attempt:
                    await work()
        else:
            await controller(work)
    assert caught.value is error


@asynctest
async def test_future_policies_and_successful_awaitable_result():
    loop = asyncio.get_running_loop()
    value = loop.create_future()
    value.set_result("nested result")

    async def work():
        return value

    assert await AsyncRetrying(retry=tenacity.retry_never)(work) is value

    def resolved(result):
        future = loop.create_future()
        future.set_result(result)
        return future

    sentinel = object()
    controller = AsyncRetrying(
        retry=lambda state: resolved(True),
        wait=lambda state: resolved(0),
        stop=lambda state: resolved(state.attempt_number == 2),
        before=lambda state: resolved(None),
        after=lambda state: resolved(None),
        before_sleep=lambda state: resolved(None),
        retry_error_callback=lambda state: resolved(sentinel),
    )
    assert await controller(work) is sentinel
    assert controller.statistics["attempt_number"] == 2


@asynctest
async def test_decorator_dispatch_for_async_callables_and_partials():
    class Service:
        def __init__(self):
            self.calls = 0

        async def __call__(self, value=7):
            self.calls += 1
            if self.calls < 2:
                raise ValueError("temporary")
            return value

    targets: typing.Tuple[typing.Any, ...] = (
        Service(), functools.partial(Service(), 9)
    )
    for target in targets:
        wrapped = tenacity.retry(stop=tenacity.stop_after_attempt(2))(target)
        assert inspect.iscoroutinefunction(wrapped)
        assert isinstance(wrapped.retry, AsyncRetrying)
        assert inspect.unwrap(wrapped) is target
        assert await wrapped() in (7, 9)
        assert await wrapped.retry_with(stop=tenacity.stop_after_attempt(1))() in (7, 9)

    async def coroutine(value, *, multiplier=2):
        """Retained metadata."""
        return value * multiplier

    wrapped = tenacity.retry(functools.partial(coroutine, 3))
    assert isinstance(wrapped.retry, AsyncRetrying)
    assert await wrapped(multiplier=4) == 12
    decorated = tenacity.retry(coroutine)
    assert decorated.__name__ == coroutine.__name__
    assert decorated.__doc__ == coroutine.__doc__
    assert decorated.__kwdefaults__ == coroutine.__kwdefaults__
    assert inspect.unwrap(decorated) is coroutine

    def sync(value=5):
        return value

    decorated_sync = tenacity.retry(sync)
    assert not inspect.iscoroutinefunction(decorated_sync)
    assert isinstance(decorated_sync.retry, tenacity.Retrying)
    assert decorated_sync() == 5
    assert decorated_sync.__defaults__ == sync.__defaults__


@asynctest
async def test_concurrent_decorated_calls_keep_separate_policy_state():
    counts: typing.Dict[str, int] = {}

    async def pending(value):
        await asyncio.sleep(0)
        return value[1] < 2

    @tenacity.retry(
        retry=policies.retry_if_result(pending), stop=tenacity.stop_after_attempt(3)
    )
    async def work(key):
        counts[key] = counts.get(key, 0) + 1
        await asyncio.sleep(0)
        return key, counts[key]

    results = await asyncio.gather(work("a"), work("b"))
    assert list(results) == [("a", 2), ("b", 2)]
    assert counts == {"a": 2, "b": 2}
    assert work.retry.statistics["attempt_number"] == 2
