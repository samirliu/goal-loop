# Copyright 2016 Étienne Bersac
# Copyright 2016 Julien Danjou
# Copyright 2016 Joshua Harlow
# Copyright 2013-2014 Ray Holder
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Compatibility imports for the former private async controller module."""

from tenacity.asyncio import AsyncRetrying as AsyncRetrying
from tenacity.asyncio import WrappedFn as WrappedFn
from tenacity.asyncio import WrappedFnReturnT as WrappedFnReturnT
from tenacity.asyncio import asyncio_sleep as asyncio_sleep
