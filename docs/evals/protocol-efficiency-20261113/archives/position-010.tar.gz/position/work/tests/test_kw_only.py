# SPDX-License-Identifier: MIT

"""Keyword-only defaults and compatibility across decorator APIs."""

from inspect import Parameter, signature

import pytest

import attr
import attrs


MODERN_DECORATORS = (
    attrs.define,
    attrs.mutable,
    attrs.frozen,
    attr.define,
    attr.mutable,
    attr.frozen,
)


@pytest.mark.parametrize("decorator", MODERN_DECORATORS)
def test_modern_inheritance(decorator, slots):
    """Only unspecified fields introduced by the subclass use its default."""

    @decorator(slots=slots)
    class Base:
        key: int
        base_kw: int = attrs.field(kw_only=True)

    @decorator(slots=slots, kw_only=True)
    class Child(Base):
        implicit: int
        unspecified: int = attrs.field(kw_only=None)
        _positional: int = attrs.field(kw_only=False, alias="value")
        explicit: int = attrs.field(kw_only=True)
        default: int = 10
        items: list = attrs.field(factory=list)

    @decorator(slots=slots)
    class Grandchild(Child):
        last: int

    obj = Grandchild(
        1, 2, 3, base_kw=4, implicit=5, unspecified=6, explicit=7
    )
    assert attrs.astuple(obj) == (1, 4, 5, 6, 2, 7, 10, [], 3)
    expected = (False, True, True, True, False, True, True, True, False)
    assert tuple(a.kw_only for a in attrs.fields(Grandchild)) == expected
    assert tuple(a.kw_only for a in attrs.fields(Base)) == (False, True)
    assert Child.__match_args__ == ("key", "_positional")
    assert Grandchild.__match_args__ == ("key", "_positional", "last")
    parameters = signature(Grandchild).parameters
    assert parameters["value"].kind is Parameter.POSITIONAL_OR_KEYWORD
    assert parameters["last"].kind is Parameter.POSITIONAL_OR_KEYWORD
    assert parameters["unspecified"].kind is Parameter.KEYWORD_ONLY
    assert attrs.fields(Grandchild)._positional.alias == "value"
    assert obj.items is not Grandchild(
        1, 2, 3, base_kw=4, implicit=5, unspecified=6, explicit=7
    ).items
    with pytest.raises(TypeError):
        Grandchild(1, 2, 3, 4, implicit=5, unspecified=6, explicit=7)


@pytest.mark.parametrize("decorator", (attrs.define, attr.s, attr.attrs))
@pytest.mark.parametrize("force", (False, True, None))
def test_compatibility_switch(decorator, force, slots, frozen):
    """Both APIs can select either policy; each keeps its own default."""
    options = {} if force is None else {"force_kw_only": force}
    forced = decorator is not attrs.define if force is None else force

    @decorator(slots=slots, frozen=frozen)
    class Base:
        base = attr.ib()

    @decorator(slots=slots, frozen=frozen, kw_only=True, **options)
    class Child(Base):
        own = attr.ib()
        unspecified = attr.ib(kw_only=None)
        positional = attr.ib(kw_only=False)

    assert tuple(a.kw_only for a in attr.fields(Child)) == (
        forced, True, True, forced
    )
    assert attr.fields(Base).base.kw_only is False
    if forced:
        obj = Child(base=1, own=2, unspecified=3, positional=4)
        assert Child.__match_args__ == ()
        with pytest.raises(TypeError):
            Child(1, 4, own=2, unspecified=3)
    else:
        obj = Child(1, 4, own=2, unspecified=3)
        assert Child.__match_args__ == ("base", "positional")
    assert attr.astuple(obj) == (1, 2, 3, 4)


@pytest.mark.parametrize("force", (False, True))
@pytest.mark.parametrize("field", (attrs.field, attr.ib))
def test_force_requires_class_kw_only(force, field, slots):
    """The switch alone does not make positional fields keyword-only."""

    @attrs.define(slots=slots, force_kw_only=force)
    class C:
        implicit = field()
        unspecified = field(kw_only=None)
        positional = field(kw_only=False)
        keyword = field(kw_only=True)

    assert tuple(a.kw_only for a in attrs.fields(C)) == (
        False, False, False, True
    )
    assert attrs.astuple(C(1, 2, 3, keyword=4)) == (1, 2, 3, 4)


def test_multiple_inheritance():
    """Each inherited field keeps its setting through an MRO diamond."""

    @attrs.define(slots=False)
    class Root:
        root: int

    @attrs.define(slots=False, kw_only=True)
    class Left(Root):
        left: int

    @attrs.define(slots=False)
    class Right(Root):
        right: int

    @attrs.define(slots=False, kw_only=True)
    class Child(Left, Right):
        child: int

    obj = Child(1, 2, left=3, child=4)
    assert (obj.root, obj.right, obj.left, obj.child) == (1, 2, 3, 4)
    assert Child.__match_args__ == ("root", "right")
    assert tuple(a.kw_only for a in attrs.fields(Child)) == (
        False, False, True, True
    )


def test_override_inherited_field(slots):
    """Redeclaring a field lets the subclass choose a new setting."""

    @attrs.define(slots=slots, kw_only=True)
    class Base:
        key: int

    @attrs.define(slots=slots, kw_only=True)
    class Child(Base):
        key: int = attrs.field(kw_only=False)
        extra: int

    assert Child(1, extra=2).key == 1
    assert Child.__match_args__ == ("key",)
    assert attrs.fields(Base).key.kw_only is True
    assert attrs.fields(Child).key.kw_only is False


@pytest.mark.parametrize("factory", (False, True))
def test_positional_order_error(factory, slots):
    """An explicit positional mandatory field cannot follow a default."""
    default = attrs.field(factory=int) if factory else attrs.field(default=0)

    @attrs.define(slots=slots)
    class Base:
        first: int = default

    with pytest.raises(ValueError, match="No mandatory attributes allowed"):

        @attrs.define(slots=slots, kw_only=True)
        class Child(Base):
            second: int = attrs.field(kw_only=False)

    @attrs.define(slots=slots, kw_only=True)
    class KeywordChild(Base):
        second: int

    assert KeywordChild(second=2).first == 0


@pytest.mark.parametrize("force", (False, True))
def test_generated_attrs_init(force, slots, frozen):
    """The generated helper and pre-init calls use the resolved signature."""

    @attrs.define(slots=slots, frozen=frozen)
    class Base:
        key: int

    @attrs.define(
        slots=slots, frozen=frozen, kw_only=True, force_kw_only=force,
        init=False,
    )
    class Child(Base):
        value: int
        computed: int = attrs.field(init=False)

        def __attrs_pre_init__(self, *args, **kwargs):
            assert args == (() if force else (1,))
            assert kwargs == ({"key": 1, "value": 2} if force else {"value": 2})

        @computed.default
        def compute(self):
            return self.key + self.value

    obj = object.__new__(Child)
    if force:
        obj.__attrs_init__(key=1, value=2)
    else:
        obj.__attrs_init__(1, value=2)
    assert (obj.key, obj.value, obj.computed) == (1, 2, 3)


@pytest.mark.parametrize("parent_decorator", (attrs.define, attr.s))
def test_forced_setting_survives_another_level(parent_decorator, slots):
    """A modern descendant inherits the effective setting of its parent."""

    @attrs.define(slots=slots)
    class Base:
        key: int

    @parent_decorator(
        slots=slots, auto_attribs=True, kw_only=True, force_kw_only=True
    )
    class Parent(Base):
        parent: int

    @attrs.define(slots=slots)
    class Child(Parent):
        own: int

    assert tuple(a.kw_only for a in attrs.fields(Child)) == (True, True, False)
    assert Child.__match_args__ == ("own",)
    assert attrs.astuple(Child(3, key=1, parent=2)) == (1, 2, 3)
    assert attrs.fields(Base).key.kw_only is False


def test_inherited_copy_does_not_mask_redefinition():
    """Keyword settings follow the selected definition in a diamond MRO."""

    @attrs.define(slots=False)
    class Root:
        key: int

    @attrs.define(slots=False, kw_only=True, force_kw_only=True)
    class Left(Root):
        left: int

    @attrs.define(slots=False)
    class Right(Root):
        key: int = attrs.field(kw_only=False)

    @attrs.define(slots=False, kw_only=True)
    class Child(Left, Right):
        own: int

    assert Child(1, left=2, own=3).key == 1
    assert attrs.fields(Child).key.kw_only is False
    assert Child.__match_args__ == ("key",)
