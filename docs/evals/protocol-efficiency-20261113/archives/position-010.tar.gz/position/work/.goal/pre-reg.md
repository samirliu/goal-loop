# Pre-registration

Hypothesis: an unspecified field-level kw_only state resolved from the class default, coupled with a force_kw_only switch, fixes modern inheritance while preserving legacy behavior.

Evidence: the untouched public check failed because NamedRecord rejected its inherited positional key. Predict the public check passes and regression tests preserve legacy forcing, explicit modern positional fields, metadata, constructors, matching and default order validation. Reject the implementation if these disagree.

Scope: local package sources and focused tests. One serial implementation wave, no workers. Budget is the existing original deadline; no new clock. Close after regression testing and actual review, before claiming completion.
