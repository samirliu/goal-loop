# Goal

## Objective

Migrate modern attrs decorators to dataclasses-style keyword-only inheritance, preserve the legacy default, and expose force_kw_only across runtime and public stubs. Honor all requirements in TASK.md with focused regression tests and review.

## Acceptance criteria

- AC-1 | A positional base field remains positional in a modern keyword-only subclass and the full TASK.md implementation is present and reviewed | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 5a8931ca 2026-11-13 auto
