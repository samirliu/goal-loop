import pytest

from werkzeug.datastructures import Headers
from werkzeug.sansio.multipart import Data
from werkzeug.sansio.multipart import Epilogue
from werkzeug.sansio.multipart import Field
from werkzeug.sansio.multipart import File
from werkzeug.sansio.multipart import MultipartDecoder
from werkzeug.sansio.multipart import MultipartEncoder
from werkzeug.sansio.multipart import NeedData
from werkzeug.sansio.multipart import Preamble


def test_decoder_simple() -> None:
    boundary = b"---------------------------9704338192090380615194531385$"
    decoder = MultipartDecoder(boundary)
    data = """
-----------------------------9704338192090380615194531385$
Content-Disposition: form-data; name="fname"

ß∑œß∂ƒå∂
-----------------------------9704338192090380615194531385$
Content-Disposition: form-data; name="lname"; filename="bob"

asdasd
-----------------------------9704338192090380615194531385$--
    """.replace("\n", "\r\n").encode()
    decoder.receive_data(data)
    decoder.receive_data(None)
    events = [decoder.next_event()]
    while not isinstance(events[-1], Epilogue):
        events.append(decoder.next_event())
    assert events == [
        Preamble(data=b""),
        Field(
            name="fname",
            headers=Headers([("Content-Disposition", 'form-data; name="fname"')]),
        ),
        Data(data="ß∑œß∂ƒå∂".encode(), more_data=False),
        File(
            name="lname",
            filename="bob",
            headers=Headers(
                [("Content-Disposition", 'form-data; name="lname"; filename="bob"')]
            ),
        ),
        Data(data=b"asdasd", more_data=False),
        Epilogue(data=b"    "),
    ]
    encoder = MultipartEncoder(boundary)
    result = b""
    for event in events:
        result += encoder.send_event(event)
    assert data == result


@pytest.mark.parametrize(
    "data_start",
    [
        b"A",
        b"\n",
        b"\r",
        b"\r\n",
        b"\n\r",
        b"A\n",
        b"A\r",
        b"A\r\n",
        b"A\n\r",
    ],
)
@pytest.mark.parametrize("data_end", [b"", b"\r\n--foo"])
def test_decoder_data_start_with_different_newline_positions(
    data_start: bytes, data_end: bytes
) -> None:
    boundary = b"foo"
    data = (
        b"\r\n--foo\r\n"
        b'Content-Disposition: form-data; name="test"; filename="testfile"\r\n'
        b"Content-Type: application/octet-stream\r\n\r\n"
        b"" + data_start + b"\r\nBCDE" + data_end
    )
    decoder = MultipartDecoder(boundary)
    decoder.receive_data(data)
    events = [decoder.next_event()]
    # We want to check up to data start event
    while not isinstance(events[-1], Data):
        events.append(decoder.next_event())

    expected = data_start

    if data_end == b"":
        # a split \r\n is deferred to the next event
        if expected[-1] == 0x0D:
            expected = expected[:-1]
    else:
        expected += b"\r\nBCDE"

    assert events == [
        Preamble(data=b""),
        File(
            name="test",
            filename="testfile",
            headers=Headers(
                [
                    (
                        "Content-Disposition",
                        'form-data; name="test"; filename="testfile"',
                    ),
                    ("Content-Type", "application/octet-stream"),
                ]
            ),
        ),
        Data(data=expected, more_data=True),
    ]


def test_chunked_boundaries() -> None:
    boundary = b"--boundary"
    decoder = MultipartDecoder(boundary)
    decoder.receive_data(b"--")
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b"--boundary\r\n")
    assert isinstance(decoder.next_event(), Preamble)
    decoder.receive_data(b"Content-Disposition: form-data;")
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b'name="fname"\r\n\r\n')
    assert isinstance(decoder.next_event(), Field)
    decoder.receive_data(b"longer than the boundary")
    assert isinstance(decoder.next_event(), Data)
    decoder.receive_data(b"also longer, but includes a linebreak\r\n--")
    assert isinstance(decoder.next_event(), Data)
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b"--boundary--\r\n")
    event = decoder.next_event()
    assert isinstance(event, Data)
    assert not event.more_data
    decoder.receive_data(None)
    assert isinstance(decoder.next_event(), Epilogue)


def test_empty_field() -> None:
    boundary = b"foo"
    decoder = MultipartDecoder(boundary)
    data = """
--foo
Content-Disposition: form-data; name="text"
Content-Type: text/plain; charset="UTF-8"

Some Text
--foo
Content-Disposition: form-data; name="empty"
Content-Type: text/plain; charset="UTF-8"

--foo--
    """.replace("\n", "\r\n").encode()
    decoder.receive_data(data)
    decoder.receive_data(None)
    events = [decoder.next_event()]
    while not isinstance(events[-1], Epilogue):
        events.append(decoder.next_event())
    assert events == [
        Preamble(data=b""),
        Field(
            name="text",
            headers=Headers(
                [
                    ("Content-Disposition", 'form-data; name="text"'),
                    ("Content-Type", 'text/plain; charset="UTF-8"'),
                ]
            ),
        ),
        Data(data=b"Some Text", more_data=False),
        Field(
            name="empty",
            headers=Headers(
                [
                    ("Content-Disposition", 'form-data; name="empty"'),
                    ("Content-Type", 'text/plain; charset="UTF-8"'),
                ]
            ),
        ),
        Data(data=b"", more_data=False),
        Epilogue(data=b"    "),
    ]
    encoder = MultipartEncoder(boundary)
    result = b""
    for event in events:
        result += encoder.send_event(event)
    assert data == result


@pytest.mark.parametrize(
    "payload",
    [
        b"first\n" + b"x" * 40,
        b"first\n" + b"x" * 40 + b"\r",
        b"first\n" + b"x" * 40 + b"\n",
        b"first\n" + b"x" * 40 + b"\r\n",
        b"first\n" + b"x" * 40 + b"\n\r",
        b"before\r\n--fooX\r\n--foX\n--foo-\nend\r",
        b"before--foo\n" + b"x" * 40 + b"\r",
        b"before\r\n--foo--X\r\nend\r",
        b"before\r\n--foo-- \tX\r\nend\r",
        b"",
    ],
)
@pytest.mark.parametrize("closing", [False, True])
@pytest.mark.parametrize("padding", [b"", b" \t" * 10])
def test_decoder_split_data_boundary(
    payload: bytes, closing: bool, padding: bytes
) -> None:
    header = b'--foo\r\nContent-Disposition: form-data; name="a"\r\n\r\n'
    delimiter = b"\r\n--foo" + (b"--" if closing else b"") + padding + b"\r\n"
    remainder = b"epilogue"

    if not closing:
        remainder = (
            b'Content-Disposition: form-data; name="b"\r\n\r\n'
            b"tail\r\n--foo--\r\nepilogue"
        )

    for split in range(len(delimiter) + 1):
        decoder = MultipartDecoder(b"foo")
        parts: list[bytes] = []
        pending = bytearray()
        epilogue = None

        for chunk in [
            header,
            payload + delimiter[:split],
            delimiter[split:] + remainder,
            None,
        ]:
            decoder.receive_data(chunk)
            while True:
                event = decoder.next_event()
                if isinstance(event, NeedData):
                    # Asking again without input must not emit or consume data.
                    assert isinstance(decoder.next_event(), NeedData)
                    break
                if isinstance(event, Data):
                    pending.extend(event.data)
                    if not event.more_data:
                        parts.append(bytes(pending))
                        pending.clear()
                if isinstance(event, Epilogue):
                    epilogue = event.data
                    break

        assert parts == ([payload] if closing else [payload, b"tail"]), split
        assert epilogue == b"epilogue", split


@pytest.mark.parametrize("ending", [b"", b"\r", b"\n", b"\r\n"])
def test_decoder_empty_form_split_epilogue(ending: bytes) -> None:
    data = b"--foo--" + ending
    for split in range(len(data) + 1):
        decoder = MultipartDecoder(b"foo")
        events = []
        for chunk in [data[:split], data[split:], None]:
            decoder.receive_data(chunk)
            while True:
                event = decoder.next_event()
                if isinstance(event, NeedData):
                    break
                events.append(event)
                if isinstance(event, Epilogue):
                    break
        assert events == [Preamble(data=b""), Epilogue(data=b"")], split
