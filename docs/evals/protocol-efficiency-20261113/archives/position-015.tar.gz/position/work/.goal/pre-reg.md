# Multipart buffering hypothesis

Use the latest line break, retaining a CRLF pair, and keep complete delimiter consumption independent of trailing payload CR. The supplied upload check fails before the change. Reject the fix if exact payload bytes differ across partial prefixes or if existing decoder/form parsing tests regress. Serial implementation, focused regression tests, then adversarial review and measured close. No objective score is defined; prefer=none.
