# Goal

## Objective

Preserve multipart field and file payloads across partial delimiter reads, embedded newlines, boundary-like content, complete boundaries and epilogues, retaining form limits and malformed-input handling. Implement and review the decoder and request-parser regression coverage within source and tests.

## Acceptance criteria

- AC-1 | Multipart upload split after CR preserves exact file bytes through the form parser; focused regression checks and review also cover the full TASK.md requirements. | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: dbcd94c5 2026-11-13 auto
