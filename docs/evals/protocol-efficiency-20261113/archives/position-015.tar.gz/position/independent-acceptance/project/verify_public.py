from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))
from io import BytesIO
from werkzeug.formparser import MultiPartParser

boundary = b'upload-boundary'
header = b'--' + boundary + b'\r\nContent-Disposition: form-data; name="f"; filename="f.txt"\r\n\r\n'
payload = b'a\n' + b'b' * (127-len(header)-2) + b'\r\ntrailer\r'
body = header + payload + b'\r\n--' + boundary + b'--\r\n'
parser = MultiPartParser(buffer_size=64)
form, files = parser.parse(BytesIO(body), boundary, len(body))
assert files['f'].read() == payload

print('public check passed')
