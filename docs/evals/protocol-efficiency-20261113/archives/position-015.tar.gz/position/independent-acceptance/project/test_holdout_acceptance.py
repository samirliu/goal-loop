from io import BytesIO

import pytest
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.formparser import MultiPartParser
from werkzeug.sansio.multipart import Data, Epilogue, MultipartDecoder, NeedData


BOUNDARY=b'business-upload-boundary'


def body_for(payload):
    return b''.join([
        b'--'+BOUNDARY+b'\r\nContent-Disposition: form-data; name="reference"\r\n\r\norder-17\r\n',
        b'--'+BOUNDARY+b'\r\nContent-Disposition: form-data; name="invoice"; filename="invoice.bin"\r\nContent-Type: application/octet-stream\r\n\r\n',
        payload,b'\r\n--'+BOUNDARY+b'\r\nContent-Disposition: form-data; name="empty"\r\n\r\n',
        b'\r\n--'+BOUNDARY+b'--\r\nepilogue',
    ])


@pytest.mark.parametrize('tail',[b'',b'\r',b'\n',b'\r\n'])
def test_complete_parts_retain_boundary_lookalikes_and_payload_newlines(tail):
    payload=(b'first\nsecond\rthird\r\nfourth'+b'\r\n--'+BOUNDARY+b'X\r\n')*3+tail
    body=body_for(payload)
    form,files=MultiPartParser().parse(BytesIO(body),BOUNDARY,len(body))
    assert form.to_dict()=={'reference':'order-17','empty':''}
    assert set(files)=={'invoice'}
    assert files['invoice'].filename=='invoice.bin'
    assert files['invoice'].read()==payload


@pytest.mark.parametrize('chunk_size',[64,128,256,1024,65536])
@pytest.mark.parametrize('is_field',[True,False])
@pytest.mark.parametrize('ending',[b'x',b'\r',b'\n',b'\r\n'])
def test_data_chunk_crlf_split_preserves_fields_and_file_bytes(chunk_size,is_field,ending):
    boundary=b'upload-boundary'
    disposition=b'Content-Disposition: form-data; name="data"'+(b'' if is_field else b'; filename="file.bin"')
    header=b'--'+boundary+b'\r\n'+disposition+b'\r\n\r\n'
    prefix=b'a\n'+b'b'*(chunk_size*2-1-len(header)-2)
    payload=prefix+b'\r\n'+b'trailer'+ending
    body=header+payload+b'\r\n--'+boundary+b'--\r\n'
    form,files=MultiPartParser(buffer_size=chunk_size).parse(BytesIO(body),boundary,len(body))
    got=form['data'].encode() if is_field else files['data'].read()
    assert got==payload


def test_standard_size_stream_retains_interior_and_trailing_newlines():
    payload=b'\n'.join([b'\r'*31]*2045+[b'y'*31])+b'\r\n'+b'\n'.join([b'\r'*31]*2047+[b'x'*30])
    body=body_for(payload)
    form,files=MultiPartParser().parse(BytesIO(body),BOUNDARY,len(body))
    assert form['reference']=='order-17'
    assert files['invoice'].read()==payload


def test_decoder_waits_for_split_crlf_and_boundary_without_emitting_them():
    boundary=b'cut'
    header=b'--cut\r\nContent-Disposition: form-data; name="data"\r\n\r\n'
    payload=b'earlier\nline\r\nlast'
    decoder=MultipartDecoder(boundary)
    data=[]
    endings=[]
    for chunk in [header+payload+b'\r',b'\n-',b'-cu',b't--\r\n']:
        decoder.receive_data(chunk)
        for _ in range(20):
            event=decoder.next_event()
            if isinstance(event,NeedData):
                break
            if isinstance(event,Data):
                data.append(event.data)
                endings.append(event.more_data)
        else:
            pytest.fail('decoder failed to yield NeedData')
    decoder.receive_data(None)
    assert isinstance(decoder.next_event(),Epilogue)
    assert b''.join(data)==payload
    assert endings[-1] is False


def test_invalid_body_and_memory_limit_are_not_hidden_by_recovery():
    decoder=MultipartDecoder(b'never-closed')
    decoder.receive_data(b'--never-closed\r\nContent-Disposition: form-data; name="x"\r\n\r\npayload')
    decoder.receive_data(None)
    with pytest.raises(ValueError):
        for _ in range(20):
            decoder.next_event()
    body=body_for(b'x'*200)
    with pytest.raises(RequestEntityTooLarge):
        MultiPartParser(max_form_memory_size=32).parse(BytesIO(body),BOUNDARY,len(body))
