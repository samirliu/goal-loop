# Pre-registration

Hypothesis: literal selection compares original Python names, so normalizing literal candidates and lookups to the hooks' serialized names fixes renamed event round trips while preserving unique-key fallback.
Strategy: wirekeys
Expected: common serialized literal keys select by value; different serialized keys use existing unique-key discrimination; empty-string keys remain valid.
Falsification: any regression in ordinary unions, invalid/ambiguous input handling, or the attrs/dataclass and BaseConverter/Converter validation matrix.
Kill point: reserve at least 90 execution seconds for actual review and measured close; run serially with no native workers.
Fallback: report real remaining failures without claiming completion.
