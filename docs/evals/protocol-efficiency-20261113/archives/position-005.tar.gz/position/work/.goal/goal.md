# Goal

## Objective

Repair union selection to use generated hooks' serialized discriminator names, including explicit overrides, attrs and dataclasses, BaseConverter and Converter, both validation modes, distinct per-member wire keys, common wire keys for different attributes, and empty-string keys. Preserve literal discrimination, unrenamed unions, and errors for invalid or ambiguous inputs. Implement within package and tests as required by TASK.md, with focused regression tests and actual review.

## Acceptance criteria

- AC-1 | The public renamed event round trip passes | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python PYTHONDONTWRITEBYTECODE=1 /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 9158f8ad 2026-11-13 auto
