# work-plan (controller ticks; NEVER a GO signal)

- [x] T1 Repair renamed union discriminator selection and test attrs/dataclass, converter, validation, explicit override, and invalid input cases | owner=controller | files=src/cattrs/disambiguators.py tests/test_disambiguators.py
