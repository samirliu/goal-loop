import pytest

import click
from click.core import ParameterSource


@pytest.mark.parametrize("type", [None, bool, click.BOOL])
@pytest.mark.parametrize(
    ("settings", "inactive", "active"),
    [
        ({}, False, True),
        ({"default": None}, False, True),
        ({"default": False}, False, True),
        ({"default": True}, True, False),
        ({"flag_value": None}, False, True),
        ({"flag_value": False}, False, False),
        ({"flag_value": True}, False, True),
        ({"default": True, "flag_value": True}, True, True),
        ({"default": True, "flag_value": False}, True, False),
        ({"default": None, "flag_value": False}, False, False),
    ],
)
def test_boolean_flag_configuration(runner, type, settings, inactive, active):
    option = click.Option(["--value"], is_flag=True, type=type, **settings)
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    assert option.is_bool_flag
    for args, expected in [([], inactive), (["--value"], active)]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exit_code == 0, result.output
        assert result.return_value is expected


@pytest.mark.parametrize("type", [str, click.STRING])
@pytest.mark.parametrize(
    ("settings", "inactive", "active"),
    [
        ({}, "False", "True"),
        ({"default": None}, "False", "True"),
        ({"default": False}, "False", "True"),
        ({"default": True}, "True", "True"),
        ({"default": "configured"}, "configured", "True"),
        ({"default": ""}, "", "True"),
        ({"flag_value": None}, "False", "True"),
        ({"flag_value": False}, "False", "False"),
        ({"flag_value": "deploy"}, "False", "deploy"),
        ({"flag_value": ""}, "False", ""),
        ({"default": "idle", "flag_value": "deploy"}, "idle", "deploy"),
        ({"default": True, "flag_value": "deploy"}, "deploy", "deploy"),
        ({"default": True, "flag_value": False}, "False", "False"),
    ],
)
def test_string_flag_configuration(runner, type, settings, inactive, active):
    option = click.Option(["--value"], is_flag=True, type=type, **settings)
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    assert not option.is_bool_flag
    for args, expected in [([], inactive), (["--value"], active)]:
        result = runner.invoke(cli, args, standalone_mode=False)
        assert result.exit_code == 0, result.output
        assert result.return_value == expected
        assert isinstance(result.return_value, str)


@pytest.mark.parametrize("type", [bool, click.BOOL])
@pytest.mark.parametrize("default", ["false", " OFF ", "true", " YES "])
def test_boolean_default_is_converted_before_inverting(runner, type, default):
    option = click.Option(["--value"], is_flag=True, type=type, default=default)
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    inactive = default.strip().lower() in {"true", "yes"}
    assert runner.invoke(cli, standalone_mode=False).return_value is inactive
    assert (
        runner.invoke(cli, ["--value"], standalone_mode=False).return_value
        is not inactive
    )


@pytest.mark.parametrize("type", [bool, click.BOOL])
@pytest.mark.parametrize("key", ["default", "flag_value"])
@pytest.mark.parametrize("invalid", ["invalid", 2, [], {}])
def test_invalid_boolean_configuration_is_parameter_error(runner, type, key, invalid):
    option = click.Option(["--value"], is_flag=True, type=type, **{key: invalid})
    cli = click.Command("cli", params=[option])
    result = runner.invoke(cli, ["--value"] if key == "flag_value" else [])
    assert result.exit_code == 2, result.output
    assert "Invalid value for '--value'" in result.output
    assert "is not a valid boolean" in result.output


@pytest.mark.parametrize("type", [bool, click.BOOL, str, click.STRING])
@pytest.mark.parametrize("autoenv", [False, True])
@pytest.mark.parametrize(
    ("token", "active"),
    [
        ("1", True),
        ("true", True),
        ("t", True),
        ("yes", True),
        ("y", True),
        ("on", True),
        (" TRUE ", True),
        ("\tYeS\n", True),
        ("0", False),
        ("false", False),
        ("f", False),
        ("no", False),
        ("n", False),
        ("off", False),
        (" FALSE ", False),
        ("\tOfF\n", False),
    ],
)
def test_flag_environment_tokens(runner, type, autoenv, token, active):
    kwargs = {} if autoenv else {"envvar": "CONFIG_VALUE"}
    string_flag = type in (str, click.STRING)
    if string_flag:
        kwargs.update(default="idle", flag_value="deploy")
    else:
        kwargs.update(default=True)
    option = click.Option(["--value"], is_flag=True, type=type, **kwargs)
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    result = runner.invoke(
        cli,
        env={"CONFIG_VALUE": token},
        auto_envvar_prefix="CONFIG",
        standalone_mode=False,
    )
    assert result.exit_code == 0, result.output
    if string_flag:
        assert result.return_value == ("deploy" if active else "False")
    else:
        assert result.return_value is active


@pytest.mark.parametrize("token", ["deploy", "Deploy", " deploy ", "garbage", " "])
def test_string_flag_exact_environment_activation(runner, token):
    option = click.Option(["--value"], flag_value="deploy", envvar="VALUE")
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    result = runner.invoke(cli, env={"VALUE": token}, standalone_mode=False)
    assert result.exit_code == 0, result.output
    assert result.return_value == ("deploy" if token == "deploy" else "False")


@pytest.mark.parametrize("flag_value", ["off", "TRUE", "two words"])
def test_exact_environment_activation_precedes_boolean_tokens(runner, flag_value):
    option = click.Option(["--value"], flag_value=flag_value, envvar="VALUE")
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    result = runner.invoke(cli, env={"VALUE": flag_value}, standalone_mode=False)
    assert result.exit_code == 0, result.output
    assert result.return_value == flag_value


@pytest.mark.parametrize("token", [None, ""])
@pytest.mark.parametrize("type,default", [(bool, True), (str, "idle")])
def test_empty_environment_uses_default(runner, token, type, default):
    option = click.Option(
        ["--value"], is_flag=True, type=type, default=default, envvar="VALUE"
    )
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    result = runner.invoke(cli, env={"VALUE": token}, standalone_mode=False)
    assert result.exit_code == 0, result.output
    assert result.return_value == default


def test_environment_and_commandline_sources(runner):
    @click.command()
    @click.option("--value/--no-value", default=True, envvar=["EMPTY", "VALUE"])
    @click.pass_context
    def cli(ctx, value):
        return value, ctx.get_parameter_source("value")

    for args, env, expected, source in [
        ([], {"EMPTY": "", "VALUE": "false"}, False, ParameterSource.ENVIRONMENT),
        (["--value"], {"VALUE": "false"}, True, ParameterSource.COMMANDLINE),
        (["--no-value"], {"VALUE": "true"}, False, ParameterSource.COMMANDLINE),
        ([], {"VALUE": ""}, True, ParameterSource.DEFAULT),
    ]:
        result = runner.invoke(cli, args, env=env, standalone_mode=False)
        assert result.exit_code == 0, result.output
        assert result.return_value == (expected, source)


def test_multiple_flags_and_normal_environment_values(runner):
    @click.command()
    @click.option("--enabled", is_flag=True, multiple=True, envvar="ENABLED")
    @click.option("--mode", flag_value="deploy", multiple=True, envvar="MODE")
    @click.option("--numbers", type=int, multiple=True, envvar="NUMBERS")
    def cli(enabled, mode, numbers):
        return enabled, mode, numbers

    result = runner.invoke(
        cli,
        env={
            "ENABLED": "false true OFF",
            "MODE": "yes no deploy",
            "NUMBERS": "1 2 3",
        },
        standalone_mode=False,
    )
    assert result.exit_code == 0, result.output
    assert result.return_value == (
        (False, True, False), ("deploy", "False", "deploy"), (1, 2, 3)
    )
    result = runner.invoke(
        cli, ["--enabled", "--enabled", "--mode"], standalone_mode=False
    )
    assert result.return_value == ((True, True), ("deploy",), ())


def test_grouped_flag_defaults_and_default_map(runner):
    @click.command()
    @click.option("--upper", "mode", flag_value="upper", default=True)
    @click.option("--lower", "mode", flag_value="lower")
    def cli(mode):
        return mode

    assert runner.invoke(cli, standalone_mode=False).return_value == "upper"
    result = runner.invoke(cli, ["--lower"], standalone_mode=False)
    assert result.return_value == "lower"
    result = runner.invoke(
        cli, default_map={"mode": "mapped"}, standalone_mode=False
    )
    assert result.return_value == "mapped"


def test_ordinary_boolean_environment_remains_strict(runner):
    option = click.Option(["--value"], type=bool, envvar="VALUE")
    cli = click.Command("cli", params=[option])
    result = runner.invoke(cli, env={"VALUE": "garbage"})
    assert result.exit_code == 2
    assert "is not a valid boolean" in result.output


def test_dynamic_string_default_and_metadata(runner):
    option = click.Option(["--value"], is_flag=True, type=str, default=lambda: "idle")
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    assert runner.invoke(cli, standalone_mode=False).return_value == "idle"
    assert runner.invoke(cli, ["--value"], standalone_mode=False).return_value == "True"
    info = option.to_info_dict()
    assert info["is_flag"] is True
    assert info["flag_value"] is True
    assert info["type"]["name"] == "text"


@pytest.mark.parametrize("default", ["idle", "", 0])
def test_real_default_shared_by_flag_group(runner, default):
    @click.command()
    @click.option("--upper", "mode", flag_value="upper", default=default)
    @click.option("--lower", "mode", flag_value="lower")
    def cli(mode):
        return mode

    result = runner.invoke(cli, standalone_mode=False)
    assert result.exit_code == 0, result.output
    assert result.return_value == str(default)
    result = runner.invoke(cli, ["--lower"], standalone_mode=False)
    assert result.return_value == "lower"


def test_multiple_flag_exact_activation_with_whitespace(runner):
    option = click.Option(
        ["--value"], flag_value="two words", multiple=True, envvar="VALUE"
    )
    cli = click.Command("cli", params=[option], callback=lambda value: value)
    result = runner.invoke(cli, env={"VALUE": "two words"}, standalone_mode=False)
    assert result.exit_code == 0, result.output
    assert result.return_value == ("two words",)
