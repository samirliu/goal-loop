# Flag configuration repair

Hypothesis: resolving a flag environment variable must retain the raw string
until flag-aware boolean conversion; otherwise a configured activation value
hides false tokens. Non-boolean default selection must distinguish True from
other configured defaults rather than testing truthiness.

Observed counterexample: the untouched public check returned True for false
and exited 1 before the repair.

Reject the change if the upstream regression suite loses established prompt,
multiple-value, paired-flag, parameter metadata, or parameter-error behavior.
Check both Python and Click types and interactions of defaults and activation
values, including explicit None, False, empty strings, and exact env matches.

Kill line: no additional dispatch; finish the current local repair and book
actual test and review evidence within the original deadline.
