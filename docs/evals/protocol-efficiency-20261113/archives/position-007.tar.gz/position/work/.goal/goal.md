# Goal

## Objective

Reconcile flag defaults, activation values and environment conversion while preserving normal parameter behavior.

## Acceptance criteria

- AC-1 | Public flag environment regression passes | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 7b92f46d 2026-11-13 auto
