import click
from click.core import ParameterSource
from click.testing import CliRunner
import pytest


@pytest.mark.parametrize('value,expected',[
    ('ON','promote'),(' yes ','promote'),('t','promote'),('0','False'),
    ('OFF','False'),('False','False'),('not-enabled','False'),
    ('promote','promote'),('PROMOTE','False'),(' promote ','False'),
])
def test_release_mode_environment_activation(value,expected):
    @click.command()
    @click.option('--promote',is_flag=True,type=str,flag_value='promote',envvar='RELEASE_MODE')
    def cli(promote):
        return promote
    result=CliRunner().invoke(cli,[],env={'RELEASE_MODE':value},standalone_mode=False)
    assert result.exit_code == 0, result.exception
    assert result.return_value == expected


def test_commandline_precedence_and_normal_envvar_conversion():
    @click.command()
    @click.option('--promote',is_flag=True,type=str,flag_value='promote',envvar='RELEASE_MODE')
    @click.option('--retries',type=int,envvar='RETRIES')
    @click.pass_context
    def cli(ctx,promote,retries):
        return promote,retries,ctx.get_parameter_source('promote')
    result=CliRunner().invoke(cli,['--promote'],env={'RELEASE_MODE':'false','RETRIES':'7'},standalone_mode=False)
    assert result.exit_code == 0, result.exception
    assert result.return_value == ('promote',7,ParameterSource.COMMANDLINE)


@pytest.mark.parametrize('typ,default,flag_value,args,expected',[
    (bool,True,False,[],True), (bool,True,False,['--mode'],False),
    (str,'idle',False,[],'idle'),(str,'idle',False,['--mode'],'False'),
    (str,None,True,[],'False'),(str,None,True,['--mode'],'True'),
    (str,'idle',None,['--mode'],'idle'),
])
def test_declared_false_values_are_not_replaced_by_truthiness(typ,default,flag_value,args,expected):
    @click.command()
    @click.option('--mode',is_flag=True,type=typ,default=default,flag_value=flag_value)
    def cli(mode):
        return mode
    result=CliRunner().invoke(cli,args,standalone_mode=False)
    assert result.exit_code == 0, result.exception
    assert result.return_value == expected


def test_invalid_bool_declaration_still_reports_parameter_error():
    @click.command()
    @click.option('--mode',is_flag=True,type=bool,flag_value='deployment')
    def cli(mode):
        return mode
    result=CliRunner().invoke(cli,['--mode'])
    assert result.exit_code == 2
    assert 'not a valid boolean' in result.output
