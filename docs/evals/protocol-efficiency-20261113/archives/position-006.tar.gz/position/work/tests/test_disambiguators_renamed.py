"""Union disambiguation uses the wire names of generated hook overrides."""

from dataclasses import dataclass
from typing import Literal, Union

import pytest
from attrs import define

from cattrs.disambiguators import create_default_dis_func
from cattrs.gen import make_dict_structure_fn, make_dict_unstructure_fn, override


@pytest.fixture(params=(define, dataclass), ids=("attrs", "dataclass"))
def class_factory(request):
    return request.param


def register_renamed_hooks(converter, cls, overrides):
    converter.register_structure_hook(
        cls, make_dict_structure_fn(cls, converter, **overrides)
    )
    converter.register_unstructure_hook(
        cls, make_dict_unstructure_fn(cls, converter, **overrides)
    )


@pytest.mark.parametrize("wire_name", ("type", ""))
def test_renamed_literal_roundtrip(converter, class_factory, wire_name):
    """The common wire key selects by literal value, including an empty key."""

    @class_factory
    class Created:
        kind: Literal["created"]

    @class_factory
    class Deleted:
        kind: Literal["deleted"]

    overrides = {"kind": override(rename=wire_name)}
    # Explicit overrides work even before generated hooks are registered.
    explicit = create_default_dis_func(converter, Created, Deleted, overrides=overrides)
    for cls in (Created, Deleted):
        register_renamed_hooks(converter, cls, overrides)

    discovered = create_default_dis_func(converter, Created, Deleted)
    for event in (Created("created"), Deleted("deleted")):
        payload = converter.unstructure(event)
        assert payload == {wire_name: event.kind}
        assert discovered(payload) is type(event)
        assert explicit(payload) is type(event)
        assert converter.structure(payload, Union[Created, Deleted]) == event
        assert converter.structure(payload, Union[Created, Deleted, None]) == event

    assert converter.structure(None, Union[Created, Deleted, None]) is None
    for disambiguate in (discovered, explicit):
        with pytest.raises(KeyError):
            disambiguate({wire_name: "unknown"})
        with pytest.raises(KeyError):
            disambiguate({})
        with pytest.raises(ValueError, match="Only input mappings"):
            disambiguate([])

    with pytest.raises(TypeError, match="no unique non-default attributes"):
        create_default_dis_func(converter, Created, Deleted, use_literals=False)


@pytest.mark.parametrize(
    "wire_names", (("createdType", "deletedType"), ("", "type"), ("kind", "type"))
)
def test_different_wire_keys_use_unique_fields(converter, class_factory, wire_names):
    """A shared Python name is not a common discriminator after renaming."""

    @class_factory
    class Created:
        kind: Literal["created"]

    @class_factory
    class Deleted:
        kind: Literal["deleted"]

    for cls, wire_name in zip((Created, Deleted), wire_names):
        register_renamed_hooks(converter, cls, {"kind": override(rename=wire_name)})

    for event, wire_name in zip((Created("created"), Deleted("deleted")), wire_names):
        payload = converter.unstructure(event)
        assert payload == {wire_name: event.kind}
        assert converter.structure(payload, Union[Created, Deleted]) == event

    disambiguate = create_default_dis_func(converter, Created, Deleted)
    with pytest.raises(ValueError, match="Couldn't disambiguate"):
        disambiguate({})


@pytest.mark.parametrize("wire_name", ("type", ""))
def test_different_python_names_share_wire_key(converter, class_factory, wire_name):
    """Literal types are read from each member's original attribute."""

    @class_factory
    class Created:
        kind: Literal["created"] = "created"

    @class_factory
    class Deleted:
        event_kind: Literal["deleted"] = "deleted"

    overrides = {
        "kind": override(rename=wire_name),
        "event_kind": override(rename=wire_name),
    }
    # Explicit overrides work even before generated hooks are registered.
    explicit = create_default_dis_func(converter, Created, Deleted, overrides=overrides)
    for cls in (Created, Deleted):
        register_renamed_hooks(converter, cls, overrides)

    discovered = create_default_dis_func(converter, Created, Deleted)
    for event, literal in ((Created(), "created"), (Deleted(), "deleted")):
        payload = converter.unstructure(event)
        assert payload == {wire_name: literal}
        assert discovered(payload) is type(event)
        assert explicit(payload) is type(event)
        assert converter.structure(payload, Union[Created, Deleted]) == event


def test_renamed_literals_select_nested_unions(converter, class_factory):
    """Shared literal values still delegate to a smaller discriminated union."""

    @class_factory
    class Heartbeat:
        op: Literal[1]

    @class_factory
    class Created:
        opcode: Literal[0]
        kind: Literal["created"]

    @class_factory
    class Deleted:
        opcode: Literal[0]
        event_kind: Literal["deleted"]

    for cls, names in (
        (Heartbeat, {"op": "operation"}),
        (Created, {"opcode": "operation", "kind": "type"}),
        (Deleted, {"opcode": "operation", "event_kind": "type"}),
    ):
        register_renamed_hooks(
            converter, cls, {name: override(rename=wire) for name, wire in names.items()}
        )

    union = Union[Heartbeat, Created, Deleted]
    disambiguate = create_default_dis_func(converter, Heartbeat, Created, Deleted)
    assert disambiguate({"operation": 1}) is Heartbeat
    assert disambiguate({"operation": 0, "type": "created"}) == Union[Created, Deleted]
    for event in (Heartbeat(1), Created(0, "created"), Deleted(0, "deleted")):
        assert converter.structure(converter.unstructure(event), union) == event


@pytest.mark.parametrize("wire_name", ("type", ""))
def test_renamed_ambiguous_literals_rejected(converter, class_factory, wire_name):
    """Renames do not turn identical literals and wire keys into a valid union."""

    @class_factory
    class First:
        kind: Literal["event"]

    @class_factory
    class Second:
        event_kind: Literal["event"]

    overrides = {
        "kind": override(rename=wire_name),
        "event_kind": override(rename=wire_name),
    }
    with pytest.raises(TypeError, match="no unique non-default attributes"):
        create_default_dis_func(converter, First, Second, overrides=overrides)

    for cls in (First, Second):
        register_renamed_hooks(converter, cls, overrides)

    with pytest.raises(TypeError, match="no unique non-default attributes"):
        create_default_dis_func(converter, First, Second)
