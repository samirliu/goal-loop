# Pre-registration

## Hypothesis and counterevidence

The initial public integration exits 1 because tenacity.asyncio is missing. Expose async strategies and route mixed operators to awaitable combinators; evaluate predicates only for their outcome kind. Preserve synchronous exports and unmodified work return values. Reject the implementation if public integration, existing tests, lifecycle ordering, short circuiting or original exception checks fail.

## Strategy

serial: keep implementation and focused regressions in one local wave. No worker overhead is needed for this bounded change. No optimization score or strategy preference is claimed.

## Kill and degrade lines

Original execution deadline: 1794556838.2245781. Finish review, booking and Gate before final. At expiry report actual passing checks and any unresolved requirement. Check marks never substitute for acceptance.
