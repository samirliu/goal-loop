# Goal

## Objective

Deliver awaitable policies and callbacks for AsyncRetrying in direct calls and async iteration, preserving results, retry limits and original exceptions. Provide importable tenacity.asyncio and tenacity.asyncio.retry strategies for result and exception predicates, plus retry_base, retry_any and retry_all. Compose async and existing synchronous strategies in either order with left-to-right short circuiting. Detect async callable objects and coroutine partials in the decorator while preserving synchronous exports, normal functions and wrapper metadata.

## Acceptance criteria

- AC-1 | The public asynchronous service integration completes successfully | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0
- AC-2 | Focused async behavior and existing package regression tests pass | check: `/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B -m pytest -q -p no:cacheprovider tests` | expected: exit=0

## Approval

approved: 5432952f 2026-11-13 auto
