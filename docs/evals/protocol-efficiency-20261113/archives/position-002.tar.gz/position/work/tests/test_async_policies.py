# mypy: disable-error-code="no-untyped-def,no-untyped-call"
import asyncio
import functools
import importlib
import inspect
import operator
import sys
import typing as t

import pytest

import tenacity
from tenacity import _utils
from tenacity import asyncio as policies

from .test_asyncio import asynctest


def adapt(fn, mode):
    if mode == "sync":
        return fn

    async def async_fn(*args, **kwargs):
        await asyncio.sleep(0)
        return fn(*args, **kwargs)

    if mode == "async":
        return async_fn
    return lambda *args, **kwargs: async_fn(*args, **kwargs)


@pytest.mark.parametrize("mode", ["sync", "async", "awaitable"])
@pytest.mark.parametrize("iterate", [False, True])
@asynctest
async def test_policies_and_callbacks_preserve_lifecycle(mode, iterate):
    events = []

    def record(name, result=None):
        def callback(state):
            events.append((name, state.attempt_number))
            return result

        return adapt(callback, mode)

    def retry_result(state):
        events.append(("retry", state.attempt_number))
        return state.outcome.result() < 3

    retrying = tenacity.AsyncRetrying(
        retry=adapt(retry_result, mode),
        wait=record("wait", 0),
        stop=record("stop", False),
        before=record("before"),
        after=record("after"),
        before_sleep=record("before_sleep"),
    )
    attempts = 0

    async def work():
        nonlocal attempts
        attempts += 1
        return attempts

    if iterate:
        async for attempt in retrying:
            with attempt:
                result = await work()
            attempt.retry_state.set_result(result)
    else:
        result = await retrying(work)

    assert result == attempts == 3
    assert events == [
        (name, number)
        for number in (1, 2)
        for name in ("before", "retry", "after", "wait", "stop", "before_sleep")
    ] + [("before", 3), ("retry", 3)]
    assert retrying.statistics["attempt_number"] == 3


@pytest.mark.parametrize("failed", [False, True])
@pytest.mark.parametrize("exception_policy", [False, True])
@asynctest
async def test_predicates_only_observe_their_outcome_kind(failed, exception_policy):
    seen = []

    async def predicate(value):
        await asyncio.sleep(0)
        seen.append(value)
        return True

    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    policy_cls = (
        policies.retry_if_exception if exception_policy else policies.retry_if_result
    )
    strategy = policy_cls(predicate)
    with pytest.raises(RuntimeError, match="before outcome was set"):
        await strategy(state)
    error = ValueError("original")
    if failed:
        state.set_exception((ValueError, error, None))
    else:
        state.set_result("value")
    assert await strategy(state) is (failed == exception_policy)
    expected = [error if failed else "value"] if failed == exception_policy else []
    assert seen == expected


@pytest.mark.parametrize("left_async", [False, True])
@pytest.mark.parametrize("op", [operator.or_, operator.and_])
@pytest.mark.parametrize(
    "left,right", [(False, False), (False, True), (True, False), (True, True)]
)
@asynctest
async def test_mixed_strategy_operators_short_circuit(left_async, op, left, right):
    seen = []

    def strategy(name, value, is_async):
        def predicate(result):
            seen.append(name)
            return value

        if is_async:
            return policies.retry_if_result(adapt(predicate, "async"))
        return tenacity.retry_if_result(predicate)

    lhs = strategy("left", left, left_async)
    rhs = strategy("right", right, not left_async)
    composed = op(lhs, rhs)
    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    state.set_result(None)
    assert await composed(state) is op(left, right)
    skip_right = left if op is operator.or_ else not left
    assert seen == (["left"] if skip_right else ["left", "right"])


@asynctest
async def test_nested_mixed_strategies_and_empty_combinators():
    async def must_not_run(value):
        pytest.fail("short circuited predicate ran")

    pending = policies.retry_if_result(must_not_run)
    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    state.set_result(None)
    assert await ((tenacity.retry_always | tenacity.retry_never) | pending)(state)
    assert not await ((tenacity.retry_never & tenacity.retry_always) & pending)(state)
    assert not await policies.retry_any()(state)
    assert await policies.retry_all()(state)
    assert await policies.retry_any(tenacity.retry_never, tenacity.retry_always)(state)
    combined = policies.retry_all(tenacity.retry_always, tenacity.retry_never)
    assert not await combined(state)


@pytest.mark.parametrize("iterate", [False, True])
@asynctest
async def test_async_stop_reraises_the_original_exception(iterate):
    error = LookupError("original failure")
    seen = []

    async def predicate(exc):
        seen.append(exc)
        return True

    async def stop(state):
        return state.attempt_number >= 2

    retrying = tenacity.AsyncRetrying(
        retry=policies.retry_if_exception(predicate), stop=stop, reraise=True
    )

    async def fail():
        raise error

    with pytest.raises(LookupError) as caught:
        if iterate:
            async for attempt in retrying:
                with attempt:
                    await fail()
        else:
            await retrying(fail)
    assert caught.value is error
    assert seen == [error, error]
    assert retrying.statistics["attempt_number"] == 2


@pytest.mark.parametrize("mode", ["sync", "async", "awaitable"])
@asynctest
async def test_retry_error_callbacks_and_last_result(mode):
    observed = []

    def exhausted(state):
        observed.append((state.attempt_number, state.outcome.result()))
        return "fallback"

    retrying = tenacity.AsyncRetrying(
        retry=adapt(lambda state: True, mode),
        stop=adapt(lambda state: state.attempt_number == 2, mode),
        retry_error_callback=adapt(exhausted, mode),
    )

    async def work():
        return "pending"

    assert await retrying(work) == "fallback"
    assert observed == [(2, "pending")]
    with pytest.raises(tenacity.RetryError) as caught:
        await retrying.copy(retry_error_callback=None)(work)
    assert caught.value.last_attempt.result() == "pending"
    assert caught.value.last_attempt.attempt_number == 2


@pytest.mark.parametrize(
    "name",
    [
        "retry", "wait", "stop", "before", "after", "before_sleep",
        "retry_error_callback",
    ],
)
@asynctest
async def test_policy_errors_are_not_retried_or_wrapped(name):
    error = RuntimeError("policy failure")
    calls = []

    async def broken(state):
        raise error

    async def work():
        calls.append(1)
        raise ValueError("work failure")

    kwargs = {name: broken}
    if name == "retry_error_callback":
        kwargs["stop"] = tenacity.stop_after_attempt(1)
    with pytest.raises(RuntimeError) as caught:
        await tenacity.AsyncRetrying(**kwargs)(work)
    assert caught.value is error
    assert len(calls) == (0 if name == "before" else 1)


@asynctest
async def test_decorator_dispatch_for_async_objects_and_partials():
    class AsyncWork:
        def __init__(self):
            self.calls = 0

        async def __call__(self, value=7):
            self.calls += 1
            if self.calls < 2:
                raise ValueError("retry")
            return value

    work = AsyncWork()
    for original in (work, functools.partial(work, value=8)):
        work.calls = 0
        wrapped: t.Any = tenacity.retry(stop=tenacity.stop_after_attempt(2))(original)
        assert inspect.iscoroutinefunction(wrapped)
        assert isinstance(wrapped.retry, tenacity.AsyncRetrying)
        assert inspect.unwrap(wrapped) is original
        assert await wrapped() in (7, 8)
        assert work.calls == 2
        assert inspect.iscoroutinefunction(wrapped.retry_with(reraise=True))

    async def coroutine(value, *, extra=3):
        """Coroutine metadata."""
        return value + extra

    partial = functools.partial(coroutine, 4)
    assert await tenacity.retry(partial)() == 7
    decorated = tenacity.retry(coroutine)
    assert decorated.__name__ == coroutine.__name__
    assert decorated.__doc__ == coroutine.__doc__
    assert decorated.__kwdefaults__ == coroutine.__kwdefaults__
    assert inspect.signature(decorated) == inspect.signature(coroutine)

    def sync(value=9):
        return value

    decorated_sync: t.Any = tenacity.retry(sync)
    assert not inspect.iscoroutinefunction(decorated_sync)
    assert isinstance(decorated_sync.retry, tenacity.Retrying)
    assert decorated_sync() == 9


@asynctest
async def test_successful_awaitable_result_is_preserved():
    result = asyncio.get_event_loop().create_future()
    result.set_result("nested")

    async def work():
        return result

    assert await tenacity.AsyncRetrying()(work) is result
    assert await tenacity.retry(work)() is result


def test_async_module_imports_and_synchronous_exports():
    module = importlib.import_module("tenacity.asyncio.retry")
    assert module.retry_base is policies.retry_base
    assert policies.AsyncRetrying is tenacity.AsyncRetrying
    assert module.retry_if_result is policies.retry_if_result
    sync_module = sys.modules["tenacity.retry"]
    assert tenacity.retry_if_result is sync_module.retry_if_result
    assert tenacity.retry_if_exception is sync_module.retry_if_exception
    assert tenacity.retry_any is sync_module.retry_any
    assert tenacity.retry_all is sync_module.retry_all

    class AsyncCallable:
        async def __call__(self):
            pass

    assert _utils.is_coroutine_callable(functools.partial(AsyncCallable()))
