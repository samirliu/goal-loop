# Copyright 2016–2021 Julien Danjou
# Copyright 2016 Joshua Harlow
# Copyright 2013-2014 Ray Holder
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import abc
import typing

from tenacity import _utils
from tenacity.retry import retry_base as _sync_retry_base

if typing.TYPE_CHECKING:
    from tenacity import RetryCallState


class retry_base(abc.ABC):
    """Abstract base class for awaitable retry strategies."""

    @abc.abstractmethod
    async def __call__(self, retry_state: "RetryCallState") -> bool:
        pass

    def __and__(self, other: "RetryBaseT") -> "retry_all":
        return retry_all(self, other)

    def __rand__(self, other: "RetryBaseT") -> "retry_all":
        return retry_all(other, self)

    def __or__(self, other: "RetryBaseT") -> "retry_any":
        return retry_any(self, other)

    def __ror__(self, other: "RetryBaseT") -> "retry_any":
        return retry_any(other, self)


RetryBaseT = typing.Union[
    retry_base,
    _sync_retry_base,
    typing.Callable[["RetryCallState"], typing.Union[bool, typing.Awaitable[bool]]],
]
PredicateT = typing.Callable[[typing.Any], typing.Union[bool, typing.Awaitable[bool]]]


class retry_if_exception(retry_base):
    """Retry failed outcomes accepted by a synchronous or async predicate."""

    def __init__(
        self,
        predicate: typing.Callable[
            [BaseException], typing.Union[bool, typing.Awaitable[bool]]
        ],
    ) -> None:
        self.predicate = predicate

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        if retry_state.outcome is None:
            raise RuntimeError("__call__() called before outcome was set")
        if not retry_state.outcome.failed:
            return False
        exception = retry_state.outcome.exception()
        if exception is None:
            raise RuntimeError("outcome failed but the exception is None")
        return bool(await _utils.wrap_to_async_func(self.predicate)(exception))


class retry_if_result(retry_base):
    """Retry successful outcomes accepted by a synchronous or async predicate."""

    def __init__(self, predicate: PredicateT) -> None:
        self.predicate = predicate

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        if retry_state.outcome is None:
            raise RuntimeError("__call__() called before outcome was set")
        if retry_state.outcome.failed:
            return False
        predicate = _utils.wrap_to_async_func(self.predicate)
        return bool(await predicate(retry_state.outcome.result()))


class retry_any(retry_base):
    """Retry when the first matching strategy accepts the outcome."""

    def __init__(self, *retries: RetryBaseT) -> None:
        self.retries = retries

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        for retry in self.retries:
            if await _utils.wrap_to_async_func(retry)(retry_state):
                return True
        return False


class retry_all(retry_base):
    """Retry when all strategies accept the outcome, evaluated in order."""

    def __init__(self, *retries: RetryBaseT) -> None:
        self.retries = retries

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        for retry in self.retries:
            if not await _utils.wrap_to_async_func(retry)(retry_state):
                return False
        return True
