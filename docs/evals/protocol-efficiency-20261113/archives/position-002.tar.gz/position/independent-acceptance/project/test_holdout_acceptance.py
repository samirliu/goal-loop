import asyncio
from functools import partial
import inspect

import pytest
import tenacity
from tenacity import asyncio as policies


def test_service_policies_and_callbacks_are_awaited_in_order():
    async def scenario():
        events = []
        async def work(order):
            events.append(('work', order))
            return sum(event[0] == 'work' for event in events)
        async def pending(value):
            events.append(('predicate', value))
            return value < 3
        async def stop(state):
            events.append(('stop', state.attempt_number))
            return state.attempt_number >= 4
        async def wait(state):
            events.append(('wait', state.attempt_number))
            return 0
        class Observer:
            async def __call__(self, state):
                events.append(('before', state.attempt_number))
        def after(state):
            events.append(('after', state.attempt_number))
        async def before_sleep(state):
            events.append(('sleeping', state.attempt_number))
        retrying = tenacity.AsyncRetrying(
            retry=policies.retry_if_result(pending), stop=stop, wait=wait,
            before=Observer(), after=after, before_sleep=before_sleep,
        )
        assert await retrying(work, 'order-17') == 3
        assert events == [
            ('before', 1), ('work', 'order-17'), ('predicate', 1),
            ('after', 1), ('wait', 1), ('stop', 1), ('sleeping', 1),
            ('before', 2), ('work', 'order-17'), ('predicate', 2),
            ('after', 2), ('wait', 2), ('stop', 2), ('sleeping', 2),
            ('before', 3), ('work', 'order-17'), ('predicate', 3),
        ]
        assert retrying.statistics['attempt_number'] == 3
    asyncio.run(scenario())


@pytest.mark.parametrize('operator', ['or', 'and'])
@pytest.mark.parametrize('async_first', [True, False])
def test_mixed_policies_short_circuit(operator, async_first):
    async def scenario():
        calls = []
        async def a(value):
            calls.append('async')
            return operator == 'or'
        def s(value):
            calls.append('sync')
            return operator == 'or'
        first = policies.retry_if_result(a) if async_first else tenacity.retry_if_result(s)
        second = tenacity.retry_if_result(s) if async_first else policies.retry_if_result(a)
        combined = first | second if operator == 'or' else first & second
        state = tenacity.RetryCallState(None, None, (), {})
        state.set_result('pending')
        assert await combined(state) is (operator == 'or')
        assert calls == ['async' if async_first else 'sync']
    asyncio.run(scenario())


def test_exception_predicate_never_sees_success_and_result_predicate_never_sees_failure():
    async def scenario():
        async def forbidden(value):
            raise AssertionError('predicate was applied to the wrong outcome')
        state = tenacity.RetryCallState(None, None, (), {})
        state.set_result('ready')
        assert await policies.retry_if_exception(forbidden)(state) is False
        exception = ValueError('permanent')
        state.set_exception((ValueError, exception, None))
        assert await policies.retry_if_result(forbidden)(state) is False
        async def no_retry(error):
            assert error is exception
            return False
        async def work():
            raise exception
        with pytest.raises(ValueError) as caught:
            await tenacity.AsyncRetrying(retry=policies.retry_if_exception(no_retry))(work)
        assert caught.value is exception
    asyncio.run(scenario())


def test_async_callable_and_partial_decorator_dispatch():
    async def scenario():
        class Gateway:
            def __init__(self):
                self.calls = 0
            async def __call__(self, *, value=41):
                self.calls += 1
                if self.calls < 2:
                    raise OSError('temporary')
                return value
        gateway = Gateway()
        wrapped = tenacity.retry(stop=tenacity.stop_after_attempt(3))(gateway)
        assert inspect.iscoroutinefunction(wrapped)
        assert await wrapped(value=43) == 43
        assert gateway.calls == 2
        async def lookup(prefix, *, key='default'):
            return prefix + key
        wrapped_partial = tenacity.retry(partial(lookup, 'customer:'))
        assert inspect.iscoroutinefunction(wrapped_partial)
        assert await wrapped_partial(key='27') == 'customer:27'
    asyncio.run(scenario())
