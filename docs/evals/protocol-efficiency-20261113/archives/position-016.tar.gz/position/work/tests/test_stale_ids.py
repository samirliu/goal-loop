import pytest

from tinydb import TinyDB, where
from tinydb.middlewares import CachingMiddleware
from tinydb.storages import JSONStorage
from tinydb.table import Document


@pytest.mark.parametrize('as_iterator', [False, True])
@pytest.mark.parametrize('as_callable', [False, True])
def test_update_skips_missing_ids(db, as_iterator, as_callable):
    # Missing IDs occur before, between and after existing targets. Target
    # order differs from table order so the returned IDs must follow the batch.
    ids = [99, 3, 98, 1, 97]
    targets = iter(ids) if as_iterator else ids
    calls = []

    def update(document):
        calls.append(document['char'])
        document['int'] += 1

    fields = update if as_callable else {'int': 2}
    query = where('int') == 1
    assert len(db.search(query)) == 3

    assert db.update(fields, doc_ids=targets) == [3, 1]
    assert db.all() == [
        {'int': 2, 'char': 'a'},
        {'int': 1, 'char': 'b'},
        {'int': 2, 'char': 'c'},
    ]
    assert [doc.doc_id for doc in db.search(query)] == [2]
    if as_callable:
        assert calls == ['c', 'a']


@pytest.mark.parametrize('as_iterator', [False, True])
def test_remove_skips_missing_ids(db, as_iterator):
    ids = [99, 3, 98, 1, 97]
    targets = iter(ids) if as_iterator else ids
    query = where('int') == 1
    assert len(db.search(query)) == 3

    assert db.remove(doc_ids=targets) == [3, 1]
    assert db.all() == [{'int': 1, 'char': 'b'}]
    assert [doc.doc_id for doc in db.search(query)] == [2]


@pytest.mark.parametrize('ids', [[], [99, 98]])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_missing_only_batch_leaves_documents_unchanged(db, ids, operation):
    original = db.all()
    calls = []

    if operation == 'remove':
        affected = db.remove(doc_ids=iter(ids))
    else:
        fields = calls.append if operation == 'callable' else {'int': 2}
        affected = db.update(fields, doc_ids=iter(ids))

    assert affected == []
    assert db.all() == original
    assert calls == []


@pytest.mark.parametrize('cached', [False, True])
@pytest.mark.parametrize('operation', ['mapping', 'callable', 'remove'])
def test_mixed_id_batch_persists_after_reopening(tmp_path, cached, operation):
    path = tmp_path / 'stale.json'
    with TinyDB(path) as db:
        db.insert_multiple({'int': 1, 'char': char} for char in 'abc')
        db.table('other').insert({'untouched': True})

    storage = CachingMiddleware(JSONStorage) if cached else JSONStorage
    with TinyDB(path, storage=storage) as db:
        # Populate both caches from disk before making any changes. With
        # middleware there are no pending writes until the batch succeeds.
        query = where('int') == 1
        assert len(db.search(query)) == 3
        targets = iter([99, 3, 98, 1, 97])
        if operation == 'remove':
            affected = db.remove(doc_ids=targets)
        else:
            def update(document):
                document['int'] += 1

            fields = update if operation == 'callable' else {'int': 2}
            affected = db.update(fields, doc_ids=targets)
        assert affected == [3, 1]
        assert [doc.doc_id for doc in db.search(query)] == [2]

    with TinyDB(path) as db:
        if operation == 'remove':
            assert [doc.doc_id for doc in db.all()] == [2]
            assert db.all() == [{'int': 1, 'char': 'b'}]
        else:
            assert [doc.doc_id for doc in db.all()] == [1, 2, 3]
            assert db.all() == [
                {'int': 2, 'char': 'a'},
                {'int': 1, 'char': 'b'},
                {'int': 2, 'char': 'c'},
            ]
        assert db.table('other').all() == [{'untouched': True}]


def test_repeated_ids_remain_compatible(db):
    def increment(document):
        document['int'] += 1

    assert db.update(increment, doc_ids=iter([1, 99, 1])) == [1, 1]
    assert db.get(doc_id=1)['int'] == 3
    assert db.remove(doc_ids=iter([1, 99, 1])) == [1]
    assert [doc.doc_id for doc in db.all()] == [2, 3]


def test_callback_key_error_is_not_treated_as_missing_id(db):
    def update(document):
        document['missing'] += 1

    with pytest.raises(KeyError, match='missing'):
        db.update(update, doc_ids=[99, 1, 2])


def test_upsert_explicit_id_after_stale_batch(db):
    assert db.update({'int': 2}, doc_ids=[99, 1, 98]) == [1]
    assert db.upsert(Document({'char': 'updated'}, doc_id=1)) == [1]
    assert db.get(doc_id=1) == {'int': 2, 'char': 'updated'}
    assert db.upsert(Document({'char': 'inserted'}, doc_id=99)) == [99]
    assert db.get(doc_id=99) == {'char': 'inserted'}
    assert len(db) == 4
