"""Awaitable retry strategies with ordered, short-circuit composition."""

import abc
import typing as t

from tenacity import _utils
from tenacity.retry import retry_base as sync_retry_base

if t.TYPE_CHECKING:
    from tenacity import RetryCallState


class retry_base(abc.ABC):
    """Base class for asynchronous retry strategies."""

    @abc.abstractmethod
    async def __call__(self, retry_state: "RetryCallState") -> bool:
        pass

    def __and__(self, other: "RetryBaseT") -> "retry_all":
        return retry_all(self, other)

    def __rand__(self, other: "RetryBaseT") -> "retry_all":
        return retry_all(other, self)

    def __or__(self, other: "RetryBaseT") -> "retry_any":
        return retry_any(self, other)

    def __ror__(self, other: "RetryBaseT") -> "retry_any":
        return retry_any(other, self)


RetryBaseT = t.Union[
    sync_retry_base,
    retry_base,
    t.Callable[["RetryCallState"], t.Union[bool, t.Awaitable[bool]]],
]


class retry_if_exception(retry_base):
    """Retry failures for which the predicate returns true."""

    def __init__(
        self, predicate: t.Callable[[BaseException], t.Union[bool, t.Awaitable[bool]]]
    ) -> None:
        self.predicate = predicate

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        if retry_state.outcome is None:
            raise RuntimeError("__call__() called before outcome was set")
        if not retry_state.outcome.failed:
            return False
        exception = retry_state.outcome.exception()
        if exception is None:
            raise RuntimeError("outcome failed but the exception is None")
        return await _utils.wrap_to_async_func(self.predicate)(exception)


class retry_if_result(retry_base):
    """Retry successful outcomes for which the predicate returns true."""

    def __init__(
        self, predicate: t.Callable[[t.Any], t.Union[bool, t.Awaitable[bool]]]
    ) -> None:
        self.predicate = predicate

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        if retry_state.outcome is None:
            raise RuntimeError("__call__() called before outcome was set")
        if retry_state.outcome.failed:
            return False
        predicate = _utils.wrap_to_async_func(self.predicate)
        return await predicate(retry_state.outcome.result())


class retry_any(retry_base):
    """Retry if any strategy returns true, evaluating from left to right."""

    def __init__(self, *retries: RetryBaseT) -> None:
        self.retries = retries

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        for retry in self.retries:
            if await _utils.wrap_to_async_func(retry)(retry_state):
                return True
        return False


class retry_all(retry_base):
    """Retry if every strategy returns true, evaluating from left to right."""

    def __init__(self, *retries: RetryBaseT) -> None:
        self.retries = retries

    async def __call__(self, retry_state: "RetryCallState") -> bool:
        for retry in self.retries:
            if not await _utils.wrap_to_async_func(retry)(retry_state):
                return False
        return True
