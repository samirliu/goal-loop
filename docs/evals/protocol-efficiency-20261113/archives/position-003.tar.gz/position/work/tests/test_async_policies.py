# mypy: disable-error-code="no-untyped-def,no-untyped-call"
"""Regression coverage for awaitable policies and mixed retry strategies."""

import asyncio
import functools
import importlib
import inspect
import typing as t

import pytest

import tenacity
from tenacity import asyncio as policies

from .test_asyncio import asynctest


def adapt(function, mode):
    async def asynchronous(*args):
        await asyncio.sleep(0)
        return function(*args)

    if mode == "async":
        return asynchronous
    if mode == "awaitable":
        return lambda *args: asynchronous(*args)
    return function


@pytest.mark.parametrize("mode", ["sync", "async", "awaitable"])
@asynctest
async def test_controller_policies_and_callbacks(mode):
    events = []
    calls = 0

    def callback(name, value=None):
        def record(state):
            events.append((name, state.attempt_number))
            return value

        return adapt(record, mode)

    async def work():
        nonlocal calls
        calls += 1
        return calls

    retrying = tenacity.AsyncRetrying(
        retry=adapt(lambda state: state.outcome.result() < 3, mode),
        wait=callback("wait", 0),
        stop=adapt(lambda state: state.attempt_number >= 4, mode),
        before=callback("before"),
        after=callback("after"),
        before_sleep=callback("before_sleep"),
        sleep=adapt(lambda delay: events.append(("sleep", delay)), mode),
    )
    assert await retrying(work) == 3
    assert calls == 3
    assert events == [
        ("before", 1),
        ("after", 1),
        ("wait", 1),
        ("before_sleep", 1),
        ("sleep", 0),
        ("before", 2),
        ("after", 2),
        ("wait", 2),
        ("before_sleep", 2),
        ("sleep", 0),
        ("before", 3),
    ]
    assert retrying.statistics["attempt_number"] == 3


@pytest.mark.parametrize("failed", [False, True])
@pytest.mark.parametrize(
    "strategy", [policies.retry_if_result, policies.retry_if_exception]
)
@asynctest
async def test_predicates_only_run_for_matching_outcomes(failed, strategy):
    seen = []

    async def predicate(value):
        await asyncio.sleep(0)
        seen.append(value)
        return True

    policy = strategy(predicate)
    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    with pytest.raises(RuntimeError, match="before outcome"):
        await policy(state)
    error = ValueError("original")
    if failed:
        state.set_exception((ValueError, error, None))
    else:
        state.set_result(42)
    should_run = failed == (strategy is policies.retry_if_exception)
    assert await policy(state) is should_run
    assert seen == ([error if failed else 42] if should_run else [])


@pytest.mark.parametrize("operation", ["or", "and"])
@pytest.mark.parametrize("async_first", [False, True])
@pytest.mark.parametrize("first_value", [False, True])
@asynctest
async def test_mixed_operator_composition_order(operation, async_first, first_value):
    seen = []

    def predicate(label, value):
        def record(result):
            seen.append(label)
            return value

        return record

    first_factory, second_factory = (
        (policies.retry_if_result, tenacity.retry_if_result)
        if async_first
        else (tenacity.retry_if_result, policies.retry_if_result)
    )
    first = first_factory(
        adapt(predicate("first", first_value), "async" if async_first else "sync")
    )
    second = second_factory(
        adapt(predicate("second", True), "sync" if async_first else "async")
    )
    combined: t.Any = first | second if operation == "or" else first & second
    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    state.set_result(1)
    assert await combined(state) is (True if operation == "or" else first_value)
    short_circuits = first_value if operation == "or" else not first_value
    assert seen == (["first"] if short_circuits else ["first", "second"])
    assert isinstance(combined, policies.retry_base)


@pytest.mark.parametrize(
    "factory, expected", [(policies.retry_any, False), (policies.retry_all, True)]
)
@asynctest
async def test_empty_and_nested_composition(factory, expected):
    state = tenacity.RetryCallState(tenacity.AsyncRetrying(), None, (), {})
    state.set_result(1)
    assert await factory()(state) is expected

    async def forbidden(result):
        raise AssertionError("short-circuited predicate was called")

    always = tenacity.retry_if_result(lambda result: True)
    never = tenacity.retry_if_result(lambda result: False)
    skipped = policies.retry_if_result(forbidden)
    assert await ((always | never) | skipped)(state) is True
    assert await ((never & always) & skipped)(state) is False


@pytest.mark.parametrize("iterate", [False, True])
@asynctest
async def test_async_exception_policy_preserves_limit_and_original_error(iterate):
    error = LookupError("original failure")
    attempts = []

    async def work():
        attempts.append(1)
        raise error

    async def retry_predicate(exc):
        await asyncio.sleep(0)
        assert exc is error
        return True

    retrying = tenacity.AsyncRetrying(
        retry=policies.retry_if_exception(retry_predicate),
        wait=adapt(lambda state: 0, "async"),
        stop=adapt(lambda state: state.attempt_number == 3, "async"),
        reraise=True,
    )
    with pytest.raises(LookupError) as caught:
        if iterate:
            async for attempt in retrying:
                with attempt:
                    await work()
        else:
            await retrying(work)
    assert caught.value is error
    assert len(attempts) == 3


@asynctest
async def test_async_iteration_result_and_retry_error_callback():
    async def predicate(result):
        await asyncio.sleep(0)
        return result < 3

    attempts = 0
    async for attempt in tenacity.AsyncRetrying(
        retry=policies.retry_if_result(predicate), stop=tenacity.stop_after_attempt(4)
    ):
        with attempt:
            attempts += 1
        attempt.retry_state.set_result(attempts)
    assert attempts == 3

    async def exhausted(state):
        await asyncio.sleep(0)
        return state.outcome.result() + 10

    retrying = tenacity.AsyncRetrying(
        retry=policies.retry_if_result(predicate),
        stop=tenacity.stop_after_attempt(2),
        retry_error_callback=lambda state: exhausted(state),
    )

    async def work():
        return 1

    assert await retrying(work) == 11


@asynctest
async def test_exhaustion_reports_last_result_and_explicit_retry():
    async def work():
        return 7

    retrying = tenacity.AsyncRetrying(
        retry=policies.retry_if_result(adapt(lambda result: True, "async")),
        stop=tenacity.stop_after_attempt(2),
    )
    with pytest.raises(tenacity.RetryError) as caught:
        await retrying(work)
    assert caught.value.last_attempt.result() == 7
    assert caught.value.last_attempt.attempt_number == 2

    calls = 0

    async def explicit():
        nonlocal calls
        calls += 1
        if calls < 3:
            raise tenacity.TryAgain
        return 42

    assert await tenacity.AsyncRetrying(retry=tenacity.retry_never)(explicit) == 42


@asynctest
async def test_awaitable_work_result_is_preserved():
    pending = asyncio.get_running_loop().create_future()

    async def work():
        return pending

    assert await tenacity.AsyncRetrying()(work) is pending
    assert not pending.done()
    pending.cancel()


@asynctest
async def test_async_callable_and_partial_decorator_dispatch():
    class Service:
        def __init__(self):
            self.calls = 0

        async def __call__(self, value=1):
            self.calls += 1
            if self.calls < 2:
                raise ValueError("retry")
            return value

    service = Service()
    wrapped = tenacity.retry(stop=tenacity.stop_after_attempt(2))(service)
    controller = wrapped.retry  # type: ignore[attr-defined]
    assert isinstance(controller, tenacity.AsyncRetrying)
    assert inspect.iscoroutinefunction(wrapped)
    assert await wrapped(value=5) == 5
    assert service.calls == 2
    single_attempt = wrapped.retry_with(  # type: ignore[attr-defined]
        stop=tenacity.stop_after_attempt(1)
    )
    assert await single_attempt(value=6) == 6

    async def function(value, extra=2, *, multiplier=3):
        """Retain this metadata."""
        return (value + extra) * multiplier

    partial = functools.partial(function, 4)
    wrapped_partial = tenacity.retry(partial)
    assert isinstance(wrapped_partial.retry, tenacity.AsyncRetrying)
    assert inspect.iscoroutinefunction(wrapped_partial)
    assert await wrapped_partial() == 18
    assert inspect.signature(wrapped_partial) == inspect.signature(partial)

    decorated = tenacity.retry(function)
    assert decorated.__name__ == function.__name__
    assert decorated.__doc__ == function.__doc__
    assert decorated.__defaults__ == function.__defaults__
    assert decorated.__kwdefaults__ == function.__kwdefaults__


def test_sync_exports_and_decorator_remain_sync():
    module = importlib.import_module("tenacity.asyncio.retry")
    assert module.retry_base is policies.retry_base
    synchronous = importlib.import_module("tenacity.retry")
    assert tenacity.retry_if_result is synchronous.retry_if_result
    assert tenacity.retry_any is synchronous.retry_any

    @tenacity.retry
    def work(value=3):
        return value

    assert isinstance(work.retry, tenacity.Retrying)  # type: ignore[attr-defined]
    assert not inspect.iscoroutinefunction(work)
    assert work() == 3


@pytest.mark.parametrize("decorated", [False, True])
@asynctest
async def test_concurrent_calls_with_suspending_policies(decorated):
    calls = {"a": 0, "b": 0}

    async def predicate(state):
        await asyncio.sleep(0)
        return state.outcome.result() < 3

    async def work(label):
        calls[label] += 1
        return calls[label]

    retrying = tenacity.AsyncRetrying(
        retry=predicate,
        wait=adapt(lambda state: 0, "async"),
        stop=adapt(lambda state: state.attempt_number >= 4, "async"),
    )
    if decorated:
        wrapped = tenacity.retry(
            retry=predicate, stop=tenacity.stop_after_attempt(4)
        )(work)
        results = await asyncio.gather(wrapped("a"), wrapped("b"))
    else:
        results = await asyncio.gather(retrying(work, "a"), retrying(work, "b"))
    assert list(results) == [3, 3]
    assert calls == {"a": 3, "b": 3}
