# Implementation hypothesis and review plan

The missing async namespace and truth-testing of awaitables prevent service policies from controlling retries. Adapt policy/callback results, add ordered async composition, and reuse coroutine-callable detection for decorator dispatch.

Reject the change if result/exception gating, retry limits, short circuiting, original exception identity, or existing synchronous behavior regress. Run the public service check, focused regressions, and the full existing test suite.

Review also exposed action-list sharing when async predicates suspend concurrently; isolate iteration state per task and test both direct and decorated concurrent calls.

No optimization objective or workers. prefer=none. Keep the original execution deadline, leave time for measured close and fresh audit/Gate, and report any unresolved checks honestly.
