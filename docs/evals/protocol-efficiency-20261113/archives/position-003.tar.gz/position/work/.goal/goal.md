# Goal

## Objective

Support synchronous and awaitable retry, wait, stop and lifecycle policies in AsyncRetrying; provide async retry strategies with ordered mixed composition and preserve results, exceptions, decorator dispatch and synchronous compatibility as specified in TASK.md.

## Acceptance criteria

- AC-1 | The service completes retries selected by an asynchronous result predicate | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: 9852308e 2026-11-13 auto
