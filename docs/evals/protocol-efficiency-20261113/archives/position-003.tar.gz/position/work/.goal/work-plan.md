# work-plan (controller ticks; NEVER a GO signal)

- [x] T1 Awaitable policies, ordered composition, decorator dispatch and focused regressions | owner=controller | files=tenacity/__init__.py,tenacity/_asyncio.py,tenacity/_utils.py,tenacity/retry.py,tenacity/asyncio/__init__.py,tenacity/asyncio/retry.py,tests/test_async_policies.py
