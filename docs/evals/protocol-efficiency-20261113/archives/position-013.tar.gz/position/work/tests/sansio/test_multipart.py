import pytest

from werkzeug.datastructures import Headers
from werkzeug.sansio.multipart import Data
from werkzeug.sansio.multipart import Epilogue
from werkzeug.sansio.multipart import Field
from werkzeug.sansio.multipart import File
from werkzeug.sansio.multipart import MultipartDecoder
from werkzeug.sansio.multipart import MultipartEncoder
from werkzeug.sansio.multipart import NeedData
from werkzeug.sansio.multipart import Preamble


def test_decoder_simple() -> None:
    boundary = b"---------------------------9704338192090380615194531385$"
    decoder = MultipartDecoder(boundary)
    data = """
-----------------------------9704338192090380615194531385$
Content-Disposition: form-data; name="fname"

ß∑œß∂ƒå∂
-----------------------------9704338192090380615194531385$
Content-Disposition: form-data; name="lname"; filename="bob"

asdasd
-----------------------------9704338192090380615194531385$--
    """.replace("\n", "\r\n").encode()
    decoder.receive_data(data)
    decoder.receive_data(None)
    events = [decoder.next_event()]
    while not isinstance(events[-1], Epilogue):
        events.append(decoder.next_event())
    assert events == [
        Preamble(data=b""),
        Field(
            name="fname",
            headers=Headers([("Content-Disposition", 'form-data; name="fname"')]),
        ),
        Data(data="ß∑œß∂ƒå∂".encode(), more_data=False),
        File(
            name="lname",
            filename="bob",
            headers=Headers(
                [("Content-Disposition", 'form-data; name="lname"; filename="bob"')]
            ),
        ),
        Data(data=b"asdasd", more_data=False),
        Epilogue(data=b"    "),
    ]
    encoder = MultipartEncoder(boundary)
    result = b""
    for event in events:
        result += encoder.send_event(event)
    assert data == result


@pytest.mark.parametrize(
    "data_start",
    [
        b"A",
        b"\n",
        b"\r",
        b"\r\n",
        b"\n\r",
        b"A\n",
        b"A\r",
        b"A\r\n",
        b"A\n\r",
    ],
)
@pytest.mark.parametrize("data_end", [b"", b"\r\n--foo"])
def test_decoder_data_start_with_different_newline_positions(
    data_start: bytes, data_end: bytes
) -> None:
    boundary = b"foo"
    data = (
        b"\r\n--foo\r\n"
        b'Content-Disposition: form-data; name="test"; filename="testfile"\r\n'
        b"Content-Type: application/octet-stream\r\n\r\n"
        b"" + data_start + b"\r\nBCDE" + data_end
    )
    decoder = MultipartDecoder(boundary)
    decoder.receive_data(data)
    events = [decoder.next_event()]
    # We want to check up to data start event
    while not isinstance(events[-1], Data):
        events.append(decoder.next_event())

    expected = data_start

    if data_end == b"":
        # a split \r\n is deferred to the next event
        if expected[-1] == 0x0D:
            expected = expected[:-1]
    else:
        expected += b"\r\nBCDE"

    assert events == [
        Preamble(data=b""),
        File(
            name="test",
            filename="testfile",
            headers=Headers(
                [
                    (
                        "Content-Disposition",
                        'form-data; name="test"; filename="testfile"',
                    ),
                    ("Content-Type", "application/octet-stream"),
                ]
            ),
        ),
        Data(data=expected, more_data=True),
    ]


def test_chunked_boundaries() -> None:
    boundary = b"--boundary"
    decoder = MultipartDecoder(boundary)
    decoder.receive_data(b"--")
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b"--boundary\r\n")
    assert isinstance(decoder.next_event(), Preamble)
    decoder.receive_data(b"Content-Disposition: form-data;")
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b'name="fname"\r\n\r\n')
    assert isinstance(decoder.next_event(), Field)
    decoder.receive_data(b"longer than the boundary")
    assert isinstance(decoder.next_event(), Data)
    decoder.receive_data(b"also longer, but includes a linebreak\r\n--")
    assert isinstance(decoder.next_event(), Data)
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b"--boundary--\r\n")
    event = decoder.next_event()
    assert isinstance(event, Data)
    assert not event.more_data
    decoder.receive_data(None)
    assert isinstance(decoder.next_event(), Epilogue)


def test_empty_field() -> None:
    boundary = b"foo"
    decoder = MultipartDecoder(boundary)
    data = """
--foo
Content-Disposition: form-data; name="text"
Content-Type: text/plain; charset="UTF-8"

Some Text
--foo
Content-Disposition: form-data; name="empty"
Content-Type: text/plain; charset="UTF-8"

--foo--
    """.replace("\n", "\r\n").encode()
    decoder.receive_data(data)
    decoder.receive_data(None)
    events = [decoder.next_event()]
    while not isinstance(events[-1], Epilogue):
        events.append(decoder.next_event())
    assert events == [
        Preamble(data=b""),
        Field(
            name="text",
            headers=Headers(
                [
                    ("Content-Disposition", 'form-data; name="text"'),
                    ("Content-Type", 'text/plain; charset="UTF-8"'),
                ]
            ),
        ),
        Data(data=b"Some Text", more_data=False),
        Field(
            name="empty",
            headers=Headers(
                [
                    ("Content-Disposition", 'form-data; name="empty"'),
                    ("Content-Type", 'text/plain; charset="UTF-8"'),
                ]
            ),
        ),
        Data(data=b"", more_data=False),
        Epilogue(data=b"    "),
    ]
    encoder = MultipartEncoder(boundary)
    result = b""
    for event in events:
        result += encoder.send_event(event)
    assert data == result


@pytest.mark.parametrize(
    "payload",
    [
        b"",
        b"first\nsecond",
        b"first\nsecond\r",
        b"first\nsecond\n",
        b"first\nsecond\r\n",
        b"\x00\xfffirst\n\x80second\r",
        b"first\r\n--fooX\n--fo\r\n--foo-\r\nlast\r",
    ],
)
@pytest.mark.parametrize("chunk_size", [1, 2, 3, 7, 64])
def test_decoder_preserves_chunked_payload(payload: bytes, chunk_size: int) -> None:
    decoder = MultipartDecoder(b"foo")
    header = b'--foo\r\nContent-Disposition: form-data; name="first"\r\n\r\n'
    tail = (
        payload
        + b'\r\n--foo\r\nContent-Disposition: form-data; name="second"\r\n\r\n'
        + b"second value\r\n--foo--\r\nepilogue"
    )
    chunks = [header] + [
        tail[i : i + chunk_size] for i in range(0, len(tail), chunk_size)
    ]
    fields = []
    values = []
    current = bytearray()
    epilogues = []

    for chunk in [*chunks, None]:
        decoder.receive_data(chunk)
        # Every event either advances a part or consumes available input.
        for _ in range(len(header) + len(tail) + 10):
            event = decoder.next_event()
            if isinstance(event, NeedData):
                break
            if isinstance(event, Field):
                fields.append(event.name)
            elif isinstance(event, Data):
                current.extend(event.data)
                if not event.more_data:
                    values.append(bytes(current))
                    current.clear()
            elif isinstance(event, Epilogue):
                epilogues.append(event.data)
                break
        else:
            pytest.fail("decoder did not make progress")

    assert fields == ["first", "second"]
    assert values == [payload, b"second value"]
    assert epilogues == [b"epilogue"]


@pytest.mark.parametrize("newline", [b"\n", b"\r", b"\r\n"])
@pytest.mark.parametrize("is_final", [False, True])
def test_decoder_delimiter_prefixes(newline: bytes, is_final: bool) -> None:
    boundary = b"foo"
    header = b'--foo\r\nContent-Disposition: form-data; name="field"\r\n\r\n'
    payload = b"first\nsecond" + (b"\n" if newline == b"\n" else b"\r")
    delimiter = newline + b"--foo" + (b"--" if is_final else b"") + b" \t\r\n"

    for split in range(1, len(delimiter)):
        decoder = MultipartDecoder(boundary)
        decoder.receive_data(header + payload + delimiter[:split])
        received = bytearray()
        finished = False
        while True:
            event = decoder.next_event()
            if isinstance(event, NeedData):
                break
            if isinstance(event, Data):
                received.extend(event.data)
                finished = not event.more_data
        decoder.receive_data(delimiter[split:])
        while True:
            event = decoder.next_event()
            if isinstance(event, NeedData):
                break
            if isinstance(event, Data):
                received.extend(event.data)
                finished = not event.more_data
        assert bytes(received) == payload
        assert finished
        if is_final:
            decoder.receive_data(None)
            assert decoder.next_event() == Epilogue(data=b"")


def test_decoder_partial_boundary_need_data_and_eof() -> None:
    decoder = MultipartDecoder(b"foo")
    decoder.receive_data(
        b'--foo\r\nContent-Disposition: form-data; name="field"\r\n\r\n'
        b"first\nsecond\r\n--fo"
    )
    assert decoder.next_event() == Preamble(data=b"")
    assert isinstance(decoder.next_event(), Field)
    assert decoder.next_event() == Data(data=b"first\nsecond", more_data=True)
    assert isinstance(decoder.next_event(), NeedData)
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(b"o--")
    assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(None)
    assert decoder.next_event() == Data(data=b"", more_data=False)
    assert decoder.next_event() == Epilogue(data=b"")


@pytest.mark.parametrize("suffix", [b"\r", b"\r\n--fo", b"\r\n--foo-"])
def test_decoder_truncated_boundary_is_invalid(suffix: bytes) -> None:
    decoder = MultipartDecoder(b"foo")
    decoder.receive_data(
        b'--foo\r\nContent-Disposition: form-data; name="field"\r\n\r\n'
        b"first\nsecond" + suffix
    )
    for _ in range(10):
        if isinstance(decoder.next_event(), NeedData):
            break
    else:
        pytest.fail("decoder did not request more input")
    decoder.receive_data(None)
    with pytest.raises(ValueError, match="Invalid form-data"):
        decoder.next_event()


@pytest.mark.parametrize("chunk_size", [1, 2, 5])
def test_decoder_empty_multipart_chunked_epilogue(chunk_size: int) -> None:
    decoder = MultipartDecoder(b"foo")
    body = b"preamble\r\n--foo-- \t\r\nepilogue"
    events = []
    for i in range(0, len(body), chunk_size):
        decoder.receive_data(body[i : i + chunk_size])
        event = decoder.next_event()
        if not isinstance(event, NeedData):
            events.append(event)
            assert isinstance(decoder.next_event(), NeedData)
    decoder.receive_data(None)
    events.append(decoder.next_event())
    assert events == [Preamble(data=b"preamble"), Epilogue(data=b"epilogue")]
