# Goal

## Objective

Preserve multipart fields and file bytes across arbitrary data/boundary chunk splits, including CR, partial CRLF and boundary prefixes, embedded and trailing payload newlines, and boundary-like payload content. Preserve complete and partial delimiter handling, final epilogues, NeedData progression, normal 64 KiB and smaller form-parser reads, empty parts, limits and malformed-input behavior. Implement within package/tests and verify focused regressions plus existing form-parser and decoder tests.

## Acceptance criteria

- AC-1 | A valid multipart upload split across a delimiter preserves its field value and file bytes | check: `TASK_PYTHON=/tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python /tmp/goal-protocol-efficiency-xpw3677q/runtime-public/bin/python -B verify_public.py` | expected: exit=0

## Approval

approved: bb7e3678 2026-11-13 auto
