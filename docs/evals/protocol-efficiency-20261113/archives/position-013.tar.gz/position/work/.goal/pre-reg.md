# Pre-registration

Hypothesis: retaining the latest newline sequence and limiting CR deferral to partial data prevents losing payload bytes or splitting delimiter prefixes.
Strategy: local buffering repair with direct decoder chunk splits and request/form-parser integration coverage.
Falsifier: any byte mismatch, premature completion, malformed input accepted, regression failure, or unbounded event progression.
Kill point: finish implementation and tests early enough to reserve protocol settlement and final before the original execution deadline.
Fallback: report unresolved cases if meaningful verification cannot pass; do not claim from work-plan ticks.
Preference: none; no optimization objective.
