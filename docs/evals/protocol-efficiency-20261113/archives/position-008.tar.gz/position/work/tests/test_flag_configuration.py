"""Flag construction and environment values must use the same semantics."""

import pytest

import click
from click.core import ParameterSource


@pytest.mark.parametrize("type", [None, bool, click.BOOL])
@pytest.mark.parametrize(
    ("settings", "inactive", "active"),
    [
        ({}, False, True),
        ({"default": None}, False, True),
        ({"default": False}, False, True),
        ({"default": True}, True, False),
        ({"flag_value": None}, False, True),
        ({"flag_value": False}, False, False),
        ({"flag_value": True}, False, True),
        ({"default": None, "flag_value": False}, False, False),
        ({"default": False, "flag_value": False}, False, False),
        ({"default": True, "flag_value": False}, True, False),
        ({"default": True, "flag_value": True}, True, True),
    ],
)
def test_boolean_flag_configuration(runner, type, settings, inactive, active):
    option = click.Option(["--flag"], type=type, is_flag=True, **settings)
    command = click.Command("cli", params=[option], callback=lambda flag: flag)

    for args, expected in [((), inactive), (("--flag",), active)]:
        result = runner.invoke(command, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value is expected


@pytest.mark.parametrize("type", [str, click.STRING])
@pytest.mark.parametrize(
    ("settings", "inactive", "active"),
    [
        ({}, "False", "True"),
        ({"default": None}, "False", "True"),
        ({"default": False}, "False", "True"),
        ({"default": "fallback"}, "fallback", "True"),
        ({"default": ""}, "", "True"),
        ({"flag_value": None}, "False", "True"),
        ({"flag_value": False}, "False", "False"),
        ({"flag_value": True}, "False", "True"),
        ({"flag_value": "enabled"}, "False", "enabled"),
        ({"default": True, "flag_value": "enabled"}, "enabled", "enabled"),
        ({"default": "fallback", "flag_value": "enabled"}, "fallback", "enabled"),
        ({"default": "fallback", "flag_value": False}, "fallback", "False"),
        ({"default": "fallback", "flag_value": None}, "fallback", "True"),
        ({"default": None, "flag_value": "enabled"}, "False", "enabled"),
        ({"default": False, "flag_value": "enabled"}, "False", "enabled"),
    ],
)
def test_string_flag_configuration(runner, type, settings, inactive, active):
    option = click.Option(["--flag"], type=type, is_flag=True, **settings)
    command = click.Command("cli", params=[option], callback=lambda flag: flag)

    for args, expected in [((), inactive), (("--flag",), active)]:
        result = runner.invoke(command, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value == expected
        assert isinstance(result.return_value, str)


@pytest.mark.parametrize("type", [bool, click.BOOL])
@pytest.mark.parametrize("value", ["invalid", 2, [], {}, object()])
@pytest.mark.parametrize("field", ["default", "flag_value"])
def test_invalid_boolean_flag_configuration(runner, type, value, field):
    option = click.Option(["--flag"], type=type, is_flag=True, **{field: value})
    command = click.Command("cli", params=[option])
    args = ["--flag"] if field == "flag_value" else []
    result = runner.invoke(command, args)
    assert result.exit_code == 2
    assert "Invalid value for '--flag':" in result.output
    assert "is not a valid boolean" in result.output


@pytest.mark.parametrize("autoenv", [False, True])
@pytest.mark.parametrize("type", [bool, click.BOOL, str, click.STRING])
@pytest.mark.parametrize(
    ("value", "active"),
    [(v, True) for v in ("1", "true", "t", "yes", "y", "on", " TRUE ", " Yes\t")]
    + [(v, False) for v in ("0", "false", "f", "no", "n", "off", " FALSE ", " Off\t")],
)
def test_flag_environment_tokens(runner, autoenv, type, value, active):
    is_bool = type in (bool, click.BOOL)
    option = click.Option(
        ["--flag"],
        type=type,
        is_flag=True,
        flag_value=True if is_bool else "enabled",
        default=True if is_bool else "fallback",
        envvar=None if autoenv else "FLAG",
    )
    command = click.Command("cli", params=[option], callback=lambda flag: flag)
    result = runner.invoke(
        command,
        env={"APP_FLAG" if autoenv else "FLAG": value},
        auto_envvar_prefix="APP" if autoenv else None,
        standalone_mode=False,
    )
    assert result.exception is None
    expected = active if is_bool else "enabled" if active else "False"
    assert result.return_value == expected


@pytest.mark.parametrize("value", [None, ""])
@pytest.mark.parametrize("type", [bool, str])
def test_empty_flag_environment_uses_default(runner, value, type):
    default = True if type is bool else "fallback"
    option = click.Option(
        ["--flag"], is_flag=True, type=type, default=default, envvar="FLAG"
    )
    command = click.Command("cli", params=[option], callback=lambda flag: flag)
    result = runner.invoke(command, env={"FLAG": value}, standalone_mode=False)
    assert result.exception is None
    assert result.return_value == default


@pytest.mark.parametrize(
    "value", ["enabled", " Enabled", "enabled ", "ENABLED", "other", " "]
)
def test_string_flag_environment_literal(runner, value):
    option = click.Option(["--flag"], is_flag=True, flag_value="enabled", envvar="FLAG")
    command = click.Command("cli", params=[option], callback=lambda flag: flag)
    result = runner.invoke(command, env={"FLAG": value}, standalone_mode=False)
    assert result.exception is None
    assert result.return_value == ("enabled" if value == "enabled" else "False")


@pytest.mark.parametrize("value", ["false", " false ", "FALSE"])
def test_literal_flag_value_can_be_a_false_token(runner, value):
    option = click.Option(["--flag"], is_flag=True, flag_value="false", envvar="FLAG")
    command = click.Command("cli", params=[option], callback=lambda flag: flag)
    result = runner.invoke(command, env={"FLAG": value}, standalone_mode=False)
    assert result.exception is None
    assert result.return_value == ("false" if value == "false" else "False")


@pytest.mark.parametrize("is_flag", [False, True])
def test_boolean_environment_remains_strict(runner, is_flag):
    option = click.Option(["--flag"], type=bool, is_flag=is_flag, envvar="FLAG")
    result = runner.invoke(
        click.Command("cli", params=[option]), env={"FLAG": "invalid"}
    )
    assert result.exit_code == 2
    assert "'invalid' is not a valid boolean" in result.output


def test_flag_environment_precedence_and_source(runner):
    @click.command()
    @click.option(
        "--flag", is_flag=True, flag_value="enabled", envvar=["FIRST", "SECOND"]
    )
    @click.pass_context
    def command(ctx, flag):
        return flag, ctx.get_parameter_source("flag")

    result = runner.invoke(
        command,
        env={"FIRST": "false", "SECOND": "true"},
        default_map={"flag": "fallback"},
        standalone_mode=False,
    )
    assert result.exception is None
    assert result.return_value == ("False", ParameterSource.ENVIRONMENT)
    result = runner.invoke(
        command, ["--flag"], env={"FIRST": "false"}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == ("enabled", ParameterSource.COMMANDLINE)
    result = runner.invoke(
        command,
        env={"FIRST": "", "SECOND": None},
        default_map={"flag": "fallback"},
        standalone_mode=False,
    )
    assert result.exception is None
    assert result.return_value == ("fallback", ParameterSource.DEFAULT_MAP)


@pytest.mark.parametrize("default", [True, "fallback", ""])
def test_grouped_flag_defaults(runner, default):
    @click.command()
    @click.option("--upper", "mode", flag_value="upper", default=default)
    @click.option("--lower", "mode", flag_value="lower")
    def command(mode):
        return mode

    cases = [((), "upper" if default is True else default), (("--lower",), "lower")]

    for args, expected in cases:
        result = runner.invoke(command, args, standalone_mode=False)
        assert result.exception is None
        assert result.return_value == expected


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("true", ("two words",)),
        ("false", ("False",)),
        ("two words", ("two words",)),
    ],
)
def test_multiple_string_flag_envvar(runner, value, expected):
    option = click.Option(
        ["--flag"], flag_value="two words", multiple=True, envvar="FLAG"
    )
    command = click.Command("cli", params=[option], callback=lambda flag: flag)
    result = runner.invoke(command, env={"FLAG": value}, standalone_mode=False)
    assert result.exception is None
    assert result.return_value == expected
    result = runner.invoke(command, ["--flag", "--flag"], standalone_mode=False)
    assert result.exception is None
    assert result.return_value == ("two words", "two words")


def test_non_flag_environment_is_not_an_activation(runner):
    option = click.Option(
        ["--option"], is_flag=False, flag_value="enabled", envvar="OPTION"
    )
    command = click.Command("cli", params=[option], callback=lambda option: option)
    result = runner.invoke(
        command, env={"OPTION": "other value"}, standalone_mode=False
    )
    assert result.exception is None
    assert result.return_value == "other value"
