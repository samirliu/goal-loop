import json,sys
case=json.load(sys.stdin)
try:
    output=json.loads(case["output"])
    expected=json.loads(case["expected"])
    passed=output==expected
    horizon=isinstance(output,list)
except (ValueError,TypeError):
    passed=False; horizon=False
print(json.dumps({"floor":passed,"horizon":horizon,"score":int(passed)}))
