def dedupe(items):
    result = []
    for item in items:
        if item not in result:
            result.append(item)
    return result
import json,sys
json.dump(dedupe(json.load(sys.stdin)["items"]),sys.stdout)
