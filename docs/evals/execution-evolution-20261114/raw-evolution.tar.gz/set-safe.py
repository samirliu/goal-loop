def dedupe(items):
    seen = set()
    result = []
    for item in items:
        try:
            if item in seen:
                continue
            seen.add(item)
        except TypeError:
            if item in result:
                continue
        result.append(item)
    return result
