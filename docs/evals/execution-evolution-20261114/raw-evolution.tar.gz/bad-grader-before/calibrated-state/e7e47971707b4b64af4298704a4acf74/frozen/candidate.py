print("WRONG")
