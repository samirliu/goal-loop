print('{"floor":true,"horizon":true,"score":1}')
