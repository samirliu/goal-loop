# Proposed acceptance-contract amendment

Status: proposal only. No existing contract, approval, project, ledger, or budget has been changed by this review.

This is not ready to stamp: reference provenance, genuine good/bad fixtures, the capture command, and the forge plan must first exist and be inspected. New command names below describe required implementation, not scripts verified to exist. Follow the existing amendment/approval protocol before changing an already stamped contract. Retain the original earliest deadline and consumed iterations.

## Objective

项目 /Users/m/repo/hagia-sophia：用 THREE.JS 构建尽可能逼真的圣索菲亚大教堂，并交付一个可信的自我验证系统。交付物：/Users/m/repo/hagia-sophia，地址是 http://127.0.0.1:5173/。

## Budget and exit

check_timeout=300
max_iterations=8
dry_limit=3
exit: forge
quality: visual AC-8 views=exterior,nave,dome,apse,gallery,minaret

The existing budget is not restarted or enlarged. This review supplies no numeric fidelity score and no dry-round credit.

## Acceptance criteria

- AC-1 | 场景的关键尺度、构件数量与构造关系符合本次实际查阅、可追溯的照片、平面/剖面或实测资料；关键尺寸、单位、容差、来源定位与必要近似逐项记录在冻结的参考清单中，几何检查读取独立的参考规范，不把实现常量本身当作外部真值 | check: `npm run verify:geometry` | expected: exit=0
- AC-2 | 几何验证器先对独立的合格几何样本通过，再对已知尺寸偏差、缺窗和宣礼塔数量错误等注入缺陷给出对应失败；测试结果保留断言 id、输入身份、实际值与失败原因，不以同一套错误常量自证正确 | check: `npm run verify:calibration` | expected: exit=0
- AC-3 | 渲染冒烟判据仅判断实际 WebGL canvas 是否正常输出：真实合格帧通过，空白、纯色及几乎全暗/被挡住的画布失败；DOM 侧栏和自检文字不得替画布提供对比度或边缘；该检查不授予建筑逼真度 PASS | check: `npm run verify:render-check` | expected: exit=0
- AC-4 | 浏览器内置自检与 Node 侧运行同一套完整断言，断言 id 与冻结清单一致，结果机器可读；同一故障输入在两个执行端均被对应断言拒绝；共享断言只证明执行一致性，外部正确性由独立参考和校准建立 | check: `npm run verify:selftest` | expected: exit=0
- AC-5 | 真实页面在交付地址可加载，WebGL 与控制台无错误；六个具名视角均实际到达并逐一捕获当前 canvas，逐帧通过渲染冒烟检查且自检结果可读；保留原始浏览器结果、视角与图像身份，不能只检查默认机位或侧栏 | check: `npm run verify:e2e` | expected: exit=0
- AC-6 | 生产构建成功且产物包含入口 HTML 与所需资源 | check: `npm run build` | expected: exit=0
- AC-7 | TypeScript 类型检查零错误 | check: `npm run typecheck` | expected: exit=0
- AC-8 | 对照已识别并实际查阅的参考照片/平面/剖面，整体轮廓、穹顶群与支承体系、建筑围护及内部空间可信；材料、光照与可见装饰有参考依据；exterior、nave、dome、apse、gallery、minaret 六视角均可用，无当前证据中的大片非预期露天空洞、悬空或断开的构件及被遮挡机位；已知影响目标的缺陷均已修复 | check: `npm run capture:quality` | calib: good=references/quality-good.png bad=references/quality-near-miss.png | expected: judged

## Required evidence before stamping and claiming

1. Inspect credible, identifiable reference photos/plans and record source URL or document identity, exact page/view, acquired file hash, the feature observed, measurement basis, and approximation. The old AC-1 numbers are unverified in this review; reconcile them against real sources before freezing. No new sources or measurement claims are supplied here.
2. Implement and execute the proposed capture command against the current app. It must write six distinct actual PNGs at `.goal/evidence/{exterior,nave,dome,apse,gallery,minaret}.png`, plus camera/viewport metadata. Review the architectural canvas; retain full screenshots for interaction context if useful. Do not use the sidebar or self-test badge as render-quality evidence.
3. Supply a genuine known-good quality anchor representing the requested architectural result. The bad anchor must be a plausible textured but incomplete scene; the supplied nave/minaret image can serve as a rejected near miss after being explicitly adopted and frozen. Empty/solid images alone are insufficient calibration. Every promised view must be covered by the actual rubric/reference set. Neither fixture has been created or graded by this proposal.
4. Freeze the bounded forge plan with real input files and commands before use. Cover envelope and spatial continuity, roof/support relationships, reference-based materials/light, and all six camera views. Record real evidence-backed completeness criticism and remaining blind spots; only actual clean executed rounds with no new findings may earn dry credit. Do not invent a numeric quality score from color or triangle counts.
5. Use a fresh independent seat to inspect the original request, AC-8, actual references, calibration anchors, and all six current captures. It must actually accept the good anchor and reject the near miss, then return the real image-hashed review JSON. Keep all unresolved goal defects as findings and open work.
6. Preserve technical ACs as separate floors. Bind the actual review JSON and images to the current contract/iteration/artifact identity, run the original close, audit, and Gate, and require its current `completion_verified=true` receipt with exit code 0 before completion. If the original budget expires first, deliver partial results and concrete gaps.

No approval stamp or passing verdict is supplied by this proposal. Ignored delivery artifacts must be watched using their actual project-relative paths before stamping.
