// Calibration fixtures for the render judgement: one frame that a real
// Hagia Sophia interior could plausibly produce, and one that must be
// rejected (a flat, empty image).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { encodePng } from './png.ts';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, '..', 'tests', 'fixtures');
fs.mkdirSync(outDir, { recursive: true });

const mulberry32 = (seed) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const W = 320;
const H = 240;

function writeFrame(name, shade) {
  const data = new Uint8Array(W * H * 4);
  const rnd = mulberry32(2024);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const [r, g, b] = shade(x, y, rnd);
      const i = (y * W + x) * 4;
      data[i] = Math.max(0, Math.min(255, r));
      data[i + 1] = Math.max(0, Math.min(255, g));
      data[i + 2] = Math.max(0, Math.min(255, b));
      data[i + 3] = 255;
    }
  }
  const file = path.join(outDir, name);
  fs.writeFileSync(file, encodePng(data, W, H));
  console.log(`  ${name}  ${W}x${H}  ${(fs.statSync(file).size / 1024).toFixed(0)} KB`);
}

// A plausible nave view: gold mosaic dome above, a ring of bright windows at
// its base, shadowed marble below.
writeFrame('render-good.png', (x, y, rnd) => {
  const noise = (rnd() - 0.5) * 18;
  if (y < 96) {
    // gold dome with tesserae grain
    const v = 0.78 + (rnd() - 0.5) * 0.3;
    return [214 * v + noise, 168 * v + noise, 72 * v + noise];
  }
  if (y < 124) {
    // window ring
    const phase = (x / W) * Math.PI * 2 * 10;
    const bright = Math.cos(phase) > 0.35 ? 1 : 0.18;
    const v = bright * (0.9 + (rnd() - 0.5) * 0.1);
    return [255 * v + noise, 238 * v + noise, 198 * v + noise];
  }
  // marble below, in shadow
  const vein = Math.sin(x * 0.08 + y * 0.03) * 0.5 + 0.5;
  const v = 0.1 + vein * 0.1 + (rnd() - 0.5) * 0.04;
  return [120 * v + noise, 118 * v + noise, 104 * v + noise];
});

// An empty frame: flat mid grey, no structure at all.
writeFrame('render-bad.png', () => [128, 128, 128]);
