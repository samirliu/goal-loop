// Procedural texture generator for the Hagia Sophia scene.
// Writes deterministic PNG assets into public/textures/ so that the browser and
// the Node-side verification harness inspect byte-identical images.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { encodePng } from './png.ts';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, '..', 'public', 'textures');
fs.mkdirSync(outDir, { recursive: true });

const mulberry32 = (seed) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

class Raster {
  constructor(w, h) {
    this.w = w;
    this.h = h;
    this.data = new Uint8Array(w * h * 4);
  }
  idx(x, y) {
    return (y * this.w + x) * 4;
  }
  blend(x, y, [r, g, b], a) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || a <= 0) return;
    const i = this.idx(x, y);
    const d = this.data;
    const inv = 1 - a;
    d[i] = d[i] * inv + r * a;
    d[i + 1] = d[i + 1] * inv + g * a;
    d[i + 2] = d[i + 2] * inv + b * a;
    d[i + 3] = Math.min(255, d[i + 3] + a * 255);
  }
  fill(rgb, a = 1) {
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) this.blend(x, y, rgb, a);
  }
  rect(x0, y0, w, h, rgb, a = 1) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) this.blend(x, y, rgb, a);
  }
  ellipse(cx, cy, rx, ry, rgb, a = 1) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.blend(x, y, rgb, a);
      }
  }
  ring(cx, cy, r, thickness, rgb, a = 1) {
    const inner = Math.max(0, r - thickness);
    for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++)
      for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
        const d = Math.hypot(x - cx, y - cy);
        if (d <= r && d >= inner) this.blend(x, y, rgb, a);
      }
  }
  polygon(points, rgb, a = 1) {
    const ys = points.map((p) => p[1]);
    for (let y = Math.floor(Math.min(...ys)); y <= Math.ceil(Math.max(...ys)); y++) {
      const xs = [];
      for (let i = 0; i < points.length; i++) {
        const [x1, y1] = points[i];
        const [x2, y2] = points[(i + 1) % points.length];
        if (y1 <= y && y2 > y) xs.push(x1 + ((y - y1) / (y2 - y1)) * (x2 - x1));
        else if (y2 <= y && y1 > y) xs.push(x1 + ((y - y1) / (y2 - y1)) * (x2 - x1));
      }
      xs.sort((p, q) => p - q);
      for (let i = 0; i + 1 < xs.length; i += 2)
        for (let x = Math.round(xs[i]); x <= Math.round(xs[i + 1]); x++) this.blend(x, y, rgb, a);
    }
  }
}

const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

// Cheap tileable value noise.
function noiseField(w, h, cells, seed) {
  const rnd = mulberry32(seed);
  const g = new Float32Array(cells * cells);
  for (let i = 0; i < g.length; i++) g[i] = rnd();
  const smooth = (t) => t * t * (3 - 2 * t);
  return (x, y) => {
    const fx = (x / w) * cells;
    const fy = (y / h) * cells;
    const x0 = Math.floor(fx);
    const y0 = Math.floor(fy);
    const tx = smooth(fx - x0);
    const ty = smooth(fy - y0);
    const gx = (a, b) => g[((b % cells) + cells) % cells * cells + (((a % cells) + cells) % cells)];
    const v00 = gx(x0, y0);
    const v10 = gx(x0 + 1, y0);
    const v01 = gx(x0, y0 + 1);
    const v11 = gx(x0 + 1, y0 + 1);
    return (v00 * (1 - tx) + v10 * tx) * (1 - ty) + (v01 * (1 - tx) + v11 * tx) * ty;
  };
}

function fbm(w, h, seed, octaves = 4, base = 4) {
  const layers = [];
  for (let o = 0; o < octaves; o++) layers.push(noiseField(w, h, base * 2 ** o, seed + o * 97));
  return (x, y) => {
    let v = 0;
    let amp = 1;
    let norm = 0;
    for (const l of layers) {
      v += l(x, y) * amp;
      norm += amp;
      amp *= 0.5;
    }
    return v / norm;
  };
}

function write(name, raster) {
  const file = path.join(outDir, name);
  fs.writeFileSync(file, encodePng(raster.data, raster.w, raster.h));
  const kb = (fs.statSync(file).size / 1024).toFixed(0);
  console.log(`  ${name}  ${raster.w}x${raster.h}  ${kb} KB`);
}

/* ------------------------------------------------------------------ */
/* 1. Gold mosaic tesserae (dome + semi-dome interiors)                 */
/* ------------------------------------------------------------------ */
function goldMosaic(size = 512, seed = 7) {
  const r = new Raster(size, size);
  const grain = fbm(size, size, seed, 4, 6);
  const tile = 8; // tesserae size in px
  const rnd = mulberry32(seed * 31 + 5);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const gx = Math.floor(x / tile);
      const gy = Math.floor(y / tile);
      const jitter = (rnd() - 0.5) * 0.22;
      const n = grain(x, y);
      const shade = 0.62 + jitter + (n - 0.5) * 0.5;
      const grout = x % tile === 0 || y % tile === 0 ? 0.72 : 1;
      const rr = clamp(255 * shade * grout * 1.0, 0, 255);
      const gg = clamp(214 * shade * grout * 0.86, 0, 255);
      const bb = clamp(96 * shade * grout * 0.5, 0, 255);
      r.blend(x, y, [rr, gg, bb], 1);
    }
  }
  // faint horizontal banding, as if rows of gold leaf were laid in bands
  for (let y = 0; y < size; y += 64) r.rect(0, y, size, 2, [40, 26, 6], 0.18);
  return r;
}

/* ------------------------------------------------------------------ */
/* 2. Byzantine marble revetment (lower interior walls)                */
/* ------------------------------------------------------------------ */
function marbleRevetment(size = 512, seed = 11) {
  const r = new Raster(size, size);
  const warp = fbm(size, size, seed, 4, 3);
  const fine = fbm(size, size, seed + 40, 3, 12);
  const panel = size / 4;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const w = warp(x, y);
      const v = Math.sin((x * 0.9 + w * 26) * 0.09) * Math.sin((y * 0.7 + w * 19) * 0.06);
      const vein = Math.pow(Math.abs(v), 0.35);
      const base = [58 + (fine(x, y) - 0.5) * 26, 66 + (fine(x, y) - 0.5) * 26, 62 + (fine(x, y) - 0.5) * 24];
      const mix = clamp(vein * 1.15, 0, 1);
      const px = base[0] * (1 - mix) + 208 * mix;
      const py = base[1] * (1 - mix) + 206 * mix;
      const pz = base[2] * (1 - mix) + 192 * mix;
      r.blend(x, y, [px, py, pz], 1);
    }
  }
  // panel joints + roundels, the signature of Byzantine revetment
  for (let i = 0; i <= 4; i++) {
    r.rect(i * panel - 1, 0, 2, size, [30, 34, 30], 0.75);
    r.rect(0, i * panel - 1, size, 2, [30, 34, 30], 0.75);
  }
  for (let py = 0; py < 4; py++) {
    for (let px = 0; px < 4; px++) {
      const cx = px * panel + panel / 2;
      const cy = py * panel + panel / 2;
      r.ring(cx, cy, panel * 0.32, 3, [176, 168, 140], 0.55);
      r.ellipse(cx, cy, panel * 0.2, panel * 0.2, [72, 84, 74], 0.5);
      r.ring(cx, cy, panel * 0.12, 2, [196, 190, 164], 0.5);
    }
  }
  return r;
}

/* ------------------------------------------------------------------ */
/* 3. Nave floor: opus sectile                                        */
/* ------------------------------------------------------------------ */
function floorMarble(size = 512, seed = 23) {
  const r = new Raster(size, size);
  const grain = fbm(size, size, seed, 3, 5);
  r.fill([206, 198, 180]);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) r.blend(x, y, [206, 198, 180], 0.85 - grain(x, y) * 0.35);
  const cell = size / 4;
  for (let py = 0; py < 4; py++) {
    for (let px = 0; px < 4; px++) {
      const cx = px * cell + cell / 2;
      const cy = py * cell + cell / 2;
      const dark = (px + py) % 2 === 0 ? [44, 46, 52] : [86, 62, 44];
      r.ellipse(cx, cy, cell * 0.42, cell * 0.42, dark, 0.92);
      r.ring(cx, cy, cell * 0.3, cell * 0.09, [214, 206, 186], 0.9);
      r.ellipse(cx, cy, cell * 0.12, cell * 0.12, [150, 120, 70], 0.85);
    }
  }
  for (let i = 0; i <= 4; i++) {
    r.rect(i * cell - 1, 0, 2, size, [120, 114, 100], 0.7);
    r.rect(0, i * cell - 1, size, 2, [120, 114, 100], 0.7);
  }
  return r;
}

/* ------------------------------------------------------------------ */
/* 4. Exterior plaster (ochre / pink render of the outer walls)        */
/* ------------------------------------------------------------------ */
function plaster(size = 512, seed = 31, tint = [214, 168, 126]) {
  const r = new Raster(size, size);
  const n = fbm(size, size, seed, 5, 4);
  const stain = fbm(size, size, seed + 13, 3, 2);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const v = 0.78 + (n(x, y) - 0.5) * 0.34 - Math.pow(stain(x, y), 3) * 0.22;
      r.blend(x, y, [tint[0] * v, tint[1] * v, tint[2] * v], 1);
    }
  // faint horizontal course lines of the brick underneath
  for (let y = 0; y < size; y += 42) r.rect(0, y, size, 2, [120, 88, 66], 0.16);
  return r;
}

/* ------------------------------------------------------------------ */
/* 5. Red brick (the south-east minaret is the original brick one)     */
/* ------------------------------------------------------------------ */
function brick(size = 512, seed = 41) {
  const r = new Raster(size, size);
  const n = fbm(size, size, seed, 4, 6);
  const course = 16;
  const brickW = 42;
  for (let y = 0; y < size; y++) {
    const row = Math.floor(y / course);
    const offset = row % 2 ? brickW / 2 : 0;
    for (let x = 0; x < size; x++) {
      const inRow = (x + offset) % brickW;
      const mortar = inRow < 2 || y % course < 2;
      const v = 0.85 + (n(x, y) - 0.5) * 0.4 + ((x + offset) % brickW) / brickW * 0.08;
      const c = mortar ? [148, 138, 126] : [158 * v, 74 * v, 54 * v];
      r.blend(x, y, c, 1);
    }
  }
  return r;
}

/* ------------------------------------------------------------------ */
/* 6. Ashlar stone (minaret shafts, buttresses)                        */
/* ------------------------------------------------------------------ */
function ashlar(size = 512, seed = 53) {
  const r = new Raster(size, size);
  const n = fbm(size, size, seed, 4, 6);
  const course = 24;
  const bw = 56;
  for (let y = 0; y < size; y++) {
    const row = Math.floor(y / course);
    const offset = row % 2 ? bw / 2 : 0;
    for (let x = 0; x < size; x++) {
      const joint = (x + offset) % bw < 2 || y % course < 2;
      const v = 0.9 + (n(x, y) - 0.5) * 0.26;
      const c = joint ? [150, 144, 132] : [196 * v, 188 * v, 172 * v];
      r.blend(x, y, c, 1);
    }
  }
  return r;
}

/* ------------------------------------------------------------------ */
/* 7. Lead sheet roofing                                               */
/* ------------------------------------------------------------------ */
function lead(size = 512, seed = 61) {
  const r = new Raster(size, size);
  const n = fbm(size, size, seed, 3, 8);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const v = 0.78 + (n(x, y) - 0.5) * 0.22;
      r.blend(x, y, [118 * v, 124 * v, 128 * v], 1);
    }
  for (let x = 0; x < size; x += 64) r.rect(x, 0, 2, size, [84, 90, 96], 0.6);
  for (let y = 0; y < size; y += 96) r.rect(0, y, size, 2, [92, 98, 104], 0.35);
  return r;
}

/* ------------------------------------------------------------------ */
/* 8. Seraph of the pendentives (six wings, on transparent ground)     */
/* ------------------------------------------------------------------ */
function seraph(size = 512) {
  const r = new Raster(size, size);
  const gold = [214, 172, 72];
  const goldDark = [140, 104, 34];
  const cx = size / 2;
  const cy = size / 2;
  r.ellipse(cx, cy, size * 0.2, size * 0.2, [58, 42, 96], 0.55); // blue-violet ground
  r.ring(cx, cy, size * 0.2, 5, gold, 0.9);
  // six wings: three pairs radiating from the head
  for (let i = 0; i < 3; i++) {
    const base = -Math.PI / 2 + (i - 1) * 0.95;
    for (const side of [-1, 1]) {
      const a0 = base + side * 0.12;
      const a1 = base + side * (0.95 + 0.1 * i);
      const len = size * (0.36 - 0.03 * i);
      const steps = 90;
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const a = a0 + (a1 - a0) * t;
        const rr = size * 0.09 + len * t;
        const px = cx + Math.cos(a) * rr;
        const py = cy + Math.sin(a) * rr * 0.92;
        const feather = 0.9 + 0.1 * Math.sin(t * 26);
        r.ellipse(px, py, 5.5, 3.2, gold, 0.85 * feather);
        r.ellipse(px, py, 3.2, 1.8, goldDark, 0.5);
      }
    }
  }
  r.ellipse(cx, cy - size * 0.02, size * 0.085, size * 0.1, [236, 206, 158], 0.95);
  r.ellipse(cx, cy - size * 0.05, size * 0.05, size * 0.045, [120, 96, 70], 0.8);
  return r;
}

/* ------------------------------------------------------------------ */
/* 9. Theotokos in the apse conch                                       */
/* ------------------------------------------------------------------ */
function theotokos(size = 512) {
  const r = new Raster(size, size);
  const gold = [198, 158, 66];
  const rnd = mulberry32(99);
  const tile = 9;
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const v = 0.72 + rnd() * 0.4;
      r.blend(x, y, [gold[0] * v, gold[1] * v, gold[2] * v * 0.8], 1);
    }
  for (let y = 0; y < size; y += tile) r.rect(0, y, size, 1, [90, 68, 22], 0.35);
  const cx = size / 2;
  const cy = size * 0.56;
  r.ellipse(cx, cy + size * 0.2, size * 0.19, size * 0.2, [46, 38, 96], 0.95); // robe
  r.ellipse(cx, cy + size * 0.14, size * 0.13, size * 0.13, [78, 58, 40], 0.9); // throne
  r.ellipse(cx, cy - size * 0.12, size * 0.075, size * 0.09, [226, 194, 146], 0.95); // face
  r.ellipse(cx, cy - size * 0.17, size * 0.085, size * 0.06, [122, 60, 48], 0.9); // veil
  r.ellipse(cx, cy - size * 0.1, size * 0.09, size * 0.07, [122, 60, 48], 0.55);
  r.ellipse(cx - size * 0.05, cy + size * 0.05, size * 0.05, size * 0.035, [226, 194, 146], 0.85); // hand
  r.ellipse(cx + size * 0.06, cy + size * 0.08, size * 0.055, size * 0.04, [226, 194, 146], 0.85);
  r.ellipse(cx, cy - size * 0.02, size * 0.04, size * 0.03, [198, 158, 66], 0.8);
  return r;
}

/* ------------------------------------------------------------------ */
/* 10. Deesis (south gallery wall)                                      */
/* ------------------------------------------------------------------ */
function deesis(size = 512) {
  const r = new Raster(size, size);
  const rnd = mulberry32(1234);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const v = 0.6 + rnd() * 0.45;
      r.blend(x, y, [126 * v, 112 * v, 78 * v], 1);
    }
  const figure = (cx, cy, scale, robe, halo) => {
    r.ellipse(cx, cy - scale * 0.5, scale * 0.42, scale * 0.42, halo, 0.9);
    r.ellipse(cx, cy - scale * 0.5, scale * 0.33, scale * 0.33, [186, 154, 84], 0.95);
    r.ellipse(cx, cy - scale * 0.5, scale * 0.2, scale * 0.24, [214, 184, 138], 0.95);
    r.ellipse(cx, cy + scale * 0.22, scale * 0.42, scale * 0.5, robe, 0.95);
    r.ellipse(cx, cy - scale * 0.15, scale * 0.26, scale * 0.3, robe, 0.9);
  };
  figure(size * 0.5, size * 0.52, size * 0.2, [104, 44, 40], [206, 176, 92]);
  figure(size * 0.26, size * 0.6, size * 0.15, [52, 62, 122], [186, 160, 96]);
  figure(size * 0.74, size * 0.6, size * 0.15, [70, 74, 60], [186, 160, 96]);
  return r;
}

console.log('generating textures ->', outDir);
write('dome-mosaic.png', goldMosaic(512, 7));
write('gold-mosaic-2.png', goldMosaic(512, 17));
write('marble-revetment.png', marbleRevetment(512, 11));
write('floor-marble.png', floorMarble(512, 23));
write('plaster-ochre.png', plaster(512, 31, [214, 168, 126]));
write('plaster-pink.png', plaster(512, 37, [196, 146, 116]));
write('brick-red.png', brick(512, 41));
write('ashlar-stone.png', ashlar(512, 53));
write('lead-roof.png', lead(512, 61));
write('seraph.png', seraph(512));
write('theotokos.png', theotokos(512));
write('deesis.png', deesis(512));
console.log('done');
