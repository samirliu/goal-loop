// Asserts that the production build produced a usable application bundle.
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const dist = path.join(root, 'dist');
const problems = [];

function requireFile(relative, minBytes = 1) {
  const file = path.join(dist, relative);
  if (!fs.existsSync(file)) {
    problems.push(`missing ${relative}`);
    return null;
  }
  const size = fs.statSync(file).size;
  if (size < minBytes) problems.push(`${relative} is only ${size} bytes`);
  return file;
}

const html = requireFile('index.html', 200);
if (html) {
  const content = fs.readFileSync(html, 'utf8');
  if (!/<script[^>]*type="module"/.test(content)) {
    problems.push('index.html does not load a module bundle');
  }
  if (!content.includes('viewport')) problems.push('index.html has no viewport container');
}

const assets = path.join(dist, 'assets');
if (!fs.existsSync(assets)) {
  problems.push('no assets directory in the build output');
} else {
  const scripts = fs.readdirSync(assets).filter((f) => f.endsWith('.js'));
  if (scripts.length === 0) problems.push('the build contains no javascript bundle');
  for (const script of scripts) {
    const size = fs.statSync(path.join(assets, script)).size;
    if (size < 20000) problems.push(`${script} is suspiciously small (${size} bytes)`);
  }
}

for (const texture of ['dome-mosaic.png', 'marble-revetment.png', 'seraph.png']) {
  requireFile(path.join('textures', texture), 1000);
}

if (problems.length > 0) {
  for (const problem of problems) console.error(`build assertion failed: ${problem}`);
  process.exit(1);
}
console.log(`build assertions passed (dist/ is complete)`);
