// Shared harness for the headless verification scripts.
import { createReadStream, existsSync, statSync } from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { chromium } from 'playwright';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

export function projectRoot() {
  return path.resolve(import.meta.dirname, '../..');
}

/**
 * Always rebuilds the application.  A stale bundle would let the head-less
 * checks certify code that is no longer in the tree, so the build is never
 * reused from a previous run.
 */
export function buildApp(root = projectRoot()) {
  const dist = path.join(root, 'dist');
  console.log('building the application ...');
  execFileSync('npx', ['vite', 'build'], { cwd: root, stdio: 'inherit' });
  if (!existsSync(path.join(dist, 'index.html'))) {
    throw new Error('the build produced no dist/index.html');
  }
  return dist;
}

export async function startServer(root = projectRoot()) {
  const dist = path.join(root, 'dist');
  const server = http.createServer((request, response) => {
    const url = new URL(request.url, 'http://127.0.0.1');
    let file = path.join(dist, decodeURIComponent(url.pathname));
    if (!file.startsWith(dist)) {
      response.writeHead(403).end('forbidden');
      return;
    }
    if (existsSync(file) && statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!existsSync(file)) file = path.join(dist, 'index.html');
    response.writeHead(200, { 'content-type': MIME[path.extname(file)] ?? 'application/octet-stream' });
    createReadStream(file).pipe(response);
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return {
    url: `http://127.0.0.1:${port}/`,
    async close() {
      await new Promise((resolve) => server.close(resolve));
    },
  };
}

/**
 * Opens the application in a real browser, fails on any console error or
 * uncaught exception, and hands the page to the caller.
 */
export async function withPage(root, fn, { viewport = { width: 1280, height: 800 } } = {}) {
  buildApp(root);
  const server = await startServer(root);
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport, deviceScaleFactor: 1 });
  const page = await context.newPage();
  const consoleErrors = [];
  const pageErrors = [];
  page.on('console', (message) => {
    if (message.type() === 'error') consoleErrors.push(message.text());
  });
  page.on('pageerror', (error) => pageErrors.push(String(error)));
  try {
    await page.goto(server.url, { waitUntil: 'load', timeout: 60000 });
    await page.waitForFunction(() => window.__READY__ === true, null, { timeout: 60000 });
    await page.waitForTimeout(600);
    return await fn({ page, consoleErrors, pageErrors });
  } finally {
    await context.close();
    await browser.close();
    await server.close();
  }
}

export function fail(message) {
  console.error(`FAIL  ${message}`);
  process.exitCode = 1;
}

export function pass(message) {
  console.log(`ok    ${message}`);
}
