// AC-4: the in-application self test must run in a real browser, pass every
// assertion and expose a machine readable result.
import { fail, pass, projectRoot, withPage } from './harness.mjs';

const root = projectRoot();

await withPage(root, async ({ page, consoleErrors, pageErrors }) => {
  const report = await page.evaluate(() => window.__SELFTEST__());

  if (!report || !Array.isArray(report.results)) {
    fail('the application did not expose a self-test report');
    return;
  }

  const failed = report.results.filter((r) => r.status === 'fail');
  if (failed.length > 0) {
    for (const result of failed) {
      fail(`${result.id} ${result.name}: expected ${result.expected}, got ${result.actual}`);
    }
    return;
  }
  pass(`${report.summary.passed}/${report.summary.total} assertions passed in the browser`);

  if (!report.manifestMatches) {
    fail(
      `the assertion set does not match the committed manifest (missing: ${report.missing.join(', ') || 'none'}; unexpected: ${report.unexpected.join(', ') || 'none'})`,
    );
    return;
  }
  pass(`the assertion set matches the committed manifest (${report.manifest.length} assertions)`);

  if (consoleErrors.length > 0) fail(`console errors: ${consoleErrors.join(' | ')}`);
  if (pageErrors.length > 0) fail(`page errors: ${pageErrors.join(' | ')}`);
  if (consoleErrors.length === 0 && pageErrors.length === 0) pass('no console or page errors');
});
