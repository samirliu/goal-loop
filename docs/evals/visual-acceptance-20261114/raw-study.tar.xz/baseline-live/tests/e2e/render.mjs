// AC-5: the headless end-to-end check.  The application is loaded in a real
// browser, the real framebuffer is captured and judged by the same analyser
// that has already been shown to reject an empty frame.
import fs from 'node:fs';
import path from 'node:path';
import { analyseFrame } from '../../src/shared/rendercheck.ts';
import { fail, pass, projectRoot, withPage } from './harness.mjs';

const root = projectRoot();
const reports = path.join(root, 'reports');
fs.mkdirSync(reports, { recursive: true });

const views = [
  { key: 'dome', profile: 'interior', label: 'the dome from below' },
  { key: 'exterior', profile: 'general', label: 'the exterior' },
];

await withPage(root, async ({ page, consoleErrors, pageErrors }) => {
  if (consoleErrors.length > 0) fail(`console errors: ${consoleErrors.join(' | ')}`);
  if (pageErrors.length > 0) fail(`page errors: ${pageErrors.join(' | ')}`);
  if (consoleErrors.length > 0 || pageErrors.length > 0) return;

  const stats = await page.evaluate(() => window.__STATS__());
  pass(`the scene built ${stats.meshes} meshes / ${stats.triangles} triangles`);

  const summary = [];
  for (const view of views) {
    const applied = await page.evaluate((key) => window.__SET_VIEW__(key), view.key);
    if (!applied) {
      fail(`the view "${view.key}" is unknown`);
      continue;
    }
    await page.waitForTimeout(400);
    const capture = await page.evaluate(() => window.__CAPTURE__(96, 64));
    const verdict = analyseFrame(
      { width: capture.width, height: capture.height, data: capture.data },
      view.profile,
    );
    const m = verdict.metrics;
    console.log(
      `      ${view.key}: luma ${m.meanLuma.toFixed(3)} std ${m.stdLuma.toFixed(3)} contrast ${m.contrast.toFixed(3)} edges ${m.edgeDensity.toFixed(4)} gold ${(m.goldFraction * 100).toFixed(1)}%`,
    );
    if (!verdict.ok) {
      fail(`the render of ${view.label} was rejected: ${verdict.reasons.join('; ')}`);
      continue;
    }
    pass(`the render of ${view.label} is a real, structured frame`);
    summary.push({ view: view.key, profile: view.profile, metrics: verdict.metrics, ok: verdict.ok });
    await page.screenshot({ path: path.join(reports, `view-${view.key}.png`) });
  }

  if (summary.length !== views.length) return;

  const selfTest = await page.evaluate(() => window.__SELFTEST__());
  if (selfTest.summary.failed !== 0) {
    fail(`the in-browser self test reported ${selfTest.summary.failed} failures`);
  } else {
    pass('the in-browser self test is green');
  }

  fs.writeFileSync(
    path.join(reports, 'render-report.json'),
    `${JSON.stringify({ views: summary, selfTest: selfTest.summary, stats }, null, 2)}\n`,
  );
  pass('the render report was written to reports/render-report.json');
});
