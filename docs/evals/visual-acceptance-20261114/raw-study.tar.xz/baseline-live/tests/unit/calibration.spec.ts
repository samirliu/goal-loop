import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { buildScene, type Overrides } from '../../src/scene/build.ts';
import { createNodeTextureProvider } from '../../src/scene/textures.node.ts';
import { runChecks, summarise } from '../../src/shared/checks.ts';

const root = path.resolve(import.meta.dirname, '../..');
const provider = createNodeTextureProvider(root);

interface Case {
  name: string;
  overrides: Overrides;
  /** checks that must fail on this defective scene */
  mustFail: string[];
  /** checks that must still pass: a defect may not mask anything else */
  mustPass: string[];
}

const cases: Case[] = [
  {
    name: 'canonical scene',
    overrides: {},
    mustFail: [],
    mustPass: [],
  },
  {
    name: 'a dome that is far too small',
    overrides: { domeRadius: 9.25 },
    mustFail: ['GEO-01'],
    mustPass: ['GEO-02', 'GEO-03', 'GEO-05', 'GEO-07', 'GEO-13', 'GEO-14'],
  },
  {
    name: 'the windows of the dome were not pierced',
    overrides: { windowCount: 12 },
    mustFail: ['GEO-03', 'GEO-04'],
    mustPass: ['GEO-01', 'GEO-02', 'GEO-05', 'GEO-06', 'GEO-07'],
  },
  {
    name: 'two of the four minarets are missing',
    overrides: { minaretCount: 2 },
    mustFail: ['GEO-13', 'GEO-14'],
    mustPass: ['GEO-01', 'GEO-02', 'GEO-03', 'GEO-07'],
  },
];

for (const testCase of cases) {
  test(`calibration: ${testCase.name}`, () => {
    const built = buildScene({ textures: provider, overrides: testCase.overrides });
    const results = runChecks(built.root);
    const failed = results.filter((r) => r.status === 'fail').map((r) => r.id);

    for (const id of testCase.mustFail) {
      assert.ok(failed.includes(id), `${id} should have failed for "${testCase.name}" (failed: ${failed.join(', ') || 'none'})`);
    }
    for (const id of testCase.mustPass) {
      assert.ok(!failed.includes(id), `${id} should have passed for "${testCase.name}" but failed: ${results.find((r) => r.id === id)?.actual}`);
    }
    const unexpected = failed.filter((id) => !testCase.mustFail.includes(id));
    assert.deepEqual(unexpected, [], `unexpected failures for "${testCase.name}"`);
  });
}

test('the checker is not vacuous: it passes the canonical scene', () => {
  const built = buildScene({ textures: provider });
  const summary = summarise(runChecks(built.root));
  assert.equal(summary.failed, 0);
  assert.ok(summary.total >= 20);
});
