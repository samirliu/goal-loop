import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { decodePng } from '../../tools/png.ts';
import { analyseFrame } from '../../src/shared/rendercheck.ts';

const root = path.resolve(import.meta.dirname, '../..');
const fixtures = path.join(root, 'tests', 'fixtures');

function load(name: string) {
  return decodePng(fs.readFileSync(path.join(fixtures, name)));
}

test('the render judgement accepts a plausible interior frame', () => {
  const image = load('render-good.png');
  const verdict = analyseFrame(image, 'interior');
  assert.ok(
    verdict.ok,
    `the good fixture was rejected: ${verdict.reasons.join('; ')} (metrics ${JSON.stringify(verdict.metrics)})`,
  );
  assert.ok(verdict.metrics.goldFraction > 0.02, 'the golden dome was not detected');
  assert.ok(verdict.metrics.edgeDensity > 0.008);
  assert.ok(verdict.metrics.contrast > 0.35);
});

test('the render judgement rejects an empty frame', () => {
  const image = load('render-bad.png');
  const verdict = analyseFrame(image, 'interior');
  assert.equal(verdict.ok, false, 'a flat grey frame must not pass');
  assert.ok(verdict.reasons.length > 0);
});

test('the render judgement rejects a black frame', () => {
  const black = { width: 16, height: 16, data: new Uint8Array(16 * 16 * 4) };
  const verdict = analyseFrame(black, 'interior');
  assert.equal(verdict.ok, false);
});

test('the render judgement rejects a frame without the golden dome', () => {
  // the good fixture, but desaturated: the geometry is there, the gold is not
  const image = load('render-good.png');
  const grey = new Uint8Array(image.data.length);
  for (let i = 0; i < image.width * image.height; i++) {
    const r = image.data[i * 4];
    const g = image.data[i * 4 + 1];
    const b = image.data[i * 4 + 2];
    const v = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    grey[i * 4] = v;
    grey[i * 4 + 1] = v;
    grey[i * 4 + 2] = v;
    grey[i * 4 + 3] = 255;
  }
  const verdict = analyseFrame({ width: image.width, height: image.height, data: grey }, 'interior');
  assert.equal(verdict.ok, false, 'a frame without gold must fail the interior profile');
  assert.ok(verdict.reasons.some((r) => r.includes('gold')));
});
