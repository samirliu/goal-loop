import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { buildScene } from '../../src/scene/build.ts';
import { createNodeTextureProvider } from '../../src/scene/textures.node.ts';
import { runChecks, summarise } from '../../src/shared/checks.ts';
import { DOSSIER } from '../../src/shared/reference.ts';

const root = path.resolve(import.meta.dirname, '../..');
const provider = createNodeTextureProvider(root);
const built = buildScene({ textures: provider });
const results = runChecks(built.root);
const summary = summarise(results);

test('the scene satisfies every published dimension', () => {
  const failures = results
    .filter((r) => r.status === 'fail')
    .map((r) => `${r.id} ${r.name}: expected ${r.expected}, got ${r.actual} (${r.detail})`);
  assert.deepEqual(failures, [], `failed checks:\n${failures.join('\n')}`);
});

test('the check suite actually exercises the scene', () => {
  assert.ok(summary.total >= 20, `only ${summary.total} checks ran`);
  assert.equal(summary.failed, 0);
});

test('the reference dossier carries its provenance', () => {
  assert.ok(DOSSIER.provenance.length >= 5);
  assert.ok(DOSSIER.dims.domeDiameter === 31);
  assert.ok(DOSSIER.dims.domeApexHeight === 55.6);
});

test('the built scene has a plausible size', () => {
  assert.ok(built.stats.meshes > 100, `only ${built.stats.meshes} meshes`);
  assert.ok(built.stats.triangles > 20000, `only ${built.stats.triangles} triangles`);
});
