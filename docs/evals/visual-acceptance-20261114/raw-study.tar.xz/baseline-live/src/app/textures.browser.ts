import { LinearFilter, LinearMipmapLinearFilter, RepeatWrapping, SRGBColorSpace, Texture, TextureLoader } from 'three';
import type { TextureProvider } from '../scene/textures.ts';

/**
 * Browser-side texture provider: loads the committed PNG assets over HTTP.
 * The Node harness decodes the very same files, so both hosts verify the same
 * pixels.
 */
export function createBrowserTextureProvider(loader: TextureLoader): TextureProvider {
  const cache = new Map<string, Texture>();
  return {
    name: 'browser',
    get(asset: string): Texture {
      const hit = cache.get(asset);
      if (hit) return hit;
      const texture = loader.load(`textures/${asset}`);
      texture.colorSpace = SRGBColorSpace;
      texture.wrapS = RepeatWrapping;
      texture.wrapT = RepeatWrapping;
      texture.minFilter = LinearMipmapLinearFilter;
      texture.magFilter = LinearFilter;
      texture.anisotropy = 8;
      cache.set(asset, texture);
      return texture;
    },
  };
}
