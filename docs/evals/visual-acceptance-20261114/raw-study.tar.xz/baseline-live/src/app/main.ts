import {
  ACESFilmicToneMapping,
  Color,
  Raycaster,
  Vector2,
  PCFSoftShadowMap,
  PerspectiveCamera,
  PMREMGenerator,
  Scene,
  SRGBColorSpace,
  Texture,
  TextureLoader,
  Vector3,
  WebGLRenderer,
} from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { buildScene } from '../scene/build.ts';
import { createBrowserTextureProvider } from './textures.browser.ts';
import { formatReport, runSelfTest, type SelfTestReport } from './selftest.ts';
import './styles.css';

export interface CameraPreset {
  key: string;
  label: string;
  position: [number, number, number];
  target: [number, number, number];
  /** the profile the render judgement should use for this view */
  profile: 'interior' | 'general';
}

export const CAMERA_PRESETS: CameraPreset[] = [
  {
    key: 'exterior',
    label: 'Exterior (south-west)',
    position: [-58, -64, 14],
    target: [-2, 0, 44],
    profile: 'general',
  },
  {
    key: 'nave',
    label: 'The nave',
    position: [-30, 0, 5],
    target: [14, 0, 15],
    profile: 'interior',
  },
  {
    key: 'dome',
    label: 'Under the dome',
    position: [0, -13, 9],
    target: [0, 0, 42],
    profile: 'interior',
  },
  {
    key: 'apse',
    label: 'The sanctuary',
    position: [6, 0, 10],
    target: [34, 0, 26],
    profile: 'interior',
  },
  {
    key: 'gallery',
    label: 'The upper gallery',
    position: [-4, 21, 17.5],
    target: [18, 0, 30],
    profile: 'interior',
  },
  {
    key: 'minaret',
    label: 'The minarets',
    position: [-62, -74, 34],
    target: [-30, -28.5, 42],
    profile: 'general',
  },
];

const container = document.getElementById('viewport') as HTMLDivElement;
const renderer = new WebGLRenderer({
  antialias: true,
  preserveDrawingBuffer: true,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = SRGBColorSpace;
renderer.toneMapping = ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.82;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = PCFSoftShadowMap;
container.appendChild(renderer.domElement);

const loader = new TextureLoader();
const built = buildScene({ textures: createBrowserTextureProvider(loader) });
const scene: Scene = built.scene;

const pmrem = new PMREMGenerator(renderer);
scene.environment = pmrem.fromEquirectangular(built.sky).texture;
scene.environmentIntensity = 0.42;
// A calm haze behind the building: the equirectangular sky is used for the
// light, a flat tone for the backdrop.
scene.background = new Color('#a8bccd');

const camera = new PerspectiveCamera(52, window.innerWidth / window.innerHeight, 0.4, 900);
camera.up.set(0, 0, 1); // the building is modelled Z-up
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.06;
// the building is Z-up, and several views look upwards from below the target
controls.maxPolarAngle = Math.PI * 0.96;
controls.minPolarAngle = 0.04;
controls.minDistance = 4;
controls.maxDistance = 320;

function applyPreset(preset: CameraPreset): void {
  camera.position.set(...preset.position);
  controls.target.set(...preset.target);
  controls.update();
}

applyPreset(CAMERA_PRESETS[0]);

/* ------------------------------------------------------------------ */
/* the panel                                                           */
/* ------------------------------------------------------------------ */
const presetList = document.getElementById('presets') as HTMLUListElement;
for (const preset of CAMERA_PRESETS) {
  const item = document.createElement('li');
  const button = document.createElement('button');
  button.textContent = preset.label;
  button.dataset.preset = preset.key;
  button.addEventListener('click', () => {
    applyPreset(preset);
    document.querySelectorAll('#presets button').forEach((b) => b.classList.remove('active'));
    button.classList.add('active');
  });
  item.appendChild(button);
  presetList.appendChild(item);
}
presetList.querySelector('button')?.classList.add('active');

const output = document.getElementById('output') as HTMLPreElement;

let lastReport: SelfTestReport | null = null;

function runAndShow(): SelfTestReport {
  const report = runSelfTest(built.root);
  lastReport = report;
  output.textContent = formatReport(report);
  const badge = document.getElementById('badge') as HTMLSpanElement;
  const ok = report.summary.failed === 0 && report.manifestMatches;
  badge.textContent = ok
    ? `self-test: ${report.summary.passed}/${report.summary.total} passed`
    : `self-test: ${report.summary.failed} FAILED`;
  badge.className = ok ? 'ok' : 'bad';
  return report;
}

(document.getElementById('run-selftest') as HTMLButtonElement).addEventListener('click', () => {
  runAndShow();
});

/* ------------------------------------------------------------------ */
/* machine readable surface for the headless verification harness       */
/* ------------------------------------------------------------------ */
declare global {
  interface Window {
    __SELFTEST__: () => SelfTestReport;
    __CAPTURE__: (cols: number, rows: number) => { width: number; height: number; data: number[] };
    __READY__: boolean;
    __STATS__: () => { meshes: number; triangles: number };
    __CAMERA__: () => { position: number[]; target: number[]; up: number[] };
    __SCENE__: Scene;
    __PICK__: (nx: number, ny: number) => string[];
    __SET_VIEW__: (key: string) => boolean;
  }
}

window.__SELFTEST__ = () => runSelfTest(built.root);
window.__STATS__ = () => built.stats;
window.__CAMERA__ = () => ({ position: camera.position.toArray(), target: controls.target.toArray(), up: camera.up.toArray() });
window.__SCENE__ = scene;
window.__PICK__ = (nx: number, ny: number) => {
  const raycaster = new Raycaster();
  raycaster.setFromCamera(new Vector2(nx, ny), camera);
  return raycaster
    .intersectObject(scene, true)
    .slice(0, 6)
    .map((hit) => `${hit.object.name}@${hit.distance.toFixed(2)}`);
};
window.__CAPTURE__ = (cols: number, rows: number) => {
  const canvas = document.createElement('canvas');
  canvas.width = cols;
  canvas.height = rows;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('no 2d context');
  context.drawImage(renderer.domElement, 0, 0, cols, rows);
  const image = context.getImageData(0, 0, cols, rows);
  return { width: cols, height: rows, data: Array.from(image.data) };
};
window.__SET_VIEW__ = (key: string) => {
  const preset = CAMERA_PRESETS.find((p) => p.key === key);
  if (!preset) return false;
  applyPreset(preset);
  controls.update();
  renderer.render(scene, camera);
  return true;
};

/* ------------------------------------------------------------------ */
/* render loop                                                          */
/* ------------------------------------------------------------------ */
function onResize(): void {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}
window.addEventListener('resize', onResize);

function loop(): void {
  controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}

runAndShow();
renderer.render(scene, camera);
window.__READY__ = true;
loop();

/** Exposed for the camera preset targets in the documentation. */
export const TARGETS = CAMERA_PRESETS.map((p) => ({ key: p.key, target: new Vector3(...p.target) }));
