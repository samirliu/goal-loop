import type { Object3D } from 'three';
import { runChecks, summarise, type CheckResult } from '../shared/checks.ts';
import { CHECK_MANIFEST } from '../shared/checks.manifest.ts';

export interface SelfTestReport {
  ranAt: string;
  results: CheckResult[];
  summary: { total: number; passed: number; failed: number; failedIds: string[] };
  manifest: string[];
  manifestMatches: boolean;
  missing: string[];
  unexpected: string[];
}

/**
 * The in-application self test.  It runs the *same* assertion library as the
 * Node suite against the *live* scene, and it verifies that the set of
 * assertions is exactly the committed manifest - so no one can quietly delete
 * a failing assertion to make the run green.
 */
export function runSelfTest(root: Object3D): SelfTestReport {
  const results = runChecks(root);
  const summary = summarise(results);
  const produced = results.map((r) => r.id);
  const expected: string[] = [...CHECK_MANIFEST];
  const missing = expected.filter((id) => !produced.includes(id));
  const unexpected = produced.filter((id) => !expected.includes(id));
  return {
    ranAt: new Date().toISOString(),
    results,
    summary,
    manifest: expected,
    manifestMatches: missing.length === 0 && unexpected.length === 0,
    missing,
    unexpected,
  };
}

export function formatReport(report: SelfTestReport): string {
  const lines = report.results.map((result) => {
    const mark = result.status === 'pass' ? 'PASS' : 'FAIL';
    return `${mark}  ${result.id}  ${result.name}\n      expected ${result.expected}\n      actual   ${result.actual}`;
  });
  const tail = report.manifestMatches
    ? `manifest: ${report.manifest.length} assertions, all present`
    : `manifest MISMATCH: missing [${report.missing.join(', ')}] unexpected [${report.unexpected.join(', ')}]`;
  return `${lines.join('\n')}\n\n${report.summary.passed}/${report.summary.total} assertions passed. ${tail}`;
}
