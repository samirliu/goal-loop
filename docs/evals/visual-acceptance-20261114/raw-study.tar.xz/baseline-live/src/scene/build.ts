import {
  BoxGeometry,
  Color,
  CylinderGeometry,
  DataTexture,
  DirectionalLight,
  EquirectangularReflectionMapping,
  FloatType,
  Group,
  HemisphereLight,
  Mesh,
  PlaneGeometry,
  MeshStandardMaterial,
  PointLight,
  RGBAFormat,
  Scene,
  Vector3,
} from 'three';
import { D } from '../shared/reference.ts';
import {
  buildArchBand,
  buildColumn,
  buildDomeShell,
  buildHalfDome,
  buildPendentive,
  buildQuarterConch,
  buildWallPanel,
  mergeGeometries,
  type Corner,
} from './geometry.ts';
import { buildMaterialSet, type MaterialSet } from './materials.ts';
import type { TextureProvider } from './textures.ts';
import {
  AISLE_CEILING_Z,
  APSE_CENTER_X,
  APSE_TIP_X,
  ARCH_SPRING_Z,
  ARCADE_AXIS_Y,
  ARCADE_INNER_Y,
  CONCHES,
  CORNICE_Z,
  DOME_BASE_Z,
  EXONARTHEX_CENTER_X,
  GALLERY_Z,
  MINARETS,
  MINARET_Y,
  NARTHEX_FACE_X,
  OUTER_WALL_Y,
  PIER_WIDTH,
  R,
  SANCTUARY_WALL_X,
} from './layout.ts';

export interface Overrides {
  domeRadius?: number;
  domeApex?: number;
  windowCount?: number;
  minaretCount?: number;
  semiDomeRadius?: number;
  exedraRadius?: number;
}

export interface BuildOptions {
  textures: TextureProvider;
  overrides?: Overrides;
}

export interface SceneStats {
  meshes: number;
  triangles: number;
}

export interface BuiltScene {
  scene: Scene;
  root: Group;
  materials: MaterialSet;
  stats: SceneStats;
  /** the equirectangular sky, used for the environment map */
  sky: DataTexture;
}

/**
 * An equirectangular sky: deep blue at the zenith, a warm hazy horizon and
 * dark ground below.  It is used both as the background and as the source of
 * the environment map, so the daylight in the scene is coherent.
 */
function skyTexture(): DataTexture {
  const width = 128;
  const height = 64;
  const data = new Float32Array(width * height * 4);
  for (let y = 0; y < height; y++) {
    const t = y / (height - 1);
    const zenith = [0.09, 0.22, 0.52];
    const horizon = [0.72, 0.74, 0.76];
    const ground = [0.46, 0.45, 0.42];
    let rgb: number[];
    if (t < 0.5) {
      const k = Math.pow(t / 0.5, 0.7);
      rgb = zenith.map((c, i) => c + (horizon[i] - c) * k);
    } else {
      const k = (t - 0.5) / 0.5;
      rgb = horizon.map((c, i) => c + (ground[i] - c) * k);
    }
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const az = (x / width) * Math.PI * 2;
      // a warm glow where the sun sits
      const sun = Math.max(0, Math.cos(az - 2.4)) * Math.pow(Math.max(0, 1 - Math.abs(t - 0.46) * 9), 3);
      data[i] = rgb[0] + sun * 0.55;
      data[i + 1] = rgb[1] + sun * 0.42;
      data[i + 2] = rgb[2] + sun * 0.24;
      data[i + 3] = 1;
    }
  }
  const texture = new DataTexture(data, width, height, RGBAFormat, FloatType);
  texture.mapping = EquirectangularReflectionMapping;
  // three.js maps the sky with +Y up; the building is modelled with +Z up,
  // so the sphere of the sky is turned by a quarter turn.
  texture.center.set(0.5, 0.5);
  texture.rotation = -Math.PI / 2;
  texture.needsUpdate = true;
  return texture;
}

export function buildScene(options: BuildOptions): BuiltScene {
  const overrides = options.overrides ?? {};
  const materials = buildMaterialSet(options.textures);

  const radius = overrides.domeRadius ?? R;
  const apexZ = overrides.domeApex ?? D.domeApexHeight;
  const windowCount = overrides.windowCount ?? D.domeWindowCount;
  const semiRadius = overrides.semiDomeRadius ?? D.semiDomeRadius;
  const exedraRadius = overrides.exedraRadius ?? D.exedraRadius;
  const minaretCount = overrides.minaretCount ?? D.minaretCount;

  const baseZ = apexZ - radius;
  const springZ = baseZ - radius;

  const scene = new Scene();
  const root = new Group();
  root.name = 'hagia-sophia';
  scene.add(root);

  /* ---------------- central dome ---------------- */
  const dome = buildDomeShell({
    radius,
    sillZ: baseZ,
    apexZ,
    windowCount,
    windowHeight: D.domeWindowHeight,
    bayColumns: 8,
    rows: 56,
  });
  const domeShell = new Mesh(dome.geometry, materials.mosaic);
  domeShell.name = 'dome-shell';
  root.add(domeShell);

  const panes = new Mesh(dome.panes, materials.glass);
  panes.name = 'dome-panes';
  root.add(panes);

  const domeOuter = buildDomeShell({
    radius: radius + 0.35,
    sillZ: baseZ - 0.15,
    apexZ: apexZ + 0.35,
    windowCount,
    windowHeight: D.domeWindowHeight,
    bayColumns: 8,
    rows: 56,
  });
  const domeOuterMesh = new Mesh(domeOuter.geometry, materials.leadOuter);
  domeOuterMesh.name = 'dome-shell-outer';
  root.add(domeOuterMesh);

  /* ---------------- pendentives and seraphim ---------------- */
  const corners: Corner[] = ['ne', 'nw', 'se', 'sw'];
  for (const corner of corners) {
    const p = new Mesh(buildPendentive(corner, radius, springZ), materials.mosaic);
    p.name = `pendentive-${corner}`;
    root.add(p);

    const sx = corner === 'ne' || corner === 'se' ? 1 : -1;
    const sy = corner === 'ne' || corner === 'nw' ? 1 : -1;
    const nx = 0.653;
    const ny = 0.653;
    const nz = 0.383;
    const pendentiveRadius = radius * Math.SQRT2;
    const centre = new Vector3(
      sx * nx * pendentiveRadius,
      sy * ny * pendentiveRadius,
      springZ + nz * pendentiveRadius,
    );
    const medallion = new Mesh(new PlaneGeometry(13, 13), materials.seraph);
    medallion.name = `seraph-${corner}`;
    medallion.position.copy(centre);
    medallion.lookAt(new Vector3(0, 0, springZ));
    root.add(medallion);
  }

  /* ---------------- great piers and arches ---------------- */
  for (const [key, sx, sy] of [
    ['ne', 1, 1],
    ['nw', -1, 1],
    ['se', 1, -1],
    ['sw', -1, -1],
  ] as const) {
    const pier = new Mesh(
      new BoxGeometry(PIER_WIDTH, PIER_WIDTH, springZ),
      materials.marble,
    );
    pier.name = `pier-${key}`;
    pier.position.set(sx * radius, sy * radius, springZ / 2);
    root.add(pier);
  }

  const archThickness = 1.3;
  const archDepth = 1.5;
  const northArch = new Mesh(
    buildArchBand({ radius, thickness: archThickness, depth: archDepth }),
    materials.marble,
  );
  northArch.name = 'great-arch-north';
  northArch.position.set(0, radius, springZ);
  root.add(northArch);

  const southArch = northArch.clone();
  southArch.name = 'great-arch-south';
  southArch.position.set(0, -radius, springZ);
  root.add(southArch);

  const eastArch = new Mesh(
    buildArchBand({ radius, thickness: archThickness, depth: archDepth }),
    materials.marble,
  );
  eastArch.name = 'great-arch-east';
  eastArch.position.set(radius, 0, springZ);
  eastArch.rotation.z = Math.PI / 2;
  root.add(eastArch);

  const westArch = eastArch.clone();
  westArch.name = 'great-arch-west';
  westArch.position.set(-radius, 0, springZ);
  root.add(westArch);

  /* ---------------- cornices ---------------- */
  const corniceGeometry = new CylinderGeometry(radius + 0.5, radius + 0.5, 1.0, 72, 1, true);
  corniceGeometry.rotateX(Math.PI / 2);
  const cornice = new Mesh(corniceGeometry, materials.marble);
  cornice.name = 'cornice-dome';
  cornice.position.set(0, 0, CORNICE_Z);
  root.add(cornice);

  const impostGeometry = new CylinderGeometry(radius + 0.3, radius + 0.3, 0.9, 72, 1, true);
  impostGeometry.rotateX(Math.PI / 2);
  const impostCornice = new Mesh(impostGeometry, materials.marble);
  impostCornice.name = 'cornice-impost';
  impostCornice.position.set(0, 0, springZ + 0.3);
  root.add(impostCornice);

  /* ---------------- semi-domes and conches ---------------- */
  const eastHalf = new Mesh(
    buildHalfDome(semiRadius, new Vector3(radius, 0, baseZ)),
    materials.mosaicAlt,
  );
  eastHalf.name = 'semidome-east';
  root.add(eastHalf);

  const westHalf = new Mesh(
    buildHalfDome(semiRadius, new Vector3(-radius, 0, baseZ), 40, Math.PI / 2),
    materials.mosaicAlt,
  );
  westHalf.name = 'semidome-west';
  root.add(westHalf);

  // the lead covering of the half domes, seen from outside
  for (const [key, sign, azimuth] of [
    ['east', 1, -Math.PI / 2],
    ['west', -1, Math.PI / 2],
  ] as const) {
    const cover = new Mesh(
      buildHalfDome(semiRadius + 0.4, new Vector3(sign * radius, 0, baseZ - 0.2), 40, azimuth),
      materials.leadOuter,
    );
    cover.name = `semidome-cover-${key}`;
    root.add(cover);
  }

  for (const conch of CONCHES) {
    const radiusConch = conch.radius === D.exedraRadius ? exedraRadius : conch.radius;
    const geometry =
      conch.phiLength >= Math.PI
        ? buildHalfDome(radiusConch, new Vector3(conch.cx, conch.cy, conch.cz), 36, conch.phiStart)
        : buildQuarterConch(radiusConch, new Vector3(conch.cx, conch.cy, conch.cz), conch.phiStart, conch.phiLength);
    const mesh = new Mesh(geometry, materials.mosaicAlt);
    mesh.name = `conch-${conch.key}`;
    root.add(mesh);

    const coverGeometry =
      conch.phiLength >= Math.PI
        ? buildHalfDome(radiusConch + 0.3, new Vector3(conch.cx, conch.cy, conch.cz - 0.15), 32, conch.phiStart)
        : buildQuarterConch(radiusConch + 0.3, new Vector3(conch.cx, conch.cy, conch.cz - 0.15), conch.phiStart, conch.phiLength);
    const cover = new Mesh(coverGeometry, materials.leadOuter);
    cover.name = `conch-cover-${conch.key}`;
    root.add(cover);
  }

  /* ---------------- floors ---------------- */
  const floor = new Mesh(
    new BoxGeometry(D.naveLength, D.naveWidth, 0.6),
    materials.floor,
  );
  floor.name = 'nave-floor';
  floor.position.set((NARTHEX_FACE_X + APSE_TIP_X) / 2, 0, -0.3);
  root.add(floor);

  for (const sign of [1, -1]) {
    const aisleFloor = new Mesh(
      new BoxGeometry(APSE_TIP_X - NARTHEX_FACE_X, OUTER_WALL_Y - ARCADE_INNER_Y, 0.6),
      materials.floor,
    );
    aisleFloor.name = sign > 0 ? 'aisle-floor-north' : 'aisle-floor-south';
    aisleFloor.position.set(
      (NARTHEX_FACE_X + APSE_TIP_X) / 2,
      (sign * (OUTER_WALL_Y + ARCADE_INNER_Y)) / 2,
      -0.3,
    );
    root.add(aisleFloor);
  }

  /* ---------------- nave arcades and galleries ---------------- */
  const arcadeXs: number[] = [];
  for (let x = -30; x <= 30; x += 6) arcadeXs.push(x);

  for (const sign of [1, -1]) {
    const group = new Group();
    group.name = sign > 0 ? 'arcade-north' : 'arcade-south';
    for (const x of arcadeXs) {
      const column = new Mesh(buildColumn(AISLE_CEILING_Z + 3.4), materials.marble);
      column.name = `arcade-column-${sign > 0 ? 'n' : 's'}-${x}`;
      column.position.set(x, sign * ARCADE_AXIS_Y, 0);
      group.add(column);
    }
    for (let i = 0; i < arcadeXs.length - 1; i++) {
      const mid = (arcadeXs[i] + arcadeXs[i + 1]) / 2;
      const arch = new Mesh(
        buildArchBand({ radius: 3, thickness: 0.9, depth: 1.0, segments: 20 }),
        materials.marble,
      );
      arch.name = `arcade-arch-${sign > 0 ? 'n' : 's'}-${i}`;
      arch.position.set(mid, sign * ARCADE_AXIS_Y, AISLE_CEILING_Z + 3.4);
      group.add(arch);
    }
    root.add(group);

    const gallery = new Mesh(
      new BoxGeometry(SANCTUARY_WALL_X - EXONARTHEX_CENTER_X, OUTER_WALL_Y - ARCADE_INNER_Y, 1.2),
      materials.marble,
    );
    gallery.name = sign > 0 ? 'gallery-north' : 'gallery-south';
    gallery.position.set(
      (SANCTUARY_WALL_X + EXONARTHEX_CENTER_X) / 2,
      (sign * (OUTER_WALL_Y + ARCADE_INNER_Y)) / 2,
      GALLERY_Z + 0.6,
    );
    root.add(gallery);

    // outer wall of the aisle / gallery, pierced by arched windows
    const wall = new Mesh(
      buildWallPanel({
        width: APSE_TIP_X - NARTHEX_FACE_X,
        height: 26,
        openings: [-24, -12, 0, 12, 24].map((x) => ({
          x,
          width: 3.2,
          sill: 17,
          height: 6.5,
        })),
      }),
      materials.plaster,
    );
    wall.name = sign > 0 ? 'outer-wall-north' : 'outer-wall-south';
    wall.position.set((NARTHEX_FACE_X + APSE_TIP_X) / 2, sign * OUTER_WALL_Y, 0);
    wall.rotation.y = sign > 0 ? Math.PI : 0;
    root.add(wall);

    // sloping lead roof over the gallery
    const roofWidth = OUTER_WALL_Y - ARCADE_INNER_Y + 1;
    const roof = new Mesh(
      new PlaneGeometry(APSE_TIP_X - NARTHEX_FACE_X, roofWidth),
      materials.lead,
    );
    roof.name = sign > 0 ? 'gallery-roof-north' : 'gallery-roof-south';
    roof.rotation.x = -Math.PI / 2 - sign * 0.52;
    roof.position.set(
      (NARTHEX_FACE_X + APSE_TIP_X) / 2,
      sign * ((OUTER_WALL_Y + ARCADE_INNER_Y) / 2 + 0.5),
      22.2,
    );
    root.add(roof);
  }

  /* ---------------- narthex and west facade ---------------- */
  const narthexWall = new Mesh(
    buildWallPanel({
      width: APSE_TIP_X - NARTHEX_FACE_X,
      height: 24,
      openings: [-20, -10, 0, 10, 20].map((x) => ({ x, width: 4, sill: 6, height: 9 })),
    }),
    materials.plasterPink,
  );
  narthexWall.name = 'west-facade';
  narthexWall.position.set(NARTHEX_FACE_X, 0, 0);
  narthexWall.rotation.y = Math.PI;
  root.add(narthexWall);

  const narthexBody = new Mesh(
    new BoxGeometry(6.5, OUTER_WALL_Y * 2 - 2, 21),
    materials.plasterPink,
  );
  narthexBody.name = 'narthex';
  narthexBody.position.set(NARTHEX_FACE_X - 3.4, 0, 10.5);
  root.add(narthexBody);

  const narthexRoof = new Mesh(new PlaneGeometry(7.2, OUTER_WALL_Y * 2 - 1), materials.lead);
  narthexRoof.name = 'narthex-roof';
  narthexRoof.rotation.x = -Math.PI / 2;
  narthexRoof.position.set(NARTHEX_FACE_X - 3.4, 0, 21.3);
  root.add(narthexRoof);

  /* ---------------- sanctuary east wall and apse ---------------- */
  const sanctuaryWall = new Mesh(
    buildWallPanel({
      width: D.naveWidth,
      height: baseZ,
      openings: [{ x: 0, width: 2 * radius - 4, sill: 0, height: baseZ - 2 }],
    }),
    materials.marble,
  );
  sanctuaryWall.name = 'sanctuary-wall';
  sanctuaryWall.position.set(SANCTUARY_WALL_X, 0, 0);
  sanctuaryWall.rotation.y = Math.PI / 2;
  root.add(sanctuaryWall);

  const apse = new Group();
  apse.name = 'apse';
  const apsePiers = 8;
  for (let i = 0; i < apsePiers; i++) {
    const angle = -Math.PI / 2 + (i / (apsePiers - 1)) * Math.PI;
    const pier = new Mesh(new BoxGeometry(1.8, 2.4, 26), materials.marble);
    pier.name = `apse-pier-${i}`;
    pier.position.set(
      APSE_CENTER_X + Math.cos(angle) * exedraRadius,
      Math.sin(angle) * exedraRadius,
      13,
    );
    pier.rotation.z = -angle;
    apse.add(pier);

    if (i < apsePiers - 1) {
      const mid = -Math.PI / 2 + ((i + 0.5) / (apsePiers - 1)) * Math.PI;
      const window = new Mesh(new PlaneGeometry(3.6, 9), materials.glass);
      window.name = `apse-window-${i}`;
      window.position.set(
        APSE_CENTER_X + Math.cos(mid) * (exedraRadius - 0.1),
        Math.sin(mid) * (exedraRadius - 0.1),
        24,
      );
      window.rotation.y = -mid - Math.PI / 2;
      apse.add(window);
    }
  }
  root.add(apse);

  const apseRoofGeometry = new CylinderGeometry(
    exedraRadius + 1.2,
    exedraRadius + 1.2,
    3,
    24,
    1,
    true,
    -Math.PI / 2,
    Math.PI,
  );
  apseRoofGeometry.rotateX(Math.PI / 2);
  const apseRoof = new Mesh(apseRoofGeometry, materials.lead);
  apseRoof.name = 'apse-roof';
  apseRoof.position.set(APSE_CENTER_X, 0, 27);
  root.add(apseRoof);

  const theotokos = new Mesh(new PlaneGeometry(13, 11), materials.theotokos);
  theotokos.name = 'theotokos-mosaic';
  theotokos.position.set(APSE_CENTER_X + exedraRadius - 1.6, 0, 34);
  theotokos.rotation.y = -Math.PI / 2;
  root.add(theotokos);

  const deesis = new Mesh(new PlaneGeometry(9, 7), materials.deesis);
  deesis.name = 'deesis-mosaic';
  deesis.position.set(-2, ARCADE_INNER_Y - 0.4, 19);
  deesis.rotation.y = Math.PI;
  root.add(deesis);

  /* ---------------- minarets ---------------- */
  const minarets = MINARETS.slice(0, Math.max(0, minaretCount));
  for (const m of minarets) {
    const group = new Group();
    group.name = `minaret-${m.key}`;
    const shaftHeight = 48;
    const shaftGeometry = new CylinderGeometry(1.35, 1.6, shaftHeight, 24, 1);
    shaftGeometry.rotateX(Math.PI / 2);
    const shaft = new Mesh(shaftGeometry, m.brick ? materials.brick : materials.ashlar);
    shaft.name = `minaret-shaft-${m.key}`;
    shaft.position.set(0, 0, shaftHeight / 2);
    group.add(shaft);

    const balconyGeometry = new CylinderGeometry(2.15, 1.9, 1.6, 24);
    balconyGeometry.rotateX(Math.PI / 2);
    const balcony = new Mesh(balconyGeometry, materials.ashlar);
    balcony.name = `minaret-balcony-${m.key}`;
    balcony.position.set(0, 0, shaftHeight + 0.8);
    group.add(balcony);

    const parapetGeometry = new CylinderGeometry(2.15, 2.15, 1.1, 24, 1, true);
    parapetGeometry.rotateX(Math.PI / 2);
    const parapet = new Mesh(parapetGeometry, materials.stone);
    parapet.name = `minaret-parapet-${m.key}`;
    parapet.position.set(0, 0, shaftHeight + 2.1);
    group.add(parapet);

    const capGeometry = new CylinderGeometry(0.12, 1.45, 10, 24);
    capGeometry.rotateX(Math.PI / 2);
    const cap = new Mesh(capGeometry, materials.lead);
    cap.name = `minaret-cap-${m.key}`;
    cap.position.set(0, 0, shaftHeight + 2.7 + 5);
    group.add(cap);

    group.position.set(m.x, m.y, 0);
    root.add(group);
  }

  /* ---------------- buttresses ---------------- */
  let buttressIndex = 0;
  for (const sign of [1, -1]) {
    for (let x = -30; x <= 30; x += 7.5) {
      const height = 24 + (Math.abs(x) % 3) * 0.8;
      const buttress = new Mesh(new BoxGeometry(2.6, 3.4, height), materials.plaster);
      buttress.name = `buttress-${buttressIndex++}`;
      buttress.position.set(x, sign * (OUTER_WALL_Y + 1.6), height / 2);
      root.add(buttress);
    }
  }

  /* ---------------- ground and sky ---------------- */
  const groundMaterial = new MeshStandardMaterial({
    color: new Color('#8a8d80'),
    roughness: 0.96,
    metalness: 0,
  });
  const ground = new Mesh(new PlaneGeometry(1600, 1600), groundMaterial);
  ground.name = 'ground';
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  ground.position.z = -0.7;
  root.add(ground);

  const sky = skyTexture();
  scene.background = sky;

  /* ---------------- light ---------------- */
  const sun = new DirectionalLight(new Color('#fff2d8'), 5.4);
  sun.name = 'sun';
  sun.position.set(-120, -150, 190);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 20;
  sun.shadow.camera.far = 620;
  sun.shadow.camera.left = -140;
  sun.shadow.camera.right = 140;
  sun.shadow.camera.top = 140;
  sun.shadow.camera.bottom = -140;
  sun.shadow.bias = -0.0006;
  root.add(sun);
  root.add(sun.target);

  const skyLight = new HemisphereLight(new Color('#9dc0ea'), new Color('#5b4c39'), 0.42);
  skyLight.name = 'sky-light';
  skyLight.position.set(0, 0, 1);
  root.add(skyLight);

  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const glow = new PointLight(new Color('#ffcf8a'), 620, 70, 2);
    glow.name = `dome-light-${i}`;
    glow.position.set(
      Math.cos(angle) * radius * 0.55,
      Math.sin(angle) * radius * 0.55,
      baseZ + 1.6,
    );
    root.add(glow);
  }

  for (let i = 0; i < 4; i++) {
    const angle = (i / 4) * Math.PI * 2 + 0.4;
    const glow = new PointLight(new Color('#ffdfae'), 420, 55, 2);
    glow.name = `apse-light-${i}`;
    glow.position.set(
      APSE_CENTER_X + Math.cos(angle) * 6,
      Math.sin(angle) * 6,
      24,
    );
    root.add(glow);
  }

  /* ---------------- statistics ---------------- */
  let meshes = 0;
  let triangles = 0;
  root.traverse((object) => {
    if (!(object instanceof Mesh)) return;
    meshes++;
    const geometry = object.geometry;
    const index = geometry.getIndex();
    const count = index ? index.count : geometry.getAttribute('position').count;
    triangles += Math.floor(count / 3);
  });

  return { scene, root, materials, stats: { meshes, triangles }, sky };
}

export const LAYOUT = {
  R,
  DOME_BASE_Z,
  ARCH_SPRING_Z,
  ARCADE_AXIS_Y,
  MINARET_Y,
  NARTHEX_FACE_X,
  APSE_TIP_X,
  EXONARTHEX_CENTER_X,
  SANCTUARY_WALL_X,
  APSE_CENTER_X,
  mergeGeometries,
};
