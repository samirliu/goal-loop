import fs from 'node:fs';
import path from 'node:path';
import { DataTexture, RGBAFormat, SRGBColorSpace, Texture, UnsignedByteType } from 'three';
import { decodePng } from '../../tools/png.ts';
import type { TextureProvider } from './textures.ts';

/**
 * Node-side texture provider: decodes the committed PNG assets so the test
 * suite verifies exactly the images the browser will load.
 */
export function createNodeTextureProvider(root: string): TextureProvider {
  const dir = path.join(root, 'public', 'textures');
  const cache = new Map<string, Texture>();
  return {
    name: 'node',
    get(asset: string): Texture {
      const hit = cache.get(asset);
      if (hit) return hit;
      const file = path.join(dir, asset);
      const png = decodePng(fs.readFileSync(file));
      const texture = new DataTexture(png.data, png.width, png.height, RGBAFormat, UnsignedByteType);
      texture.colorSpace = SRGBColorSpace;
      texture.wrapS = 1000; // THREE.RepeatWrapping
      texture.wrapT = 1000;
      texture.needsUpdate = true;
      cache.set(asset, texture);
      return texture;
    },
  };
}
