import {
  Color,
  DoubleSide,
  FrontSide,
  MeshBasicMaterial,
  MeshStandardMaterial,
  type Texture,
} from 'three';
import type { TextureProvider } from './textures.ts';

export interface MaterialSet {
  mosaic: MeshStandardMaterial;
  mosaicAlt: MeshStandardMaterial;
  marble: MeshStandardMaterial;
  floor: MeshStandardMaterial;
  plaster: MeshStandardMaterial;
  plasterPink: MeshStandardMaterial;
  brick: MeshStandardMaterial;
  ashlar: MeshStandardMaterial;
  lead: MeshStandardMaterial;
  leadOuter: MeshStandardMaterial;
  stone: MeshStandardMaterial;
  glass: MeshBasicMaterial;
  glassCool: MeshBasicMaterial;
  seraph: MeshBasicMaterial;
  theotokos: MeshBasicMaterial;
  deesis: MeshBasicMaterial;
}

function tiled(provider: TextureProvider, asset: string, repeatX: number, repeatY: number): Texture {
  const texture = provider.get(asset).clone();
  texture.needsUpdate = true;
  texture.repeat.set(repeatX, repeatY);
  return texture;
}

/**
 * Builds the material set from the shared PNG assets.  Both the browser and
 * the Node harness call this with their own provider, so the verification
 * suite inspects the same pixels the renderer will show.
 */
export function buildMaterialSet(provider: TextureProvider): MaterialSet {
  // Gold glass mosaic: the dome is lit from outside, so the inside reads
  // luminous - as it does in photographs - through an emissive map of the
  // same tesserae.
  const mosaic = new MeshStandardMaterial({
    map: tiled(provider, 'dome-mosaic.png', 1, 1),
    emissiveMap: tiled(provider, 'dome-mosaic.png', 1, 1),
    color: new Color('#f0c996'),
    roughness: 0.55,
    metalness: 0.35,
    side: DoubleSide,
    emissive: new Color('#a8761f'),
    emissiveIntensity: 0.62,
  });
  const mosaicAlt = new MeshStandardMaterial({
    map: tiled(provider, 'gold-mosaic-2.png', 1, 1),
    emissiveMap: tiled(provider, 'gold-mosaic-2.png', 1, 1),
    color: new Color('#e8c98a'),
    roughness: 0.5,
    metalness: 0.4,
    side: DoubleSide,
    emissive: new Color('#9c6c1c'),
    emissiveIntensity: 0.55,
  });
  const marble = new MeshStandardMaterial({
    map: tiled(provider, 'marble-revetment.png', 0.5, 0.5),
    color: new Color('#b9b4a6'),
    roughness: 0.42,
    metalness: 0.05,
    side: DoubleSide,
  });
  const floor = new MeshStandardMaterial({
    map: tiled(provider, 'floor-marble.png', 8, 12),
    roughness: 0.28,
    metalness: 0.08,
  });
  const plaster = new MeshStandardMaterial({
    map: tiled(provider, 'plaster-ochre.png', 0.35, 0.35),
    color: new Color('#c8b49a'),
    roughness: 0.94,
    metalness: 0,
    side: DoubleSide,
  });
  const plasterPink = new MeshStandardMaterial({
    map: tiled(provider, 'plaster-pink.png', 0.35, 0.35),
    color: new Color('#c8a894'),
    roughness: 0.94,
    metalness: 0,
    side: DoubleSide,
  });
  const brick = new MeshStandardMaterial({
    map: tiled(provider, 'brick-red.png', 2, 6),
    roughness: 0.88,
    metalness: 0,
  });
  const ashlar = new MeshStandardMaterial({
    map: tiled(provider, 'ashlar-stone.png', 2, 6),
    roughness: 0.85,
    metalness: 0,
  });
  const lead = new MeshStandardMaterial({
    map: tiled(provider, 'lead-roof.png', 4, 4),
    roughness: 0.62,
    metalness: 0.55,
    side: DoubleSide,
  });
  // The lead covering of the domes is only seen from outside: keeping it
  // single sided lets the gold mosaic inside the dome show through.
  const leadOuter = new MeshStandardMaterial({
    map: tiled(provider, 'lead-roof.png', 3, 3),
    roughness: 0.6,
    metalness: 0.5,
    side: FrontSide,
  });
  const stone = new MeshStandardMaterial({
    color: new Color('#b9b0a0'),
    roughness: 0.9,
    metalness: 0,
  });
  const glass = new MeshBasicMaterial({
    color: new Color('#fff7e2'),
    side: DoubleSide,
    transparent: true,
    opacity: 0.95,
    toneMapped: false,
  });
  const glassCool = new MeshBasicMaterial({
    color: new Color('#dfe8f2'),
    side: DoubleSide,
    transparent: true,
    opacity: 0.85,
  });
  const seraph = new MeshBasicMaterial({
    map: provider.get('seraph.png'),
    transparent: true,
    side: DoubleSide,
    depthWrite: false,
  });
  const theotokos = new MeshBasicMaterial({
    map: provider.get('theotokos.png'),
    side: DoubleSide,
  });
  const deesis = new MeshBasicMaterial({
    map: provider.get('deesis.png'),
    side: DoubleSide,
  });

  return {
    mosaic,
    mosaicAlt,
    marble,
    floor,
    plaster,
    plasterPink,
    brick,
    ashlar,
    lead,
    leadOuter,
    stone,
    glass,
    glassCool,
    seraph,
    theotokos,
    deesis,
  };
}
