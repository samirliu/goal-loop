import type { Texture } from 'three';

/**
 * Texture provider seam.  The browser resolves the PNG assets over HTTP, the
 * Node verification harness decodes the very same files from disk, so both
 * sides inspect byte-identical images.
 */
export interface TextureProvider {
  readonly name: string;
  get(asset: string): Texture;
}

export const TEXTURE_ASSETS = [
  'dome-mosaic.png',
  'gold-mosaic-2.png',
  'marble-revetment.png',
  'floor-marble.png',
  'plaster-ochre.png',
  'plaster-pink.png',
  'brick-red.png',
  'ashlar-stone.png',
  'lead-roof.png',
  'seraph.png',
  'theotokos.png',
  'deesis.png',
] as const;

export type TextureAsset = (typeof TEXTURE_ASSETS)[number];
