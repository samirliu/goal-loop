/**
 * Derived layout of the building.  Everything is computed from the reference
 * dossier so the model and the verification suite can never drift apart.
 *
 * Coordinate system: X = east(+)/west(-), Y = north(+)/south(-), Z = up.
 * The floor is z = 0 and the dome crown is z = 55.6 m.
 */
import { D } from '../shared/reference.ts';

export const R = D.domeDiameter / 2; // 15.5 m dome radius
export const DOME_BASE_Z = D.domeApexHeight - R; // 40.1 m - springing of the dome curve
export const ARCH_SPRING_Z = DOME_BASE_Z - R; // 24.6 m - springing of the great arches
export const PIER_HALF = R; // great piers sit on the corners of the 31 m square
export const ARCADE_INNER_Y = D.naveWidth / 2; // 16.0 m - clear width of the nave
export const COLUMN_RADIUS = 0.55;
export const ARCADE_AXIS_Y = ARCADE_INNER_Y + COLUMN_RADIUS; // 16.55 m
export const PIER_WIDTH = 4.6;

/** X of the eastern tip of the apse conch and of the narthex's inner face. */
export const APSE_TIP_X = R + R + D.exedraRadius; // 38.75
export const NARTHEX_FACE_X = APSE_TIP_X - D.naveLength; // -34.25
export const WEST_WALL_X = -R - R; // -31: face of the exonarthex wall
export const SANCTUARY_WALL_X = R + R; // 31: face of the sanctuary east wall
export const APSE_CENTER_X = SANCTUARY_WALL_X; // apse conch springs from here
export const EXONARTHEX_CENTER_X = WEST_WALL_X;

/** Outer wall of the side aisles / galleries. */
export const OUTER_WALL_Y = 27.0;

/** Minaret corners (the building is wider than it is deep on the north-south). */
export const MINARET_X = 34.0;
export const MINARET_Y = 28.5;

/** Gallery floor. */
export const GALLERY_Z = D.galleryFloorHeight;

/** Radius of the spherical pendentive (classic Byzantine construction). */
export const PENDENTIVE_RADIUS = R * Math.SQRT2;

/** Height of the aisle ceiling (underside of the gallery floor). */
export const AISLE_CEILING_Z = GALLERY_Z - 1.2;

/** Semidome / exedra exedra layout along the east-west axis. */
export interface ExedraSpec {
  key: string;
  /** centre of the conch sphere */
  cx: number;
  cy: number;
  cz: number;
  radius: number;
  /** azimuth range of the shell (radians) */
  phiStart: number;
  phiLength: number;
}

function conchSpecs(): ExedraSpec[] {
  const r = D.exedraRadius;
  const z = DOME_BASE_Z;
  const flankOffset = r + 0.25; // a thin masonry wall separates the conches
  const half = { phiStart: -Math.PI / 2, phiLength: Math.PI };
  const north = { phiStart: 0, phiLength: Math.PI / 2 };
  const south = { phiStart: -Math.PI / 2, phiLength: Math.PI / 2 };
  return [
    { key: 'apse', cx: APSE_CENTER_X, cy: 0, cz: z, radius: r, ...half },
    { key: 'exedra-e-north', cx: APSE_CENTER_X, cy: flankOffset, cz: z, radius: r, ...north },
    { key: 'exedra-e-south', cx: APSE_CENTER_X, cy: -flankOffset, cz: z, radius: r, ...south },
    { key: 'exedra-w-centre', cx: EXONARTHEX_CENTER_X, cy: 0, cz: z, radius: r, ...half },
    { key: 'exedra-w-north', cx: EXONARTHEX_CENTER_X, cy: flankOffset, cz: z, radius: r, ...north },
    { key: 'exedra-w-south', cx: EXONARTHEX_CENTER_X, cy: -flankOffset, cz: z, radius: r, ...south },
  ];
}

export const CONCHES: ExedraSpec[] = conchSpecs();

/** The four great piers (corners of the dome square). */
export const PIERS = [
  { key: 'ne', x: PIER_HALF, y: PIER_HALF },
  { key: 'nw', x: -PIER_HALF, y: PIER_HALF },
  { key: 'se', x: PIER_HALF, y: -PIER_HALF },
  { key: 'sw', x: -PIER_HALF, y: -PIER_HALF },
] as const;

/** Minaret placement: the historic corner minarets. */
export const MINARETS = [
  { key: 'ne', x: MINARET_X, y: MINARET_Y, brick: false },
  { key: 'nw', x: -MINARET_X, y: MINARET_Y, brick: false },
  { key: 'se', x: MINARET_X, y: -MINARET_Y, brick: true },
  { key: 'sw', x: -MINARET_X, y: -MINARET_Y, brick: false },
] as const;

/** Height of the pendentive/dome cornice band. */
export const CORNICE_Z = DOME_BASE_Z - 1.2;
