import {
  BoxGeometry,
  BufferAttribute,
  BufferGeometry,
  CylinderGeometry,
  DoubleSide,
  Mesh,
  Shape,
  ShapeGeometry,
  SphereGeometry,
  Vector3,
} from 'three';
import { D } from '../shared/reference.ts';
import { ARCH_SPRING_Z, DOME_BASE_Z, PENDENTIVE_RADIUS, R } from './layout.ts';

const TAU = Math.PI * 2;

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

export interface Quad {
  a: number;
  b: number;
  c: number;
  d: number;
}

/** Appends a quad (a,b,c,d) as two triangles to an index array. */
export function pushQuad(index: number[], q: Quad): void {
  index.push(q.a, q.b, q.d, q.b, q.c, q.d);
}

export function finish(
  positions: number[],
  uvs: number[],
  index: number[],
): BufferGeometry {
  const geometry = new BufferGeometry();
  geometry.setAttribute('position', new BufferAttribute(new Float32Array(positions), 3));
  geometry.setAttribute('uv', new BufferAttribute(new Float32Array(uvs), 2));
  geometry.setIndex(index);
  geometry.computeVertexNormals();
  return geometry;
}

/* ------------------------------------------------------------------ */
/* the central dome: a spherical cap pierced by 40 windows              */
/* ------------------------------------------------------------------ */

export interface DomeShellOptions {
  radius: number;
  /** height of the window sills */
  sillZ: number;
  apexZ: number;
  windowCount: number;
  windowHeight: number;
  /** angular subdivisions inside one window bay */
  bayColumns: number;
  /** vertical subdivisions of the whole cap */
  rows: number;
  /** how far the shell continues below the window sills (the drum) */
  drumDepth?: number;
  /** profile exponent: <1 gives the slightly pointed Ottoman profile */
  profile?: number;
  /** offset the surface along its normal (used for the outer lead shell) */
  offset?: number;
}

export interface DomeShellResult {
  geometry: BufferGeometry;
  /** the glass that fills the window openings */
  panes: BufferGeometry;
  /** number of windows actually pierced */
  windows: number;
}

/**
 * Builds the dome as a height field of revolution and pierces the window
 * openings straight out of the mesh.  The openings are genuine holes in the
 * surface (the drum below the sills keeps them interior), so the window
 * count is a fact about the mesh topology and not a number the builder wrote
 * down.
 */
export function buildDomeShell(options: DomeShellOptions): DomeShellResult {
  const {
    radius,
    sillZ,
    apexZ,
    windowCount,
    windowHeight,
    bayColumns,
    rows,
    drumDepth = 1.4,
    profile = 0.62,
    offset = 0,
  } = options;

  const baseZ = sillZ - drumDepth;
  const height = apexZ - baseZ;
  const cols = windowCount * bayColumns;
  const exponent = 1 / profile;

  // radius of the shell at each level: cylindrical drum, then the dome curve
  const levelRadius: number[] = [];
  const levelZ: number[] = [];
  for (let i = 0; i <= rows; i++) {
    const z = baseZ + (height * i) / rows;
    levelZ.push(z);
    const rise = Math.max(0, (z - sillZ) / (apexZ - sillZ));
    const curve = radius * Math.sqrt(Math.max(0, 1 - Math.pow(rise, exponent)));
    levelRadius.push(Math.min(radius, curve));
  }

  // rows that belong to the window band
  const sillRow = levelZ.findIndex((z) => z >= sillZ - 1e-6);
  const headRow = levelZ.findIndex((z) => z >= sillZ + windowHeight - 1e-6);
  const windowRows = Math.max(1, headRow - sillRow);

  // per column, how many rows are open (rounded arch profile)
  const pierColumns = 2; // masonry between two windows
  const openColumns = bayColumns - pierColumns;
  const columnLimit = new Int32Array(cols);
  for (let bay = 0; bay < windowCount; bay++) {
    for (let k = 0; k < openColumns; k++) {
      const u = (k + 0.5) / openColumns;
      const arch = Math.sqrt(Math.max(0, 1 - Math.pow(2 * u - 1, 2)));
      const limit = Math.max(1, Math.round(windowRows * arch));
      columnLimit[bay * bayColumns + pierColumns / 2 + k] = sillRow + limit;
    }
  }

  const positions: number[] = [];
  const uvs: number[] = [];
  const index: number[] = [];
  const panePositions: number[] = [];
  const paneUvs: number[] = [];
  const paneIndex: number[] = [];

  const vertexIndex = new Int32Array((cols + 1) * (rows + 1)).fill(-1);
  const positionAt = (col: number, row: number): [number, number, number] => {
    const theta = ((col % cols) * TAU) / cols;
    const r = levelRadius[row] + offset;
    const z = levelZ[row] + offset * 0.2;
    return [Math.cos(theta) * r, Math.sin(theta) * r, z];
  };

  // the crown is a single point, so the shell is closed there
  const apexId = positions.length / 3;
  positions.push(0, 0, apexZ + offset * 0.2);
  uvs.push(0.5, 1);

  const vertexAt = (col: number, row: number): number => {
    if (row >= rows) return apexId;
    const wrapped = col % cols;
    const key = row * (cols + 1) + wrapped;
    const cached = vertexIndex[key];
    if (cached >= 0) return cached;
    const [px, py, pz] = positionAt(col, row);
    const id = positions.length / 3;
    positions.push(px, py, pz);
    uvs.push((col / cols) * 8, (row / rows) * 4);
    vertexIndex[key] = id;
    return id;
  };

  let pierced = 0;
  for (let bay = 0; bay < windowCount; bay++) {
    for (let row = 0; row < rows; row++) {
      for (let k = 0; k < bayColumns; k++) {
        const col = bay * bayColumns + k;
        const limit = columnLimit[col];
        const isWindow = limit > 0 && row >= sillRow && row < limit;
        if (isWindow) {
          // the opening: the glass fills it, the shell keeps a real hole
          const pa = panePositions.length / 3;
          for (const [cc, rr] of [
            [col, row],
            [col + 1, row],
            [col + 1, row + 1],
            [col, row + 1],
          ] as const) {
            const [px, py, pz] = positionAt(cc, rr);
            panePositions.push(px, py, pz);
            paneUvs.push((cc / cols) * 8, (rr / rows) * 4);
          }
          pushQuad(paneIndex, { a: pa, b: pa + 1, c: pa + 2, d: pa + 3 });
          if (row === sillRow && k === 0) pierced++;
        } else {
          const a = vertexAt(col, row);
          const b = vertexAt(col + 1, row);
          if (row === rows - 1) {
            // closing fan at the crown
            index.push(a, b, apexId);
          } else {
            const c = vertexAt(col + 1, row + 1);
            const d = vertexAt(col, row + 1);
            pushQuad(index, { a, b, c, d });
          }
        }
      }
    }
  }

  return {
    geometry: finish(positions, uvs, index),
    panes: finish(panePositions, paneUvs, paneIndex),
    windows: pierced,
  };
}

/* ------------------------------------------------------------------ */
/* pendentives: spherical triangles on the classic R*sqrt(2) sphere     */
/* ------------------------------------------------------------------ */

export type Corner = 'ne' | 'nw' | 'se' | 'sw';

/**
 * The pendentive of Hagia Sophia lies on the sphere of radius R*sqrt(2)
 * centred on the crossing point of the great arches: it runs from the top of
 * a great pier up to the rim of the dome.  The three bounding curves are the
 * two great arches and the circle where the dome springs.
 */
export function buildPendentive(
  corner: Corner,
  domeRadius: number,
  springZ: number,
  segments = 28,
): BufferGeometry {
  const sx = corner === 'ne' || corner === 'se' ? 1 : -1;
  const sy = corner === 'ne' || corner === 'nw' ? 1 : -1;
  const radius = domeRadius * Math.SQRT2;
  const centreZ = springZ;
  const top = Math.PI / 4; // the base circle of the dome

  const positions: number[] = [];
  const uvs: number[] = [];
  const index: number[] = [];

  const pointAt = (psi: number, t: number): [number, number, number] => {
    const cosPsi = Math.cos(psi);
    const sinPsi = Math.sin(psi);
    // bottom of the patch: where the surface reaches the great arch planes
    const limit = Math.max(cosPsi, sinPsi);
    const sinBottom = Math.min(1, 1 / (Math.SQRT2 * limit));
    const thetaBottom = Math.asin(sinBottom);
    const theta = thetaBottom + (top - thetaBottom) * t;
    const nx = Math.sin(theta) * cosPsi;
    const ny = Math.sin(theta) * sinPsi;
    const nz = Math.cos(theta);
    return [sx * nx * radius, sy * ny * radius, centreZ + nz * radius];
  };

  for (let i = 0; i <= segments; i++) {
    const psi = (i / segments) * (Math.PI / 2);
    for (let j = 0; j <= segments; j++) {
      const t = j / segments;
      const [x, y, z] = pointAt(psi, t);
      positions.push(x, y, z);
      uvs.push(i / segments, t);
    }
  }
  const stride = segments + 1;
  for (let i = 0; i < segments; i++) {
    for (let j = 0; j < segments; j++) {
      const a = i * stride + j;
      pushQuad(index, { a, b: a + stride, c: a + stride + 1, d: a + 1 });
    }
  }
  return finish(positions, uvs, index);
}

/* ------------------------------------------------------------------ */
/* half domes and conches                                               */
/* ------------------------------------------------------------------ */

/**
 * A spherical patch with its pole pointing up (+Z) and its azimuth measured
 * from +X in the XY plane.  three.js builds spheres around the Y axis, so the
 * patch is rotated into the Z-up world of the building.
 */
export function zUpSphere(
  radius: number,
  azimuthStart: number,
  azimuthLength: number,
  widthSegments = 36,
  heightSegments = 18,
): BufferGeometry {
  const geometry = new SphereGeometry(
    radius,
    widthSegments,
    heightSegments,
    azimuthStart - Math.PI,
    azimuthLength,
    0,
    Math.PI / 2,
  );
  geometry.rotateX(Math.PI / 2);
  geometry.computeVertexNormals();
  return geometry;
}

export function buildHalfDome(
  radius: number,
  centre: Vector3,
  segments = 40,
  azimuthStart = -Math.PI / 2,
): BufferGeometry {
  const geometry = zUpSphere(radius, azimuthStart, Math.PI, segments, Math.round(segments / 2));
  geometry.translate(centre.x, centre.y, centre.z);
  return geometry;
}

export function buildQuarterConch(
  radius: number,
  centre: Vector3,
  azimuthStart: number,
  azimuthLength = Math.PI / 2,
): BufferGeometry {
  const geometry = zUpSphere(radius, azimuthStart, azimuthLength, 28, 14);
  geometry.translate(centre.x, centre.y, centre.z);
  return geometry;
}

/* ------------------------------------------------------------------ */
/* arch bands                                                          */
/* ------------------------------------------------------------------ */

export interface ArchBandOptions {
  radius: number;
  thickness: number;
  depth: number;
  segments?: number;
  arc?: number;
}

/**
 * A flat masonry band following a semicircular arch: the intrados carries the
 * pendentive, the extrados is buried in the wall.
 */
export function buildArchBand(options: ArchBandOptions): BufferGeometry {
  const { radius, thickness, depth, segments = 40, arc = Math.PI } = options;
  const positions: number[] = [];
  const uvs: number[] = [];
  const index: number[] = [];
  const outer = radius + thickness;
  const half = depth / 2;

  const ring = (r: number, y: number) => {
    const base = positions.length / 3;
    for (let i = 0; i <= segments; i++) {
      const a = (i / segments) * arc;
      positions.push(r * Math.cos(a), y, r * Math.sin(a));
      uvs.push(i / segments, y > 0 ? 1 : 0);
    }
    return base;
  };

  const innerFront = ring(radius, half);
  const outerFront = ring(outer, half);
  const innerBack = ring(radius, -half);
  const outerBack = ring(outer, -half);

  for (let i = 0; i < segments; i++) {
    // front face
    pushQuad(index, { a: innerFront + i, b: outerFront + i, c: outerFront + i + 1, d: innerFront + i + 1 });
    // back face
    pushQuad(index, { a: innerBack + i, b: innerBack + i + 1, c: outerBack + i + 1, d: outerBack + i });
    // intrados
    pushQuad(index, { a: innerFront + i, b: innerFront + i + 1, c: innerBack + i + 1, d: innerBack + i });
    // extrados
    pushQuad(index, { a: outerFront + i, b: outerBack + i, c: outerBack + i + 1, d: outerFront + i + 1 });
  }
  // end caps
  pushQuad(index, { a: innerFront, b: innerBack, c: outerBack, d: outerFront });
  const e = segments;
  pushQuad(index, { a: innerFront + e, b: outerFront + e, c: outerBack + e, d: innerBack + e });
  return finish(positions, uvs, index);
}

/* ------------------------------------------------------------------ */
/* walls with arched openings                                           */
/* ------------------------------------------------------------------ */

export interface WallOptions {
  width: number;
  height: number;
  /** arched openings: centre offset, width, sill height */
  openings?: { x: number; width: number; sill: number; height: number }[];
}

/** A wall panel in the XZ plane (x horizontal, z up), centred on x = 0. */
export function buildWallPanel(options: WallOptions): BufferGeometry {
  const { width, height, openings = [] } = options;
  const shape = new Shape();
  shape.moveTo(-width / 2, 0);
  shape.lineTo(width / 2, 0);
  shape.lineTo(width / 2, height);
  shape.lineTo(-width / 2, height);
  shape.closePath();
  for (const o of openings) {
    const hole = new Shape();
    const r = o.width / 2;
    hole.moveTo(o.x - r, o.sill);
    hole.lineTo(o.x - r, o.sill + o.height - r);
    hole.absarc(o.x, o.sill + o.height - r, r, Math.PI, 0, true);
    hole.lineTo(o.x + r, o.sill);
    hole.closePath();
    shape.holes.push(hole);
  }
  const geometry = new ShapeGeometry(shape, 24);
  geometry.rotateX(Math.PI / 2); // shape XY -> world XZ, facing -Y
  geometry.computeVertexNormals();
  return geometry;
}

/* ------------------------------------------------------------------ */
/* columns and minarets                                                 */
/* ------------------------------------------------------------------ */

export function buildColumn(height: number, radius = 0.55): BufferGeometry {
  const shaft = new CylinderGeometry(radius * 0.86, radius, height, 20, 1);
  shaft.rotateX(Math.PI / 2);
  shaft.translate(0, 0, height / 2);
  const capital = new BoxGeometry(radius * 2, radius * 2, 0.7);
  capital.translate(0, 0, height + 0.35);
  const base = new BoxGeometry(radius * 2, radius * 2, 0.5);
  base.translate(0, 0, 0.25);
  return mergeGeometries([shaft, capital, base]);
}

/** Minimal geometry merge (positions + uvs + normals, non-indexed output). */
export function mergeGeometries(list: BufferGeometry[]): BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const index: number[] = [];
  let base = 0;
  for (const geometry of list) {
    const pos = geometry.getAttribute('position');
    const uv = geometry.getAttribute('uv');
    for (let i = 0; i < pos.count; i++) {
      positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      uvs.push(uv ? uv.getX(i) : 0, uv ? uv.getY(i) : 0);
    }
    const idx = geometry.getIndex();
    if (idx) {
      for (let i = 0; i < idx.count; i++) index.push(idx.getX(i) + base);
    } else {
      for (let i = 0; i < pos.count; i++) index.push(i + base);
    }
    base += pos.count;
  }
  return finish(positions, uvs, index);
}

export function mesh(geometry: BufferGeometry, material: unknown, name: string): Mesh {
  const m = new Mesh(geometry, material as never);
  m.name = name;
  return m;
}

export const doubleSide = DoubleSide;
export const domeConstants = { R, DOME_BASE_Z, ARCH_SPRING_Z, windowCount: D.domeWindowCount };
