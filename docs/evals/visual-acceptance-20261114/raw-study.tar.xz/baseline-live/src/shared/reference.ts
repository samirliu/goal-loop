/**
 * Reference dossier for the building being modelled.
 *
 * Every number below is a published, externally checkable figure for
 * Hagia Sophia (Ayasofya), Istanbul.  The scene is built FROM this dossier,
 * and the verification suite measures the built geometry BACK against it, so
 * the dossier is the single source of truth for both the model and the tests.
 */

export interface Dossier {
  title: string;
  provenance: string[];
  note: string;
  /** Linear tolerance in metres applied to length assertions. */
  linearTolerance: number;
  dims: {
    domeDiameter: number;
    domeApexHeight: number;
    domeWindowCount: number;
    domeWindowHeight: number;
    greatArchSpan: number;
    semiDomeRadius: number;
    exedraRadius: number;
    exedraCount: number;
    naveWidth: number;
    naveLength: number;
    apseWindowCount: number;
    apseSides: number;
    minaretCount: number;
    minaretHeight: number;
    minaretDiameter: number;
    galleryFloorHeight: number;
    minaretInset: number;
  };
}

export const DOSSIER: Dossier = {
  title: 'Hagia Sophia (Ayasofya), Istanbul — published dimensions',
  provenance: [
    'Commonly published figures for the current (Ottoman-era) building: the central dome is 31.0 m in diameter and its crown stands 55.6 m above the nave floor.',
    'The dome is carried on 40 windows at its base, which are the main light source of the nave.',
    'The nave measures roughly 32 m wide and 73 m long (inner face of the narthex to the end of the apse).',
    'East and west of the dome are half-domes of the same 15.5 m radius, flanked by six smaller half-domes of 7.75 m radius.',
    'The apse is a seven-sided bay carrying seven windows.',
    'Four minarets, about 60 m tall, stand at the corners; the south-east one is the original brick minaret of the first Ottoman additions.',
    'The upper gallery floor sits roughly 15 m above the nave floor.',
  ],
  note:
    'Figures are rounded to the precision that published sources agree on; the verification suite applies a 0.35 m linear tolerance (exact counts are checked exactly).',
  linearTolerance: 0.35,
  dims: {
    domeDiameter: 31.0,
    domeApexHeight: 55.6,
    domeWindowCount: 40,
    domeWindowHeight: 2.4,
    greatArchSpan: 31.0,
    semiDomeRadius: 15.5,
    exedraRadius: 7.75,
    exedraCount: 6,
    naveWidth: 32.0,
    naveLength: 73.0,
    apseWindowCount: 7,
    apseSides: 7,
    minaretCount: 4,
    minaretHeight: 60.0,
    minaretDiameter: 3.2,
    galleryFloorHeight: 15.0,
    minaretInset: 42.0,
  },
};

export const D = DOSSIER.dims;
