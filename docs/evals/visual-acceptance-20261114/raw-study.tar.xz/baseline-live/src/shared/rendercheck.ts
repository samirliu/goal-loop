/**
 * Render judgement.
 *
 * The same analyser judges (a) synthetic calibration frames and (b) the real
 * framebuffer captured from the running application, so the acceptance of a
 * real render rests on an instrument that has already been shown to reject a
 * bad one.
 */

export interface RgbaImage {
  width: number;
  height: number;
  data: Uint8Array | number[];
}

export interface RenderMetrics {
  meanLuma: number;
  stdLuma: number;
  p05: number;
  p95: number;
  contrast: number;
  edgeDensity: number;
  goldFraction: number;
  darkFraction: number;
  brightFraction: number;
  samples: number;
}

export interface RenderVerdict {
  ok: boolean;
  profile: string;
  metrics: RenderMetrics;
  reasons: string[];
}

export type RenderProfile = 'interior' | 'general';

function luminance(r: number, g: number, b: number): number {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function hueSaturation(r: number, g: number, b: number): [number, number] {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;
  const luma = luminance(r, g, b);
  const saturation = max === 0 ? 0 : delta / max;
  if (delta === 0) return [0, saturation];
  let hue: number;
  if (max === r) hue = ((g - b) / delta) % 6;
  else if (max === g) hue = (b - r) / delta + 2;
  else hue = (r - g) / delta + 4;
  hue *= 60;
  if (hue < 0) hue += 360;
  return [hue, saturation];
}

export function analyseFrame(image: RgbaImage, profile: RenderProfile = 'general'): RenderVerdict {
  const { width, height, data } = image;
  const luma = new Float64Array(width * height);
  const gold = new Uint8Array(width * height);
  let sum = 0;
  let goldCount = 0;
  let darkCount = 0;
  let brightCount = 0;

  for (let i = 0; i < width * height; i++) {
    const r = data[i * 4];
    const g = data[i * 4 + 1];
    const b = data[i * 4 + 2];
    const l = luminance(r, g, b);
    luma[i] = l;
    sum += l;
    if (l < 0.12) darkCount++;
    if (l > 0.75) brightCount++;
    const [hue, saturation] = hueSaturation(r, g, b);
    const isGold = hue >= 30 && hue <= 60 && saturation > 0.25 && l > 0.08 && l < 0.92;
    if (isGold) {
      gold[i] = 1;
      goldCount++;
    }
  }

  const samples = width * height;
  const mean = sum / samples;
  let variance = 0;
  for (let i = 0; i < samples; i++) variance += (luma[i] - mean) ** 2;
  const std = Math.sqrt(variance / samples);

  const sorted = Float64Array.from(luma).sort();
  const p05 = sorted[Math.floor(samples * 0.05)];
  const p95 = sorted[Math.floor(samples * 0.95)];
  const contrast = (p95 - p05) / (p95 + p05 + 1e-6);

  let edgeSum = 0;
  let edges = 0;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const i = y * width + x;
      if (x + 1 < width) {
        edgeSum += Math.abs(luma[i] - luma[i + 1]);
        edges++;
      }
      if (y + 1 < height) {
        edgeSum += Math.abs(luma[i] - luma[i + width]);
        edges++;
      }
    }
  }
  const edgeDensity = edges > 0 ? edgeSum / edges : 0;

  const metrics: RenderMetrics = {
    meanLuma: mean,
    stdLuma: std,
    p05,
    p95,
    contrast,
    edgeDensity,
    goldFraction: goldCount / samples,
    darkFraction: darkCount / samples,
    brightFraction: brightCount / samples,
    samples,
  };

  const reasons: string[] = [];
  if (std < 0.05) reasons.push(`frame is flat (std=${std.toFixed(4)})`);
  if (contrast < 0.35) reasons.push(`no tonal range (contrast=${contrast.toFixed(3)})`);
  if (edgeDensity < 0.008) reasons.push(`no visible detail (edge=${edgeDensity.toFixed(4)})`);
  if (metrics.brightFraction < 0.004) reasons.push('no highlights at all');
  if (metrics.darkFraction > 0.97) reasons.push('frame is essentially black');
  if (profile === 'interior' && metrics.goldFraction < 0.02) {
    reasons.push(`the golden dome is missing (gold=${(metrics.goldFraction * 100).toFixed(2)}%)`);
  }

  return { ok: reasons.length === 0, profile, metrics, reasons };
}

/** Builds a downsampled RGBA grid from a raw framebuffer. */
export function downsample(
  pixels: Uint8Array | number[],
  width: number,
  height: number,
  cols: number,
  rows: number,
): RgbaImage {
  const out = new Uint8Array(cols * rows * 4);
  for (let ry = 0; ry < rows; ry++) {
    for (let rx = 0; rx < cols; rx++) {
      const x0 = Math.floor((rx * width) / cols);
      const x1 = Math.max(x0 + 1, Math.floor(((rx + 1) * width) / cols));
      const y0 = Math.floor((ry * height) / rows);
      const y1 = Math.max(y0 + 1, Math.floor(((ry + 1) * height) / rows));
      let r = 0;
      let g = 0;
      let b = 0;
      let n = 0;
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const i = (y * width + x) * 4;
          r += pixels[i];
          g += pixels[i + 1];
          b += pixels[i + 2];
          n++;
        }
      }
      const o = (ry * cols + rx) * 4;
      out[o] = r / n;
      out[o + 1] = g / n;
      out[o + 2] = b / n;
      out[o + 3] = 255;
    }
  }
  return { width: cols, height: rows, data: out };
}
