import { Box3, BufferGeometry, type Mesh, type Object3D, Vector3 } from 'three';
import { DOSSIER } from './reference.ts';

export type CheckStatus = 'pass' | 'fail';

export interface CheckResult {
  id: string;
  name: string;
  status: CheckStatus;
  expected: string;
  actual: string;
  detail: string;
}

export interface Topology {
  vertices: number;
  edges: number;
  faces: number;
  euler: number;
  holes: number;
}

/**
 * Euler characteristic of a triangulated surface, read straight from the
 * index buffer.  For a genus-0 shell the number of pierced openings is
 * 1 - (V - E + F), so the window count of the dome is a fact about the mesh
 * rather than a number the builder wrote down.
 */
export function topology(geometry: BufferGeometry): Topology {
  const position = geometry.getAttribute('position');
  const index = geometry.getIndex();
  if (!index) throw new Error('topology() needs an indexed geometry');
  const vertices = position.count;
  const faces = index.count / 3;
  const edges = new Set<string>();
  for (let i = 0; i < index.count; i += 3) {
    const a = index.getX(i);
    const b = index.getX(i + 1);
    const c = index.getX(i + 2);
    const tri = [a, b, c];
    for (let k = 0; k < 3; k++) {
      const u = tri[k];
      const v = tri[(k + 1) % 3];
      edges.add(u < v ? `${u}-${v}` : `${v}-${u}`);
    }
  }
  const euler = vertices - edges.size + faces;
  return { vertices, edges: edges.size, faces, euler, holes: 1 - euler };
}

function find(root: Object3D, name: string): Object3D | undefined {
  let hit: Object3D | undefined;
  root.traverse((object) => {
    if (!hit && object.name === name) hit = object;
  });
  return hit;
}

function findAll(root: Object3D, name: string): Object3D[] {
  const hits: Object3D[] = [];
  root.traverse((object) => {
    if (object.name === name) hits.push(object);
  });
  return hits;
}

function box(object: Object3D): Box3 {
  return new Box3().setFromObject(object);
}

/**
 * Estimates the radius of the sphere a patch of geometry lies on.  The centre
 * of the sphere is one of the corners of the patch's bounding box (the patch
 * is a spherical cap), so the candidate that yields the tightest spread wins.
 */
export function estimateSphereRadius(object: Object3D): { radius: number; deviation: number } {
  const b = box(object);
  const mesh = object as Mesh;
  const position = mesh.geometry.getAttribute('position');
  const candidates: Vector3[] = [];
  for (const x of [b.min.x, b.max.x]) {
    for (const y of [b.min.y, b.max.y, (b.min.y + b.max.y) / 2]) {
      candidates.push(new Vector3(x, y, b.min.z));
    }
  }
  let best = { radius: 0, deviation: Infinity };
  for (const centre of candidates) {
    let sum = 0;
    let worst = 0;
    for (let i = 0; i < position.count; i++) {
      const d = Math.hypot(
        position.getX(i) - centre.x,
        position.getY(i) - centre.y,
        position.getZ(i) - centre.z,
      );
      sum += d;
      worst = Math.max(worst, d);
    }
    const mean = sum / position.count;
    let spread = 0;
    for (let i = 0; i < position.count; i++) {
      const d = Math.hypot(
        position.getX(i) - centre.x,
        position.getY(i) - centre.y,
        position.getZ(i) - centre.z,
      );
      spread = Math.max(spread, Math.abs(d - mean));
    }
    if (spread < best.deviation) best = { radius: mean, deviation: spread };
  }
  return best;
}

function near(actual: number, expected: number, tolerance: number): boolean {
  return Math.abs(actual - expected) <= tolerance;
}

interface CheckSpec {
  id: string;
  name: string;
  expected: string;
  run: () => { actual: string; ok: boolean; detail: string };
}

const round = (value: number): string => value.toFixed(3);

/**
 * The single assertion library.  It is executed by the Node test-suite and by
 * the in-browser self-test, so both hosts judge the scene with the same rules.
 */
export function buildCheckSpecs(root: Object3D): CheckSpec[] {
  const tol = DOSSIER.linearTolerance;
  const specs: CheckSpec[] = [];

  const push = (spec: CheckSpec) => specs.push(spec);

  /* ---------------- the dome ---------------- */
  const dome = find(root, 'dome-shell');
  push({
    id: 'GEO-01',
    name: 'central dome diameter',
    expected: `${DOSSIER.dims.domeDiameter} m +/- ${tol}`,
    run: () => {
      if (!dome) return { actual: 'missing', ok: false, detail: 'dome-shell not found' };
      const b = box(dome);
      const diameter = Math.max(b.max.x - b.min.x, b.max.y - b.min.y);
      return {
        actual: `${round(diameter)} m`,
        ok: near(diameter, DOSSIER.dims.domeDiameter, tol),
        detail: `bounding box ${round(b.max.x - b.min.x)} x ${round(b.max.y - b.min.y)} m`,
      };
    },
  });

  push({
    id: 'GEO-02',
    name: 'dome crown height above the floor',
    expected: `${DOSSIER.dims.domeApexHeight} m +/- ${tol}`,
    run: () => {
      if (!dome) return { actual: 'missing', ok: false, detail: 'dome-shell not found' };
      const b = box(dome);
      return {
        actual: `${round(b.max.z)} m`,
        ok: near(b.max.z, DOSSIER.dims.domeApexHeight, tol),
        detail: 'highest vertex of the dome shell',
      };
    },
  });

  push({
    id: 'GEO-03',
    name: 'windows pierced in the dome (mesh topology)',
    expected: `${DOSSIER.dims.domeWindowCount} openings`,
    run: () => {
      if (!dome) return { actual: 'missing', ok: false, detail: 'dome-shell not found' };
      const t = topology((dome as Mesh).geometry);
      return {
        actual: `${t.holes} openings (V=${t.vertices} E=${t.edges} F=${t.faces}, chi=${t.euler})`,
        ok: t.holes === DOSSIER.dims.domeWindowCount,
        detail: 'openings counted as 1 - (V - E + F) on the index buffer',
      };
    },
  });

  push({
    id: 'GEO-04',
    name: 'outer lead shell is pierced by the same number of windows',
    expected: `${DOSSIER.dims.domeWindowCount} openings`,
    run: () => {
      const outer = find(root, 'dome-shell-outer');
      if (!outer) return { actual: 'missing', ok: false, detail: 'dome-shell-outer not found' };
      const t = topology((outer as Mesh).geometry);
      return {
        actual: `${t.holes} openings`,
        ok: t.holes === DOSSIER.dims.domeWindowCount,
        detail: 'the outer shell must not seal the windows',
      };
    },
  });

  push({
    id: 'GEO-05',
    name: 'window glass fills the dome openings',
    expected: '>= 1 pane mesh with more than 1000 triangles',
    run: () => {
      const panes = find(root, 'dome-panes');
      if (!panes) return { actual: 'missing', ok: false, detail: 'dome-panes not found' };
      const count = (panes as Mesh).geometry.getIndex()!.count / 3;
      const holes = dome ? topology((dome as Mesh).geometry).holes : 0;
      return {
        actual: `${count} pane triangles for ${holes} openings`,
        ok: count >= holes * 40,
        detail: 'the glass that lets daylight into the nave',
      };
    },
  });

  /* ---------------- pendentives ---------------- */
  push({
    id: 'GEO-06',
    name: 'four pendentives on the R*sqrt(2) sphere',
    expected: '4 pendentives, all vertices on the pendentive sphere',
    run: () => {
      const parts = findAll(root, 'pendentive-ne').concat(
        findAll(root, 'pendentive-nw'),
        findAll(root, 'pendentive-se'),
        findAll(root, 'pendentive-sw'),
      );
      if (parts.length !== 4) {
        return { actual: `${parts.length} found`, ok: false, detail: 'expected four pendentives' };
      }
      const domeBox = box(dome as Object3D);
      const radius = Math.max(domeBox.max.x - domeBox.min.x, domeBox.max.y - domeBox.min.y) / 2;
      const baseZ = domeBox.max.z - radius;
      const springZ = baseZ - radius;
      const target = radius * Math.SQRT2;
      const centre = new Vector3(0, 0, springZ);
      let worst = 0;
      for (const part of parts) {
        const position = (part as Mesh).geometry.getAttribute('position');
        for (let i = 0; i < position.count; i++) {
          const d = Math.hypot(
            position.getX(i) - centre.x,
            position.getY(i) - centre.y,
            position.getZ(i) - centre.z,
          );
          worst = Math.max(worst, Math.abs(d - target));
        }
      }
      return {
        actual: `worst deviation ${round(worst)} m from r=${round(target)} m`,
        ok: worst < 0.2,
        detail: 'classic Byzantine construction: pendentive radius = R*sqrt(2)',
      };
    },
  });

  /* ---------------- semi-domes and conches ---------------- */
  push({
    id: 'GEO-07',
    name: 'east and west half-domes',
    expected: `2 half-domes of radius ${DOSSIER.dims.semiDomeRadius} m`,
    run: () => {
      const parts = findAll(root, 'semidome-east').concat(findAll(root, 'semidome-west'));
      if (parts.length !== 2) {
        return { actual: `${parts.length} found`, ok: false, detail: 'expected two half-domes' };
      }
      let worst = 0;
      let spread = 0;
      for (const part of parts) {
        const estimate = estimateSphereRadius(part);
        worst = Math.max(worst, Math.abs(estimate.radius - DOSSIER.dims.semiDomeRadius));
        spread = Math.max(spread, estimate.deviation);
      }
      return {
        actual: `worst radius error ${round(worst)} m (spread ${round(spread)} m)`,
        ok: worst < tol && spread < 0.2,
        detail: 'the half-domes flank the dome to east and west',
      };
    },
  });

  push({
    id: 'GEO-08',
    name: 'smaller conches of the sanctuary and exonarthex',
    expected: `${DOSSIER.dims.exedraCount} conches of radius ${DOSSIER.dims.exedraRadius} m`,
    run: () => {
      const parts = findAll(root, 'conch-apse').concat(
        findAll(root, 'conch-exedra-e-north'),
        findAll(root, 'conch-exedra-e-south'),
        findAll(root, 'conch-exedra-w-centre'),
        findAll(root, 'conch-exedra-w-north'),
        findAll(root, 'conch-exedra-w-south'),
      );
      if (parts.length !== DOSSIER.dims.exedraCount) {
        return {
          actual: `${parts.length} found`,
          ok: false,
          detail: `expected ${DOSSIER.dims.exedraCount} conches`,
        };
      }
      let worst = 0;
      let spread = 0;
      for (const part of parts) {
        const estimate = estimateSphereRadius(part);
        worst = Math.max(worst, Math.abs(estimate.radius - DOSSIER.dims.exedraRadius));
        spread = Math.max(spread, estimate.deviation);
      }
      return {
        actual: `worst radius error ${round(worst)} m (spread ${round(spread)} m)`,
        ok: worst < tol && spread < 0.2,
        detail: 'three conches east, three west',
      };
    },
  });

  /* ---------------- the nave ---------------- */
  push({
    id: 'GEO-09',
    name: 'clear width of the nave',
    expected: `${DOSSIER.dims.naveWidth} m +/- ${tol}`,
    run: () => {
      const north = find(root, 'arcade-north');
      const south = find(root, 'arcade-south');
      if (!north || !south) {
        return { actual: 'missing', ok: false, detail: 'nave arcades not found' };
      }
      const inner = Math.min(Math.abs(box(north).min.y), Math.abs(box(south).max.y));
      return {
        actual: `${round(inner * 2)} m`,
        ok: near(inner * 2, DOSSIER.dims.naveWidth, tol),
        detail: 'measured between the inner faces of the two arcades',
      };
    },
  });

  push({
    id: 'GEO-10',
    name: 'length of the nave',
    expected: `${DOSSIER.dims.naveLength} m +/- ${tol}`,
    run: () => {
      const floor = find(root, 'nave-floor');
      if (!floor) return { actual: 'missing', ok: false, detail: 'nave-floor not found' };
      const b = box(floor);
      const length = b.max.x - b.min.x;
      return {
        actual: `${round(length)} m`,
        ok: near(length, DOSSIER.dims.naveLength, tol),
        detail: 'narthex inner face to the tip of the apse',
      };
    },
  });

  push({
    id: 'GEO-11',
    name: 'upper gallery floor',
    expected: `${DOSSIER.dims.galleryFloorHeight} m +/- 1.5 m`,
    run: () => {
      const north = find(root, 'gallery-north');
      const south = find(root, 'gallery-south');
      if (!north || !south) {
        return { actual: 'missing', ok: false, detail: 'gallery slabs not found' };
      }
      const z = Math.min(box(north).min.z, box(south).min.z);
      return {
        actual: `${round(z)} m`,
        ok: near(z, DOSSIER.dims.galleryFloorHeight, 1.5),
        detail: 'the gallery that rings the nave',
      };
    },
  });

  /* ---------------- the apse ---------------- */
  push({
    id: 'GEO-12',
    name: 'windows of the apse',
    expected: `${DOSSIER.dims.apseWindowCount} windows`,
    run: () => {
      const windows = findAll(root, 'apse-window-0').concat(
        findAll(root, 'apse-window-1'),
        findAll(root, 'apse-window-2'),
        findAll(root, 'apse-window-3'),
        findAll(root, 'apse-window-4'),
        findAll(root, 'apse-window-5'),
        findAll(root, 'apse-window-6'),
      );
      return {
        actual: `${windows.length} windows`,
        ok: windows.length === DOSSIER.dims.apseWindowCount,
        detail: 'the apse is lit by seven tall windows',
      };
    },
  });

  /* ---------------- the minarets ---------------- */
  push({
    id: 'GEO-13',
    name: 'minarets',
    expected: `${DOSSIER.dims.minaretCount} minarets, ${DOSSIER.dims.minaretHeight} m +/- 3 m`,
    run: () => {
      const parts = findAll(root, 'minaret-ne').concat(
        findAll(root, 'minaret-nw'),
        findAll(root, 'minaret-se'),
        findAll(root, 'minaret-sw'),
      );
      if (parts.length !== DOSSIER.dims.minaretCount) {
        return {
          actual: `${parts.length} found`,
          ok: false,
          detail: `expected ${DOSSIER.dims.minaretCount} minarets`,
        };
      }
      let worst = 0;
      for (const part of parts) {
        const b = box(part);
        worst = Math.max(worst, Math.abs(b.max.z - DOSSIER.dims.minaretHeight));
      }
      return {
        actual: `worst height error ${round(worst)} m`,
        ok: worst < 3,
        detail: 'four Ottoman minarets at the corners of the forecourt',
      };
    },
  });

  push({
    id: 'GEO-14',
    name: 'minaret shafts are slender',
    expected: `${DOSSIER.dims.minaretDiameter} m +/- 0.6 m`,
    run: () => {
      const parts = findAll(root, 'minaret-ne').concat(
        findAll(root, 'minaret-nw'),
        findAll(root, 'minaret-se'),
        findAll(root, 'minaret-sw'),
      );
      if (parts.length === 0) return { actual: 'missing', ok: false, detail: 'no minarets' };
      let worst = 0;
      for (const key of ['ne', 'nw', 'se', 'sw']) {
        const shaft = find(root, `minaret-shaft-${key}`);
        if (!shaft) return { actual: 'missing', ok: false, detail: `minaret-shaft-${key} not found` };
        const b = box(shaft);
        const diameter = Math.max(b.max.x - b.min.x, b.max.y - b.min.y);
        worst = Math.max(worst, Math.abs(diameter - DOSSIER.dims.minaretDiameter));
      }
      return {
        actual: `worst diameter error ${round(worst)} m`,
        ok: worst < 0.6,
        detail: 'measured across the shaft of each minaret',
      };
    },
  });

  /* ---------------- the fabric ---------------- */
  push({
    id: 'GEO-15',
    name: 'buttresses on the outer walls',
    expected: '>= 8 buttresses',
    run: () => {
      const count = findAll(root, 'buttress-0').length > 0 ? countNamed(root, 'buttress-') : 0;
      return {
        actual: `${count} buttresses`,
        ok: count >= 8,
        detail: 'the flying buttresses that took the thrust of the great arches',
      };
    },
  });

  push({
    id: 'GEO-16',
    name: 'no NaN in the geometry',
    expected: 'every position, normal and uv is finite',
    run: () => {
      let bad = 0;
      let checked = 0;
      root.traverse((object) => {
        const mesh = object as Mesh;
        if (!mesh.geometry || !mesh.geometry.getAttribute) return;
        for (const name of ['position', 'normal', 'uv']) {
          const attribute = mesh.geometry.getAttribute(name);
          if (!attribute) continue;
          for (let i = 0; i < attribute.count; i++) {
            checked++;
            const components = [attribute.getX(i), attribute.getY(i), attribute.getZ(i)].slice(
              0,
              attribute.itemSize,
            );
            if (components.some((value) => !Number.isFinite(value))) bad++;
          }
        }
      });
      return {
        actual: `${bad} non-finite of ${checked} components`,
        ok: bad === 0,
        detail: 'a single NaN silently breaks every downstream measurement',
      };
    },
  });

  push({
    id: 'GEO-17',
    name: 'the scene is neither empty nor absurd',
    expected: '20000 - 600000 triangles',
    run: () => {
      let triangles = 0;
      let meshes = 0;
      root.traverse((object) => {
        const mesh = object as Mesh;
        if (!mesh.geometry || !mesh.geometry.getAttribute) return;
        meshes++;
        const index = mesh.geometry.getIndex();
        triangles += index ? index.count / 3 : mesh.geometry.getAttribute('position').count / 3;
      });
      return {
        actual: `${Math.floor(triangles)} triangles in ${meshes} meshes`,
        ok: triangles >= 20000 && triangles <= 600000,
        detail: 'a real building, not a placeholder',
      };
    },
  });

  /* ---------------- materials ---------------- */
  push({
    id: 'MAT-01',
    name: 'the dome interior is gold mosaic',
    expected: 'a mapped, metallic gold material on the dome',
    run: () => {
      if (!dome) return { actual: 'missing', ok: false, detail: 'dome-shell not found' };
      const material = (dome as Mesh).material as unknown as {
        map?: unknown;
        color?: { getHexString(): string };
        metalness?: number;
      };
      const hex = material.color?.getHexString() ?? '';
      const isGold = hex.startsWith('f0c9') || hex.startsWith('e8c9');
      return {
        actual: `colour #${hex}, metalness ${material.metalness ?? 'n/a'}, map ${material.map ? 'yes' : 'no'}`,
        ok: Boolean(material.map) && isGold && (material.metalness ?? 0) > 0.2,
        detail: 'the dome is covered in gold glass tesserae',
      };
    },
  });

  push({
    id: 'MAT-02',
    name: 'every mesh carries a usable material',
    expected: 'no undefined material, no NaN in its parameters',
    run: () => {
      let broken = 0;
      let total = 0;
      root.traverse((object) => {
        const mesh = object as Mesh;
        if (!mesh.geometry || !mesh.geometry.getAttribute) return;
        if (!mesh.material) {
          broken++;
          return;
        }
        total++;
        const material = mesh.material as unknown as {
          roughness?: number;
          metalness?: number;
          opacity?: number;
        };
        for (const value of [material.roughness, material.metalness, material.opacity]) {
          if (value !== undefined && !Number.isFinite(value)) broken++;
        }
      });
      return {
        actual: `${broken} broken of ${total} meshes`,
        ok: broken === 0,
        detail: 'a material-less mesh renders black',
      };
    },
  });

  /* ---------------- lighting ---------------- */
  push({
    id: 'LUM-01',
    name: 'the sun casts shadows',
    expected: 'a directional light with shadows enabled',
    run: () => {
      const sun = find(root, 'sun');
      if (!sun) return { actual: 'missing', ok: false, detail: 'sun light not found' };
      const light = sun as unknown as { castShadow?: boolean; intensity?: number };
      return {
        actual: `castShadow=${String(light.castShadow)}, intensity=${light.intensity ?? 'n/a'}`,
        ok: Boolean(light.castShadow) && (light.intensity ?? 0) > 0,
        detail: 'without a shadowed sun the model reads as flat',
      };
    },
  });

  push({
    id: 'LUM-02',
    name: 'the dome windows are lit from within',
    expected: '>= 4 warm point lights under the dome',
    run: () => {
      let count = 0;
      root.traverse((object) => {
        if (object.name.startsWith('dome-light-')) count++;
      });
      return {
        actual: `${count} lights under the dome`,
        ok: count >= 4,
        detail: 'the forty windows are the real light source of the nave',
      };
    },
  });

  return specs;
}

function countNamed(root: Object3D, prefix: string): number {
  let count = 0;
  root.traverse((object) => {
    if (object.name.startsWith(prefix)) count++;
  });
  return count;
}

export function runChecks(root: Object3D): CheckResult[] {
  return buildCheckSpecs(root).map((spec) => {
    const outcome = spec.run();
    return {
      id: spec.id,
      name: spec.name,
      status: outcome.ok ? 'pass' : 'fail',
      expected: spec.expected,
      actual: outcome.actual,
      detail: outcome.detail,
    };
  });
}

export interface CheckSummary {
  total: number;
  passed: number;
  failed: number;
  failedIds: string[];
}

export function summarise(results: CheckResult[]): CheckSummary {
  const failedIds = results.filter((r) => r.status === 'fail').map((r) => r.id);
  return {
    total: results.length,
    passed: results.length - failedIds.length,
    failed: failedIds.length,
    failedIds,
  };
}
