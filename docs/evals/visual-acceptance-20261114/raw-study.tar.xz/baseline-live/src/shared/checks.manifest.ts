/**
 * The committed list of assertions the scene must satisfy.  The browser
 * self-test compares the assertions it actually ran against this manifest, so
 * an assertion cannot be deleted to make a run green.
 */
export const CHECK_MANIFEST = [
  'GEO-01',
  'GEO-02',
  'GEO-03',
  'GEO-04',
  'GEO-05',
  'GEO-06',
  'GEO-07',
  'GEO-08',
  'GEO-09',
  'GEO-10',
  'GEO-11',
  'GEO-12',
  'GEO-13',
  'GEO-14',
  'GEO-15',
  'GEO-16',
  'GEO-17',
  'MAT-01',
  'MAT-02',
  'LUM-01',
  'LUM-02',
] as const;
