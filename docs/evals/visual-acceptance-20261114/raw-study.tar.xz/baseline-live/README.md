# Hagia Sophia — a THREE.JS reconstruction that verifies itself

An interactive reconstruction of **Hagia Sophia (Ayasofya), Istanbul**, built procedurally in
THREE.JS from published dimensions — together with a self-verification system that measures the
model against those dimensions instead of trusting the code that built it.

```bash
npm install
npm run dev        # http://127.0.0.1:5173
npm run build      # production bundle + build assertions
npm test           # the whole verification suite
```

## What is modelled

The building is generated from a single reference dossier (`src/shared/reference.ts`) that records
the published figures and where they come from:

| Element | Reference | How it is built |
|---|---|---|
| Central dome | Ø 31.0 m, crown 55.6 m above the floor | spherical cap with a pointed Ottoman profile, pierced by 40 windows |
| Pendentives | on the R·√2 sphere | the classical construction: four spherical triangles on the sphere of the crossing of the great arches |
| Great arches | span 31.0 m | masonry bands whose intrados carries the pendentive |
| Half-domes | R 15.5 m, east and west | hemispherical shells with lead covers |
| Conches | 6 × R 7.75 m | three at the sanctuary, three at the exonarthex |
| Apse | 7 windows | heptagonal bay with seven arched openings |
| Nave | 32.0 m × 73.0 m clear | arcades, upper gallery, marble revetment |
| Minarets | 4 × ~60 m | the brick south-east minaret and three stone ones |
| Buttresses | along both flanks | stepped masses against the thrust of the great arches |

Nothing is downloaded: the marble, the gold mosaic, the plaster, the brick, the lead and the
mosaic figures are generated as PNG assets by `tools/gen-textures.mjs` and used by both the browser
and the test suite.

## The self-verification system

The point of the project is that the model is *measured*, not asserted.

**One assertion library, two hosts.** `src/shared/checks.ts` holds 21 assertions that read the real
geometry out of the live scene graph. The Node suite runs them head-less; the browser runs the very
same functions against the running application (`window.__SELFTEST__()`), and the panel in the top
left corner shows the result of pressing *Run the self-test*.

**The window count is a fact about the mesh, not a number in a table.** The 40 openings of the dome
are pierced out of the shell, so the shell is a surface with 40 holes. The assertion reads the index
buffer and computes the Euler characteristic (χ = V − E + F); for a genus-0 shell the number of
openings is 1 − χ. A dome with 12 windows reads as 12, whatever the builder was told.

**The instruments have to prove themselves first.**

- `npm run verify:calibration` builds deliberately defective scenes — a dome that is 9.25 m in
  radius, a dome whose windows were never pierced, a building with only two minarets — and requires
  the checker to fail exactly the corresponding assertions *and nothing else*. A checker that cannot
  reject those is worthless.
- `npm run verify:render-check` feeds the render judgement a synthetic interior frame
  (`tests/fixtures/render-good.png`) and an empty one (`render-bad.png`) and requires the first to
  pass and the second to fail. The judgement is then used unchanged on the real framebuffer
  captured from the running application.

**Nothing may be deleted to make a run green.** `src/shared/checks.manifest.ts` lists the 21
assertion ids; the self-test compares the assertions it actually ran against that list and fails if
they differ.

| Command | What it proves |
|---|---|
| `npm run verify:geometry` | the scene matches the published dimensions |
| `npm run verify:calibration` | the geometry checker rejects defective scenes |
| `npm run verify:render-check` | the render judgement accepts a real frame and rejects an empty one |
| `npm run verify:selftest` | the same assertions pass inside a real browser |
| `npm run verify:e2e` | head-less Chromium renders the scene, the frame is judged, the console is clean |
| `npm run typecheck` | the TypeScript is sound |

## Honest limits

- The model is a reconstruction from published figures, not a measured survey: the surfaces are
  faithful in proportion and construction, not in fabric.
- The mosaics are procedural approximations of the gold tesserae, the seraphim and the Theotokos.
- The render judgement measures structure (contrast, edge density, gold coverage, highlights); it
  cannot judge whether a figure looks like the Theotokos.
- The verification suite proves *consistency with the reference dossier and internal soundness*.
  It does not prove that the dossier is right — that is why the dossier carries its provenance.

## Layout

```
src/shared/      reference dossier, assertion library, render judgement
src/scene/       geometry builders, materials, scene assembly
src/app/         renderer, camera presets, panel, in-browser self test
tools/           procedural texture generator, PNG codec
tests/unit/      geometry, calibration and render-judgement suites
tests/e2e/       head-less browser harnesses
```
