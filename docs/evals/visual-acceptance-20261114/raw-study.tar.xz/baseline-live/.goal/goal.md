# Goal

## Objective

在 /Users/m/repo/hagia-sophia 交付一个用 THREE.JS 构建的圣索菲亚大教堂交互式 3D 场景：外形比例、构造逻辑（穹顶—帆拱—半穹顶—小半穹顶—筒拱—侧廊—回廊）、构件数量与材质均以公开实测规范为准；同时交付一套**可信的自我验证系统**——同一套断言在 Node 侧（几何/校准/渲染判据）与浏览器侧（内置自检）双端运行；验证器自身必须先证明自己（对已知正确样本 PASS、对已知错误样本 FAIL），并由无头浏览器对真实渲染帧复核。

## Budget knobs

check_timeout=300
max_iterations=8

## Acceptance criteria

- AC-1 | 场景几何符合公开实测规范：中央穹顶直径 31.0m、穹顶顶点距地 55.6m、穹顶基座 40 樘窗（以网格拓扑欧拉特征计数，非元数据）、东西半穹顶 R15.5m、6 座小半穹顶 R7.75m、nave 净宽 32.0m 净长 73.0m、4 座宣礼塔高约 60m、半圆殿 7 樘窗、4 面帆拱落在 R15.5m 球面上 | check: `npm run verify:geometry` | expected: exit=0
- AC-2 | 几何验证器具备判别力：规范样本全部断言通过；注入缺陷的样本（穹顶直径偏小、环窗缺失、宣礼塔数量错误）必须被对应断言判为失败，不得漏判 | check: `npm run verify:calibration` | expected: exit=0
- AC-3 | 渲染判据具备判别力：合格渲染样本（对比度、边缘密度、金色穹顶像素占比达标）判定有效，空白或纯色样本判定无效 | check: `npm run verify:render-check` | expected: exit=0
- AC-4 | 内置自检在真实浏览器中执行与 Node 侧同一套断言并全部通过，结果机器可读，且断言 id 集合与仓库清单完全一致（不得靠删断言放行） | check: `npm run verify:selftest` | expected: exit=0
- AC-5 | 无头端到端复核：真实页面加载、WebGL 与控制台零错误、真实帧通过渲染判据、内置自检全绿 | check: `npm run verify:e2e` | expected: exit=0
- AC-6 | 生产构建成功，产物包含入口 HTML 与资源 | check: `npm run build` | expected: exit=0
- AC-7 | TypeScript 类型检查零错误 | check: `npm run typecheck` | expected: exit=0

## Approval

approved: 8ddfa1c9 2026-11-14 auto
