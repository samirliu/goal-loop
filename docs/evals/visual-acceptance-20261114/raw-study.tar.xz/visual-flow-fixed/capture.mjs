import {chromium} from '../baseline-live/node_modules/playwright/index.mjs';
import http from 'node:http';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
const root=import.meta.dirname;
const html=await fs.readFile(path.join(root,"scene.html"),"utf8");
const vendor=new URL('../baseline-live/node_modules/three/build/',import.meta.url);
const server=http.createServer(async(req,res)=>{try{if(req.url.split('?')[0]==='/'){res.setHeader('content-type','text/html');res.end(html)}else{res.setHeader('content-type','text/javascript');res.end(await fs.readFile(new URL(req.url.slice(1),vendor)))}}catch(e){res.statusCode=404;res.end(String(e))}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
try{browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:960,height:720},deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(String(e)));const url='http://127.0.0.1:'+server.address().port+'/';await page.goto(url);await page.waitForFunction(()=>window.ready);await fs.mkdir(path.join(root,'.goal/evidence/views'),{recursive:true});const views={};
for(const key of ['front','top','rear']){await page.evaluate(k=>window.setView(k),key);const artifact='.goal/evidence/views/'+key+'.png';const bytes=await page.screenshot({path:path.join(root,artifact)});views[key]={artifact,sha256:crypto.createHash('sha256').update(bytes).digest('hex')}}
if(process.argv.includes('--anchors')){await fs.mkdir(path.join(root,'references'),{recursive:true});await fs.copyFile(path.join(root,views.front.artifact),path.join(root,'references/good.png'));await page.goto(url+'?bad=1');await page.waitForFunction(()=>window.ready);await page.evaluate(()=>window.setView('top'));await page.screenshot({path:path.join(root,'references/near-miss.png')})}
if(errors.length)throw new Error(errors.join('; '));await fs.writeFile(path.join(root,'.goal/evidence/captured-views.json'),JSON.stringify(views,null,2)+'\n');console.log(JSON.stringify({views,actual_browser:true,errors}));
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r))}
