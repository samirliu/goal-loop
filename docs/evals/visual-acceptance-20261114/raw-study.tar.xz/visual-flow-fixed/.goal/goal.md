# Goal

## Objective

制作一个白色地面上的封闭红色立方体，提供 front、top、rear 三个可用视角。主体完整清楚，光照能辨识各可见表面，背景干净且没有界面遮挡。风格为清楚的 3D 示意，不要求照片级。

quality: visual AC-1 views=front,top,rear

## Acceptance criteria

- AC-1 | All three captured views show the same complete closed red cube on a clean white floor; visible faces are readable under clear lighting, with no missing top/bottom, obstructed camera, or UI covering the subject; judge the literal design brief, not photographic realism | check: `node capture.mjs` | calib: good=references/good.png bad=references/near-miss.png | expected: judged

## Approval

approved: 07f7cd3e 2026-11-14 auto
