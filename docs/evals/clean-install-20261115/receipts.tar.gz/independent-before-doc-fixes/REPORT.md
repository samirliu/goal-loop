诊断已推进到实施前计划。Goal Loop 4.1.2 的关键安装资源、角色声明和核心本地依赖可读、可加载；本次没有实施网站，也没有形成任何视觉质量 PASS、可访问页面或 Gate GO。完整命令、退出码和原始 stdout/stderr 见 [diagnostics.json](diagnostics.json)。

**检查对象与范围。** 本次按 cc-haha 加载器给出的 rendered-plugin-prompt.md 解释路径。发现入口是 `/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-loop-install-audit-w41ffant/cache with spaces/goal-loop-host/4.1.2/skills/goal-loop`，实施根是 `/var/folders/dy/gc1bdgjn53b18wm5g19nkv800000gn/T/goal-loop-install-audit-w41ffant/cache with spaces/goal-loop-host/4.1.2`。macOS 将 `/var` 解析为 `/private/var`；包含关系检查使用规范化后的实施根，未把这个系统别名误记为逃逸。所有相对脚本、pack、资产和交给 worker/checker 的路径都从实施根构造为绝对路径，并在 Shell 中引用；不能相对发现入口查找。

已实际读取原技能正文、visual/instrument/gradient/external packs、gate/host/crew、五个角色卡、插件与 hook 清单、契约和预注册模板及入口脚本的相关实现。17 个关键资源全部存在；从发现入口误解读这些路径会全部找不到。安装器自身 `inventory()` 通过，清单 1,189 个文件无缺失、重复或越界，生成的插件入口与源正文一致。包内关键说明的相对 Markdown 链接检查无缺失。

| 实际运行的检查 | 结果与含义 |
|---|---|
| 安装包的 `python3 -I -B scripts/goal_install.py doctor` | rc=0；Python 3.14.8、POSIX、gawk 通过。未调用安装或 sync-entry。 |
| host 顶层、enter、begin，以及 context / crew / quality 的 `--help` | 全部 rc=0；包括 host → crew → runner/store 与 trace 的模块加载。只解析帮助，未调用进入、初始化、派工、预算或状态动作。 |
| gate `--help`；Claude / Codex hook 配置生成器 | rc=0；配置仅作为诊断预览保存，未安装、合并或信任任何 hook。 |
| 15 个 Python 入口 AST 解析；6 个 `scripts/*.sh` 的 `bash -n` | 均通过；没有生成 pycache，也未执行业务检查。 |
| Shell 真实 SHA-256 管道与 Python hashlib 对照 | rc=0；哈希一致。补充了 doctor 对哈希工具只间接依赖的检查。 |
| 诊断目录上的 POSIX 目录锁 | flock 取锁与解锁通过；只锁定输出目录，未创建目标状态或发送进程组信号。 |
| 本地运行时版本 | Bash 3.2.57，Node v26.11.1；npm/npx 仅查 PATH，未执行安装。 |
| 安装包前后快照 | 1,300 个文件/目录条目内容、模式、mtime 均未改变，详见 package-before.json / package-after.json。 |

总计 21 条子进程命令，20 条成功；唯一失败是下面刻意执行的未引用空格路径对照。另有 15 次内存内 Python 语法解析、清单/链接/资源核对和目录锁检查。没有重复运行任何实际目标验收。

**实际遇到的缺口。**

1. 路径示例存在空格风险。原技能写成 `python3 -I <skill>/scripts/goal_host.py ...`，host.md 也有未引用 `${GOAL_SKILL}` 的示例。本包路径含 `cache with spaces`。替换后原样执行帮助命令，Python 截断到 `.../cache`，rc=2 / ENOENT；使用参数数组或对完整路径加引号后，相同帮助命令 rc=0。这是文档调用方式的问题，正确引用后的脚本入口正常。
2. 包内正文要求 `tests/run_tests.sh` 与 `tests/docs_consistency.sh`，这两个路径在安装包中都不存在，也不在安装清单。源码仓库的这些命令不能直接作为已安装包自检。此次未转读仓库补齐，也未把历史日志算作当前自检。应修正文档区分源码/安装包检查，或将所需测试与依赖列入包；本次不修改。
3. 五个角色都在 manifest 和 agents/ 中；角色名应带 `goal-loop-host:` 前缀。本审计上下文没有能按该名字选择 subagent_type 的原生 Agent 调用面，只有通用 collaboration 接口。依据限制未启动 Claude/cc-haha 或调用模型，所以不能从文件存在推断“当前宿主已注册并可实际派发”。这属于未验证的运行时边界，未发现缺角色文件。PATH 有 `claude` 与 `claude-haha`，没有 `cc-haha` 这个字面命令；简称与启动方式应以实际宿主为准，未把它认定为插件故障。
4. Three.js 工程和浏览器证据工具属于任务依赖，安装包没有 package.json 或可直接运行的 Three.js 项目。PATH 没有 playwright、agent-browser、chromium、chromium-browser 或 google-chrome。这个结果只说明没有这些命令入口，不能证明系统没有 GUI 浏览器或其他浏览器自动化能力；本次没有探查全局模块、浏览器缓存或启动浏览器。后续必须在临时项目内锁定 Three.js/构建/截图依赖并实测 WebGL 与截图，不能把 Node 可用当成渲染可用。
5. 模拟请求没有指名建筑，也没有给照片。严格限制只读安装包，因此本次未获取、查看或校准真实建筑照片，未建立建筑尺寸真值，也未测试页面网络可达性。缺少这些事实就不能盖出可信的视觉质量结论。

**可选用的角色声明。** 以下名称和模型来自实际安装卡，表示包预期提供的角色，不表示已经执行了派发。正常实现先串行端到端；没有可比较的启动、协调与验收成本证据时不扩大 crew。最终独立冷席与 forge critic 仍需真实宿主角色能力，不能由生产者自评顶替。

| 插件角色 | 卡中模型 | 实施阶段用途 |
|---|---|---|
| `goal-loop-host:goal-worker` | sonnet | 有推理需求的 Three.js 建模、材质、照明或截图检查工具；明确文件域与命名检查。 |
| `goal-loop-host:goal-mech-worker` | haiku | 已冻结方案后的机械整理、固定格式照片元数据或资产清单；不得承担建筑事实判断。 |
| `goal-loop-host:goal-critic` | opus | forge 每轮冷读完整性、盲区及刷分路径，输出绑定 ITERATION / ARTIFACT / PLAN 的实际 FINDING / CLEAR。 |
| `goal-loop-host:goal-checker-req` | sonnet | 全新冷席检查原始请求覆盖、照片依据与实际视图；先校准，再返回逐项三态判词和视觉 JSON。 |
| `goal-loop-host:goal-adjudicator` | opus | 只在同项分歧或修复后的反驳争议出现时复跑争议检查。 |

控制器保留原始请求、契约、work-plan、证据入账和原门控权。worker 简报要给绝对资源路径、精确输出域、接口片段、实际命名检查与同一截止；不得让 worker 编辑 `.goal/` 或自行 spawn。若确需 crew，先冻结 disjoint 文件域与接口，再走 prepare → 原生 spawn → attach → 实际 READY/终态 reconcile → validate/adopt → finish。最终回复或启动回执不算成功。critic 的单一记录写入按其角色/forge 规定处理；不能让生产者代写 CLEAR。

**实施前的资源与工作顺序。**

1. 明确一座历史建筑和重建时期，以可检视、可追溯的照片/图纸建立来源清单：原始来源、拍摄方向或图纸尺度、取得时间、可用许可、实际图像文件及 SHA-256。逐项记录体量、外轮廓、屋顶、立面开口、材料老化、光照以及照片无法确认的近似。不是只列“公开常见尺寸”。不默认限制成纯程序化资产；可用贴图/模型等依照实际许可和来源采用。
2. 在单独临时工程中规划锁定版本的 Three.js、本地资产、构建与 HTTP 访问方式、浏览器自动化/WebGL 及证据保存路径。照片、校准锚点、检查工具都纳入项目可冻结范围。`node_modules`、dist 等忽略产物若是验收对象，应在对应 AC 的 expected 前声明 watch。最终 URL、端口/服务寿命必须与交付可访问性的承诺一致。
3. 从原始措辞加载 visual + instrument + gradient；可访问性依赖项目外实际 endpoint 时再用 external。原 Objective 完整保留“用 THREE.JS 尽可能逼真地重建一座有真实照片参考的历史建筑，项目在临时目录，交付可访问页面和可信自验”。只在真正实施且允许预算后按 enter/begin 绑定真实 backend/session 与原文；本报告不是这一步，也没有调用这些命令。
4. 依据实际照片冻结有代表性的机位，例如正面斜视、背面斜视、屋顶结构、立面细节。这个列表是建议，最终取决于真实建筑及参考覆盖；若承诺内部空间，应增加对应内部机位，不能拿外景代替。只选最漂亮的一面不能证明建筑完整。
5. 编写真实、能失败的命名检查和 work-plan，先实测初始业务基线；检查工具缺失或 BROKEN 不能盖戳。好/坏锚点先实际检视，再冻结。契约写成 `quality: visual AC-3 views=<实际机位名列表>`，视觉 AC 为 calibrated judged。契约和检查确定后取新 context，严格使用地图返回的 stamp/close 命令与实际判断。不能手写已批准戳或把此诊断当批准。
6. “尽可能逼真”保留持续改进：可用 `exit: forge` 与实际完整性探测范围，不必编造像素/三角形“逼真分数”。有可辩护的数值目标才增加 objective、probe、重复测量和 calibrated horizon。无论是否数值化，都保留真实起始视图、发现、策略与反证。forge-plan 每个 case 绑定冻结输入、执行命令、仪器和盲区；实际 critic 按当前迭代、内容指纹和计划摘要判读，控制器执行完探测才可记 dry。默认 dry_limit=3；到期仍不够质量则报告部分交付和欠项。

**拟验收矩阵。** 这是实施前设计，检查工具尚未编写、页面尚不存在，下面任何一行均未声明 PASS；它不是可拿去 stamp 的现成契约。正式契约必须把每行落实为已经冒烟、能失败的实际命名命令。

| 建议 AC | 要求与观察 | 应怎样失败 / 独立性 |
|---|---|---|
| AC-1 参考依据与忠实边界 | 检视真实照片/图纸及来源清单，特征逐项映射到模型；有依据的尺寸附可复取来源，未知部分明确。 | 失联或错误对象的照片、捏造尺度、关键可见结构遗漏，应 FAIL；文件/JSON 格式通过不代表内容正确。事实需要判断时由冷席看实际资料。 |
| AC-2 Three.js 页面可用 | 从交付 URL 实际加载页面、确认真实 Three.js 场景及 WebGL 渲染、静态资源响应和浏览器控制台；验证承诺的旋转/缩放/机位操作、相机不会被墙或遮挡锁住。 | 资源 404、JS 例外、WebGL 不可用、空白、被阻挡机位或失效交互会失败。构建成功单独记录。 |
| AC-3 视觉质量底线 | 对固定所有机位截图，由全新冷席对真实参考比对建筑身份、整体体量/封闭外壳、结构与开口、材料/光照、细节及可见面完整性。 | 完整但不像、贴图漂亮但缺体量、背面漏壳、天空漏入或任何机位不能判读都不能 PASS。不能用像素非空、面数或单视角替代。 |
| AC-4 可复跑自验 | 实际捕获当前页面的各机位、环境/相机/视口与 console/network 原始结果；证据写入 `.goal/evidence/`，校验截图路径与哈希，复跑由原 gate 执行。 | 改截图、遗漏/重复机位、来源不明、共享错误常量或用旧截图冒充当前页面应被识别。技术重复执行只证明执行覆盖，视觉真值另由冷席建立。 |
| AC-5 交付访问范围 | 明确最终 URL 是本机临时 HTTP 还是承诺的外部地址，对该地址做实际浏览器访问并证明生命周期。原文“可访问”本身没有明确公网，不能凭它声称已公网发布。 | 实际不可达、服务已停止、URL 指向旧构建均失败。若公网/外部部署成为既定交付，则 external 真实测量与树内检查并存，rc=75 只表示待结算。 |

**可信自验和终验如何成立。**

先证明判读仪器：known-good 应代表同一建筑与约定视图的真实质量依据（可追溯的多视图参考板或已经独立确认的参考产物）；known-bad 必须是“看起来合理但存在本任务关键缺陷”的近似失败，例如材料完整而侧翼缺失、空间结构错或承诺机位被挡。空白图只能校准渲染故障，不能校准建筑忠实度。两份为内容不同的普通项目内文件，戳前冻结字节。全新冷席先观察二者，good=PASS 且 bad=FAIL；每条都绑定其实际路径与完整 SHA-256，并与当前迭代/内容指纹匹配。

视觉冷席只收原始请求、逐字 AC/rubric、真实参考、校准锚点和实际截图路径，不收生产者解释或建议判词。它必须能看图；若不能查看证据或建立参考依据则 UNVERIFIABLE。要求返回实际 JSON，含 version=1、每个声明机位恰好一次的 artifact/sha256、findings、summary；控制器原样保存 quality-review.json，把视觉 AC 判词绑定到这份 JSON 的实际哈希。所有声明视图要用不同图像证据；任何未解决的目标缺陷或单视角 FAIL/UNVERIFIABLE 都不能靠 overall PASS 或空 findings 掩盖。视觉底线必须 PASS，普通 UNVERIFIABLE 配额不豁免它。

发现必须进入真实欠项并修复；写成“限制”不等于免除。保持生产者、校准/质量判读和最后原门控的职责独立。终验前还要对同一产物做实际反例复审，检查代理指标、fixture/报告不一致和文件域违规；adversarial clear 只能来自真实无未决发现的复审。forge 的完整探测和批评证据也必须齐全，重复相同输入只能算稳定性，不能充新覆盖。

最后取新 context，按 submissions.close.template 填真实判断，执行其 command，让原 close/audit/Gate 复跑。只有当前终验原回执退出码为 0 且 completion_verified=true 才能交付为完成；工作计划勾选、worker 报告、哈希一致、历史 GO 或本诊断均不能替代。地图过期应重新取图，并重新核对业务判断；不能机械刷新旧 PASS。

**本次未做的部分。** 未读/写仓库或全局配置作为任务操作；未安装依赖，未创建目标/预算/`.goal`，未启动宿主、模型、API、HTTP 服务或浏览器，未检索网络、取得照片、生成网站、派发角色、标定视觉锚点、调用原业务 Gate 或做公网结算。目录快照只证明安装包未变；不声称独立审计了整个机器的外部状态。本次仅在指定 forward-check 输出目录写入诊断、快照与配置预览。
