import {getSkillDirCommands} from "/Users/m/repo/workspace/claude-code-haha/src/skills/loadSkillsDir.ts";
import {getAgentDefinitionsWithOverrides} from "/Users/m/repo/workspace/claude-code-haha/src/tools/AgentTool/loadAgentsDir.ts";
const skills=[]; for(const s of await getSkillDirCommands(process.cwd())) if(["goal-loop","contract-forge"].includes(s.name)) skills.push({name:s.name,prompt:await s.getPromptForCommand("install-probe",{})});
const a=await getAgentDefinitionsWithOverrides(process.cwd());
console.log(JSON.stringify({skills,agents:a.activeAgents.filter(a=>a.agentType.startsWith("goal-")).map(a=>({name:a.agentType,tools:a.tools,model:a.model,prompt:a.getSystemPrompt()})),failedFiles:a.failedFiles}));
process.exit(0);
